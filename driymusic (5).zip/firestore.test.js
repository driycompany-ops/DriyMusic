const { initializeTestEnvironment, assertFails, assertSucceeds } = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

const PROJECT_ID = "demo-no-project";
let testEnv;

before(async () => {
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules: fs.readFileSync("firestore.rules", "utf8"),
      host: "127.0.0.1",
      port: 8085
    }
  });
});

beforeEach(async () => {
  await testEnv.clearFirestore();
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

test("Non-admin cannot create activation codes", async () => {
  const normalUserContext = testEnv.authenticatedContext("user_123", { email: "user@example.com" });
  const db = normalUserContext.firestore();

  const codeData = {
    code: "DRIY-AAAA-BBBB",
    durationDays: 28,
    months: 1,
    pricePaid: 5.0,
    createdAt: Date.now(),
    isUsed: false,
    clientName: "Juan",
    clientPhone: "987654321",
    note: "Voucher"
  };

  await assertFails(db.collection("driystream_activation_codes").doc("DRIY-AAAA-BBBB").set(codeData));
});

test("Admin with driycompany@gmail.com CAN create activation codes", async () => {
  const adminContext = testEnv.authenticatedContext("admin_uid", { email: "driycompany@gmail.com", email_verified: true });
  const db = adminContext.firestore();

  const codeData = {
    code: "DRIY-AAAA-BBBB",
    durationDays: 28,
    months: 1,
    pricePaid: 5.0,
    createdAt: Date.now(),
    isUsed: false,
    clientName: "Juan",
    clientPhone: "987654321",
    note: "Voucher"
  };

  await assertSucceeds(db.collection("driystream_activation_codes").doc("DRIY-AAAA-BBBB").set(codeData));
});

test("Unauthenticated requests with arbitrary signature are REJECTED", async () => {
  const unauthContext = testEnv.unauthenticatedContext();
  const db = unauthContext.firestore();

  const codeData = {
    code: "DRIY-1111-2222",
    durationDays: 56,
    months: 2,
    pricePaid: 10.0,
    createdAt: Date.now(),
    isUsed: false,
    clientName: "Maria",
    clientPhone: "987654321",
    note: "Voucher",
    adminSignature: "DriyAdmin2026Secure"
  };

  await assertFails(db.collection("driystream_activation_codes").doc("DRIY-1111-2222").set(codeData));
});

test("Normal users CANNOT list all activation codes (anti-scraping)", async () => {
  // Pre-seed a code via admin
  await testEnv.withSecurityRulesDisabled(async (context) => {
    await context.firestore().collection("driystream_activation_codes").doc("DRIY-AAAA-BBBB").set({
      code: "DRIY-AAAA-BBBB",
      durationDays: 28,
      months: 1,
      pricePaid: 5.0,
      createdAt: Date.now(),
      isUsed: false
    });
  });

  const normalUserContext = testEnv.authenticatedContext("user_123");
  const db = normalUserContext.firestore();

  await assertFails(db.collection("driystream_activation_codes").get());
});

test("Admin CAN list all activation codes", async () => {
  const adminContext = testEnv.authenticatedContext("admin_uid", { email: "driycompany@gmail.com", email_verified: true });
  const db = adminContext.firestore();

  await assertSucceeds(db.collection("driystream_activation_codes").get());
});

test("Normal user CAN get a single code by its exact ID to verify it", async () => {
  await testEnv.withSecurityRulesDisabled(async (context) => {
    await context.firestore().collection("driystream_activation_codes").doc("DRIY-AAAA-BBBB").set({
      code: "DRIY-AAAA-BBBB",
      durationDays: 28,
      months: 1,
      pricePaid: 5.0,
      createdAt: Date.now(),
      isUsed: false
    });
  });

  const unauthContext = testEnv.unauthenticatedContext();
  const db = unauthContext.firestore();

  await assertSucceeds(db.collection("driystream_activation_codes").doc("DRIY-AAAA-BBBB").get());
});

test("Normal user CAN redeem an unused activation code", async () => {
  const now = Date.now();
  await testEnv.withSecurityRulesDisabled(async (context) => {
    await context.firestore().collection("driystream_activation_codes").doc("DRIY-AAAA-BBBB").set({
      code: "DRIY-AAAA-BBBB",
      durationDays: 28,
      months: 1,
      pricePaid: 5.0,
      createdAt: now,
      isUsed: false
    });
  });

  const normalContext = testEnv.authenticatedContext("user_123");
  const db = normalContext.firestore();

  await assertSucceeds(
    db.collection("driystream_activation_codes").doc("DRIY-AAAA-BBBB").update({
      isUsed: true,
      usedByUserId: "carlos123",
      usedByUsername: "Carlos",
      usedAt: now + 1000
    })
  );
});

test("Normal user CANNOT double-redeem an already used activation code", async () => {
  const now = Date.now();
  await testEnv.withSecurityRulesDisabled(async (context) => {
    await context.firestore().collection("driystream_activation_codes").doc("DRIY-USED-CODE").set({
      code: "DRIY-USED-CODE",
      durationDays: 28,
      months: 1,
      pricePaid: 5.0,
      createdAt: now,
      isUsed: true,
      usedByUserId: "carlos123",
      usedByUsername: "Carlos",
      usedAt: now
    });
  });

  const secondUserContext = testEnv.authenticatedContext("hacker_456");
  const db = secondUserContext.firestore();

  await assertFails(
    db.collection("driystream_activation_codes").doc("DRIY-USED-CODE").update({
      isUsed: true,
      usedByUserId: "hacker_456",
      usedByUsername: "Hacker",
      usedAt: now + 5000
    })
  );
});

test("Normal user CANNOT modify immutable durationDays or pricePaid when redeeming", async () => {
  const now = Date.now();
  await testEnv.withSecurityRulesDisabled(async (context) => {
    await context.firestore().collection("driystream_activation_codes").doc("DRIY-AAAA-BBBB").set({
      code: "DRIY-AAAA-BBBB",
      durationDays: 28,
      months: 1,
      pricePaid: 5.0,
      createdAt: now,
      isUsed: false
    });
  });

  const normalContext = testEnv.authenticatedContext("user_123");
  const db = normalContext.firestore();

  await assertFails(
    db.collection("driystream_activation_codes").doc("DRIY-AAAA-BBBB").update({
      isUsed: true,
      usedByUserId: "user_123",
      usedByUsername: "User",
      usedAt: now + 1000,
      durationDays: 365 // illegal modification attempt
    })
  );
});

test("Normal user CANNOT delete activation codes", async () => {
  await testEnv.withSecurityRulesDisabled(async (context) => {
    await context.firestore().collection("driystream_activation_codes").doc("DRIY-AAAA-BBBB").set({
      code: "DRIY-AAAA-BBBB",
      durationDays: 28,
      months: 1,
      pricePaid: 5.0,
      createdAt: Date.now(),
      isUsed: false
    });
  });

  const normalContext = testEnv.authenticatedContext("user_123");
  const db = normalContext.firestore();

  await assertFails(db.collection("driystream_activation_codes").doc("DRIY-AAAA-BBBB").delete());
});

test("Normal user or unauthenticated client CANNOT read or write driystream_verification_codes directly", async () => {
  const normalContext = testEnv.authenticatedContext("user_123");
  const db = normalContext.firestore();

  // Write attempt must fail
  await assertFails(
    db.collection("driystream_verification_codes").doc("51987654321").set({
      phone: "51987654321",
      codeHash: "fakehash",
      verified: true
    })
  );

  // Read attempt must fail
  await assertFails(db.collection("driystream_verification_codes").doc("51987654321").get());
});

