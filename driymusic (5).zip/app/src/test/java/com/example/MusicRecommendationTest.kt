package com.example

import com.example.data.model.SongEntity
import com.example.service.MusicUniverse
import com.example.service.SmartMoodEngine
import com.example.service.YouTubeService
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class MusicRecommendationTest {

    private fun createSong(
        id: String,
        title: String,
        artist: String,
        genre: String = "Urbano Latino",
        durationSeconds: Int = 200
    ) = SongEntity(
        id = id,
        title = title,
        artist = artist,
        genre = genre,
        album = "Album",
        coverUrl = "https://example.com/cover.jpg",
        audioUrl = "https://example.com/audio.mp3",
        durationSeconds = durationSeconds
    )

    @Test
    fun testIsIndividualSongRejectsLongVideosOver5Minutes() {
        // Individual song <= 5 minutes (300 seconds)
        assertTrue(YouTubeService.isIndividualSong("Café", 210))
        assertTrue(YouTubeService.isIndividualSong("Bésame Sin Sentir", 225))
        assertTrue(YouTubeService.isIndividualSong("Dembow", 200))
        assertTrue(YouTubeService.isIndividualSong("A Mí", 299))

        // Exceeds 5 minutes (> 300 seconds)
        assertFalse("301 seconds exceeds 5 minutes", YouTubeService.isIndividualSong("Canción Larga", 301))
        assertFalse("14-minute session should be rejected", YouTubeService.isIndividualSong("Micro TDH Live", 865))
        assertFalse("15-minute mix should be rejected", YouTubeService.isIndividualSong("Grandes Temas", 900))
        assertFalse("1-hour compilation should be rejected", YouTubeService.isIndividualSong("Éxitos", 3600))
    }

    @Test
    fun testIsIndividualSongRejectsMixesSessionsAndCompilations() {
        // Forbidden mix keywords
        assertFalse("Mix rejected", YouTubeService.isIndividualSong("Micro TDH Mix 2024", 210))
        assertFalse("Megamix rejected", YouTubeService.isIndividualSong("Urbano Megamix", 180))
        assertFalse("DJ mix rejected", YouTubeService.isIndividualSong("DJ Mix Verano", 250))
        assertFalse("Session rejected", YouTubeService.isIndividualSong("Micro TDH - Acoustic Session", 240))
        assertFalse("Sesión rejected", YouTubeService.isIndividualSong("Sesión en Vivo Micro TDH", 230))
        assertFalse("Compilación rejected", YouTubeService.isIndividualSong("Compilación de Éxitos", 220))
        assertFalse("Recopilación rejected", YouTubeService.isIndividualSong("Recopilación Trap", 210))
        assertFalse("Enganchado rejected", YouTubeService.isIndividualSong("Enganchado Reggaetón", 240))
        assertFalse("Full album rejected", YouTubeService.isIndividualSong("Micro TDH Full Album", 250))
        assertFalse("Álbum completo rejected", YouTubeService.isIndividualSong("Álbum Completo", 250))
        assertFalse("Grandes éxitos rejected", YouTubeService.isIndividualSong("Grandes Éxitos Micro TDH", 210))
        assertFalse("Top canciones rejected", YouTubeService.isIndividualSong("Top Canciones Micro TDH", 210))
        assertFalse("15 minutos rejected", YouTubeService.isIndividualSong("Micro TDH 15 minutos", 240))
        assertFalse("Too short snippet rejected", YouTubeService.isIndividualSong("Intro", 20))
    }

    @Test
    fun testMicroTdhRecommendationsBuildCleanQueriesWithoutMix() {
        val microTdhSong = createSong(
            id = "micro_1",
            title = "Café",
            artist = "Micro TDH",
            genre = "Urbano Latino",
            durationSeconds = 210
        )

        // Musical universe detection
        assertEquals(MusicUniverse.URBANO_LATINO, SmartMoodEngine.detectMusicUniverse(microTdhSong))

        // Queries generated for Spotify-style autoplay
        val queries = SmartMoodEngine.buildSearchQueriesForSong(microTdhSong)
        assertTrue("Queries must not be empty", queries.isNotEmpty())

        for (q in queries) {
            val lower = q.lowercase()
            assertFalse("Autoplay query must not contain 'mix': $q", lower.contains("mix"))
            assertFalse("Autoplay query must not contain 'session': $q", lower.contains("session"))
            assertFalse("Autoplay query must not contain 'sesion': $q", lower.contains("sesion"))
            assertFalse("Autoplay query must not contain 'radio': $q", lower.contains("radio"))
        }

        // Must target Micro TDH official singles and related urban artists
        assertTrue("Should include same artist query", queries.any { it.contains("Micro TDH", ignoreCase = true) })
    }

    @Test
    fun testFindLocalCatalogRecommendationsExcludesLongTracks() {
        val currentSong = createSong(
            id = "c1",
            title = "Bésame Sin Sentir",
            artist = "Micro TDH",
            durationSeconds = 200
        )

        val localCatalog = listOf(
            createSong("ok1", "Café", "Micro TDH", durationSeconds = 210),
            createSong("ok2", "Dembow", "Danny Ocean", durationSeconds = 220),
            createSong("long1", "Micro TDH 15 min Set", "Micro TDH", durationSeconds = 890),
            createSong("mix1", "Micro TDH Mix", "Micro TDH", durationSeconds = 200),
            createSong("rock1", "Do I Wanna Know", "Arctic Monkeys", genre = "Rock", durationSeconds = 240)
        )

        val recs = SmartMoodEngine.findLocalCatalogRecommendations(currentSong, localCatalog, emptySet())

        assertTrue("Recommendations must be found", recs.isNotEmpty())
        for (r in recs) {
            assertTrue("Duration must be <= 300 seconds", r.durationSeconds <= 300)
            assertFalse("Must not be a mix or set", SmartMoodEngine.isMixOrCompilationTitle(r.title))
            assertEquals("Must belong to URBANO_LATINO universe", MusicUniverse.URBANO_LATINO, SmartMoodEngine.detectMusicUniverse(r))
        }
    }
}
