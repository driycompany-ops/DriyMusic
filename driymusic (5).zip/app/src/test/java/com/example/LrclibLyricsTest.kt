package com.example

import com.example.data.model.LyricLine
import com.example.data.model.LyricsData
import com.example.service.LrclibLyricsService
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class LrclibLyricsTest {

    @Test
    fun testCleanTrackTitle_removesYouTubeNoise() {
        val raw1 = "Bad Bunny - Ojitos Lindos (Official Video)"
        val cleaned1 = LrclibLyricsService.cleanTrackTitle(raw1)
        assertFalse(cleaned1.contains("Official", ignoreCase = true))
        assertFalse(cleaned1.contains("Video", ignoreCase = true))

        val raw2 = "KAROL G, Shakira - TQG (Audio Oficial)"
        val cleaned2 = LrclibLyricsService.cleanTrackTitle(raw2)
        assertFalse(cleaned2.contains("Audio Oficial", ignoreCase = true))

        val raw3 = "Feid ft. Young Miko - Classy 101 [Lyric Video]"
        val cleaned3 = LrclibLyricsService.cleanTrackTitle(raw3)
        assertFalse(cleaned3.contains("Lyric Video", ignoreCase = true))
        assertFalse(cleaned3.contains("ft.", ignoreCase = true))

        val raw4 = "Quevedo - Columbia | Video Oficial"
        val cleaned4 = LrclibLyricsService.cleanTrackTitle(raw4)
        assertEquals("Quevedo - Columbia", cleaned4)
    }

    @Test
    fun testCleanArtistName_removesTopicAndVevo() {
        assertEquals("Bad Bunny", LrclibLyricsService.cleanArtistName("Bad Bunny - Topic"))
        assertEquals("KarolG", LrclibLyricsService.cleanArtistName("KarolGVEVO"))
        assertEquals("Coldplay", LrclibLyricsService.cleanArtistName("Coldplay Official"))
        assertEquals("Dua Lipa", LrclibLyricsService.cleanArtistName("Dua Lipa Channel"))
    }

    @Test
    fun testGenerateCandidatePairs_extractsArtistAndTrack() {
        val pairs = LrclibLyricsService.generateCandidatePairs(
            rawTitle = "Bad Bunny - Monaco (Official Video)",
            rawArtist = "Bad Bunny"
        )
        // Should have "Monaco" as trackName and "Bad Bunny" as artistName
        assertTrue(pairs.any { it.trackName.equals("Monaco", ignoreCase = true) && it.artistName.equals("Bad Bunny", ignoreCase = true) })

        val pairs2 = LrclibLyricsService.generateCandidatePairs(
            rawTitle = "Feid, Young Miko - Classy 101",
            rawArtist = "Feid"
        )
        assertTrue(pairs2.any { it.trackName.equals("Classy 101", ignoreCase = true) })
    }

    @Test
    fun testParseLrcString_handlesTimestampsAndOffset() {
        val lrc = """
            [ti: Test Song]
            [ar: Test Artist]
            [offset: 500]
            [00:05.00] Primera linea
            [00:10.50] Segunda linea
            [00:15.00][00:25.00] Coro repetido
        """.trimIndent()

        val lines = LrclibLyricsService.parseLrcString(lrc)
        // 4 lines total (first line, second line, and two for the repeated chorus)
        assertEquals(4, lines.size)

        // With offset +500ms, 00:05.00 (5000ms) becomes 5500ms
        assertEquals(5500L, lines[0].timeMs)
        assertEquals("Primera linea", lines[0].text)

        assertEquals(11000L, lines[1].timeMs)
        assertEquals("Segunda linea", lines[1].text)

        // Repeated chorus
        assertEquals(15500L, lines[2].timeMs)
        assertEquals("Coro repetido", lines[2].text)

        assertEquals(25500L, lines[3].timeMs)
        assertEquals("Coro repetido", lines[3].text)
    }

    @Test
    fun testFindBestLyricsMatch_prefersMatchingDurationAndSynced() {
        // Target: 210s duration
        val targetDuration = 210

        // Candidate A: synced lyrics, but live version (duration 310s, 100s difference!)
        val liveVersion = LyricsData(
            trackName = "Monaco",
            artistName = "Bad Bunny",
            durationSeconds = 310,
            syncedLyrics = listOf(LyricLine(1000, "Hola")),
            hasSync = true
        )

        // Candidate B: studio version (duration 212s, 2s difference!)
        val studioVersion = LyricsData(
            trackName = "Monaco",
            artistName = "Bad Bunny",
            durationSeconds = 212,
            syncedLyrics = listOf(LyricLine(1000, "Díganme")),
            hasSync = true
        )

        val best = LrclibLyricsService.findBestLyricsMatch(
            candidates = listOf(liveVersion, studioVersion),
            targetTitle = "Monaco",
            targetArtist = "Bad Bunny",
            targetDurationSec = targetDuration
        )

        assertNotNull(best)
        assertEquals(212, best?.durationSeconds)
        assertEquals("Díganme", best?.syncedLyrics?.first()?.text)
    }
}
