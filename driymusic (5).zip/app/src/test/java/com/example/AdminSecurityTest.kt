package com.example

import com.example.data.model.UserEntity
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AdminSecurityTest {

    @Test
    fun testImpostorCannotGainAdminByNameOrSurname() {
        val impostor = UserEntity(
            id = "impostor_user_1",
            displayName = "driy company",
            firstName = "driy",
            lastName = "company",
            username = "random_user_99",
            phoneNumber = "999888777"
        )
        assertFalse("User named 'driy company' must NOT become Master Admin", impostor.isMasterAdmin)
        assertFalse("User named 'driy company' must NOT have free active subscription", impostor.isSubscriptionActive)
    }

    @Test
    fun testImpostorCannotGainAdminByAdminPhoneOrEmail() {
        val impostor = UserEntity(
            id = "impostor_user_2",
            displayName = "Juan Perez",
            firstName = "Juan",
            lastName = "Perez",
            username = "juanperez",
            phoneNumber = "928598496",
            email = "driycompany@gmail.com"
        )
        assertFalse("User spoofing admin phone or email must NOT become Master Admin", impostor.isMasterAdmin)
        assertFalse("User spoofing admin phone must NOT have active subscription", impostor.isSubscriptionActive)
    }

    @Test
    fun testLegitimateAdminIsMasterAdmin() {
        val admin = UserEntity(
            id = "driyadmincompany",
            displayName = "driy company",
            firstName = "driy",
            lastName = "company",
            username = "DriyAdmincompany",
            phoneNumber = "928598496"
        )
        assertTrue("Legitimate admin account must be Master Admin", admin.isMasterAdmin)
        assertTrue("Legitimate admin must have active subscription", admin.isSubscriptionActive)
    }
}
