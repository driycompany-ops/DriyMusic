package com.example

import com.example.data.model.JamSessionState
import com.example.data.model.SongEntity
import com.example.data.model.UserEntity
import com.example.service.DriyJamManager
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.After
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class DriyJamManagerTest {

    @Before
    fun setup() {
        DriyJamManager.leaveSession()
    }

    @After
    fun tearDown() {
        DriyJamManager.leaveSession()
    }

    @Test
    fun testCreateJamSessionSetsHostingStateWithQr() {
        val user = UserEntity(
            id = "user_test_1",
            displayName = "DJ Test",
            username = "djtest"
        )
        val song = SongEntity(
            id = "song_1",
            title = "Canción de Prueba",
            artist = "Artista Driy",
            genre = "Urbano",
            album = "Driy Album",
            audioUrl = "https://example.com/audio.mp3",
            coverUrl = "https://example.com/cover.jpg",
            durationSeconds = 180
        )

        DriyJamManager.createSession(user, song)

        val state = DriyJamManager.jamState.value
        assertTrue("State should be Hosting", state is JamSessionState.Hosting)
        val hosting = state as JamSessionState.Hosting
        assertTrue(hosting.session.code.startsWith("JAM-"))
        assertEquals("DJ Test", hosting.session.hostName)
        assertEquals("Canción de Prueba", hosting.session.currentSongTitle)
        assertNotNull("QR Bitmap should be generated", hosting.qrBitmap)
        assertEquals(1, hosting.session.participants.size)
        assertTrue(hosting.session.participants[0].isHost)
    }

    @Test
    fun testJoinJamSessionWithCode() = kotlinx.coroutines.runBlocking {
        val listener = UserEntity(
            id = "listener_1",
            displayName = "Amigo Oyente",
            username = "oyente"
        )

        val result = DriyJamManager.joinSession("JAM-9988", listener)
        assertTrue(result.isSuccess)

        val state = DriyJamManager.jamState.value
        assertTrue("State should be Joined", state is JamSessionState.Joined)
        val joined = state as JamSessionState.Joined
        assertEquals("JAM-9988", joined.session.code)
        assertTrue(joined.session.participants.any { it.name == "Amigo Oyente" })
        DriyJamManager.leaveSession()
    }

    @Test
    fun testGenerateQrBitmapProducesValidBitmap() {
        val bitmap = DriyJamManager.generateQrBitmap("driy://jam/JAM-1234", 256)
        assertNotNull(bitmap)
        assertEquals(256, bitmap?.width)
        assertEquals(256, bitmap?.height)
    }

    @Test
    fun testGetSessionKeyExtraction() {
        assertEquals("4821", DriyJamManager.getSessionKey("4821"))
        assertEquals("4821", DriyJamManager.getSessionKey("JAM-4821"))
        assertEquals("4821", DriyJamManager.getSessionKey("jam-4821"))
        assertEquals("4821", DriyJamManager.getSessionKey("jam 4821"))
        assertEquals("4821", DriyJamManager.getSessionKey("JAM4821"))
        assertEquals("4821", DriyJamManager.getSessionKey("driy://jam/JAM-4821"))
        assertEquals("4821", DriyJamManager.getSessionKey("Código: 4821"))
    }

    @Test
    fun testCrossUserJoinSession() = kotlinx.coroutines.runBlocking {
        val host = UserEntity(id = "host_1", displayName = "Host User")
        val song = SongEntity(
            id = "song_host",
            title = "Canción Compartida",
            artist = "Artista Driy",
            genre = "Pop",
            album = "Álbum",
            audioUrl = "https://example.com/audio.mp3",
            coverUrl = "https://example.com/cover.jpg",
            durationSeconds = 200
        )
        DriyJamManager.createSession(host, song)
        val hostState = DriyJamManager.jamState.value as JamSessionState.Hosting
        val code = hostState.session.code

        val listener = UserEntity(id = "listener_2", displayName = "Amigo Invitado")
        val joinResult = DriyJamManager.joinSession(code, listener)
        assertTrue(joinResult.isSuccess)
        val joinedSession = joinResult.getOrNull()
        assertNotNull(joinedSession)
        assertEquals(code, joinedSession?.code)
        assertTrue(joinedSession?.participants?.any { it.name == "Amigo Invitado" } == true)
        DriyJamManager.leaveSession()
    }
}
