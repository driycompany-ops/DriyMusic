package com.example

import com.example.util.PasswordHasher
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PasswordHasherTest {

    @Test
    fun testHashAndVerifySuccess() {
        val rawPassword = "SuperSecretPassword123!"
        val hash = PasswordHasher.hashPassword(rawPassword)

        assertTrue("Hash should start with prefix", PasswordHasher.isHashed(hash))
        assertTrue("Verification should succeed with correct password", PasswordHasher.verifyPassword(rawPassword, hash))
        assertFalse("Verification should fail with wrong password", PasswordHasher.verifyPassword("WrongPassword!", hash))
    }

    @Test
    fun testUniqueSaltsProduceDifferentHashes() {
        val rawPassword = "SamePassword456"
        val hash1 = PasswordHasher.hashPassword(rawPassword)
        val hash2 = PasswordHasher.hashPassword(rawPassword)

        assertNotEquals("Two hashes for the same password must have distinct salts", hash1, hash2)
        assertTrue(PasswordHasher.verifyPassword(rawPassword, hash1))
        assertTrue(PasswordHasher.verifyPassword(rawPassword, hash2))
    }

    @Test
    fun testLegacyPlainTextBackwardCompatibility() {
        val legacyPassword = "MyOldPlainTextPassword"

        assertFalse("Plaintext password should not be recognized as hashed", PasswordHasher.isHashed(legacyPassword))
        assertTrue("Verification must succeed for legacy plaintext password", PasswordHasher.verifyPassword(legacyPassword, legacyPassword))
        assertFalse("Verification must fail when guessing wrong against legacy password", PasswordHasher.verifyPassword("IncorrectPassword", legacyPassword))
    }

    @Test
    fun testEmptyOrBlankPasswords() {
        assertFalse(PasswordHasher.verifyPassword("", ""))
        assertFalse(PasswordHasher.verifyPassword("abc", ""))
        assertFalse(PasswordHasher.verifyPassword("", "pbkdf_v1$123$456"))
    }
}
