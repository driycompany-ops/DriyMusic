package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.AssistantAnimationMode
import com.example.data.model.VirtualAssistantCatalog
import com.example.service.VirtualAssistantManager
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class VirtualAssistantTest {

    @Before
    fun setup() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        VirtualAssistantManager.init(context)
        VirtualAssistantManager.selectAvatar("jorge_luna")
        VirtualAssistantManager.setEnabled(false)
    }

    @Test
    fun testVirtualAssistantIsDisabledByDefault() {
        val state = VirtualAssistantManager.state.value
        assertFalse("Virtual Assistant must be disabled by default", state.isEnabled)
    }

    @Test
    fun testAvatarIsStandingByDefault() {
        VirtualAssistantManager.setEnabled(true)
        val state = VirtualAssistantManager.state.value
        assertEquals("Avatar must be standing upright by default", AssistantAnimationMode.STANDING, state.currentAnimationMode)
    }

    @Test
    fun testIgnoreCommandWithoutWakeWord() {
        VirtualAssistantManager.setEnabled(true)
        VirtualAssistantManager.setCustomAvatarName("Jorge")

        // Stray voice or background speech without saying the avatar name
        val handled = VirtualAssistantManager.processCommand("reproduce musica")
        assertFalse("Command without wake word must be ignored", handled)

        val handledPause = VirtualAssistantManager.processCommand("para la musica")
        assertFalse("Pause without wake word must be ignored", handledPause)
    }

    @Test
    fun testVirtualAssistantActivationAndAvatarCatalog() {
        VirtualAssistantManager.setEnabled(true)
        val state = VirtualAssistantManager.state.value
        assertTrue("Assistant should be enabled", state.isEnabled)

        val avatars = VirtualAssistantCatalog.avatars
        assertTrue("Catalog should contain avatars", avatars.isNotEmpty())
        assertEquals("jorge_luna", avatars.first().id)
        assertEquals("Jorge Luna", avatars.first().name)
    }

    @Test
    fun testChangeAvatarCustomNameAndUserCallingTitle() {
        VirtualAssistantManager.setEnabled(true)
        VirtualAssistantManager.setCustomAvatarName("Jorgito")
        VirtualAssistantManager.setUserCallingTitle("mi rey")

        val state = VirtualAssistantManager.state.value
        assertEquals("Jorgito", state.customAvatarName)
        assertEquals("mi rey", state.userCallingTitle)
    }

    @Test
    fun testProcessReproduceMusicaCommandChangesAnimation() {
        VirtualAssistantManager.setEnabled(true)
        VirtualAssistantManager.setCustomAvatarName("Jorge")
        VirtualAssistantManager.setUserCallingTitle("mi rey")

        val handled = VirtualAssistantManager.processCommand("Jorge reproduce música", isDirectChip = true)
        assertTrue("Command should be recognized", handled)

        val state = VirtualAssistantManager.state.value
        assertEquals(AssistantAnimationMode.CHANGING_MUSIC, state.currentAnimationMode)
        assertNotNull(state.thoughtText)
        assertTrue(state.thoughtText!!.contains("mi rey"))
    }

    @Test
    fun testSpecificSongAndArtistSearchCommand() {
        VirtualAssistantManager.setEnabled(true)
        VirtualAssistantManager.setCustomAvatarName("Jorgito")
        VirtualAssistantManager.setUserCallingTitle("mi rey")

        val handled = VirtualAssistantManager.processCommand("Jorgito reproduce Soy Peor de Bad Bunny", isDirectChip = true)
        assertTrue("Specific song search command should be recognized", handled)

        val state = VirtualAssistantManager.state.value
        assertEquals(AssistantAnimationMode.CHANGING_MUSIC, state.currentAnimationMode)
        assertNotNull(state.thoughtText)
        assertTrue(state.thoughtText!!.contains("Soy Peor") || state.thoughtText!!.contains("mi rey"))
    }

    @Test
    fun testProcessDameTuBendicionCommandShowsBlessingCard() {
        VirtualAssistantManager.setEnabled(true)
        VirtualAssistantManager.setCustomAvatarName("Jorgito")
        VirtualAssistantManager.setUserCallingTitle("mi rey")

        val handled = VirtualAssistantManager.processCommand("jorgito dame tu bendición", isDirectChip = true)
        assertTrue("Blessing command should be recognized", handled)

        val state = VirtualAssistantManager.state.value
        assertEquals(AssistantAnimationMode.BLESSING, state.currentAnimationMode)
        assertNotNull(state.thoughtText)
        assertTrue(state.thoughtText!!.contains("bendición") || state.thoughtText!!.contains("Bendecido"))
    }

    @Test
    fun testProcessPausaCommandChangesAnimation() {
        VirtualAssistantManager.setEnabled(true)
        VirtualAssistantManager.setCustomAvatarName("Jorge")
        VirtualAssistantManager.setUserCallingTitle("patrón")

        val handled = VirtualAssistantManager.processCommand("jorge para la música", isDirectChip = true)
        assertTrue("Pause command should be recognized", handled)

        val state = VirtualAssistantManager.state.value
        assertEquals(AssistantAnimationMode.CHANGING_MUSIC, state.currentAnimationMode)
        assertTrue(state.thoughtText!!.contains("patrón"))
    }

    @Test
    fun testBuscaAndPonCommandsTriggerSearch() {
        VirtualAssistantManager.setEnabled(true)
        VirtualAssistantManager.setCustomAvatarName("Jorge")
        VirtualAssistantManager.setUserCallingTitle("mi rey")

        val handledBusca = VirtualAssistantManager.processCommand("jorge busca bohemian rhapsody", isDirectChip = true)
        assertTrue("Busca command should be recognized", handledBusca)
        assertEquals(AssistantAnimationMode.CHANGING_MUSIC, VirtualAssistantManager.state.value.currentAnimationMode)

        val handledPon = VirtualAssistantManager.processCommand("jorge pon despacito", isDirectChip = true)
        assertTrue("Pon command should be recognized", handledPon)
        assertEquals(AssistantAnimationMode.CHANGING_MUSIC, VirtualAssistantManager.state.value.currentAnimationMode)
    }

    @Test
    fun testAvanzaAndRetrocedeDoNotSearchForSong() {
        VirtualAssistantManager.setEnabled(true)
        VirtualAssistantManager.setCustomAvatarName("Jorge")
        VirtualAssistantManager.setUserCallingTitle("mi rey")

        val handledAvanza = VirtualAssistantManager.processCommand("jorge avanza", isDirectChip = true)
        assertTrue("Avanza command should be recognized", handledAvanza)
        assertTrue(VirtualAssistantManager.state.value.thoughtText!!.contains("siguiente canción"))

        val handledRetrocede = VirtualAssistantManager.processCommand("jorge retrocede", isDirectChip = true)
        assertTrue("Retrocede command should be recognized", handledRetrocede)
        assertTrue(VirtualAssistantManager.state.value.thoughtText!!.contains("anterior"))
    }

    @Test
    fun testBlessingVariationsOrderInversion() {
        VirtualAssistantManager.setEnabled(true)
        VirtualAssistantManager.setCustomAvatarName("Jorge")
        VirtualAssistantManager.setUserCallingTitle("mi rey")

        // Inverted: "dame tu bedi jorge"
        val handled1 = VirtualAssistantManager.processCommand("dame tu bedi jorge", isDirectChip = true)
        assertTrue("Blessing variation 'bedi' should be recognized", handled1)
        assertEquals(AssistantAnimationMode.BLESSING, VirtualAssistantManager.state.value.currentAnimationMode)

        // Inverted: "tu bedicion dame jorge"
        val handled2 = VirtualAssistantManager.processCommand("tu bedicion dame jorge", isDirectChip = true)
        assertTrue("Blessing variation 'tu bedicion dame' should be recognized", handled2)
        assertEquals(AssistantAnimationMode.BLESSING, VirtualAssistantManager.state.value.currentAnimationMode)
    }

    @Test
    fun testJungkookCatalogAudioMappings() {
        val jungkook = VirtualAssistantCatalog.getById("jungkook")
        assertTrue("Jungkook must have voice audio enabled", jungkook.hasVoiceAudio)
        assertNotNull("Greeting audio must not be null", jungkook.greetingAudioRes)
        assertNotNull("Love audio must not be null", jungkook.loveAudioRes)
        assertNotNull("Change song audio must not be null", jungkook.changeSongAudioRes)
        assertNotNull("Resume audio must not be null", jungkook.resumeSongAudioRes)
        assertNotNull("Pause audio must not be null", jungkook.pauseSongAudioRes)
        assertNotNull("Previous song audio must not be null", jungkook.previousSongAudioRes)
        assertNotNull("Mute audio must not be null", jungkook.muteAudioRes)
        assertNotNull("Volume 50 audio must not be null", jungkook.volume50AudioRes)
        assertNotNull("Volume down audio must not be null", jungkook.volumeDownAudioRes)
        assertNotNull("Volume up audio must not be null", jungkook.volumeUpAudioRes)
        assertNotNull("What's playing audio must not be null", jungkook.currentSongAudioRes)
    }

    @Test
    fun testJungkookVoiceCommandsRecognized() {
        VirtualAssistantManager.setEnabled(true)
        VirtualAssistantManager.selectAvatar("jungkook")

        // 1. Resume
        val handledResume = VirtualAssistantManager.processCommand("jungkook renaudando la musica", isDirectChip = true)
        assertTrue("Resume command should be recognized", handledResume)
        assertTrue(VirtualAssistantManager.state.value.thoughtText!!.contains("Reanudando la música"))

        // 2. Pause
        val handledPause = VirtualAssistantManager.processCommand("jungkook pausa la musica", isDirectChip = true)
        assertTrue("Pause command should be recognized", handledPause)
        assertTrue(VirtualAssistantManager.state.value.thoughtText!!.contains("Pausando la música"))

        // 3. Previous song
        val handledPrev = VirtualAssistantManager.processCommand("jungkook pon la cancion anterior", isDirectChip = true)
        assertTrue("Previous command should be recognized", handledPrev)
        assertTrue(VirtualAssistantManager.state.value.thoughtText!!.contains("canción anterior"))

        // 4. Mute
        val handledMute = VirtualAssistantManager.processCommand("jungkook silencia el audio", isDirectChip = true)
        assertTrue("Mute command should be recognized", handledMute)
        assertTrue(VirtualAssistantManager.state.value.thoughtText!!.contains("Silenciando el audio"))

        // 5. Volume 50%
        val handled50 = VirtualAssistantManager.processCommand("jungkook pon la musia al 50", isDirectChip = true)
        assertTrue("Volume 50 command should be recognized", handled50)
        assertTrue(VirtualAssistantManager.state.value.thoughtText!!.contains("50%"))

        // 6. Volume down
        val handledDown = VirtualAssistantManager.processCommand("jungkook baja el volumen", isDirectChip = true)
        assertTrue("Volume down command should be recognized", handledDown)
        assertTrue(VirtualAssistantManager.state.value.thoughtText!!.contains("Bajando el volumen"))

        // 7. Volume up
        val handledUp = VirtualAssistantManager.processCommand("jungkook sube el volumen", isDirectChip = true)
        assertTrue("Volume up command should be recognized", handledUp)
        assertTrue(VirtualAssistantManager.state.value.thoughtText!!.contains("Subiendo el volumen"))

        // 8. What's playing
        val handledQuery = VirtualAssistantManager.processCommand("jungkook que musica esta sonando", isDirectChip = true)
        assertTrue("Query command should be recognized", handledQuery)
        assertTrue(VirtualAssistantManager.state.value.thoughtText!!.contains("canción"))
    }
}
