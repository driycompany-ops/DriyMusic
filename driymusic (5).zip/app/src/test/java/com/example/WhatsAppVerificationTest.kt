package com.example

import com.example.service.DriyWhatsAppVerificationManager
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class WhatsAppVerificationTest {

    @Test
    fun testFormatPhoneForWhatsApp_nineDigitsPrependsPeruPrefix() {
        val result = DriyWhatsAppVerificationManager.formatPhoneForWhatsApp("921483434")
        assertEquals("51921483434", result)
    }

    @Test
    fun testFormatPhoneForWhatsApp_withSpacesAndDashes() {
        val result = DriyWhatsAppVerificationManager.formatPhoneForWhatsApp(" 921-483-434 ")
        assertEquals("51921483434", result)
    }

    @Test
    fun testFormatPhoneForWhatsApp_alreadyHasCountryCode() {
        val result = DriyWhatsAppVerificationManager.formatPhoneForWhatsApp("+51921483434")
        assertEquals("51921483434", result)
    }

    @Test
    fun testFormatPhoneForWhatsApp_internationalNumberKeepsDigits() {
        val result = DriyWhatsAppVerificationManager.formatPhoneForWhatsApp("+14155552671")
        assertEquals("14155552671", result)
    }

    @Test
    fun testOfficialBotNumberConstant() {
        assertEquals("51921483434", DriyWhatsAppVerificationManager.OFFICIAL_VERIFICATION_BOT_PHONE)
    }

    @Test
    fun testZeroKnowledgePrinciple_doesNotContainGeneratedCodeInClient() {
        // Verification that the client manager does NOT generate local random codes in its public API
        val methods = DriyWhatsAppVerificationManager::class.java.declaredMethods
        val hasLocalRandomGenerator = methods.any { it.name.contains("generateRandomCode", ignoreCase = true) }
        assertFalse("Client must not generate OTP codes locally", hasLocalRandomGenerator)
    }
}
