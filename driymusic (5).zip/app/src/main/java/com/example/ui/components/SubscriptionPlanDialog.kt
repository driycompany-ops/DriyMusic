package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import com.example.R
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import com.example.service.DriyReferralManager
import com.example.service.FirebaseUserManager
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.UserEntity
import com.example.service.DriyActivationCodeManager
import com.example.service.RedeemResult
import com.example.ui.theme.DriyBackground
import com.example.ui.theme.DriyDivider
import com.example.ui.theme.DriyGold
import com.example.ui.theme.DriySurface
import com.example.ui.theme.DriySurfaceVariant
import com.example.ui.theme.DriyTextPrimary
import com.example.ui.theme.DriyTextSecondary
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SubscriptionPlanDialog(
    isOpen: Boolean,
    onDismiss: () -> Unit,
    user: UserEntity?,
    initialTab: Int = 0, // 0 = Calcular y Pagar, 1 = Canjear Código
    onCodeRedeemedSuccessfully: () -> Unit = {}
) {
    if (!isOpen) return

    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var selectedTab by remember { mutableIntStateOf(initialTab) }

    // Plan calculator state
    var selectedMonths by remember { mutableIntStateOf(1) }
    val totalAmount = DriyActivationCodeManager.calculateTotal(selectedMonths)
    val totalDays = DriyActivationCodeManager.calculateDays(selectedMonths)

    // Redeem code state
    var codeInput by remember { mutableStateOf("") }
    var isRedeeming by remember { mutableStateOf(false) }
    var redeemFeedbackMessage by remember { mutableStateOf<String?>(null) }
    var isSuccessFeedback by remember { mutableStateOf(false) }

    // Referral state ("¿Vienes por un amigo?")
    var hasReferrer by remember { mutableStateOf(!user?.referredBy.isNullOrBlank()) }
    var referrerInput by remember { mutableStateOf(user?.referredBy ?: "") }
    var referrerValidationStatus by remember { mutableStateOf<String?>(null) }
    var isReferrerValid by remember { mutableStateOf(!user?.referredBy.isNullOrBlank()) }
    var isValidatingReferrer by remember { mutableStateOf(false) }

    LaunchedEffect(referrerInput, hasReferrer) {
        if (!hasReferrer) {
            referrerValidationStatus = null
            isReferrerValid = false
            return@LaunchedEffect
        }
        val clean = referrerInput.trim().removePrefix("@").lowercase()
        if (clean.isBlank()) {
            referrerValidationStatus = null
            isReferrerValid = false
            return@LaunchedEffect
        }
        val currentUsername = user?.username?.trim()?.removePrefix("@")?.lowercase() ?: ""
        if (clean == currentUsername) {
            referrerValidationStatus = "No puedes ingresar tu propio usuario"
            isReferrerValid = false
            return@LaunchedEffect
        }
        isValidatingReferrer = true
        kotlinx.coroutines.delay(350)
        try {
            val userManager = FirebaseUserManager(context)
            val exists = userManager.isUsernameTaken(clean)
            if (exists) {
                referrerValidationStatus = "✓ Amigo verificado (@$clean)"
                isReferrerValid = true
            } else {
                referrerValidationStatus = "Usuario '@$clean' no encontrado en DriyMusic"
                isReferrerValid = false
            }
        } catch (e: Exception) {
            referrerValidationStatus = null
            isReferrerValid = false
        } finally {
            isValidatingReferrer = false
        }
    }

    val yapePurple = Color(0xFF732282)
    val plinCyan = Color(0xFF00A3E0)
    val whatsappGreen = Color(0xFF25D366)

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .clip(RoundedCornerShape(24.dp))
                .border(1.5.dp, DriyGold.copy(alpha = 0.6f), RoundedCornerShape(24.dp))
                .testTag("subscription_plan_dialog"),
            color = DriyBackground
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp)
            ) {
                // Header with close button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(DriyGold.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Star,
                                contentDescription = null,
                                tint = DriyGold,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Membresía DriyMusic",
                                color = DriyTextPrimary,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Acceso ilimitado • S/. 5.00 al mes",
                                color = DriyTextSecondary,
                                fontSize = 11.sp
                            )
                        }
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Cerrar",
                            tint = DriyTextSecondary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Tab Switcher (Calcular & Pagar vs Canjear Código)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(DriySurfaceVariant)
                        .padding(4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (selectedTab == 0) DriyGold else Color.Transparent)
                            .clickable { selectedTab = 0 }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Payment,
                                contentDescription = null,
                                tint = if (selectedTab == 0) DriyBackground else DriyTextSecondary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Calcular y Pagar",
                                color = if (selectedTab == 0) DriyBackground else DriyTextSecondary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (selectedTab == 1) DriyGold else Color.Transparent)
                            .clickable { selectedTab = 1 }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Key,
                                contentDescription = null,
                                tint = if (selectedTab == 1) DriyBackground else DriyTextSecondary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Canjear Código",
                                color = if (selectedTab == 1) DriyBackground else DriyTextSecondary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                if (selectedTab == 0) {
                    // TAB 0: CALCULATOR AND PAYMENT INSTRUCTIONS
                    Text(
                        text = "1. Elige la cantidad de meses (1 a 12):",
                        color = DriyGold,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    // Month Selector (- / + and Stepper)
                    Card(
                        colors = CardDefaults.cardColors(containerColor = DriySurface),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                IconButton(
                                    onClick = { if (selectedMonths > 1) selectedMonths-- },
                                    enabled = selectedMonths > 1,
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clip(CircleShape)
                                        .background(if (selectedMonths > 1) DriySurfaceVariant else DriySurfaceVariant.copy(alpha = 0.4f))
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Remove,
                                        contentDescription = "Menos meses",
                                        tint = if (selectedMonths > 1) DriyGold else DriyTextSecondary.copy(alpha = 0.5f)
                                    )
                                }

                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = "$selectedMonths ${if (selectedMonths == 1) "Mes" else "Meses"}",
                                        color = DriyTextPrimary,
                                        fontSize = 24.sp,
                                        fontWeight = FontWeight.ExtraBold
                                    )
                                    Text(
                                        text = "$totalDays días de acceso continuo (28 días/mes)",
                                        color = DriyTextSecondary,
                                        fontSize = 12.sp
                                    )
                                }

                                IconButton(
                                    onClick = { if (selectedMonths < 12) selectedMonths++ },
                                    enabled = selectedMonths < 12,
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clip(CircleShape)
                                        .background(if (selectedMonths < 12) DriyGold else DriySurfaceVariant.copy(alpha = 0.4f))
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Add,
                                        contentDescription = "Más meses",
                                        tint = if (selectedMonths < 12) DriyBackground else DriyTextSecondary.copy(alpha = 0.5f)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            // Quick chip shortcuts (1m, 2m, 3m, 6m, 12m)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                listOf(1, 2, 3, 6, 12).forEach { m ->
                                    val isCurrent = selectedMonths == m
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = if (isCurrent) DriyGold else DriySurfaceVariant,
                                        modifier = Modifier
                                            .weight(1f)
                                            .clickable { selectedMonths = m }
                                    ) {
                                        Text(
                                            text = "${m}m",
                                            color = if (isCurrent) DriyBackground else DriyTextPrimary,
                                            fontSize = 12.sp,
                                            fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Medium,
                                            textAlign = TextAlign.Center,
                                            modifier = Modifier.padding(vertical = 6.dp)
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))
                            HorizontalDivider(color = DriyDivider)
                            Spacer(modifier = Modifier.height(14.dp))

                            // Dynamic Calculation Summary Box
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(DriySurfaceVariant)
                                    .padding(14.dp)
                            ) {
                                Column {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = "Fórmula: $selectedMonths mes${if (selectedMonths > 1) "es" else ""} × S/. 5.00",
                                            color = DriyTextSecondary,
                                            fontSize = 13.sp
                                        )
                                        Text(
                                            text = "S/. ${"%.2f".format(totalAmount)}",
                                            color = DriyGold,
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "TOTAL A PAGAR:",
                                            color = DriyTextPrimary,
                                            fontSize = 15.sp,
                                            fontWeight = FontWeight.Black
                                        )
                                        Text(
                                            text = "S/. ${"%.2f".format(totalAmount)}",
                                            color = Color(0xFF4CAF50),
                                            fontSize = 22.sp,
                                            fontWeight = FontWeight.Black
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Step 2: Payment Details (Yape & Plin Card)
                    Text(
                        text = "2. Realiza tu pago por Yape o Plin:",
                        color = DriyGold,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Card(
                        colors = CardDefaults.cardColors(containerColor = DriySurface),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            // Titular header
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(DriySurfaceVariant)
                                    .padding(vertical = 8.dp, horizontal = 12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Titular de las cuentas:",
                                    color = DriyTextSecondary,
                                    fontSize = 12.sp
                                )
                                Text(
                                    text = DriyActivationCodeManager.DEFAULT_ADMIN_HOLDER_NAME,
                                    color = DriyGold,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Yape Card
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(yapePurple.copy(alpha = 0.15f))
                                    .border(1.dp, yapePurple.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Surface(
                                        color = yapePurple,
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text(
                                            text = "💜 Yape",
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = "Número Yape:",
                                            color = DriyTextSecondary,
                                            fontSize = 10.sp
                                        )
                                        Text(
                                            text = DriyActivationCodeManager.YAPE_DISPLAY_PHONE,
                                            color = DriyTextPrimary,
                                            fontSize = 16.sp,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                }

                                Button(
                                    onClick = {
                                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                        val clip = ClipData.newPlainText("Yape", DriyActivationCodeManager.YAPE_PHONE)
                                        clipboard.setPrimaryClip(clip)
                                        Toast.makeText(context, "Número de Yape copiado (950312209)", Toast.LENGTH_SHORT).show()
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = yapePurple,
                                        contentColor = Color.White
                                    ),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ContentCopy,
                                        contentDescription = "Copiar Yape",
                                        modifier = Modifier.size(13.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Copiar", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Plin Card
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(plinCyan.copy(alpha = 0.15f))
                                    .border(1.dp, plinCyan.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Surface(
                                        color = plinCyan,
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text(
                                            text = "💙 Plin",
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = "Número Plin:",
                                            color = DriyTextSecondary,
                                            fontSize = 10.sp
                                        )
                                        Text(
                                            text = DriyActivationCodeManager.PLIN_DISPLAY_PHONE,
                                            color = DriyTextPrimary,
                                            fontSize = 16.sp,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                }

                                Button(
                                    onClick = {
                                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                        val clip = ClipData.newPlainText("Plin", DriyActivationCodeManager.PLIN_PHONE)
                                        clipboard.setPrimaryClip(clip)
                                        Toast.makeText(context, "Número de Plin copiado (921483434)", Toast.LENGTH_SHORT).show()
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = plinCyan,
                                        contentColor = Color.White
                                    ),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ContentCopy,
                                        contentDescription = "Copiar Plin",
                                        modifier = Modifier.size(13.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Copiar", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            // Official Plin QR Code Display
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(DriySurfaceVariant)
                                    .border(1.dp, plinCyan.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
                                    .padding(14.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.QrCode2,
                                        contentDescription = "QR Plin",
                                        tint = plinCyan,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "Código QR Oficial Plin",
                                        color = DriyTextPrimary,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                // Render the actual QR image on a clean white container
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(Color.White)
                                        .padding(12.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Image(
                                        painter = painterResource(id = R.drawable.qr_plin),
                                        contentDescription = "QR Plin de driy company",
                                        modifier = Modifier.size(180.dp),
                                        contentScale = ContentScale.Fit
                                    )
                                }

                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "Escanea con tu aplicación de Plin, Interbank, BBVA o Scotiabank",
                                    color = DriyTextSecondary,
                                    fontSize = 11.sp,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    // Step 2.5: ¿Vienes por recomendación de un amigo?
                    Card(
                        colors = CardDefaults.cardColors(containerColor = DriySurface),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, if (hasReferrer) DriyGold.copy(alpha = 0.5f) else Color.Transparent, RoundedCornerShape(16.dp))
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(32.dp)
                                            .clip(CircleShape)
                                            .background(DriyGold.copy(alpha = 0.2f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.CardGiftcard,
                                            contentDescription = null,
                                            tint = DriyGold,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = "¿Vienes por recomendación de un amigo?",
                                            color = DriyTextPrimary,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp
                                        )
                                        Text(
                                            text = "Ingresa su usuario para apoyarlo a ganar 3 meses gratis",
                                            color = DriyTextSecondary,
                                            fontSize = 10.sp
                                        )
                                    }
                                }
                                Switch(
                                    checked = hasReferrer,
                                    onCheckedChange = { checked ->
                                        hasReferrer = checked
                                        if (!checked) {
                                            referrerInput = ""
                                        }
                                    },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = DriyGold,
                                        checkedTrackColor = DriyGold.copy(alpha = 0.3f),
                                        uncheckedThumbColor = DriyTextSecondary,
                                        uncheckedTrackColor = DriySurfaceVariant
                                    )
                                )
                            }

                            if (hasReferrer) {
                                Spacer(modifier = Modifier.height(12.dp))
                                OutlinedTextField(
                                    value = referrerInput,
                                    onValueChange = { referrerInput = it },
                                    label = { Text("Usuario de tu amigo (ej: @carlos)") },
                                    leadingIcon = {
                                        Icon(
                                            imageVector = Icons.Default.Person,
                                            contentDescription = null,
                                            tint = DriyGold
                                        )
                                    },
                                    trailingIcon = {
                                        if (isValidatingReferrer) {
                                            CircularProgressIndicator(
                                                modifier = Modifier.size(16.dp),
                                                strokeWidth = 2.dp,
                                                color = DriyGold
                                            )
                                        } else if (isReferrerValid) {
                                            Icon(
                                                imageVector = Icons.Default.CheckCircle,
                                                contentDescription = "Válido",
                                                tint = Color(0xFF4CAF50),
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = if (isReferrerValid) Color(0xFF4CAF50) else DriyGold,
                                        unfocusedBorderColor = DriyDivider,
                                        focusedLabelColor = DriyGold,
                                        unfocusedLabelColor = DriyTextSecondary,
                                        focusedTextColor = DriyTextPrimary,
                                        unfocusedTextColor = DriyTextPrimary
                                    )
                                )

                                if (referrerValidationStatus != null) {
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = referrerValidationStatus ?: "",
                                        color = if (isReferrerValid) Color(0xFF4CAF50) else Color(0xFFE57373),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    // Step 3: Button to send voucher via WhatsApp with exact prompt presentation
                    Text(
                        text = "3. Envía tu comprobante para recibir tu código:",
                        color = DriyGold,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = {
                            val userName = user?.displayName?.ifBlank { user.firstName } ?: "Usuario DriyMusic"
                            val userPhone = user?.phoneNumber ?: ""
                            val cleanReferrer = if (hasReferrer && isReferrerValid) {
                                referrerInput.trim().removePrefix("@").lowercase()
                            } else {
                                user?.referredBy ?: ""
                            }

                            // If referrer is set, link in database asynchronously
                            if (cleanReferrer.isNotBlank() && user != null) {
                                coroutineScope.launch {
                                    DriyReferralManager.attachReferrerToUser(
                                        context = context,
                                        currentUserId = user.id,
                                        referrerUsername = cleanReferrer
                                    )
                                }
                            }

                            DriyActivationCodeManager.sendVoucherViaWhatsApp(
                                context = context,
                                userName = userName,
                                userPhone = userPhone,
                                months = selectedMonths,
                                referredBy = cleanReferrer
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .testTag("btn_send_voucher_whatsapp"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = whatsappGreen,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Send,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Enviar Voucher por WhatsApp (S/. ${"%.2f".format(totalAmount)})",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Al presionar se abrirá tu WhatsApp con el mensaje listo para que adjuntes la captura de tu voucher. Se verificará y recibirás tu código de activación único.",
                        color = DriyTextSecondary,
                        fontSize = 11.sp,
                        textAlign = TextAlign.Center,
                        lineHeight = 15.sp,
                        modifier = Modifier.fillMaxWidth()
                    )
                } else {
                    // TAB 1: REDEEM CODE
                    Card(
                        colors = CardDefaults.cardColors(containerColor = DriySurface),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(18.dp)) {
                            Text(
                                text = "Ingresa tu Código de Activación:",
                                color = DriyTextPrimary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "El código único recibido por WhatsApp (ejemplo: DRIY-7K2X-9P4M). Recuerda que cada código es de un solo uso.",
                                color = DriyTextSecondary,
                                fontSize = 12.sp,
                                lineHeight = 16.sp
                            )
                            Spacer(modifier = Modifier.height(10.dp))

                            // Cloud Backend Security Badge
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(DriyGold.copy(alpha = 0.12f))
                                    .border(1.dp, DriyGold.copy(alpha = 0.35f), RoundedCornerShape(8.dp))
                                    .padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Verified,
                                    contentDescription = null,
                                    tint = DriyGold,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Validación en la nube (Cloud Functions + Anti-Clonación)",
                                    color = DriyGold,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            OutlinedTextField(
                                value = codeInput,
                                onValueChange = { codeInput = it.uppercase().trim() },
                                label = { Text("Código de Activación") },
                                placeholder = { Text("DRIY-XXXX-XXXX") },
                                singleLine = true,
                                trailingIcon = {
                                    IconButton(
                                        onClick = {
                                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                            val text = clipboard.primaryClip?.getItemAt(0)?.text?.toString()
                                            if (!text.isNullOrBlank()) {
                                                codeInput = text.trim().uppercase()
                                            }
                                        }
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.ContentCopy,
                                            contentDescription = "Pegar",
                                            tint = DriyGold
                                        )
                                    }
                                },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = DriyGold,
                                    unfocusedBorderColor = DriyDivider,
                                    focusedTextColor = DriyTextPrimary,
                                    unfocusedTextColor = DriyTextPrimary,
                                    focusedContainerColor = DriyBackground,
                                    unfocusedContainerColor = DriyBackground
                                ),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("input_activation_code")
                            )

                            Spacer(modifier = Modifier.height(16.dp))

                            Button(
                                onClick = {
                                    if (user == null) {
                                        Toast.makeText(context, "Inicia sesión primero para activar tu código", Toast.LENGTH_SHORT).show()
                                        return@Button
                                    }
                                    if (codeInput.isBlank()) {
                                        redeemFeedbackMessage = "Por favor escribe o pega tu código."
                                        isSuccessFeedback = false
                                        return@Button
                                    }

                                    isRedeeming = true
                                    redeemFeedbackMessage = null

                                    coroutineScope.launch {
                                        val result = DriyActivationCodeManager.redeemCode(
                                            context = context,
                                            rawCode = codeInput,
                                            activeUser = user
                                        )
                                        isRedeeming = false
                                        when (result) {
                                            is RedeemResult.Success -> {
                                                isSuccessFeedback = true
                                                val dateStr = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date(result.newExpirationMs))
                                                val serverNotice = if (result.isServerVerified) "🔒 ${result.verifiedBy}" else "💾 Verificado localmente"
                                                redeemFeedbackMessage = "¡Membresía Activada con Éxito! 🎉\nCódigo canjeado por ${result.months} mes(es) (+${result.addedDays} días).\nActiva hasta el: $dateStr\n$serverNotice"
                                                codeInput = ""
                                                onCodeRedeemedSuccessfully()
                                            }
                                            is RedeemResult.AlreadyUsed -> {
                                                isSuccessFeedback = false
                                                val who = result.usedByUsername ?: "otro usuario"
                                                redeemFeedbackMessage = "Este código ya fue utilizado por $who y no puede volver a usarse."
                                            }
                                            is RedeemResult.InvalidCode -> {
                                                isSuccessFeedback = false
                                                redeemFeedbackMessage = result.message
                                            }
                                            is RedeemResult.Error -> {
                                                isSuccessFeedback = false
                                                redeemFeedbackMessage = result.message
                                            }
                                        }
                                    }
                                },
                                enabled = !isRedeeming && codeInput.isNotBlank(),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(50.dp)
                                    .testTag("btn_redeem_activation_code"),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = DriyGold,
                                    contentColor = DriyBackground
                                ),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                if (isRedeeming) {
                                    CircularProgressIndicator(
                                        color = DriyBackground,
                                        modifier = Modifier.size(20.dp),
                                        strokeWidth = 2.dp
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Validando código...", fontWeight = FontWeight.Bold)
                                } else {
                                    Icon(
                                        imageVector = Icons.Default.Verified,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Activar Membresía", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                }
                            }

                            if (redeemFeedbackMessage != null) {
                                Spacer(modifier = Modifier.height(14.dp))
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(
                                            if (isSuccessFeedback) Color(0x224CAF50) else Color(0x22FF5252)
                                        )
                                        .border(
                                            1.dp,
                                            if (isSuccessFeedback) Color(0xFF4CAF50) else Color(0xFFFF5252),
                                            RoundedCornerShape(12.dp)
                                        )
                                        .padding(14.dp)
                                ) {
                                    Row(verticalAlignment = Alignment.Top) {
                                        Icon(
                                            imageVector = if (isSuccessFeedback) Icons.Default.CheckCircle else Icons.Default.Close,
                                            contentDescription = null,
                                            tint = if (isSuccessFeedback) Color(0xFF4CAF50) else Color(0xFFFF5252),
                                            modifier = Modifier.size(20.dp)
                                        )
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Text(
                                            text = redeemFeedbackMessage ?: "",
                                            color = if (isSuccessFeedback) Color(0xFFE8F5E9) else Color(0xFFFFCDD2),
                                            fontSize = 12.sp,
                                            lineHeight = 16.sp
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Quick link back to calculate & pay
                    OutlinedButton(
                        onClick = { selectedTab = 0 },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = DriyGold),
                        border = androidx.compose.foundation.BorderStroke(1.dp, DriyGold),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("¿Aún no tienes un código? Solicítalo aquí por Yape/Plin", fontSize = 12.sp)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}
