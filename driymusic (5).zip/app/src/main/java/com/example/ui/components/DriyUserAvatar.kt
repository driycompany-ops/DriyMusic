package com.example.ui.components

import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.SubcomposeAsyncImage
import com.example.ui.theme.DriyGold
import com.example.ui.theme.DriySurfaceVariant
import java.io.File

/**
 * Robust User Avatar component for DriyMusic.
 * Handles:
 * 1. Base64 JPEG data URLs (data:image/jpeg;base64,...)
 * 2. Local device files (/data/user/0/... or filesDir/avatar_{userId}.jpg)
 * 3. Remote HTTP/HTTPS URLs (Unsplash preset avatars)
 * 4. Content / File URIs
 * 5. Elegant Gold + Gradient initial fallback so it NEVER displays empty or transparent!
 */
@Composable
fun DriyUserAvatar(
    photoUrl: String?,
    userId: String? = null,
    displayName: String? = null,
    modifier: Modifier = Modifier,
    size: Dp = 72.dp,
    borderColor: Color = DriyGold,
    borderWidth: Dp = 2.dp,
    onClick: (() -> Unit)? = null
) {
    val context = LocalContext.current

    // 1. Try decoding Base64 if photoUrl is a data URI or base64 string
    val base64Bitmap: ImageBitmap? = remember(photoUrl) {
        if (!photoUrl.isNullOrBlank() && (photoUrl.startsWith("data:image") || (photoUrl.length > 300 && !photoUrl.startsWith("http")))) {
            try {
                val cleanBase64 = if (photoUrl.contains(",")) photoUrl.substringAfter(",") else photoUrl
                val bytes = Base64.decode(cleanBase64.trim(), Base64.DEFAULT)
                val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                // Cache to file in background if possible
                if (bmp != null && !userId.isNullOrBlank()) {
                    try {
                        val file = File(context.filesDir, "avatar_${userId.trim().lowercase()}.jpg")
                        if (!file.exists() || file.length() == 0L) {
                            file.writeBytes(bytes)
                        }
                    } catch (_: Exception) {}
                }
                bmp?.asImageBitmap()
            } catch (e: Exception) {
                null
            }
        } else null
    }

    // 2. Check if local cached file exists
    val localFile: File? = remember(photoUrl, userId) {
        if (!photoUrl.isNullOrBlank() && !photoUrl.startsWith("http") && !photoUrl.startsWith("data:")) {
            val f = File(photoUrl)
            if (f.exists() && f.length() > 0) f else null
        } else if (!userId.isNullOrBlank()) {
            val f = File(context.filesDir, "avatar_${userId.trim().lowercase()}.jpg")
            if (f.exists() && f.length() > 0) f else {
                val fRaw = File(context.filesDir, "avatar_${userId.trim()}.jpg")
                if (fRaw.exists() && fRaw.length() > 0) fRaw else null
            }
        } else null
    }

    // 3. Fallback remote / Uri model
    val asyncModel: Any? = remember(photoUrl, localFile) {
        when {
            localFile != null -> localFile
            !photoUrl.isNullOrBlank() && (photoUrl.startsWith("http://") || photoUrl.startsWith("https://") || photoUrl.startsWith("content://") || photoUrl.startsWith("file://")) -> photoUrl
            else -> null
        }
    }

    val boxModifier = modifier
        .size(size)
        .clip(CircleShape)
        .border(borderWidth, borderColor, CircleShape)
        .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
        .testTag("driy_user_avatar")

    Box(
        modifier = boxModifier,
        contentAlignment = Alignment.Center
    ) {
        when {
            base64Bitmap != null -> {
                Image(
                    bitmap = base64Bitmap,
                    contentDescription = "Foto de perfil",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
            asyncModel != null -> {
                SubcomposeAsyncImage(
                    model = asyncModel,
                    contentDescription = "Foto de perfil",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                    loading = {
                        AvatarInitialsFallback(displayName = displayName, size = size)
                    },
                    error = {
                        AvatarInitialsFallback(displayName = displayName, size = size)
                    }
                )
            }
            else -> {
                AvatarInitialsFallback(displayName = displayName, size = size)
            }
        }
    }
}

@Composable
fun AvatarInitialsFallback(
    displayName: String?,
    size: Dp,
    modifier: Modifier = Modifier
) {
    val cleanName = displayName?.trim().orEmpty()
    val initial = cleanName.firstOrNull()?.uppercaseChar()?.toString() ?: "D"

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF2E2A20),
                        Color(0xFF1B1A16)
                    )
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        if (cleanName.isNotBlank()) {
            Text(
                text = initial,
                color = DriyGold,
                fontSize = (size.value * 0.42f).sp,
                fontWeight = FontWeight.Bold
            )
        } else {
            Icon(
                imageVector = Icons.Default.Person,
                contentDescription = "Avatar",
                tint = DriyGold.copy(alpha = 0.85f),
                modifier = Modifier.size(size * 0.52f)
            )
        }
    }
}
