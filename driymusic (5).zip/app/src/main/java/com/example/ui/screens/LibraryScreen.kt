package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.DownloadDone
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.FolderEntity
import com.example.data.model.FolderWithStats
import com.example.data.model.SongEntity
import com.example.service.PlayerState
import com.example.ui.components.FolderCard
import com.example.ui.components.FolderDetailView
import com.example.ui.components.FolderRenameDialog
import com.example.ui.components.SongItemRow
import com.example.ui.theme.DriyBackground
import com.example.ui.theme.DriyDivider
import com.example.ui.theme.DriyGold
import com.example.ui.theme.DriySurface
import com.example.ui.theme.DriySurfaceVariant
import com.example.ui.theme.DriyTextPrimary
import com.example.ui.theme.DriyTextSecondary

enum class LibraryTab {
    FOLDERS, DOWNLOADS, ALL
}

@Composable
fun LibraryScreen(
    downloadedSongs: List<SongEntity>,
    allSongs: List<SongEntity>,
    foldersWithStats: List<FolderWithStats>,
    activeFolder: FolderEntity?,
    activeFolderSongs: List<SongEntity>,
    playerState: PlayerState,
    downloadProgress: Map<String, Float>,
    onPlaySong: (SongEntity, List<SongEntity>) -> Unit,
    onToggleFavorite: (SongEntity) -> Unit,
    onDownloadSong: (SongEntity) -> Unit,
    onOpenSongOptions: (SongEntity) -> Unit = {},
    onOpenDownloadsFolder: () -> Unit = {},
    onScanDownloads: () -> Unit = {},
    onOpenFolderDetail: (FolderEntity) -> Unit,
    onCloseFolderDetail: () -> Unit,
    onCreateFolder: (String) -> Unit,
    onRenameFolder: (String, String) -> Unit,
    onDeleteFolder: (FolderEntity) -> Unit,
    onRemoveSongFromFolder: (String, String) -> Unit,
    onSyncCloud: () -> Unit = {},
    isSyncingCloud: Boolean = false
) {
    BackHandler(enabled = activeFolder != null) {
        onCloseFolderDetail()
    }

    var selectedTab by remember { mutableStateOf(LibraryTab.FOLDERS) }
    var folderToRename by remember { mutableStateOf<FolderEntity?>(null) }
    var folderToDelete by remember { mutableStateOf<FolderEntity?>(null) }
    var isCreatingFolderDialogOpen by remember { mutableStateOf(false) }
    var newFolderNameInput by remember { mutableStateOf("") }

    if (activeFolder != null) {
        FolderDetailView(
            folder = activeFolder,
            songs = activeFolderSongs,
            isPlaying = playerState.isPlaying,
            currentSongId = playerState.currentSong?.id,
            downloadProgress = downloadProgress,
            onBack = onCloseFolderDetail,
            onPlayAll = {
                if (activeFolderSongs.isNotEmpty()) {
                    onPlaySong(activeFolderSongs.first(), activeFolderSongs)
                }
            },
            onShuffleAll = {
                if (activeFolderSongs.isNotEmpty()) {
                    val shuffled = activeFolderSongs.shuffled()
                    onPlaySong(shuffled.first(), shuffled)
                }
            },
            onPlaySong = onPlaySong,
            onToggleFavorite = onToggleFavorite,
            onDownloadSong = onDownloadSong,
            onOpenSongOptions = onOpenSongOptions,
            onRenameFolder = { folderToRename = activeFolder },
            onDeleteFolder = { folderToDelete = activeFolder },
            onRemoveSongFromFolder = { songId -> onRemoveSongFromFolder(activeFolder.id, songId) },
            onSyncCloud = onSyncCloud
        )

        FolderRenameDialog(
            folder = folderToRename,
            onDismiss = { folderToRename = null },
            onConfirmRename = { newName ->
                folderToRename?.let { onRenameFolder(it.id, newName) }
                folderToRename = null
            }
        )

        if (folderToDelete != null) {
            AlertDialog(
                onDismissRequest = { folderToDelete = null },
                containerColor = DriySurface,
                title = { Text("Eliminar carpeta", color = DriyTextPrimary, fontWeight = FontWeight.Bold) },
                text = {
                    Text(
                        "¿Estás seguro de que deseas eliminar la carpeta '${folderToDelete?.name}'? Las canciones seguirán existiendo en tu catálogo.",
                        color = DriyTextSecondary,
                        fontSize = 13.sp
                    )
                },
                confirmButton = {
                    Button(
                        onClick = {
                            folderToDelete?.let { onDeleteFolder(it) }
                            folderToDelete = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = androidx.compose.ui.graphics.Color(0xFFE57373))
                    ) {
                        Text("Eliminar", color = androidx.compose.ui.graphics.Color.White, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { folderToDelete = null }) {
                        Text("Cancelar", color = DriyTextSecondary)
                    }
                }
            )
        }
        return
    }

    Surface(
        color = com.example.ui.theme.DriyScreenBackground,
        modifier = Modifier
            .fillMaxSize()
            .testTag("library_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = 16.dp)
        ) {
            Text(
                text = "Tu Biblioteca",
                color = DriyTextPrimary,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 16.dp)
            )

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
            ) {
                FilterChip(
                    selected = selectedTab == LibraryTab.FOLDERS,
                    onClick = { selectedTab = LibraryTab.FOLDERS },
                    label = { Text("Carpetas (${foldersWithStats.size})") },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Folder,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = DriyGold,
                        selectedLabelColor = DriyBackground,
                        selectedLeadingIconColor = DriyBackground,
                        containerColor = DriySurface,
                        labelColor = DriyTextPrimary,
                        iconColor = DriyTextSecondary
                    ),
                    border = FilterChipDefaults.filterChipBorder(
                        borderColor = DriyDivider,
                        selectedBorderColor = DriyGold,
                        enabled = true,
                        selected = selectedTab == LibraryTab.FOLDERS
                    )
                )

                FilterChip(
                    selected = selectedTab == LibraryTab.DOWNLOADS,
                    onClick = { selectedTab = LibraryTab.DOWNLOADS },
                    label = { Text("Descargas (${downloadedSongs.size})") },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.DownloadDone,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = DriyGold,
                        selectedLabelColor = DriyBackground,
                        selectedLeadingIconColor = DriyBackground,
                        containerColor = DriySurface,
                        labelColor = DriyTextPrimary,
                        iconColor = DriyTextSecondary
                    ),
                    border = FilterChipDefaults.filterChipBorder(
                        borderColor = DriyDivider,
                        selectedBorderColor = DriyGold,
                        enabled = true,
                        selected = selectedTab == LibraryTab.DOWNLOADS
                    )
                )

                FilterChip(
                    selected = selectedTab == LibraryTab.ALL,
                    onClick = { selectedTab = LibraryTab.ALL },
                    label = { Text("Todo (${allSongs.size})") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = DriyGold,
                        selectedLabelColor = DriyBackground,
                        containerColor = DriySurface,
                        labelColor = DriyTextPrimary
                    ),
                    border = FilterChipDefaults.filterChipBorder(
                        borderColor = DriyDivider,
                        selectedBorderColor = DriyGold,
                        enabled = true,
                        selected = selectedTab == LibraryTab.ALL
                    )
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            when (selectedTab) {
                LibraryTab.FOLDERS -> {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Tus Carpetas y Listas",
                            color = DriyTextPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(
                                onClick = onSyncCloud,
                                modifier = Modifier
                                    .size(36.dp)
                                    .testTag("sync_cloud_btn")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Sync,
                                    contentDescription = "Sincronizar nube",
                                    tint = DriyGold,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            TextButton(
                                onClick = { isCreatingFolderDialogOpen = true },
                                modifier = Modifier.testTag("create_folder_top_btn")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CreateNewFolder,
                                    contentDescription = null,
                                    tint = DriyGold,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Nueva carpeta",
                                    color = DriyGold,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                            }
                        }
                    }

                    LazyColumn(
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(bottom = 90.dp)
                    ) {
                        items(foldersWithStats, key = { it.folder.id }) { item ->
                            FolderCard(
                                folderWithStats = item,
                                onClick = { onOpenFolderDetail(item.folder) },
                                onRename = { folderToRename = item.folder },
                                onDelete = { folderToDelete = item.folder }
                            )
                        }
                    }
                }

                LibraryTab.DOWNLOADS -> {
                    if (downloadedSongs.isEmpty()) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(bottom = 80.dp)
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.padding(24.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.DownloadDone,
                                    contentDescription = null,
                                    tint = DriyTextSecondary,
                                    modifier = Modifier.size(56.dp)
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                Text(
                                    text = "Aún no tienes música descargada",
                                    color = DriyTextPrimary,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "Toca el icono de descarga en cualquier canción para guardarla en tu dispositivo y escucharla 100% sin internet.",
                                    color = DriyTextSecondary,
                                    fontSize = 13.sp,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )
                                Spacer(modifier = Modifier.height(20.dp))
                                Button(
                                    onClick = onScanDownloads,
                                    colors = ButtonDefaults.buttonColors(containerColor = DriyGold, contentColor = DriyBackground),
                                    shape = RoundedCornerShape(20.dp),
                                    contentPadding = PaddingValues(horizontal = 18.dp, vertical = 10.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Refresh,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Escanear carpeta DriyStream", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                }
                            }
                        }
                    } else {
                        LazyColumn(
                            contentPadding = PaddingValues(bottom = 90.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            item {
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = DriySurfaceVariant,
                                    border = BorderStroke(1.dp, DriyDivider),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 16.dp, vertical = 8.dp)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Folder,
                                            contentDescription = null,
                                            tint = DriyGold,
                                            modifier = Modifier.size(24.dp)
                                        )
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = "Carpeta DriyStream única verificada",
                                                color = DriyTextPrimary,
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Text(
                                                text = "${downloadedSongs.size} canciones disponibles offline",
                                                color = DriyTextSecondary,
                                                fontSize = 11.sp
                                            )
                                        }
                                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            OutlinedButton(
                                                onClick = onScanDownloads,
                                                border = BorderStroke(1.dp, DriyGold),
                                                shape = RoundedCornerShape(20.dp),
                                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Refresh,
                                                    contentDescription = null,
                                                    tint = DriyGold,
                                                    modifier = Modifier.size(14.dp)
                                                )
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("Escanear", color = DriyGold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                            }
                                            OutlinedButton(
                                                onClick = onOpenDownloadsFolder,
                                                border = BorderStroke(1.dp, DriyDivider),
                                                shape = RoundedCornerShape(20.dp),
                                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp)
                                            ) {
                                                Text("Archivos", color = DriyTextSecondary, fontSize = 11.sp)
                                            }
                                        }
                                    }
                                }
                            }

                            items(downloadedSongs) { song ->
                                SongItemRow(
                                    song = song,
                                    isPlaying = playerState.isPlaying,
                                    isCurrentSong = playerState.currentSong?.id == song.id,
                                    downloadProgress = downloadProgress[song.id],
                                    onPlay = { onPlaySong(song, downloadedSongs) },
                                    onToggleFavorite = { onToggleFavorite(song) },
                                    onDownload = { onDownloadSong(song) },
                                    onOptionsClick = { onOpenSongOptions(song) }
                                )
                            }
                        }
                    }
                }

                LibraryTab.ALL -> {
                    LazyColumn(
                        contentPadding = PaddingValues(bottom = 90.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(allSongs) { song ->
                            SongItemRow(
                                song = song,
                                isPlaying = playerState.isPlaying,
                                isCurrentSong = playerState.currentSong?.id == song.id,
                                downloadProgress = downloadProgress[song.id],
                                onPlay = { onPlaySong(song, allSongs) },
                                onToggleFavorite = { onToggleFavorite(song) },
                                onDownload = { onDownloadSong(song) },
                                onOptionsClick = { onOpenSongOptions(song) }
                            )
                        }
                    }
                }
            }
        }
    }

    FolderRenameDialog(
        folder = folderToRename,
        onDismiss = { folderToRename = null },
        onConfirmRename = { newName ->
            folderToRename?.let { onRenameFolder(it.id, newName) }
            folderToRename = null
        }
    )

    if (folderToDelete != null) {
        AlertDialog(
            onDismissRequest = { folderToDelete = null },
            containerColor = DriySurface,
            title = { Text("Eliminar carpeta", color = DriyTextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    "¿Estás seguro de que deseas eliminar la carpeta '${folderToDelete?.name}'? Las canciones seguirán existiendo en tu catálogo.",
                    color = DriyTextSecondary,
                    fontSize = 13.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        folderToDelete?.let { onDeleteFolder(it) }
                        folderToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = androidx.compose.ui.graphics.Color(0xFFE57373))
                ) {
                    Text("Eliminar", color = androidx.compose.ui.graphics.Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { folderToDelete = null }) {
                    Text("Cancelar", color = DriyTextSecondary)
                }
            }
        )
    }

    if (isCreatingFolderDialogOpen) {
        AlertDialog(
            onDismissRequest = {
                isCreatingFolderDialogOpen = false
                newFolderNameInput = ""
            },
            containerColor = DriySurface,
            title = {
                Text("Nueva carpeta de música", color = DriyTextPrimary, fontWeight = FontWeight.Bold)
            },
            text = {
                Column {
                    Text(
                        "Introduce el nombre para tu nueva carpeta:",
                        color = DriyTextSecondary,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = newFolderNameInput,
                        onValueChange = { newFolderNameInput = it },
                        placeholder = { Text("Ej: Gym, En el auto, Relax...", color = DriyTextSecondary, fontSize = 13.sp) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = DriySurfaceVariant,
                            unfocusedContainerColor = DriySurfaceVariant,
                            focusedBorderColor = DriyGold,
                            unfocusedBorderColor = DriyDivider,
                            focusedTextColor = DriyTextPrimary,
                            unfocusedTextColor = DriyTextPrimary
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth().testTag("dialog_new_folder_input")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newFolderNameInput.isNotBlank()) {
                            onCreateFolder(newFolderNameInput.trim())
                            newFolderNameInput = ""
                            isCreatingFolderDialogOpen = false
                        }
                    },
                    enabled = newFolderNameInput.isNotBlank(),
                    colors = ButtonDefaults.buttonColors(containerColor = DriyGold, contentColor = DriyBackground),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Crear", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        isCreatingFolderDialogOpen = false
                        newFolderNameInput = ""
                    }
                ) {
                    Text("Cancelar", color = DriyTextSecondary)
                }
            }
        )
    }
}
