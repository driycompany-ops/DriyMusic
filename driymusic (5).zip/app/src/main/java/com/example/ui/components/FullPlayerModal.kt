package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.QueueMusic
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.LyricsUiState
import com.example.data.model.SongEntity
import com.example.service.PlayerState
import com.example.ui.theme.DriyBackground
import com.example.ui.theme.DriyDivider
import com.example.ui.theme.DriyGold
import com.example.ui.theme.DriySurface
import com.example.ui.theme.DriySurfaceVariant
import com.example.ui.theme.DriyTextPrimary
import com.example.ui.theme.DriyTextSecondary

@Composable
fun FullPlayerModal(
    visible: Boolean,
    playerState: PlayerState,
    downloadProgress: Float?,
    isLyricsVisible: Boolean = false,
    lyricsUiState: LyricsUiState = LyricsUiState(),
    isFavorite: Boolean = false,
    onToggleLyrics: () -> Unit = {},
    onRetryLyrics: () -> Unit = {},
    onAdjustLyricsOffset: (Long) -> Unit = {},
    onResetLyricsOffset: () -> Unit = {},
    onCustomSearchLyrics: (String) -> Unit = {},
    onDismiss: () -> Unit,
    onTogglePlayPause: () -> Unit,
    onNext: () -> Unit,
    onPrev: () -> Unit,
    onSeekTo: (Long) -> Unit,
    onToggleShuffle: () -> Unit,
    onToggleRepeat: () -> Unit,
    onToggleFavorite: (SongEntity) -> Unit,
    onDownload: (SongEntity) -> Unit,
    onOpenQueue: () -> Unit = {}
) {
    AnimatedVisibility(
        visible = visible && playerState.currentSong != null,
        enter = slideInVertically(initialOffsetY = { it }),
        exit = slideOutVertically(targetOffsetY = { it })
    ) {
        val song = playerState.currentSong ?: return@AnimatedVisibility
        val effectiveIsFavorite = isFavorite || song.isFavorite
        var sliderPosition by remember(playerState.currentPositionMs) {
            mutableFloatStateOf(playerState.currentPositionMs.toFloat())
        }
        var isDragging by remember { mutableFloatStateOf(0f) }
        val totalDurationMs = playerState.durationMs.coerceAtLeast(1000L)

        Surface(
            color = DriyBackground,
            modifier = Modifier
                .fillMaxSize()
                .testTag("full_player_modal")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Top Action Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.size(44.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.KeyboardArrowDown,
                            contentDescription = "Cerrar reproductor",
                            tint = DriyTextPrimary,
                            modifier = Modifier.size(32.dp)
                        )
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = if (isLyricsVisible) "LETRA EN VIVO • LRCLIB" else "REPRODUCIENDO DESDE DRIYSTREAM",
                            color = DriyGold,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = song.album,
                            color = DriyTextSecondary,
                            fontSize = 12.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // Lyrics Toggle Button in Top Bar
                        Surface(
                            shape = CircleShape,
                            color = if (isLyricsVisible) DriyGold.copy(alpha = 0.22f) else DriySurfaceVariant.copy(alpha = 0.6f),
                            border = if (isLyricsVisible) androidx.compose.foundation.BorderStroke(1.dp, DriyGold) else null,
                            modifier = Modifier
                                .clickable { onToggleLyrics() }
                                .testTag("full_player_lyrics_toggle_btn")
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Mic,
                                    contentDescription = if (isLyricsVisible) "Ocultar letra" else "Ver letra",
                                    tint = if (isLyricsVisible) DriyGold else DriyTextSecondary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(6.dp))

                        // Top Heart / Favorite action pill
                        Surface(
                            shape = CircleShape,
                            color = if (effectiveIsFavorite) DriyGold.copy(alpha = 0.22f) else DriySurfaceVariant.copy(alpha = 0.6f),
                            border = if (effectiveIsFavorite) androidx.compose.foundation.BorderStroke(1.dp, DriyGold) else null,
                            modifier = Modifier.testTag("full_player_top_favorite_pill")
                        ) {
                            AnimatedHeartButton(
                                isFavorite = effectiveIsFavorite,
                                onClick = { onToggleFavorite(song) },
                                size = 38.dp,
                                iconSize = 22.dp
                            )
                        }

                        IconButton(
                            onClick = onOpenQueue,
                            modifier = Modifier.size(40.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.QueueMusic,
                                contentDescription = "Cola de reproducción",
                                tint = DriyGold,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }
                }

                // Middle section: either Synchronized Lyrics or Album Cover View
                if (isLyricsVisible) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                    ) {
                        SynchronizedLyricsView(
                            song = song,
                            currentPositionMs = playerState.currentPositionMs,
                            lyricsUiState = lyricsUiState,
                            onSeekTo = onSeekTo,
                            onCloseLyrics = onToggleLyrics,
                            onRetry = onRetryLyrics,
                            onAdjustOffset = onAdjustLyricsOffset,
                            onResetOffset = onResetLyricsOffset,
                            onCustomSearch = onCustomSearchLyrics,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                } else {
                    Spacer(modifier = Modifier.height(10.dp))

                    Box(
                        modifier = Modifier
                            .size(270.dp)
                            .shadow(24.dp, RoundedCornerShape(20.dp), spotColor = DriyGold.copy(alpha = 0.25f))
                            .clip(RoundedCornerShape(20.dp))
                            .background(DriySurface)
                    ) {
                        AsyncImage(
                            model = song.coverUrl,
                            contentDescription = song.title,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Prominent "Ver Letra" activation pill
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = DriySurfaceVariant,
                        border = androidx.compose.foundation.BorderStroke(1.dp, DriyGold.copy(alpha = 0.45f)),
                        modifier = Modifier
                            .clickable { onToggleLyrics() }
                            .testTag("full_player_view_lyrics_pill")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 7.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Mic,
                                contentDescription = null,
                                tint = DriyGold,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "🎤 Ver Letra en Vivo (LRCLIB)",
                                color = DriyGold,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                }

                // Song Title, Artist and Download action
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = song.title,
                            color = DriyTextPrimary,
                            fontSize = if (isLyricsVisible) 18.sp else 21.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = song.artist,
                            color = DriyTextSecondary,
                            fontSize = if (isLyricsVisible) 13.sp else 15.sp,
                            fontWeight = FontWeight.Medium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )

                        if (playerState.isSmartAutoplay && !isLyricsVisible) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Surface(
                                color = DriyGold.copy(alpha = 0.15f),
                                shape = RoundedCornerShape(8.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, DriyGold.copy(alpha = 0.35f))
                            ) {
                                Text(
                                    text = playerState.autoplayVibeDescription ?: "✨ Smart Autoplay: ${playerState.autoplayMoodName ?: "100% afinidad"}",
                                    color = DriyGold,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        AnimatedHeartButton(
                            isFavorite = effectiveIsFavorite,
                            onClick = { onToggleFavorite(song) },
                            size = 38.dp,
                            iconSize = 22.dp
                        )

                        Spacer(modifier = Modifier.width(6.dp))

                        Surface(
                            color = DriySurfaceVariant,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .clickable { onDownload(song) }
                                .testTag("full_player_download_btn")
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                if (downloadProgress != null) {
                                    CircularProgressIndicator(
                                        progress = { downloadProgress },
                                        strokeWidth = 2.dp,
                                        color = DriyGold,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Descargando...", color = DriyGold, fontSize = 11.sp)
                                } else if (song.isDownloaded) {
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = "Descargada",
                                        tint = DriyGold,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Guardada", color = DriyGold, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                } else {
                                    Icon(
                                        imageVector = Icons.Default.Download,
                                        contentDescription = "Descargar",
                                        tint = DriyTextPrimary,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Bajar", color = DriyTextPrimary, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Progress Slider & Timestamps
                Column(modifier = Modifier.fillMaxWidth()) {
                    Slider(
                        value = sliderPosition,
                        onValueChange = {
                            isDragging = 1f
                            sliderPosition = it
                        },
                        onValueChangeFinished = {
                            isDragging = 0f
                            onSeekTo(sliderPosition.toLong())
                        },
                        valueRange = 0f..totalDurationMs.toFloat(),
                        colors = SliderDefaults.colors(
                            thumbColor = DriyGold,
                            activeTrackColor = DriyGold,
                            inactiveTrackColor = DriyDivider
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = formatDurationMs(sliderPosition.toLong()),
                            color = DriyTextSecondary,
                            fontSize = 11.sp
                        )
                        Text(
                            text = formatDurationMs(totalDurationMs),
                            color = DriyTextSecondary,
                            fontSize = 11.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Media Playback Controls
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    IconButton(
                        onClick = onToggleShuffle,
                        modifier = Modifier.size(42.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Shuffle,
                            contentDescription = "Aleatorio",
                            tint = if (playerState.isShuffle) DriyGold else DriyTextSecondary,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    IconButton(
                        onClick = onPrev,
                        modifier = Modifier.size(46.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.SkipPrevious,
                            contentDescription = "Anterior",
                            tint = DriyTextPrimary,
                            modifier = Modifier.size(32.dp)
                        )
                    }

                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(64.dp)
                            .clip(CircleShape)
                            .background(DriyGold)
                            .clickable { onTogglePlayPause() }
                            .testTag("full_player_play_pause")
                    ) {
                        Icon(
                            imageVector = if (playerState.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = if (playerState.isPlaying) "Pausar" else "Reproducir",
                            tint = DriyBackground,
                            modifier = Modifier.size(36.dp)
                        )
                    }

                    IconButton(
                        onClick = onNext,
                        modifier = Modifier.size(46.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.SkipNext,
                            contentDescription = "Siguiente",
                            tint = DriyTextPrimary,
                            modifier = Modifier.size(32.dp)
                        )
                    }

                    IconButton(
                        onClick = onToggleRepeat,
                        modifier = Modifier.size(42.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Repeat,
                            contentDescription = "Repetir",
                            tint = if (playerState.isRepeat) DriyGold else DriyTextSecondary,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Queue indicator bar (or compact return to cover button if lyrics active)
                if (isLyricsVisible) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = DriySurfaceVariant.copy(alpha = 0.8f),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp)
                            .clickable { onToggleLyrics() }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.MusicNote,
                                contentDescription = null,
                                tint = DriyGold,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Volver a la carátula",
                                color = DriyTextPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                } else {
                    val queueSize = (playerState.queue.size - 1).coerceAtLeast(0)
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = DriySurface,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp)
                            .clickable { onOpenQueue() }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 9.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.QueueMusic,
                                    contentDescription = null,
                                    tint = DriyGold,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Cola de reproducción",
                                    color = DriyTextPrimary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                            Text(
                                text = if (playerState.preloadedSongId != null) "⚡ Gapless listo (0s espera)" else if (queueSize > 0) "$queueSize en espera • Smart Autoplay" else "Smart Autoplay Activo (0% silencio)",
                                color = DriyGold,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
            }
        }
    }
}
