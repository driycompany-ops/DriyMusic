package com.example.ui.screens

import android.content.Context
import android.util.Log
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import com.example.R
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockReset
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.UserEntity
import com.example.service.DriyWhatsAppVerificationManager
import com.example.service.GlobalUserSyncClient
import com.example.ui.theme.DriyBackground
import com.example.ui.theme.DriyDivider
import com.example.ui.theme.DriyGold
import com.example.ui.theme.DriySurface
import com.example.ui.theme.DriySurfaceVariant
import com.example.ui.theme.DriyTextPrimary
import com.example.ui.theme.DriyTextSecondary
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val WhatsAppGreen = Color(0xFF25D366)
private val WhatsAppDarkBg = Color(0xFF11291B)

private enum class AuthStep {
    WELCOME_CHOICE,
    REGISTER_FORM,
    REGISTER_WHATSAPP_VERIFY,
    LOGIN_FORM,
    LOGIN_WHATSAPP_VERIFY,
    RECOVER_ACCOUNT_FORM,
    RESET_PASSWORD_SCREEN
}

@Composable
fun LoginScreen(
    isAuthenticating: Boolean = false,
    onCheckUsernameTaken: suspend (String) -> Boolean,
    onCheckPhoneTaken: suspend (String) -> Boolean,
    onFindAccountByPhone: suspend (String) -> UserEntity? = { null },
    onValidateLoginCredentials: suspend (username: String, password: String, phone: String) -> String?,
    onVerifyIdentityForRecovery: suspend (firstName: String, lastName: String, phone: String) -> UserEntity? = { _, _, _ -> null },
    onResetPassword: suspend (userIdOrUsername: String, newPassword: String) -> Boolean = { _, _ -> false },
    onRegisterUser: (
        firstName: String,
        lastName: String,
        username: String,
        password: String,
        phoneNumber: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) -> Unit,
    onLoginUser: (
        username: String,
        password: String,
        phoneNumber: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) -> Unit,
    onLoginWithGoogle: (Context) -> Unit = {}
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var currentStep by remember { mutableStateOf(AuthStep.WELCOME_CHOICE) }

    // Register Form Fields
    var regFirstName by remember { mutableStateOf("") }
    var regLastName by remember { mutableStateOf("") }
    var regUsername by remember { mutableStateOf("") }
    var regPassword by remember { mutableStateOf("") }
    var regPhone by remember { mutableStateOf("") }
    var isPasswordVisible by remember { mutableStateOf(false) }

    // Live global username check
    var isUsernameAvailable by remember { mutableStateOf<Boolean?>(null) }
    var isCheckingUsername by remember { mutableStateOf(false) }

    // Live phone number check
    var isPhoneAvailable by remember { mutableStateOf<Boolean?>(null) }
    var isCheckingPhone by remember { mutableStateOf(false) }
    var existingPhoneOwner by remember { mutableStateOf<String?>(null) }

    // Login Form Fields
    var loginUsername by remember { mutableStateOf("") }
    var loginPassword by remember { mutableStateOf("") }
    var loginPhone by remember { mutableStateOf("") }
    var isLoginPasswordVisible by remember { mutableStateOf(false) }

    // Account Recovery Fields
    var recoverFirstName by remember { mutableStateOf("") }
    var recoverLastName by remember { mutableStateOf("") }
    var recoverPhone by remember { mutableStateOf("") }
    var isVerifyingRecovery by remember { mutableStateOf(false) }
    var verifiedUserForReset by remember { mutableStateOf<UserEntity?>(null) }

    // Password Reset Fields
    var resetNewPassword by remember { mutableStateOf("") }
    var resetConfirmPassword by remember { mutableStateOf("") }
    var isResetNewPasswordVisible by remember { mutableStateOf(false) }
    var isResetConfirmPasswordVisible by remember { mutableStateOf(false) }
    var isSubmittingPasswordReset by remember { mutableStateOf(false) }

    // WhatsApp Verification State (Authoritative Server-Side Validation)
    var enteredCode by remember { mutableStateOf("") }
    var targetPhoneState by remember { mutableStateOf("") }
    var activeSessionToken by remember { mutableStateOf("") }
    var resendTimer by remember { mutableIntStateOf(60) }
    var isVerifyingCodeOnServer by remember { mutableStateOf(false) }
    var isRequestingWhatsAppCode by remember { mutableStateOf(false) }

    // Feedback & UI State
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var successMessage by remember { mutableStateOf<String?>(null) }
    var isSubmittingForm by remember { mutableStateOf(false) }

    // Real-time username verification
    LaunchedEffect(regUsername) {
        val trimmed = GlobalUserSyncClient.cleanKey(regUsername)
        if (trimmed.length < 3) {
            isUsernameAvailable = null
            isCheckingUsername = false
            return@LaunchedEffect
        }
        isCheckingUsername = true
        delay(250)
        val taken = onCheckUsernameTaken(trimmed)
        isUsernameAvailable = !taken
        isCheckingUsername = false
    }

    // Real-time phone number verification
    LaunchedEffect(regPhone) {
        val digits = regPhone.filter { it.isDigit() }
        if (digits.length < 7) {
            isPhoneAvailable = null
            existingPhoneOwner = null
            isCheckingPhone = false
            return@LaunchedEffect
        }
        isCheckingPhone = true
        delay(300)
        val existingAccount = onFindAccountByPhone(digits)
        if (existingAccount != null) {
            isPhoneAvailable = false
            existingPhoneOwner = existingAccount.username.ifBlank { existingAccount.displayName }
        } else {
            val isTaken = onCheckPhoneTaken(digits)
            if (isTaken) {
                isPhoneAvailable = false
                existingPhoneOwner = null
            } else {
                isPhoneAvailable = true
                existingPhoneOwner = null
            }
        }
        isCheckingPhone = false
    }

    LaunchedEffect(currentStep, resendTimer) {
        if ((currentStep == AuthStep.REGISTER_WHATSAPP_VERIFY || currentStep == AuthStep.LOGIN_WHATSAPP_VERIFY) && resendTimer > 0) {
            delay(1000)
            resendTimer--
        }
    }

    fun dispatchWhatsAppCode(phone: String, username: String, purpose: String = "REGISTER", onReady: () -> Unit) {
        targetPhoneState = phone
        enteredCode = ""
        isRequestingWhatsAppCode = true
        errorMessage = null
        coroutineScope.launch {
            val result = DriyWhatsAppVerificationManager.requestVerificationCode(context, phone, username, purpose)
            isRequestingWhatsAppCode = false
            result.onSuccess { challenge ->
                activeSessionToken = challenge.sessionToken
                resendTimer = challenge.cooldownSeconds
                successMessage = challenge.message
                onReady()
            }.onFailure { err ->
                errorMessage = err.message ?: "No se pudo solicitar el código de verificación por WhatsApp."
            }
        }
    }

    Surface(
        color = DriyBackground,
        modifier = Modifier
            .fillMaxSize()
            .testTag("login_screen")
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 28.dp, vertical = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Top Bar with back navigation
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (currentStep != AuthStep.WELCOME_CHOICE) {
                        IconButton(
                            onClick = {
                                errorMessage = null
                                successMessage = null
                                currentStep = when (currentStep) {
                                    AuthStep.REGISTER_WHATSAPP_VERIFY -> AuthStep.REGISTER_FORM
                                    AuthStep.LOGIN_WHATSAPP_VERIFY -> AuthStep.LOGIN_FORM
                                    AuthStep.RESET_PASSWORD_SCREEN -> AuthStep.RECOVER_ACCOUNT_FORM
                                    AuthStep.RECOVER_ACCOUNT_FORM -> AuthStep.LOGIN_FORM
                                    else -> AuthStep.WELCOME_CHOICE
                                }
                            },
                            modifier = Modifier.testTag("auth_back_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Regresar",
                                tint = DriyGold
                            )
                        }
                    } else {
                        Spacer(modifier = Modifier.size(48.dp))
                    }

                    Spacer(modifier = Modifier.weight(1f))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Image(
                            painter = painterResource(R.drawable.driymusic_logo),
                            contentDescription = "Logo DriyMusic",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(28.dp)
                                .clip(RoundedCornerShape(6.dp))
                        )
                        Text(
                            text = "DRIYMUSIC",
                            color = DriyGold,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 2.sp
                        )
                    }

                    Spacer(modifier = Modifier.weight(1f))
                    Spacer(modifier = Modifier.size(48.dp))
                }

                // Header Logo / Branding
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(vertical = 12.dp)
                ) {
                    Image(
                        painter = painterResource(R.drawable.driymusic_logo),
                        contentDescription = "Logo DriyMusic",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(72.dp)
                            .clip(RoundedCornerShape(18.dp))
                            .border(1.5.dp, DriyGold.copy(alpha = 0.8f), RoundedCornerShape(18.dp))
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = when (currentStep) {
                            AuthStep.RECOVER_ACCOUNT_FORM -> "Recuperación Segura de Cuenta"
                            AuthStep.RESET_PASSWORD_SCREEN -> "Restablecer tu Contraseña"
                            else -> "Tu Música, Tus Reglas"
                        },
                        color = DriyTextSecondary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                // Error Message Banner
                if (errorMessage != null) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF2E1515)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 16.dp)
                            .border(1.dp, Color(0xFFEF5350).copy(alpha = 0.6f), RoundedCornerShape(12.dp))
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Error,
                                contentDescription = null,
                                tint = Color(0xFFEF5350),
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = errorMessage ?: "",
                                color = Color(0xFFFFCDD2),
                                fontSize = 12.sp,
                                lineHeight = 16.sp
                            )
                        }
                    }
                }

                // Success Message Banner
                if (successMessage != null) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF142E1B)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 16.dp)
                            .border(1.dp, Color(0xFF66BB6A).copy(alpha = 0.6f), RoundedCornerShape(12.dp))
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = Color(0xFF66BB6A),
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = successMessage ?: "",
                                color = Color(0xFFC8E6C9),
                                fontSize = 12.sp,
                                lineHeight = 16.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }

                // ==================== STEP 1: WELCOME CHOICE ====================
                if (currentStep == AuthStep.WELCOME_CHOICE) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "¡Bienvenido!",
                            color = DriyTextPrimary,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Elige una opción para ingresar a la plataforma",
                            color = DriyTextSecondary,
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.height(26.dp))

                        Button(
                            onClick = {
                                errorMessage = null
                                successMessage = null
                                currentStep = AuthStep.REGISTER_FORM
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = DriyGold,
                                contentColor = DriyBackground
                            ),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(54.dp)
                                .testTag("btn_choose_register")
                        ) {
                            Text(
                                text = "Crear cuenta",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        OutlinedButton(
                            onClick = {
                                errorMessage = null
                                successMessage = null
                                currentStep = AuthStep.LOGIN_FORM
                            },
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = DriyGold
                            ),
                            border = ButtonDefaults.outlinedButtonBorder.copy(
                                brush = Brush.linearGradient(listOf(DriyGold, DriyGold.copy(alpha = 0.5f)))
                            ),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(54.dp)
                                .testTag("btn_choose_login")
                        ) {
                            Text(
                                text = "Iniciar sesión",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }


                        Spacer(modifier = Modifier.height(14.dp))


                        Surface(
                            color = DriySurfaceVariant,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    errorMessage = null
                                    successMessage = null
                                    currentStep = AuthStep.RECOVER_ACCOUNT_FORM
                                }
                                .border(1.dp, DriyDivider, RoundedCornerShape(12.dp))
                                .testTag("btn_welcome_recover_account")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.LockReset,
                                    contentDescription = null,
                                    tint = DriyGold,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "¿Olvidaste tu contraseña? Recuperar cuenta",
                                    color = DriyGold,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }

                // ==================== STEP 2: REGISTER FORM ====================
                else if (currentStep == AuthStep.REGISTER_FORM) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 16.dp)
                    ) {
                        Text(
                            text = "Crear cuenta",
                            color = DriyTextPrimary,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Completa tus datos para enviarte tu código de verificación a tu WhatsApp",
                            color = DriyTextSecondary,
                            fontSize = 12.sp
                        )
                        Spacer(modifier = Modifier.height(16.dp))

                        // Nombre & Apellido
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedTextField(
                                value = regFirstName,
                                onValueChange = { regFirstName = it; errorMessage = null },
                                placeholder = { Text("Nombre", color = DriyTextSecondary, fontSize = 13.sp) },
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp),
                                colors = inputColors(),
                                modifier = Modifier.weight(1f).testTag("reg_first_name_input")
                            )
                            OutlinedTextField(
                                value = regLastName,
                                onValueChange = { regLastName = it; errorMessage = null },
                                placeholder = { Text("Apellido", color = DriyTextSecondary, fontSize = 13.sp) },
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp),
                                colors = inputColors(),
                                modifier = Modifier.weight(1f).testTag("reg_last_name_input")
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Nombre de usuario
                        OutlinedTextField(
                            value = regUsername,
                            onValueChange = {
                                regUsername = it.replace(" ", "")
                                errorMessage = null
                            },
                            placeholder = { Text("Nombre de usuario (ej: tupapa)", color = DriyTextSecondary, fontSize = 13.sp) },
                            singleLine = true,
                            leadingIcon = {
                                Icon(Icons.Default.Person, contentDescription = null, tint = DriyGold, modifier = Modifier.size(20.dp))
                            },
                            trailingIcon = {
                                if (isCheckingUsername) {
                                    CircularProgressIndicator(strokeWidth = 2.dp, color = DriyGold, modifier = Modifier.size(18.dp))
                                } else if (isUsernameAvailable == true) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = "Disponible", tint = Color(0xFF66BB6A), modifier = Modifier.size(20.dp))
                                } else if (isUsernameAvailable == false) {
                                    Icon(Icons.Default.Error, contentDescription = "No disponible", tint = Color(0xFFEF5350), modifier = Modifier.size(20.dp))
                                }
                            },
                            isError = isUsernameAvailable == false,
                            shape = RoundedCornerShape(12.dp),
                            colors = inputColors(),
                            modifier = Modifier.fillMaxWidth().testTag("reg_username_input")
                        )

                        if (isUsernameAvailable == false) {
                            Text(
                                text = "⚠️ Este nombre de usuario ya está usado. Por favor elige otro.",
                                color = Color(0xFFEF5350),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(top = 4.dp, start = 4.dp)
                            )
                        } else if (isUsernameAvailable == true) {
                            Text(
                                text = "✓ Nombre de usuario disponible",
                                color = Color(0xFF66BB6A),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                modifier = Modifier.padding(top = 4.dp, start = 4.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Contraseña
                        OutlinedTextField(
                            value = regPassword,
                            onValueChange = { regPassword = it; errorMessage = null },
                            placeholder = { Text("Contraseña", color = DriyTextSecondary, fontSize = 13.sp) },
                            singleLine = true,
                            visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                            leadingIcon = {
                                Icon(Icons.Default.Lock, contentDescription = null, tint = DriyGold, modifier = Modifier.size(20.dp))
                            },
                            trailingIcon = {
                                IconButton(onClick = { isPasswordVisible = !isPasswordVisible }) {
                                    Icon(
                                        imageVector = if (isPasswordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                        contentDescription = null,
                                        tint = DriyTextSecondary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            },
                            shape = RoundedCornerShape(12.dp),
                            colors = inputColors(),
                            modifier = Modifier.fillMaxWidth().testTag("reg_password_input")
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Teléfono
                        OutlinedTextField(
                            value = regPhone,
                            onValueChange = { regPhone = it; errorMessage = null },
                            placeholder = { Text("Número telefónico / WhatsApp (ej: 987654321)", color = DriyTextSecondary, fontSize = 13.sp) },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            leadingIcon = {
                                Icon(Icons.Default.Phone, contentDescription = null, tint = WhatsAppGreen, modifier = Modifier.size(20.dp))
                            },
                            trailingIcon = {
                                if (isCheckingPhone) {
                                    CircularProgressIndicator(strokeWidth = 2.dp, color = WhatsAppGreen, modifier = Modifier.size(18.dp))
                                } else if (isPhoneAvailable == true) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = "Disponible", tint = Color(0xFF66BB6A), modifier = Modifier.size(20.dp))
                                } else if (isPhoneAvailable == false) {
                                    Icon(Icons.Default.Error, contentDescription = "No disponible", tint = Color(0xFFEF5350), modifier = Modifier.size(20.dp))
                                }
                            },
                            isError = isPhoneAvailable == false,
                            shape = RoundedCornerShape(12.dp),
                            colors = inputColors(),
                            modifier = Modifier.fillMaxWidth().testTag("reg_phone_input")
                        )

                        if (isPhoneAvailable == false) {
                            Column(modifier = Modifier.padding(top = 4.dp, start = 4.dp)) {
                                Text(
                                    text = if (existingPhoneOwner != null) {
                                        "⚠️ Este número ya está asociado a la cuenta de @$existingPhoneOwner. Por favor inicia sesión."
                                    } else {
                                        "⚠️ Este número ya está registrado en otra cuenta. Por favor inicia sesión."
                                    },
                                    color = Color(0xFFEF5350),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                TextButton(
                                    onClick = {
                                        loginPhone = regPhone
                                        if (existingPhoneOwner != null) {
                                            loginUsername = existingPhoneOwner ?: ""
                                        }
                                        currentStep = AuthStep.LOGIN_FORM
                                        errorMessage = null
                                    },
                                    contentPadding = PaddingValues(horizontal = 0.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "👉 Iniciar sesión con esta cuenta",
                                        color = DriyGold,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        } else if (isPhoneAvailable == true) {
                            Text(
                                text = "✓ Número de WhatsApp disponible para registro",
                                color = Color(0xFF66BB6A),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                modifier = Modifier.padding(top = 4.dp, start = 4.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        Button(
                            onClick = {
                                if (regFirstName.isBlank()) {
                                    errorMessage = "Por favor ingresa tu nombre."
                                    return@Button
                                }
                                if (regLastName.isBlank()) {
                                    errorMessage = "Por favor ingresa tu apellido."
                                    return@Button
                                }
                                val cleanUsername = GlobalUserSyncClient.cleanKey(regUsername)
                                if (cleanUsername.length < 3) {
                                    errorMessage = "El nombre de usuario debe tener al menos 3 caracteres."
                                    return@Button
                                }
                                if (regPassword.length < 4) {
                                    errorMessage = "La contraseña debe tener al menos 4 caracteres."
                                    return@Button
                                }
                                if (regPhone.trim().length < 6) {
                                    errorMessage = "Por favor ingresa un número de teléfono válido para WhatsApp."
                                    return@Button
                                }
                                if (isUsernameAvailable == false) {
                                    errorMessage = "⚠️ Este nombre de usuario ya está usado. Por favor elige otro."
                                    return@Button
                                }
                                if (isPhoneAvailable == false) {
                                    errorMessage = "⚠️ Ya existe una cuenta asociada a este número. Por favor inicia sesión."
                                    return@Button
                                }

                                isSubmittingForm = true
                                coroutineScope.launch {
                                    val isTaken = onCheckUsernameTaken(cleanUsername)
                                    if (isTaken) {
                                        isUsernameAvailable = false
                                        errorMessage = "⚠️ Este nombre de usuario ya está usado. Por favor elige otro."
                                        isSubmittingForm = false
                                        return@launch
                                    }
                                    val isPhoneUsed = onCheckPhoneTaken(regPhone.trim())
                                    if (isPhoneUsed) {
                                        isPhoneAvailable = false
                                        errorMessage = "⚠️ Ya existe una cuenta asociada a este número. Por favor inicia sesión."
                                        isSubmittingForm = false
                                        return@launch
                                    }
                                    isSubmittingForm = false
                                    errorMessage = null
                                    dispatchWhatsAppCode(regPhone.trim(), cleanUsername, "REGISTER") {
                                        currentStep = AuthStep.REGISTER_WHATSAPP_VERIFY
                                    }
                                }
                            },
                            enabled = !isSubmittingForm && isUsernameAvailable != false && isPhoneAvailable != false && !isCheckingUsername && !isCheckingPhone,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = WhatsAppGreen,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .testTag("btn_submit_register")
                        ) {
                            if (isSubmittingForm) {
                                CircularProgressIndicator(color = Color.White, strokeWidth = 2.dp, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Comprobando...", fontWeight = FontWeight.Bold)
                            } else {
                                Icon(Icons.Default.Phone, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Continuar y Enviar Código por WhatsApp", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("¿Ya tienes cuenta?", color = DriyTextSecondary, fontSize = 13.sp)
                            Spacer(modifier = Modifier.width(4.dp))
                            TextButton(
                                onClick = {
                                    errorMessage = null
                                    successMessage = null
                                    currentStep = AuthStep.LOGIN_FORM
                                }
                            ) {
                                Text("Inicia sesión", color = DriyGold, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                // ==================== STEP 3: LOGIN FORM ====================
                else if (currentStep == AuthStep.LOGIN_FORM) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 16.dp)
                    ) {
                        Text(
                            text = "Iniciar sesión",
                            color = DriyTextPrimary,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Ingresa tus credenciales y verifica tu cuenta con WhatsApp",
                            color = DriyTextSecondary,
                            fontSize = 12.sp
                        )
                        Spacer(modifier = Modifier.height(16.dp))

                        // Usuario
                        OutlinedTextField(
                            value = loginUsername,
                            onValueChange = { loginUsername = it; errorMessage = null },
                            placeholder = { Text("Nombre de usuario", color = DriyTextSecondary, fontSize = 13.sp) },
                            singleLine = true,
                            leadingIcon = {
                                Icon(Icons.Default.Person, contentDescription = null, tint = DriyGold, modifier = Modifier.size(20.dp))
                            },
                            shape = RoundedCornerShape(12.dp),
                            colors = inputColors(),
                            modifier = Modifier.fillMaxWidth().testTag("login_username_input")
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Contraseña
                        OutlinedTextField(
                            value = loginPassword,
                            onValueChange = { loginPassword = it; errorMessage = null },
                            placeholder = { Text("Contraseña", color = DriyTextSecondary, fontSize = 13.sp) },
                            singleLine = true,
                            visualTransformation = if (isLoginPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                            leadingIcon = {
                                Icon(Icons.Default.Lock, contentDescription = null, tint = DriyGold, modifier = Modifier.size(20.dp))
                            },
                            trailingIcon = {
                                IconButton(onClick = { isLoginPasswordVisible = !isLoginPasswordVisible }) {
                                    Icon(
                                        imageVector = if (isLoginPasswordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                        contentDescription = null,
                                        tint = DriyTextSecondary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            },
                            shape = RoundedCornerShape(12.dp),
                            colors = inputColors(),
                            modifier = Modifier.fillMaxWidth().testTag("login_password_input")
                        )

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 4.dp, bottom = 4.dp),
                            horizontalArrangement = Arrangement.End
                        ) {
                            TextButton(
                                onClick = {
                                    errorMessage = null
                                    successMessage = null
                                    currentStep = AuthStep.RECOVER_ACCOUNT_FORM
                                },
                                contentPadding = PaddingValues(0.dp)
                            ) {
                                Text(
                                    text = "¿Olvidaste tu contraseña? Recuperar cuenta",
                                    color = DriyGold,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }

                        // Teléfono
                        OutlinedTextField(
                            value = loginPhone,
                            onValueChange = { loginPhone = it; errorMessage = null },
                            placeholder = { Text("Teléfono / WhatsApp registrado", color = DriyTextSecondary, fontSize = 13.sp) },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            leadingIcon = {
                                Icon(Icons.Default.Phone, contentDescription = null, tint = WhatsAppGreen, modifier = Modifier.size(20.dp))
                            },
                            shape = RoundedCornerShape(12.dp),
                            colors = inputColors(),
                            modifier = Modifier.fillMaxWidth().testTag("login_phone_input")
                        )

                        Spacer(modifier = Modifier.height(20.dp))

                        Button(
                            onClick = {
                                if (loginUsername.isBlank()) {
                                    errorMessage = "Por favor ingresa tu nombre de usuario."
                                    return@Button
                                }
                                if (loginPassword.isBlank()) {
                                    errorMessage = "Por favor ingresa tu contraseña."
                                    return@Button
                                }
                                if (loginPhone.isBlank()) {
                                    errorMessage = "Por favor ingresa tu número telefónico."
                                    return@Button
                                }

                                isSubmittingForm = true
                                coroutineScope.launch {
                                    val validationError = onValidateLoginCredentials(
                                        loginUsername.trim(),
                                        loginPassword.trim(),
                                        loginPhone.trim()
                                    )
                                    isSubmittingForm = false
                                    if (validationError != null) {
                                        errorMessage = validationError
                                    } else {
                                        errorMessage = null
                                        dispatchWhatsAppCode(loginPhone.trim(), loginUsername.trim(), "LOGIN") {
                                            currentStep = AuthStep.LOGIN_WHATSAPP_VERIFY
                                        }
                                    }
                                }
                            },
                            enabled = !isSubmittingForm,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = WhatsAppGreen,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .testTag("btn_submit_login")
                        ) {
                            if (isSubmittingForm) {
                                CircularProgressIndicator(color = Color.White, strokeWidth = 2.dp, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Verificando credenciales...", fontWeight = FontWeight.Bold)
                            } else {
                                Icon(Icons.Default.Phone, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Verificar y Enviar por WhatsApp", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("¿No tienes cuenta?", color = DriyTextSecondary, fontSize = 13.sp)
                            Spacer(modifier = Modifier.width(4.dp))
                            TextButton(
                                onClick = {
                                    errorMessage = null
                                    successMessage = null
                                    currentStep = AuthStep.REGISTER_FORM
                                }
                            ) {
                                Text("Crear cuenta", color = DriyGold, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                // ==================== STEP 4: RECOVER ACCOUNT FORM ====================
                else if (currentStep == AuthStep.RECOVER_ACCOUNT_FORM) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 16.dp)
                    ) {
                        Text(
                            text = "Recuperar cuenta",
                            color = DriyTextPrimary,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Ingresa tu nombre, apellido y tu número telefónico registrado para verificar tu identidad y restablecer tu contraseña.",
                            color = DriyTextSecondary,
                            fontSize = 12.sp,
                            lineHeight = 17.sp
                        )
                        Spacer(modifier = Modifier.height(18.dp))

                        Card(
                            colors = CardDefaults.cardColors(containerColor = DriySurfaceVariant),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, DriyGold.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Shield,
                                    contentDescription = null,
                                    tint = DriyGold,
                                    modifier = Modifier.size(22.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = "Verificación segura: Si los datos coinciden con tu cuenta, podrás establecer una nueva contraseña de inmediato.",
                                    color = DriyTextPrimary,
                                    fontSize = 12.sp,
                                    lineHeight = 16.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(18.dp))

                        Text(
                            text = "NOMBRE REGISTRADO *",
                            color = DriyGold,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(
                            value = recoverFirstName,
                            onValueChange = { recoverFirstName = it; errorMessage = null },
                            placeholder = { Text("Ej: Carlos, María...", color = DriyTextSecondary, fontSize = 13.sp) },
                            singleLine = true,
                            leadingIcon = {
                                Icon(Icons.Default.Person, contentDescription = null, tint = DriyGold, modifier = Modifier.size(20.dp))
                            },
                            shape = RoundedCornerShape(12.dp),
                            colors = inputColors(),
                            modifier = Modifier.fillMaxWidth().testTag("recover_first_name_input")
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = "APELLIDO REGISTRADO *",
                            color = DriyGold,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(
                            value = recoverLastName,
                            onValueChange = { recoverLastName = it; errorMessage = null },
                            placeholder = { Text("Ej: Sánchez, Gómez...", color = DriyTextSecondary, fontSize = 13.sp) },
                            singleLine = true,
                            leadingIcon = {
                                Icon(Icons.Default.Person, contentDescription = null, tint = DriyGold, modifier = Modifier.size(20.dp))
                            },
                            shape = RoundedCornerShape(12.dp),
                            colors = inputColors(),
                            modifier = Modifier.fillMaxWidth().testTag("recover_last_name_input")
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = "NÚMERO TELEFÓNICO / WHATSAPP *",
                            color = DriyGold,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(
                            value = recoverPhone,
                            onValueChange = { recoverPhone = it; errorMessage = null },
                            placeholder = { Text("Ej: 987654321", color = DriyTextSecondary, fontSize = 13.sp) },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            leadingIcon = {
                                Icon(Icons.Default.Phone, contentDescription = null, tint = WhatsAppGreen, modifier = Modifier.size(20.dp))
                            },
                            shape = RoundedCornerShape(12.dp),
                            colors = inputColors(),
                            modifier = Modifier.fillMaxWidth().testTag("recover_phone_input")
                        )

                        Spacer(modifier = Modifier.height(24.dp))

                        Button(
                            onClick = {
                                if (recoverFirstName.isBlank()) {
                                    errorMessage = "Por favor ingresa tu nombre registrado."
                                    return@Button
                                }
                                if (recoverLastName.isBlank()) {
                                    errorMessage = "Por favor ingresa tu apellido registrado."
                                    return@Button
                                }
                                if (recoverPhone.trim().length < 6) {
                                    errorMessage = "Por favor ingresa tu número telefónico registrado."
                                    return@Button
                                }

                                isVerifyingRecovery = true
                                errorMessage = null
                                coroutineScope.launch {
                                    val matchedUser = onVerifyIdentityForRecovery(
                                        recoverFirstName.trim(),
                                        recoverLastName.trim(),
                                        recoverPhone.trim()
                                    )
                                    isVerifyingRecovery = false
                                    if (matchedUser != null) {
                                        verifiedUserForReset = matchedUser
                                        resetNewPassword = ""
                                        resetConfirmPassword = ""
                                        currentStep = AuthStep.RESET_PASSWORD_SCREEN
                                    } else {
                                        errorMessage = "No se encontró ninguna cuenta que coincida con ese nombre, apellido y número telefónico. Por favor verifica los datos ingresados."
                                    }
                                }
                            },
                            enabled = !isVerifyingRecovery,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = DriyGold,
                                contentColor = DriyBackground
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .testTag("btn_verify_recovery")
                        ) {
                            if (isVerifyingRecovery) {
                                CircularProgressIndicator(color = DriyBackground, strokeWidth = 2.dp, modifier = Modifier.size(22.dp))
                                Spacer(modifier = Modifier.width(10.dp))
                                Text("Comprobando identidad...", fontWeight = FontWeight.Bold)
                            } else {
                                Icon(Icons.Default.Security, contentDescription = null, tint = DriyBackground, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Verificar Datos y Continuar", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("¿Recordaste tu contraseña?", color = DriyTextSecondary, fontSize = 13.sp)
                            Spacer(modifier = Modifier.width(4.dp))
                            TextButton(
                                onClick = {
                                    errorMessage = null
                                    successMessage = null
                                    currentStep = AuthStep.LOGIN_FORM
                                }
                            ) {
                                Text("Inicia sesión", color = DriyGold, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                // ==================== STEP 5: RESET PASSWORD SCREEN ====================
                else if (currentStep == AuthStep.RESET_PASSWORD_SCREEN) {
                    val user = verifiedUserForReset
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 16.dp)
                    ) {
                        Text(
                            text = "Restablecer contraseña",
                            color = DriyTextPrimary,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Crea una nueva contraseña segura para tu cuenta.",
                            color = DriyTextSecondary,
                            fontSize = 12.sp
                        )
                        Spacer(modifier = Modifier.height(16.dp))

                        Card(
                            colors = CardDefaults.cardColors(containerColor = WhatsAppDarkBg),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, WhatsAppGreen.copy(alpha = 0.6f), RoundedCornerShape(14.dp))
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(42.dp)
                                        .clip(CircleShape)
                                        .background(WhatsAppGreen),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Identidad Verificada con Éxito",
                                        color = WhatsAppGreen,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "${user?.displayName ?: ""} (@${user?.username ?: ""})",
                                        color = Color.White,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        text = "Teléfono: +${user?.phoneNumber ?: ""}",
                                        color = Color(0xFFC8E6C9),
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(18.dp))

                        Text(
                            text = "NUEVA CONTRASEÑA *",
                            color = DriyGold,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(
                            value = resetNewPassword,
                            onValueChange = { resetNewPassword = it; errorMessage = null },
                            placeholder = { Text("Escribe tu nueva contraseña", color = DriyTextSecondary, fontSize = 13.sp) },
                            singleLine = true,
                            visualTransformation = if (isResetNewPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                            leadingIcon = {
                                Icon(Icons.Default.Lock, contentDescription = null, tint = DriyGold, modifier = Modifier.size(20.dp))
                            },
                            trailingIcon = {
                                IconButton(onClick = { isResetNewPasswordVisible = !isResetNewPasswordVisible }) {
                                    Icon(
                                        imageVector = if (isResetNewPasswordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                        contentDescription = null,
                                        tint = DriyTextSecondary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            },
                            shape = RoundedCornerShape(12.dp),
                            colors = inputColors(),
                            modifier = Modifier.fillMaxWidth().testTag("reset_new_password_input")
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        Text(
                            text = "CONFIRMAR NUEVA CONTRASEÑA *",
                            color = DriyGold,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(
                            value = resetConfirmPassword,
                            onValueChange = { resetConfirmPassword = it; errorMessage = null },
                            placeholder = { Text("Repite tu nueva contraseña", color = DriyTextSecondary, fontSize = 13.sp) },
                            singleLine = true,
                            visualTransformation = if (isResetConfirmPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                            leadingIcon = {
                                Icon(Icons.Default.Key, contentDescription = null, tint = DriyGold, modifier = Modifier.size(20.dp))
                            },
                            trailingIcon = {
                                IconButton(onClick = { isResetConfirmPasswordVisible = !isResetConfirmPasswordVisible }) {
                                    Icon(
                                        imageVector = if (isResetConfirmPasswordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                        contentDescription = null,
                                        tint = DriyTextSecondary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            },
                            shape = RoundedCornerShape(12.dp),
                            colors = inputColors(),
                            modifier = Modifier.fillMaxWidth().testTag("reset_confirm_password_input")
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        val isLengthValid = resetNewPassword.length >= 4
                        val isMatchValid = resetNewPassword.isNotBlank() && resetNewPassword == resetConfirmPassword

                        Card(
                            colors = CardDefaults.cardColors(containerColor = DriySurface),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = "Requisitos de seguridad:",
                                    color = DriyTextSecondary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = if (isLengthValid) Icons.Default.CheckCircle else Icons.Default.Shield,
                                        contentDescription = null,
                                        tint = if (isLengthValid) Color(0xFF66BB6A) else DriyTextSecondary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "Al menos 4 caracteres",
                                        color = if (isLengthValid) Color(0xFFC8E6C9) else DriyTextSecondary,
                                        fontSize = 11.sp
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = if (isMatchValid) Icons.Default.CheckCircle else Icons.Default.Shield,
                                        contentDescription = null,
                                        tint = if (isMatchValid) Color(0xFF66BB6A) else DriyTextSecondary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "Ambas contraseñas deben coincidir exactamente",
                                        color = if (isMatchValid) Color(0xFFC8E6C9) else DriyTextSecondary,
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(22.dp))

                        Button(
                            onClick = {
                                if (resetNewPassword.length < 4) {
                                    errorMessage = "La nueva contraseña debe tener al menos 4 caracteres."
                                    return@Button
                                }
                                if (resetNewPassword != resetConfirmPassword) {
                                    errorMessage = "Las contraseñas no coinciden. Por favor revísalas."
                                    return@Button
                                }
                                val targetUser = verifiedUserForReset
                                if (targetUser == null) {
                                    errorMessage = "Error al identificar la cuenta. Por favor intenta de nuevo."
                                    return@Button
                                }
                                isSubmittingPasswordReset = true
                                errorMessage = null
                                coroutineScope.launch {
                                    val success = onResetPassword(targetUser.id, resetNewPassword)
                                    isSubmittingPasswordReset = false
                                    if (success) {
                                        loginUsername = targetUser.username
                                        loginPassword = resetNewPassword
                                        loginPhone = targetUser.phoneNumber
                                        successMessage = "¡Contraseña restablecida con éxito! Inicia sesión con tu nueva contraseña."
                                        currentStep = AuthStep.LOGIN_FORM
                                    } else {
                                        errorMessage = "Hubo un problema al guardar la nueva contraseña. Por favor intenta de nuevo."
                                    }
                                }
                            },
                            enabled = !isSubmittingPasswordReset && isLengthValid && isMatchValid,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = DriyGold,
                                contentColor = DriyBackground
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .testTag("btn_confirm_reset_password")
                        ) {
                            if (isSubmittingPasswordReset) {
                                CircularProgressIndicator(color = DriyBackground, strokeWidth = 2.dp, modifier = Modifier.size(22.dp))
                                Spacer(modifier = Modifier.width(10.dp))
                                Text("Guardando nueva contraseña...", fontWeight = FontWeight.Bold)
                            } else {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = DriyBackground, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Guardar Nueva Contraseña", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                // ==================== STEP 6: WHATSAPP VERIFICATION SCREEN ====================
                else if (currentStep == AuthStep.REGISTER_WHATSAPP_VERIFY || currentStep == AuthStep.LOGIN_WHATSAPP_VERIFY) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(WhatsAppGreen.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Phone,
                                contentDescription = null,
                                tint = WhatsAppGreen,
                                modifier = Modifier.size(32.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Verificación por WhatsApp",
                            color = DriyTextPrimary,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))

                        val formattedPhone = DriyWhatsAppVerificationManager.formatPhoneForWhatsApp(targetPhoneState)
                        Text(
                            text = "Código de seguridad enviado a tu WhatsApp:\n+$formattedPhone",
                            color = DriyTextSecondary,
                            fontSize = 13.sp,
                            textAlign = TextAlign.Center,
                            lineHeight = 18.sp
                        )
                        Spacer(modifier = Modifier.height(16.dp))

                        Card(
                            colors = CardDefaults.cardColors(containerColor = WhatsAppDarkBg),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, WhatsAppGreen.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = WhatsAppGreen,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Verificación Segura del Servidor",
                                        color = WhatsAppGreen,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "El código OTP de 6 dígitos ha sido emitido de forma segura en la nube. Ingrésalo abajo para validar la titularidad de tu número.",
                                        color = Color(0xFFC8E6C9),
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        OutlinedButton(
                            onClick = {
                                val currentUsername = if (currentStep == AuthStep.REGISTER_WHATSAPP_VERIFY) regUsername.trim() else loginUsername.trim()
                                DriyWhatsAppVerificationManager.reopenWhatsApp(
                                    context = context,
                                    phoneNumber = targetPhoneState,
                                    username = currentUsername
                                )
                            },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = WhatsAppGreen),
                            border = androidx.compose.foundation.BorderStroke(1.dp, WhatsAppGreen.copy(alpha = 0.7f)),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth(0.9f)
                                .height(44.dp)
                                .testTag("btn_reopen_whatsapp")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Phone,
                                contentDescription = "WhatsApp",
                                tint = WhatsAppGreen,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Reabrir chat en WhatsApp",
                                color = WhatsAppGreen,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(18.dp))

                        OutlinedTextField(
                            value = enteredCode,
                            onValueChange = {
                                if (it.length <= 6) {
                                    enteredCode = it.filter { char -> char.isDigit() }
                                    errorMessage = null
                                }
                            },
                            placeholder = { Text("000000", color = DriyTextSecondary, fontSize = 24.sp, letterSpacing = 8.sp) },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                            textStyle = androidx.compose.ui.text.TextStyle(
                                color = DriyGold,
                                fontSize = 26.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center,
                                letterSpacing = 8.sp
                            ),
                            shape = RoundedCornerShape(14.dp),
                            colors = inputColors(),
                            modifier = Modifier
                                .fillMaxWidth(0.85f)
                                .testTag("whatsapp_code_input")
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        if (resendTimer > 0) {
                            Text(
                                text = "Reenviar código por WhatsApp en ${resendTimer}s",
                                color = DriyTextSecondary,
                                fontSize = 12.sp
                            )
                        } else {
                            TextButton(
                                onClick = {
                                    val currentUsername = if (currentStep == AuthStep.REGISTER_WHATSAPP_VERIFY) regUsername.trim() else loginUsername.trim()
                                    val currentPurpose = if (currentStep == AuthStep.REGISTER_WHATSAPP_VERIFY) "REGISTER" else "LOGIN"
                                    dispatchWhatsAppCode(targetPhoneState, currentUsername, currentPurpose) {}
                                },
                                enabled = !isRequestingWhatsAppCode
                            ) {
                                if (isRequestingWhatsAppCode) {
                                    CircularProgressIndicator(color = WhatsAppGreen, strokeWidth = 2.dp, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Solicitando...", color = WhatsAppGreen, fontSize = 13.sp)
                                } else {
                                    Text("Reenviar código por WhatsApp", color = WhatsAppGreen, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        Button(
                            onClick = {
                                if (enteredCode.length != 6) {
                                    errorMessage = "Por favor ingresa el código de 6 dígitos que te enviamos a tu WhatsApp."
                                    return@Button
                                }
                                isVerifyingCodeOnServer = true
                                errorMessage = null
                                val activeUsername = if (currentStep == AuthStep.REGISTER_WHATSAPP_VERIFY) regUsername.trim() else loginUsername.trim()

                                coroutineScope.launch {
                                    val verifyResult = DriyWhatsAppVerificationManager.verifyCode(
                                        phoneNumber = targetPhoneState,
                                        code = enteredCode.trim(),
                                        username = activeUsername
                                    )
                                    isVerifyingCodeOnServer = false
                                    verifyResult.onSuccess {
                                        errorMessage = null
                                        if (currentStep == AuthStep.REGISTER_WHATSAPP_VERIFY) {
                                            onRegisterUser(
                                                regFirstName,
                                                regLastName,
                                                regUsername,
                                                regPassword,
                                                regPhone,
                                                { },
                                                { err -> errorMessage = err }
                                            )
                                        } else {
                                            onLoginUser(
                                                loginUsername,
                                                loginPassword,
                                                loginPhone,
                                                { },
                                                { err -> errorMessage = err }
                                            )
                                        }
                                    }.onFailure { err ->
                                        errorMessage = err.message ?: "El código ingresado es incorrecto o ha expirado."
                                    }
                                }
                            },
                            enabled = !isAuthenticating && !isVerifyingCodeOnServer && !isRequestingWhatsAppCode,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = DriyGold,
                                contentColor = DriyBackground
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .testTag("btn_confirm_whatsapp_code")
                        ) {
                            if (isAuthenticating || isVerifyingCodeOnServer) {
                                CircularProgressIndicator(color = DriyBackground, strokeWidth = 2.dp, modifier = Modifier.size(22.dp))
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    if (isVerifyingCodeOnServer) "Validando código en el servidor..." else "Iniciando sesión...",
                                    fontWeight = FontWeight.Bold
                                )
                            } else {
                                Text(
                                    text = if (currentStep == AuthStep.REGISTER_WHATSAPP_VERIFY) "Verificar y Continuar a Mis Gustos" else "Verificar e Iniciar Sesión",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                // Footer
                Text(
                    text = "DriyMusic • Todos los derechos reservados 2026",
                    color = DriyTextSecondary.copy(alpha = 0.5f),
                    fontSize = 11.sp,
                    modifier = Modifier.padding(top = 16.dp)
                )
            }
        }
    }
}

@Composable
private fun inputColors() = OutlinedTextFieldDefaults.colors(
    focusedContainerColor = DriySurface,
    unfocusedContainerColor = DriySurface,
    focusedBorderColor = DriyGold,
    unfocusedBorderColor = DriyDivider,
    focusedTextColor = DriyTextPrimary,
    unfocusedTextColor = DriyTextPrimary,
    cursorColor = DriyGold
)
