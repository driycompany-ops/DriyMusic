package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.graphics.Color

@Composable
fun DriyMusicTheme(
    themeState: AppThemeState = ThemeManager.themeState.collectAsState().value,
    content: @Composable () -> Unit
) {
    val dynamicColorScheme = darkColorScheme(
        primary = themeState.accentColor,
        onPrimary = themeState.backgroundColor,
        primaryContainer = themeState.surfaceColor,
        onPrimaryContainer = themeState.accentColor,
        secondary = themeState.accentColor,
        onSecondary = themeState.backgroundColor,
        secondaryContainer = themeState.surfaceColor,
        onSecondaryContainer = themeState.textColor,
        tertiary = themeState.accentColor.copy(alpha = 0.85f),
        onTertiary = themeState.backgroundColor,
        background = themeState.backgroundColor,
        onBackground = themeState.textColor,
        surface = themeState.surfaceColor,
        onSurface = themeState.textColor,
        surfaceVariant = themeState.surfaceColor,
        onSurfaceVariant = themeState.textSecondaryColor,
        outline = themeState.accentColor.copy(alpha = 0.35f),
        error = DriyError,
        onError = Color.White
    )

    CompositionLocalProvider(
        LocalDriyTheme provides themeState
    ) {
        MaterialTheme(
            colorScheme = dynamicColorScheme,
            typography = Typography,
            content = content
        )
    }
}

@Composable
fun DriyStreamTheme(
    themeState: AppThemeState = ThemeManager.themeState.collectAsState().value,
    content: @Composable () -> Unit
) = DriyMusicTheme(themeState = themeState, content = content)
