package com.example.ui.theme

import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

val LocalDriyTheme = staticCompositionLocalOf { AppThemeState() }

val DriyBackground: Color
    @Composable get() = LocalDriyTheme.current.backgroundColor

val DriyScreenBackground: Color
    @Composable get() = if (LocalDriyTheme.current.backgroundPhotoUri.isNullOrBlank()) {
        LocalDriyTheme.current.backgroundColor
    } else {
        Color.Transparent
    }

val DriySurface: Color
    @Composable get() = LocalDriyTheme.current.surfaceColor

val DriySurfaceVariant: Color
    @Composable get() = LocalDriyTheme.current.surfaceColor.copy(alpha = 0.85f)

val DriyGold: Color
    @Composable get() = LocalDriyTheme.current.accentColor

val DriyGoldLight: Color
    @Composable get() = LocalDriyTheme.current.accentColor.copy(alpha = 0.85f)

val DriyTextPrimary: Color
    @Composable get() = LocalDriyTheme.current.textColor

val DriyTextSecondary: Color
    @Composable get() = LocalDriyTheme.current.textSecondaryColor

val DriyDivider: Color
    @Composable get() = LocalDriyTheme.current.accentColor.copy(alpha = 0.25f)

val DriyError: Color = Color(0xFFCF6679)
