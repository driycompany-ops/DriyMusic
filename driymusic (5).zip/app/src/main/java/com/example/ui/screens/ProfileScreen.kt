package com.example.ui.screens

import android.net.Uri
import kotlinx.coroutines.launch
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.PickVisualMediaRequest
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.ui.res.painterResource
import com.example.R
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import android.content.Context
import android.content.ClipData
import android.content.ClipboardManager
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material.icons.filled.Tune
import com.example.BuildConfig
import com.example.data.model.ReferralProgressState
import com.example.service.DriyReferralManager
import com.example.ui.components.AdminPublishUpdateDialog
import com.example.ui.components.AppUpdateDialog
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.LinearProgressIndicator
import android.widget.Toast
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material.icons.filled.Headphones
import coil.compose.AsyncImage
import coil.compose.SubcomposeAsyncImage
import com.example.ui.components.DriyUserAvatar
import com.example.data.model.JamSessionState
import com.example.service.PlayerState
import com.example.data.model.UserEntity
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Verified
import com.example.data.model.AssistantAnimationMode
import com.example.data.model.VirtualAssistantCatalog
import com.example.service.VirtualAssistantManager
import com.example.ui.components.AdminCodeGeneratorDialog
import com.example.ui.components.AnimatedSpriteAvatar
import com.example.ui.components.AppearanceCustomizerDialog
import com.example.ui.components.JamDialog
import com.example.ui.components.SubscriptionPlanDialog
import com.example.ui.components.VirtualAssistantBottomSheet
import com.example.ui.theme.DriyBackground
import com.example.ui.theme.DriyDivider
import com.example.ui.theme.DriyGold
import com.example.ui.theme.DriySurface
import com.example.ui.theme.DriySurfaceVariant
import com.example.ui.theme.DriyTextPrimary
import com.example.ui.theme.DriyTextSecondary
import com.example.ui.theme.ThemeManager
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ProfileScreen(
    user: UserEntity?,
    allRegisteredUsers: List<UserEntity> = emptyList(),
    isNativeIslandDetected: Boolean,
    islandMode: String = "AUTO",
    onSetIslandMode: (String) -> Unit = {},
    hasOverlayPermission: Boolean,
    onRequestOverlayPermission: () -> Unit,
    jamState: JamSessionState = JamSessionState.Idle,
    playerState: PlayerState? = null,
    onCreateJam: () -> Unit = {},
    onJoinJam: (String, (Boolean, String) -> Unit) -> Unit = { _, _ -> },
    onLeaveJam: () -> Unit = {},
    onUpdateDisplayName: (String) -> Unit = {},
    onUpdatePhotoUri: (Uri) -> Unit = {},
    onUpdatePresetPhoto: (String) -> Unit = {},
    onSignOut: () -> Unit,
    onDeleteAccount: () -> Unit = {}
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val scrollState = rememberScrollState()
    var showEditDialog by remember { mutableStateOf(false) }
    var editNameText by remember(user?.displayName) { mutableStateOf(user?.displayName ?: "") }
    var showAvatarDialog by remember { mutableStateOf(false) }
    var showDeleteDialog by remember { mutableStateOf(false) }
    var showAssistantSheet by remember { mutableStateOf(false) }
    var showJamDialog by remember { mutableStateOf(false) }
    var showThemeCustomizer by remember { mutableStateOf(false) }
    var showSubscriptionDialog by remember { mutableStateOf(false) }
    var subscriptionInitialTab by remember { mutableIntStateOf(0) }
    var showAdminCodeGenerator by remember { mutableStateOf(false) }
    var showAdminPublishUpdate by remember { mutableStateOf(false) }
    var manualUpdateInfo by remember { mutableStateOf<com.example.service.AppUpdateInfo?>(null) }
    var isCheckingUpdatesManually by remember { mutableStateOf(false) }

    // Referral 20-friends program state
    var referralProgress by remember { mutableStateOf(ReferralProgressState()) }
    var isReferralLoading by remember { mutableStateOf(false) }
    var showFriendsList by remember { mutableStateOf(false) }
    var isClaimingReward by remember { mutableStateOf(false) }

    val refreshReferrals: () -> Unit = {
        val uname = user?.username ?: ""
        if (uname.isNotBlank()) {
            coroutineScope.launch {
                isReferralLoading = true
                try {
                    val res = DriyReferralManager.getReferralProgress(uname)
                    referralProgress = res
                } catch (e: Exception) {
                    // ignore
                } finally {
                    isReferralLoading = false
                }
            }
        }
    }

    androidx.compose.runtime.LaunchedEffect(user?.username, user?.isMasterAdmin) {
        if (user?.isMasterAdmin != true) {
            refreshReferrals()
        }
    }

    val themeState by ThemeManager.themeState.collectAsState()
    val assistantState by VirtualAssistantManager.state.collectAsState()

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            onUpdatePhotoUri(uri)
        }
    }

    val presetAvatars = listOf(
        "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400&q=80",
        "https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=400&q=80",
        "https://images.unsplash.com/photo-1527980965255-d3b416303d12?w=400&q=80",
        "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=400&q=80",
        "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&q=80",
        "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&q=80"
    )

    if (showAvatarDialog) {
        AlertDialog(
            onDismissRequest = { showAvatarDialog = false },
            containerColor = DriySurface,
            title = {
                Text(
                    text = "Cambiar Foto de Perfil",
                    color = DriyTextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            },
            text = {
                Column {
                    Text(
                        text = "Sube una imagen desde tu dispositivo o elige un avatar artístico de música:",
                        color = DriyTextSecondary,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Button(
                        onClick = {
                            showAvatarDialog = false
                            photoPickerLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = DriyGold,
                            contentColor = DriyBackground
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp)
                            .testTag("pick_from_gallery_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.PhotoLibrary,
                            contentDescription = null,
                            tint = DriyBackground,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Elegir de tu galería", fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "O ELIGE UN AVATAR CON ESTILO:",
                        color = DriyGold,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        presetAvatars.take(3).forEach { url ->
                            Box(
                                modifier = Modifier
                                    .size(62.dp)
                                    .clip(CircleShape)
                                    .border(2.dp, if (user?.photoUrl == url) DriyGold else DriyDivider, CircleShape)
                                    .clickable {
                                        onUpdatePresetPhoto(url)
                                        showAvatarDialog = false
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                SubcomposeAsyncImage(
                                    model = url,
                                    contentDescription = "Avatar preset",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize(),
                                    loading = {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxSize()
                                                .background(DriySurfaceVariant)
                                        )
                                    },
                                    error = {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxSize()
                                                .background(DriySurfaceVariant),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Person,
                                                contentDescription = null,
                                                tint = DriyGold.copy(alpha = 0.5f),
                                                modifier = Modifier.size(28.dp)
                                            )
                                        }
                                    }
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        presetAvatars.drop(3).take(3).forEach { url ->
                            Box(
                                modifier = Modifier
                                    .size(62.dp)
                                    .clip(CircleShape)
                                    .border(2.dp, if (user?.photoUrl == url) DriyGold else DriyDivider, CircleShape)
                                    .clickable {
                                        onUpdatePresetPhoto(url)
                                        showAvatarDialog = false
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                SubcomposeAsyncImage(
                                    model = url,
                                    contentDescription = "Avatar preset",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize(),
                                    loading = {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxSize()
                                                .background(DriySurfaceVariant)
                                        )
                                    },
                                    error = {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxSize()
                                                .background(DriySurfaceVariant),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Person,
                                                contentDescription = null,
                                                tint = DriyGold.copy(alpha = 0.5f),
                                                modifier = Modifier.size(28.dp)
                                            )
                                        }
                                    }
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showAvatarDialog = false }) {
                    Text("Cancelar", color = DriyTextSecondary)
                }
            }
        )
    }

    JamDialog(
        isOpen = showJamDialog,
        onDismiss = { showJamDialog = false },
        jamState = jamState,
        currentUser = user,
        playerState = playerState ?: PlayerState(),
        onCreateJam = onCreateJam,
        onJoinJam = onJoinJam,
        onLeaveJam = onLeaveJam
    )

    VirtualAssistantBottomSheet(
        visible = showAssistantSheet,
        onDismiss = { showAssistantSheet = false }
    )

    SubscriptionPlanDialog(
        isOpen = showSubscriptionDialog,
        onDismiss = { showSubscriptionDialog = false },
        user = user,
        initialTab = subscriptionInitialTab,
        onCodeRedeemedSuccessfully = {
            // Updated in database and firestore
        }
    )

    AdminCodeGeneratorDialog(
        isOpen = showAdminCodeGenerator,
        onDismiss = { showAdminCodeGenerator = false }
    )

    AdminPublishUpdateDialog(
        isOpen = showAdminPublishUpdate,
        onDismiss = { showAdminPublishUpdate = false }
    )

    AppUpdateDialog(
        updateInfo = manualUpdateInfo,
        onDismiss = { manualUpdateInfo = null }
    )

    if (showEditDialog) {
        AlertDialog(
            onDismissRequest = { showEditDialog = false },
            containerColor = DriySurface,
            title = {
                Text(
                    text = "Cambiar tu Nombre",
                    color = DriyTextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            },
            text = {
                Column {
                    Text(
                        text = "Elige cómo quieres que DriyMusic te salude y muestre tu perfil:",
                        color = DriyTextSecondary,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = editNameText,
                        onValueChange = { editNameText = it },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = DriyGold,
                            unfocusedBorderColor = DriyDivider,
                            focusedTextColor = DriyTextPrimary,
                            unfocusedTextColor = DriyTextPrimary,
                            focusedContainerColor = DriyBackground,
                            unfocusedContainerColor = DriyBackground
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (editNameText.isNotBlank()) {
                            onUpdateDisplayName(editNameText.trim())
                            showEditDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DriyGold, contentColor = DriyBackground)
                ) {
                    Text("Guardar", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditDialog = false }) {
                    Text("Cancelar", color = DriyTextSecondary)
                }
            }
        )
    }

    Surface(
        color = if (themeState.backgroundPhotoUri.isNullOrBlank()) DriyBackground else Color.Transparent,
        modifier = Modifier
            .fillMaxSize()
            .testTag("profile_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(horizontal = 20.dp, vertical = 20.dp)
                .padding(bottom = 80.dp)
        ) {
            Text(
                text = "Tu Cuenta",
                color = DriyTextPrimary,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(20.dp))

            Card(
                colors = CardDefaults.cardColors(containerColor = DriySurface),
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(18.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .testTag("profile_avatar_box"),
                        contentAlignment = Alignment.BottomEnd
                    ) {
                        DriyUserAvatar(
                            photoUrl = user?.photoUrl,
                            userId = user?.id,
                            displayName = user?.displayName,
                            size = 72.dp,
                            borderColor = DriyGold,
                            borderWidth = 2.dp,
                            onClick = { showAvatarDialog = true }
                        )
                        Box(
                            modifier = Modifier
                                .size(24.dp)
                                .clip(CircleShape)
                                .background(DriyGold)
                                .border(1.5.dp, DriySurface, CircleShape)
                                .clickable { showAvatarDialog = true },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.CameraAlt,
                                contentDescription = "Cambiar foto",
                                tint = DriyBackground,
                                modifier = Modifier.size(13.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(16.dp))

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = user?.displayName ?: "Usuario DriyMusic",
                                color = DriyTextPrimary,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                            IconButton(
                                onClick = {
                                    editNameText = user?.displayName ?: ""
                                    showEditDialog = true
                                },
                                modifier = Modifier
                                    .padding(start = 4.dp)
                                    .size(28.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Edit,
                                    contentDescription = "Editar nombre",
                                    tint = DriyGold,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = user?.email ?: "conectado@gmail.com",
                            color = DriyTextSecondary,
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "📸 Cambiar foto",
                            color = DriyGold,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier
                                .clickable { showAvatarDialog = true }
                                .padding(vertical = 2.dp)
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(DriyGold)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Sesión Activa y Persistente",
                                color = DriyGold,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Membresía & Suscripción DriyMusic Section
            val isAdmin = user?.isMasterAdmin == true
            val isSubActive = isAdmin || (user?.isSubscriptionActive == true)
            val remainingDays = if (isAdmin) 3650 else (user?.getRemainingDays() ?: 0)

            Text(
                text = "Membresía y Acceso",
                color = DriyGold,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(10.dp))

            Card(
                colors = CardDefaults.cardColors(containerColor = DriySurface),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.dp,
                        if (isSubActive) Color(0xFF4CAF50).copy(alpha = 0.8f) else DriyGold.copy(alpha = 0.35f),
                        RoundedCornerShape(16.dp)
                    )
                    .testTag("card_subscription_status")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(46.dp)
                                .clip(CircleShape)
                                .background(if (isSubActive) Color(0x334CAF50) else DriyGold.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (isSubActive) Icons.Default.Verified else Icons.Default.CreditCard,
                                contentDescription = null,
                                tint = if (isSubActive) Color(0xFF4CAF50) else DriyGold,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = if (isAdmin) "Cuenta de Propietario (Owner)" else if (isSubActive) "Membresía Activa" else "Plan de Acceso Mensual",
                                    color = DriyTextPrimary,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    color = if (isAdmin) Color(0xFFAB47BC) else if (isSubActive) Color(0xFF4CAF50) else DriyGold,
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = if (isAdmin) "DUEÑO / ADMIN" else if (isSubActive) "VIP" else "S/. 5/MES",
                                        color = if (isAdmin) Color.White else DriyBackground,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            if (isAdmin) {
                                Text(
                                    text = "👑 Propietario Master • Acceso Total Vitalicio sin restricciones ni candados",
                                    color = Color(0xFFCE93D8),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            } else if (isSubActive && user != null) {
                                val expDate = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date(user.subscriptionExpiresAt))
                                Text(
                                    text = "¡Acceso ilimitado! $remainingDays días restantes • Vence: $expDate",
                                    color = Color(0xFF81C784),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            } else {
                                Text(
                                    text = "Obtén tu código de 1 a 12 meses por Yape/Plin (28 días por mes)",
                                    color = DriyTextSecondary,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    HorizontalDivider(color = DriyDivider)
                    Spacer(modifier = Modifier.height(12.dp))

                    if (isAdmin) {
                        Button(
                            onClick = { showAdminCodeGenerator = true },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFFAB47BC),
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp)
                                .testTag("btn_open_admin_panel_direct")
                        ) {
                            Icon(
                                imageVector = Icons.Default.AdminPanelSettings,
                                contentDescription = null,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Abrir Panel de Administrador (Códigos)",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedButton(
                            onClick = { showAdminPublishUpdate = true },
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = Color(0xFFCE93D8)
                            ),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFAB47BC).copy(alpha = 0.6f)),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(44.dp)
                                .testTag("btn_publish_ota_update_admin")
                        ) {
                            Icon(
                                imageVector = Icons.Default.CloudUpload,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Publicar Actualización OTA a Usuarios",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    } else {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    subscriptionInitialTab = 0
                                    showSubscriptionDialog = true
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = DriyGold,
                                    contentColor = DriyBackground
                                ),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(40.dp)
                                    .testTag("btn_open_plan_payment")
                            ) {
                                Text(
                                    text = if (isSubActive) "Extender Plan" else "Adquirir Plan",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            OutlinedButton(
                                onClick = {
                                    subscriptionInitialTab = 1
                                    showSubscriptionDialog = true
                                },
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = DriyGold),
                                border = androidx.compose.foundation.BorderStroke(1.dp, DriyGold),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(40.dp)
                                    .testTag("btn_open_redeem_code")
                            ) {
                                Text(
                                    text = "Canjear Código",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }

            // Invitar Amigos y Recompensas (20 Amigos = 3 Meses Gratis) - Solo visible para usuarios regulares
            if (!isAdmin) {
                Spacer(modifier = Modifier.height(20.dp))

                Text(
                    text = "Invitar Amigos y Recompensas 🎁",
                    color = DriyGold,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(10.dp))

                Card(
                colors = CardDefaults.cardColors(containerColor = DriySurface),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.2.dp,
                        if (referralProgress.isGoalCompleted) Color(0xFF4CAF50) else DriyGold.copy(alpha = 0.5f),
                        RoundedCornerShape(16.dp)
                    )
                    .testTag("card_invite_friends_referral")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    // Header with Icon and Live Refresh button
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(if (referralProgress.isGoalCompleted) Color(0x334CAF50) else DriyGold.copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CardGiftcard,
                                    contentDescription = null,
                                    tint = if (referralProgress.isGoalCompleted) Color(0xFF4CAF50) else DriyGold,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "¡Gana 3 Meses Gratis!",
                                    color = DriyTextPrimary,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Invita a 20 amigos que activen su membresía",
                                    color = DriyTextSecondary,
                                    fontSize = 12.sp
                                )
                            }
                        }

                        IconButton(
                            onClick = { refreshReferrals() },
                            enabled = !isReferralLoading,
                            modifier = Modifier.size(36.dp)
                        ) {
                            if (isReferralLoading) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(18.dp),
                                    strokeWidth = 2.dp,
                                    color = DriyGold
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = "Actualizar",
                                    tint = DriyGold,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Referral Code Box with Copy & Share Actions
                    val referralCode = user?.username?.trim()?.removePrefix("@") ?: "mi_usuario"
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(DriySurfaceVariant)
                            .border(1.dp, DriyDivider, RoundedCornerShape(12.dp))
                            .padding(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Tu código de referido:",
                                    color = DriyTextSecondary,
                                    fontSize = 11.sp
                                )
                                Text(
                                    text = "@$referralCode",
                                    color = DriyGold,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                OutlinedButton(
                                    onClick = {
                                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                        val clip = ClipData.newPlainText("Código Referido DriyMusic", "@$referralCode")
                                        clipboard.setPrimaryClip(clip)
                                        Toast.makeText(context, "Código @$referralCode copiado", Toast.LENGTH_SHORT).show()
                                    },
                                    shape = RoundedCornerShape(8.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = DriyGold),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, DriyGold.copy(alpha = 0.7f)),
                                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                    modifier = Modifier.height(36.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ContentCopy,
                                        contentDescription = "Copiar",
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Copiar", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }

                                Button(
                                    onClick = {
                                        DriyReferralManager.shareReferralInvitation(context, referralCode)
                                    },
                                    shape = RoundedCornerShape(8.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Color(0xFF25D366),
                                        contentColor = Color.White
                                    ),
                                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                    modifier = Modifier.height(36.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Share,
                                        contentDescription = "Compartir",
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Invitar", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Progress Bar Section (0 / 20)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Amigos activados y pagados:",
                            color = DriyTextPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "${referralProgress.activePaidReferrals} / ${referralProgress.requiredGoal}",
                            color = if (referralProgress.isGoalCompleted) Color(0xFF4CAF50) else DriyGold,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    LinearProgressIndicator(
                        progress = { referralProgress.progressFraction },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(12.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .testTag("referral_progress_bar"),
                        color = if (referralProgress.isGoalCompleted) Color(0xFF4CAF50) else DriyGold,
                        trackColor = DriySurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = if (referralProgress.isGoalCompleted) "¡Meta 20/20 completa!" else "Faltan ${referralProgress.remainingToGoal} amigos con membresía",
                            color = if (referralProgress.isGoalCompleted) Color(0xFF4CAF50) else DriyTextSecondary,
                            fontSize = 11.sp
                        )
                        Text(
                            text = "${(referralProgress.progressFraction * 100).toInt()}%",
                            color = DriyTextSecondary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // GOAL REACHED ACTION BUTTON
                    if (referralProgress.isGoalCompleted || referralProgress.activePaidReferrals >= 20) {
                        Spacer(modifier = Modifier.height(14.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFF2E7D32).copy(alpha = 0.18f))
                                .border(1.2.dp, Color(0xFF4CAF50), RoundedCornerShape(12.dp))
                                .padding(14.dp)
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "🏆 ¡FELICITACIONES! META ALCANZADA",
                                    color = Color(0xFF4CAF50),
                                    fontWeight = FontWeight.Black,
                                    fontSize = 13.sp,
                                    textAlign = TextAlign.Center
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Has completado los 20 amigos registrados y activados. Solicita al administrador tu código de activación por 3 meses gratis.",
                                    color = DriyTextPrimary,
                                    fontSize = 11.sp,
                                    textAlign = TextAlign.Center
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                Button(
                                    onClick = {
                                        if (user != null) {
                                            coroutineScope.launch {
                                                isClaimingReward = true
                                                DriyReferralManager.claimThreeMonthsReward(
                                                    context = context,
                                                    user = user,
                                                    progress = referralProgress
                                                )
                                                refreshReferrals()
                                                isClaimingReward = false
                                            }
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Color(0xFF25D366),
                                        contentColor = Color.White
                                    ),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(44.dp)
                                        .testTag("btn_claim_three_months_reward")
                                ) {
                                    if (isClaimingReward) {
                                        CircularProgressIndicator(
                                            modifier = Modifier.size(18.dp),
                                            color = Color.White,
                                            strokeWidth = 2.dp
                                        )
                                    } else {
                                        Icon(
                                            imageVector = Icons.Default.Send,
                                            contentDescription = null,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = "Reclamar 3 Meses Gratis al Admin",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    HorizontalDivider(color = DriyDivider)
                    Spacer(modifier = Modifier.height(10.dp))

                    // Expandable list of friends and their payment statuses
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { showFriendsList = !showFriendsList }
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Group,
                                contentDescription = null,
                                tint = DriyGold,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Ver amigos registrados (${referralProgress.totalReferrals})",
                                color = DriyTextPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        Icon(
                            imageVector = if (showFriendsList) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                            contentDescription = null,
                            tint = DriyTextSecondary,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    if (showFriendsList) {
                        Spacer(modifier = Modifier.height(8.dp))
                        if (referralProgress.friendsList.isEmpty()) {
                            Text(
                                text = "Aún ningún amigo ha ingresado tu código. Comparte tu invitación por WhatsApp para que al pagar su membresía te indiquen como quien los invitó.",
                                color = DriyTextSecondary,
                                fontSize = 11.sp,
                                lineHeight = 15.sp,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 6.dp)
                            )
                        } else {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                referralProgress.friendsList.forEach { friend ->
                                    Surface(
                                        color = DriySurfaceVariant,
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 12.dp, vertical = 8.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(28.dp)
                                                        .clip(CircleShape)
                                                        .background(if (friend.isActivatedAndPaid) Color(0x334CAF50) else DriyBackground),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.Person,
                                                        contentDescription = null,
                                                        tint = if (friend.isActivatedAndPaid) Color(0xFF4CAF50) else DriyTextSecondary,
                                                        modifier = Modifier.size(16.dp)
                                                    )
                                                }
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Column {
                                                    Text(
                                                        text = friend.displayName.ifBlank { "@${friend.username}" },
                                                        color = DriyTextPrimary,
                                                        fontSize = 12.sp,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                    Text(
                                                        text = "@${friend.username}",
                                                        color = DriyTextSecondary,
                                                        fontSize = 10.sp
                                                    )
                                                }
                                            }

                                            Surface(
                                                color = if (friend.isActivatedAndPaid) Color(0xFF2E7D32) else Color(0xFF5D4037),
                                                shape = RoundedCornerShape(6.dp)
                                            ) {
                                                Text(
                                                    text = if (friend.isActivatedAndPaid) "✓ Activo (VIP)" else "⏳ Pendiente pago",
                                                    color = Color.White,
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

            // Admin Generator Section (Visible for driycompany@gmail.com and admin accounts)
            if (isAdmin) {
                Spacer(modifier = Modifier.height(16.dp))
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1428)),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.2.dp, Color(0xFFAB47BC), RoundedCornerShape(16.dp))
                        .clickable { showAdminCodeGenerator = true }
                        .testTag("card_admin_code_generator")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFAB47BC)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AdminPanelSettings,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "👑 Panel de Administrador",
                                    color = Color.White,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    color = Color(0xFF7B1FA2),
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = "DRIY ADMIN",
                                        color = Color.White,
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Genera códigos únicos (1 a 12 meses) y envíalos por WhatsApp con 1 toque",
                                color = Color(0xFFE1BEE7),
                                fontSize = 11.sp,
                                lineHeight = 15.sp
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = { showAdminCodeGenerator = true },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFFAB47BC),
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text("Generar", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Asistente Virtual Section (Desactivado por defecto, activable por el usuario)
            Text(
                text = "Tu Asistente Virtual",
                color = DriyGold,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(10.dp))
            Card(
                colors = CardDefaults.cardColors(containerColor = DriySurface),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.dp,
                        if (assistantState.isEnabled) DriyGold else DriyGold.copy(alpha = 0.35f),
                        RoundedCornerShape(16.dp)
                    )
                    .clickable { showAssistantSheet = true }
                    .testTag("card_virtual_assistant")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(CircleShape)
                                    .background(if (assistantState.isEnabled) DriyGold else DriySurfaceVariant),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.SmartToy,
                                    contentDescription = null,
                                    tint = if (assistantState.isEnabled) DriyBackground else DriyGold,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "Asistente Virtual",
                                        color = DriyTextPrimary,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Surface(
                                        color = if (assistantState.isEnabled) DriyGold else DriySurfaceVariant,
                                        shape = RoundedCornerShape(4.dp)
                                    ) {
                                        Text(
                                            text = if (assistantState.isEnabled) "ACTIVO" else "DESACTIVADO",
                                            color = if (assistantState.isEnabled) DriyBackground else DriyTextSecondary,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = if (assistantState.isEnabled)
                                        "${assistantState.customAvatarName} te escucha • Te llama: \"${assistantState.userCallingTitle}\""
                                    else
                                        "Toca para activarlo y elegir entre tus avatares disponibles",
                                    color = DriyTextSecondary,
                                    fontSize = 12.sp,
                                    lineHeight = 15.sp
                                )
                            }
                        }

                        androidx.compose.material3.Switch(
                            checked = assistantState.isEnabled,
                            onCheckedChange = { enabled ->
                                VirtualAssistantManager.setEnabled(enabled)
                            },
                            colors = androidx.compose.material3.SwitchDefaults.colors(
                                checkedThumbColor = DriyBackground,
                                checkedTrackColor = DriyGold,
                                uncheckedThumbColor = DriyTextSecondary,
                                uncheckedTrackColor = DriySurfaceVariant
                            )
                        )
                    }

                    if (assistantState.isEnabled) {
                        val currentAvatar = VirtualAssistantCatalog.getById(assistantState.selectedAvatarId)
                        Spacer(modifier = Modifier.height(12.dp))
                        HorizontalDivider(color = DriyDivider)
                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(DriySurfaceVariant)
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(46.dp, 58.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color.Transparent),
                                contentAlignment = Alignment.Center
                            ) {
                                AnimatedSpriteAvatar(
                                    drawableRes = currentAvatar.idleDrawableRes,
                                    totalFrames = currentAvatar.idleFrames,
                                    animationMode = AssistantAnimationMode.STANDING,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${currentAvatar.name} (\"${assistantState.customAvatarName}\")",
                                    color = DriyGold,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Responde con pensamientos silenciosos 💭",
                                    color = DriyTextSecondary,
                                    fontSize = 11.sp
                                )
                            }
                            OutlinedButton(
                                onClick = { showAssistantSheet = true },
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = DriyGold),
                                border = androidx.compose.foundation.BorderStroke(1.dp, DriyGold),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                modifier = Modifier.height(32.dp)
                            ) {
                                Text("Avatares", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Dedicated Jam Section
            Text(
                text = "Sesión Grupal en Directo",
                color = DriyGold,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(10.dp))
            Card(
                colors = CardDefaults.cardColors(containerColor = DriySurface),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, DriyGold.copy(alpha = 0.35f), RoundedCornerShape(16.dp))
                    .clickable { showJamDialog = true }
                    .testTag("card_jam_session")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(DriyGold),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Headphones,
                            contentDescription = "Función Jam",
                            tint = DriyBackground,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Driy Jam Grupal",
                                color = DriyTextPrimary,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            when (jamState) {
                                is JamSessionState.Hosting -> {
                                    Text(
                                        text = "• EN VIVO",
                                        color = Color(0xFF4CAF50),
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.ExtraBold
                                    )
                                }
                                is JamSessionState.Joined -> {
                                    Text(
                                        text = "• CONECTADO",
                                        color = Color(0xFF4CAF50),
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.ExtraBold
                                    )
                                }
                                JamSessionState.Idle -> {}
                            }
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = when (jamState) {
                                is JamSessionState.Hosting -> "Sala activa: ${jamState.session.code} (${jamState.session.participants.size} miembros)"
                                is JamSessionState.Joined -> "Conectado a la sala: ${jamState.session.code}"
                                JamSessionState.Idle -> "Escucha música sincronizada con amigos con QR o código"
                            },
                            color = DriyTextSecondary,
                            fontSize = 12.sp,
                            lineHeight = 16.sp
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = { showJamDialog = true },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = DriyGold,
                            contentColor = DriyBackground
                        ),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = if (jamState is JamSessionState.Idle) "Jam" else "Ver Jam",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = "Personalización y Apariencia",
                color = DriyGold,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(10.dp))

            Card(
                colors = CardDefaults.cardColors(containerColor = DriySurface),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showThemeCustomizer = true }
                    .border(1.dp, DriyGold.copy(alpha = 0.35f), RoundedCornerShape(16.dp))
                    .testTag("btn_open_theme_customizer")
            ) {
                Row(
                    modifier = Modifier.padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(DriyGold.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Palette,
                            contentDescription = null,
                            tint = DriyGold,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Personalizar Colores y Fondo",
                            color = DriyTextPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Modifica marcos, letras o pon una foto de fondo",
                            color = DriyTextSecondary,
                            fontSize = 12.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = DriySurfaceVariant
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .clip(CircleShape)
                                            .background(themeState.accentColor)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Marcos", color = DriyTextSecondary, fontSize = 10.sp)
                                }
                            }
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = DriySurfaceVariant
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .clip(CircleShape)
                                            .background(themeState.textColor)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Letras", color = DriyTextSecondary, fontSize = 10.sp)
                                }
                            }
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = DriySurfaceVariant
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = if (themeState.backgroundPhotoUri != null) "🖼️ Con foto" else "🎨 Color",
                                        color = DriyTextSecondary,
                                        fontSize = 10.sp
                                    )
                                }
                            }
                        }
                    }
                    Icon(
                        imageVector = Icons.Default.Tune,
                        contentDescription = "Editar",
                        tint = DriyGold,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "Isla Dinámica y Segundo Plano",
                color = DriyGold,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(10.dp))

            Card(
                colors = CardDefaults.cardColors(containerColor = DriySurface),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.PhoneAndroid,
                            contentDescription = null,
                            tint = DriyGold,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Detección de Hardware Nativo",
                            color = DriyTextPrimary,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Modo de Isla:",
                        color = DriyTextSecondary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(
                            Triple("AUTO", "⚙️ Auto", "Detectar si el cel tiene isla nativa"),
                            Triple("FORCE_NATIVE", "📱 Solo Nativa", "Usar cápsula/isla del celular"),
                            Triple("FORCE_OVERLAY", "🏝️ Flotante", "Usar isla visual de DriyMusic")
                        ).forEach { (mode, label, _) ->
                            val isSelected = islandMode == mode
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (isSelected) DriyGold else DriySurfaceVariant,
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { onSetIslandMode(mode) }
                            ) {
                                Box(
                                    contentAlignment = Alignment.Center,
                                    modifier = Modifier.padding(vertical = 10.dp, horizontal = 4.dp)
                                ) {
                                    Text(
                                        text = label,
                                        color = if (isSelected) DriyBackground else DriyTextPrimary,
                                        fontSize = 11.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                        maxLines = 1
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    if (isNativeIslandDetected || islandMode == "FORCE_NATIVE") {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(DriySurfaceVariant)
                                .padding(12.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = DriyGold,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = "Conectado al reproductor nativo del sistema (MediaSession + MediaStyle). Tu celular mostrará los controles, carátula y estado directamente en su isla o cápsula dinámica de fábrica.",
                                    color = DriyTextPrimary,
                                    fontSize = 12.sp,
                                    lineHeight = 17.sp
                                )
                            }
                        }
                    } else {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(DriySurfaceVariant)
                                .padding(12.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Info,
                                    contentDescription = null,
                                    tint = DriyGold,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = "Isla Flotante DriyMusic: Aparecerá centrada arriba sobre cualquier aplicación cuando salgas de la app.",
                                    color = DriyTextPrimary,
                                    fontSize = 12.sp,
                                    lineHeight = 17.sp
                                )
                            }
                        }
                    }

                    if (islandMode != "FORCE_NATIVE") {
                        Spacer(modifier = Modifier.height(14.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Permiso de superposición (Isla flotante)",
                                    color = DriyTextPrimary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium
                                )
                                Text(
                                    text = if (hasOverlayPermission) "Concedido (Isla flotante lista)" else "Requiere permiso para flotar sobre otras apps",
                                    color = if (hasOverlayPermission) DriyGold else DriyTextSecondary,
                                    fontSize = 11.sp
                                )
                            }
                            Button(
                                onClick = onRequestOverlayPermission,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (hasOverlayPermission) DriySurfaceVariant else DriyGold,
                                    contentColor = if (hasOverlayPermission) DriyTextPrimary else DriyBackground
                                ),
                                shape = RoundedCornerShape(20.dp)
                            ) {
                                Text(
                                    text = if (hasOverlayPermission) "Listo" else "Activar",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    HorizontalDivider(color = DriyDivider)
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Reglas de Comportamiento:\n• Desaparece cuando DriyMusic está en pantalla.\n• Aparece en el borde superior central al salir de la app.\n• Temporizador: desaparece tras 5 minutos en pausa.\n• Controles nativos en pantalla de bloqueo vía MediaSession.",
                        color = DriyTextSecondary,
                        fontSize = 11.sp,
                        lineHeight = 16.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            OutlinedButton(
                onClick = onSignOut,
                shape = RoundedCornerShape(28.dp),
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = Color(0xFFFF5252)
                ),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x66FF5252)),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("sign_out_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Logout,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Cerrar Sesión",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Button(
                onClick = { showDeleteDialog = true },
                shape = RoundedCornerShape(28.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0x33FF3B30),
                    contentColor = Color(0xFFFF453A)
                ),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x55FF3B30)),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("delete_account_button")
            ) {
                Icon(
                    imageVector = Icons.Default.DeleteForever,
                    contentDescription = null,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Eliminar Cuenta",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(modifier = Modifier.height(28.dp))

            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Image(
                    painter = painterResource(R.drawable.driymusic_logo),
                    contentDescription = "DriyMusic Logo",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(54.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .border(1.5.dp, DriyGold.copy(alpha = 0.7f), RoundedCornerShape(14.dp))
                )
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "DriyMusic",
                    color = DriyGold,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Tu Música, Tus Reglas • v${BuildConfig.VERSION_NAME} (Build ${BuildConfig.VERSION_CODE})",
                    color = DriyTextSecondary,
                    fontSize = 12.sp
                )
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedButton(
                    onClick = {
                        isCheckingUpdatesManually = true
                        coroutineScope.launch {
                            val up = com.example.service.DriyAppUpdater.checkForUpdate()
                            isCheckingUpdatesManually = false
                            if (up != null) {
                                manualUpdateInfo = up
                            } else {
                                Toast.makeText(context, "¡Ya tienes la versión más reciente de DriyMusic!", Toast.LENGTH_SHORT).show()
                            }
                        }
                    },
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = DriyGold
                    ),
                    border = androidx.compose.foundation.BorderStroke(1.dp, DriyGold.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.testTag("btn_check_updates_profile")
                ) {
                    if (isCheckingUpdatesManually) {
                        CircularProgressIndicator(
                            color = DriyGold,
                            modifier = Modifier.size(16.dp),
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Buscando...", fontSize = 12.sp)
                    } else {
                        Icon(
                            imageVector = Icons.Default.SystemUpdate,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Buscar Actualizaciones", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(32.dp))
        }
    }

    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            containerColor = DriySurface,
            title = {
                Text(
                    text = "¿Eliminar cuenta definitivamente?",
                    color = DriyTextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            },
            text = {
                Text(
                    text = "Esta acción es irreversible. Se eliminará tu usuario, tus datos guardados, tus carpetas de música y preferencias de DriyMusic.",
                    color = DriyTextSecondary,
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteDialog = false
                        onDeleteAccount()
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFFF3B30),
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.testTag("confirm_delete_account_btn")
                ) {
                    Text("Eliminar Cuenta", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showDeleteDialog = false },
                    modifier = Modifier.testTag("cancel_delete_account_btn")
                ) {
                    Text("Cancelar", color = DriyTextSecondary)
                }
            }
        )
    }

    if (showThemeCustomizer) {
        AppearanceCustomizerDialog(
            onDismissRequest = { showThemeCustomizer = false }
        )
    }
}
