package com.example.ui.components

import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Wallpaper
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.ui.theme.ThemeManager

@Composable
fun AppearanceCustomizerDialog(
    onDismissRequest: () -> Unit
) {
    val context = LocalContext.current
    val themeState by ThemeManager.themeState.collectAsState()

    var selectedTab by remember { mutableIntStateOf(0) }
    var bgModeTab by remember { mutableIntStateOf(if (themeState.backgroundPhotoUri != null) 1 else 0) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            ThemeManager.setBackgroundPhoto(context, uri)
            bgModeTab = 1
        }
    }

    val accentPresets = listOf(
        Triple("Oro Driy", Color(0xFFE6B800), "Dorado original"),
        Triple("Cyan Neón", Color(0xFF00E5FF), "Eléctrico"),
        Triple("Verde Neón", Color(0xFF00E676), "Esmeralda"),
        Triple("Púrpura", Color(0xFFD500F9), "Violeta"),
        Triple("Rosa Rubí", Color(0xFFFF1744), "Cálido"),
        Triple("Naranja Solar", Color(0xFFFF6D00), "Fuego"),
        Triple("Azul Real", Color(0xFF2979FF), "Vibrante"),
        Triple("Blanco Puro", Color(0xFFFFFFFF), "Diamante"),
        Triple("Ámbar", Color(0xFFFFAB00), "Dorado suave"),
        Triple("Turquesa", Color(0xFF1DE9B6), "Menta marina")
    )

    val textPresets = listOf(
        Pair("Blanco Puro", Color(0xFFFFFFFF)),
        Pair("Crema Suave", Color(0xFFFFF9C4)),
        Pair("Oro Claro", Color(0xFFFFD54F)),
        Pair("Plata Platino", Color(0xFFECEFF1)),
        Pair("Cyan Hielo", Color(0xFFE0F7FA)),
        Pair("Rosa Pastel", Color(0xFFFCE4EC)),
        Pair("Menta Claro", Color(0xFFE8F5E9))
    )

    val bgColorPresets = listOf(
        Pair("Negro AMOLED", Color(0xFF000000)),
        Pair("Carbón Driy", Color(0xFF121212)),
        Pair("Azul Noche", Color(0xFF0A0F1D)),
        Pair("Púrpura Noche", Color(0xFF140A1E)),
        Pair("Verde Bosque", Color(0xFF0A1A12)),
        Pair("Vino Tinto", Color(0xFF1A0A0E))
    )

    val wallpaperPresets = listOf(
        Pair("🎧 Estudio Musical", "https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?w=1080&q=80"),
        Pair("🎸 Luces de Concierto", "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=1080&q=80"),
        Pair("🌌 Nebulosa Cósmica", "https://images.unsplash.com/photo-1506703719100-a0f3a48c0f86?w=1080&q=80"),
        Pair("📻 Tornamesa Vinilo", "https://images.unsplash.com/photo-1539185441755-769473a23570?w=1080&q=80"),
        Pair("⚡ Cyberpunk Audio", "https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?w=1080&q=80"),
        Pair("🏙️ Luces Urbanas Bokeh", "https://images.unsplash.com/photo-1519501025264-65ba15a82390?w=1080&q=80")
    )

    AlertDialog(
        onDismissRequest = onDismissRequest,
        containerColor = Color(0xFF181818),
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(themeState.accentColor),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Palette,
                            contentDescription = null,
                            tint = Color.Black,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Personalizar Apariencia",
                        color = themeState.textColor,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                }
                IconButton(onClick = onDismissRequest) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Cerrar",
                        tint = themeState.textColor.copy(alpha = 0.6f)
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = "VISTA PREVIA EN TIEMPO REAL",
                    color = themeState.accentColor,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(6.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(115.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .border(1.5.dp, themeState.accentColor, RoundedCornerShape(14.dp))
                        .background(themeState.backgroundColor)
                ) {
                    if (!themeState.backgroundPhotoUri.isNullOrBlank()) {
                        AsyncImage(
                            model = themeState.backgroundPhotoUri,
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Color.Black.copy(alpha = themeState.backgroundDim))
                        )
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(54.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(themeState.surfaceColor)
                                .border(1.dp, themeState.accentColor.copy(alpha = 0.6f), RoundedCornerShape(10.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.GraphicEq,
                                contentDescription = null,
                                tint = themeState.accentColor,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "DriyMusic",
                                color = themeState.textColor,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "Personalizado a tu estilo",
                                color = themeState.textColor.copy(alpha = 0.7f),
                                fontSize = 11.sp,
                                maxLines = 1
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth(0.85f)
                                    .height(4.dp)
                                    .clip(RoundedCornerShape(2.dp))
                                    .background(themeState.textColor.copy(alpha = 0.2f))
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth(0.55f)
                                        .height(4.dp)
                                        .background(themeState.accentColor)
                                )
                            }
                        }

                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(themeState.accentColor),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = null,
                                tint = Color.Black,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF262626))
                        .padding(3.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    listOf(
                        0 to "Marcos",
                        1 to "Letras",
                        2 to "Fondo",
                        3 to "Temas"
                    ).forEach { (idx, label) ->
                        val isSelected = selectedTab == idx
                        Surface(
                            shape = RoundedCornerShape(9.dp),
                            color = if (isSelected) themeState.accentColor else Color.Transparent,
                            modifier = Modifier
                                .weight(1f)
                                .clickable { selectedTab = idx }
                        ) {
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier.padding(vertical = 8.dp)
                            ) {
                                Text(
                                    text = label,
                                    color = if (isSelected) Color.Black else themeState.textColor,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                if (selectedTab == 0) {
                    Text(
                        text = "Elige el color para marcos, botones y acentos:",
                        color = themeState.textColor.copy(alpha = 0.8f),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        accentPresets.chunked(5).forEach { rowColors ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                rowColors.forEach { (name, color, _) ->
                                    val isSelected = themeState.accentColor == color
                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        modifier = Modifier
                                            .clickable { ThemeManager.setAccentColor(color) }
                                            .padding(2.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(44.dp)
                                                .clip(CircleShape)
                                                .background(color)
                                                .border(
                                                    if (isSelected) 2.5.dp else 1.dp,
                                                    if (isSelected) Color.White else Color.Black.copy(alpha = 0.5f),
                                                    CircleShape
                                                ),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            if (isSelected) {
                                                Icon(
                                                    imageVector = Icons.Default.Check,
                                                    contentDescription = "Seleccionado",
                                                    tint = if (color == Color.White) Color.Black else Color.White,
                                                    modifier = Modifier.size(22.dp)
                                                )
                                            }
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = name.split(" ").first(),
                                            color = themeState.textColor,
                                            fontSize = 9.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                        )
                                    }
                                }
                            }
                        }
                    }
                } else if (selectedTab == 1) {
                    Text(
                        text = "Elige el color para las letras y títulos:",
                        color = themeState.textColor.copy(alpha = 0.8f),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        textPresets.forEach { (name, color) ->
                            val isSelected = themeState.textColor == color
                            Card(
                                colors = CardDefaults.cardColors(
                                    containerColor = if (isSelected) Color(0xFF2C2C2C) else Color(0xFF202020)
                                ),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .clickable { ThemeManager.setTextColor(color) }
                                    .border(
                                        if (isSelected) 1.5.dp else 0.5.dp,
                                        if (isSelected) themeState.accentColor else Color(0xFF333333),
                                        RoundedCornerShape(12.dp)
                                    )
                            ) {
                                Column(
                                    modifier = Modifier.padding(12.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(CircleShape)
                                            .background(color)
                                            .border(1.dp, Color.Gray.copy(alpha = 0.5f), CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        if (isSelected) {
                                            Icon(
                                                imageVector = Icons.Default.Check,
                                                contentDescription = null,
                                                tint = Color.Black,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = name,
                                        color = color,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                } else if (selectedTab == 2) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFF262626))
                            .padding(2.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (bgModeTab == 0) themeState.accentColor else Color.Transparent,
                            modifier = Modifier
                                .weight(1f)
                                .clickable {
                                    bgModeTab = 0
                                    ThemeManager.clearBackgroundPhoto()
                                }
                        ) {
                            Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(vertical = 8.dp)) {
                                Text(
                                    text = "Color Sólido",
                                    color = if (bgModeTab == 0) Color.Black else themeState.textColor,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (bgModeTab == 1) themeState.accentColor else Color.Transparent,
                            modifier = Modifier
                                .weight(1f)
                                .clickable { bgModeTab = 1 }
                        ) {
                            Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(vertical = 8.dp)) {
                                Text(
                                    text = "Foto de Fondo",
                                    color = if (bgModeTab == 1) Color.Black else themeState.textColor,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    if (bgModeTab == 0) {
                        Text(
                            text = "Elige un tono de fondo sólido:",
                            color = themeState.textColor.copy(alpha = 0.8f),
                            fontSize = 12.sp
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            bgColorPresets.chunked(3).forEach { rowColors ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    rowColors.forEach { (name, color) ->
                                        val isSelected = themeState.backgroundColor == color && themeState.backgroundPhotoUri == null
                                        Surface(
                                            color = color,
                                            shape = RoundedCornerShape(12.dp),
                                            modifier = Modifier
                                                .weight(1f)
                                                .height(48.dp)
                                                .clickable {
                                                    ThemeManager.clearBackgroundPhoto()
                                                    ThemeManager.setBackgroundColor(color)
                                                }
                                                .border(
                                                    if (isSelected) 2.dp else 1.dp,
                                                    if (isSelected) themeState.accentColor else Color(0xFF333333),
                                                    RoundedCornerShape(12.dp)
                                                )
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(horizontal = 8.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.Center
                                            ) {
                                                if (isSelected) {
                                                    Icon(
                                                        imageVector = Icons.Default.Check,
                                                        contentDescription = null,
                                                        tint = themeState.accentColor,
                                                        modifier = Modifier.size(16.dp)
                                                    )
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                }
                                                Text(
                                                    text = name,
                                                    color = Color.White,
                                                    fontSize = 10.sp,
                                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                                    maxLines = 1
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        Button(
                            onClick = {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = themeState.accentColor,
                                contentColor = Color.Black
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp)
                                .testTag("btn_pick_bg_wallpaper")
                        ) {
                            Icon(Icons.Default.Wallpaper, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Subir Foto de mi Galería", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }

                        if (!themeState.backgroundPhotoUri.isNullOrBlank()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            OutlinedButton(
                                onClick = {
                                    ThemeManager.clearBackgroundPhoto()
                                    bgModeTab = 0
                                },
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFEF5350)),
                                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFEF5350)),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(40.dp)
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Quitar foto y usar color sólido", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            text = "O elige un fondo musical exclusivo:",
                            color = themeState.textColor.copy(alpha = 0.8f),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            wallpaperPresets.forEach { (name, url) ->
                                val isSelected = themeState.backgroundPhotoUri == url
                                Card(
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier
                                        .size(width = 110.dp, height = 75.dp)
                                        .clickable {
                                            ThemeManager.setPresetBackgroundPhoto(url)
                                        }
                                        .border(
                                            if (isSelected) 2.dp else 1.dp,
                                            if (isSelected) themeState.accentColor else Color.Transparent,
                                            RoundedCornerShape(12.dp)
                                        )
                                ) {
                                    Box(modifier = Modifier.fillMaxSize()) {
                                        AsyncImage(
                                            model = url,
                                            contentDescription = name,
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier.fillMaxSize()
                                        )
                                        Box(
                                            modifier = Modifier
                                                .fillMaxSize()
                                                .background(Color.Black.copy(alpha = 0.45f))
                                        )
                                        Text(
                                            text = name,
                                            color = Color.White,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier
                                                .align(Alignment.BottomCenter)
                                                .padding(4.dp),
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        if (isSelected) {
                                            Box(
                                                modifier = Modifier
                                                    .size(20.dp)
                                                    .align(Alignment.TopEnd)
                                                    .padding(3.dp)
                                                    .clip(CircleShape)
                                                    .background(themeState.accentColor),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Check,
                                                    contentDescription = null,
                                                    tint = Color.Black,
                                                    modifier = Modifier.size(12.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        if (!themeState.backgroundPhotoUri.isNullOrBlank()) {
                            Spacer(modifier = Modifier.height(14.dp))
                            Text(
                                text = "Oscurecimiento de foto: ${(themeState.backgroundDim * 100).toInt()}% (para nitidez de letras)",
                                color = themeState.textColor.copy(alpha = 0.8f),
                                fontSize = 11.sp
                            )
                            Slider(
                                value = themeState.backgroundDim,
                                onValueChange = { ThemeManager.setBackgroundDim(it) },
                                valueRange = 0.15f..0.85f,
                                colors = SliderDefaults.colors(
                                    thumbColor = themeState.accentColor,
                                    activeTrackColor = themeState.accentColor,
                                    inactiveTrackColor = Color.DarkGray
                                )
                            )
                        }
                    }
                } else if (selectedTab == 3) {
                    Text(
                        text = "Aplica combinaciones completas en un solo toque:",
                        color = themeState.textColor.copy(alpha = 0.8f),
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    val presets = listOf(
                        Quadruple("✨ Driy Gold Clásico", Color(0xFFE6B800), Color(0xFFEDEDED), Color(0xFF121212)),
                        Quadruple("⚡ Cyberpunk 2077", Color(0xFF00E5FF), Color(0xFFFFFFFF), Color(0xFF0A0F1D)),
                        Quadruple("🔮 Synthwave Noche", Color(0xFFD500F9), Color(0xFFFFF9C4), Color(0xFF140A1E)),
                        Quadruple("🧪 Toxic Emerald", Color(0xFF00E676), Color(0xFFFFFFFF), Color(0xFF0A1A12)),
                        Quadruple("⚪ AMOLED Puro", Color(0xFFFFFFFF), Color(0xFFFFFFFF), Color(0xFF000000)),
                        Quadruple("🔥 Solar Flame", Color(0xFFFF6D00), Color(0xFFFFD54F), Color(0xFF16120E))
                    )

                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        presets.forEach { (name, accent, text, bg) ->
                            Card(
                                colors = CardDefaults.cardColors(containerColor = bg),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        ThemeManager.applyPreset(accent, text, bg, null)
                                    }
                                    .border(1.5.dp, accent, RoundedCornerShape(12.dp))
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text(name, color = text, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                        Text("Acento personalizado y fondo", color = text.copy(alpha = 0.6f), fontSize = 10.sp)
                                    }
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Box(modifier = Modifier.size(20.dp).clip(CircleShape).background(accent))
                                        Box(modifier = Modifier.size(20.dp).clip(CircleShape).background(text))
                                        Box(modifier = Modifier.size(20.dp).clip(CircleShape).background(bg).border(1.dp, Color.White, CircleShape))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismissRequest,
                colors = ButtonDefaults.buttonColors(
                    containerColor = themeState.accentColor,
                    contentColor = Color.Black
                ),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("Listo", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
        },
        dismissButton = {
            TextButton(
                onClick = { ThemeManager.resetToDefaults() }
            ) {
                Icon(Icons.Default.RestartAlt, contentDescription = null, tint = themeState.textColor.copy(alpha = 0.7f), modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Restablecer", color = themeState.textColor.copy(alpha = 0.7f), fontSize = 12.sp)
            }
        }
    )
}

private data class Quadruple<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)
