package com.example.ui

import android.app.Application
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.Artist
import com.example.data.model.FolderEntity
import com.example.data.model.FolderWithStats
import com.example.data.model.Genre
import com.example.data.model.JamSessionState
import com.example.data.model.LyricsUiState
import com.example.data.model.SongEntity
import com.example.data.model.UploadedSongEntity
import com.example.data.model.UserEntity
import com.example.data.repository.MusicRepository
import com.example.data.repository.UserRepository
import com.example.service.DriyAudioPlayer
import com.example.service.DriyJamManager
import com.example.service.DynamicIslandDetector
import com.example.service.FirebaseMusicSyncManager
import com.example.service.LrclibLyricsService
import com.example.service.PlayerState
import com.example.service.YouTubeService
import com.example.service.UserCloudSyncManager
import com.example.service.SingleDeviceSessionManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

sealed class Screen {
    data object Login : Screen()
    data object OnboardingGenre : Screen()
    data object OnboardingArtist : Screen()
    data object Home : Screen()
    data object Search : Screen()
    data object Library : Screen()
    data object UploadMusic : Screen()
    data object Profile : Screen()
}

class DriyViewModel(application: Application) : AndroidViewModel(application) {
    private val musicRepo = MusicRepository(application)
    private val userRepo = UserRepository(application)
    private val authManager = com.example.service.FirebaseAuthManager(application, userRepo)

    private val _currentScreen = MutableStateFlow<Screen>(
        if (userRepo.isUserLoggedIn()) {
            if (userRepo.isOnboardingCompleted()) Screen.Home else Screen.OnboardingGenre
        } else {
            Screen.Login
        }
    )
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    private val _isAuthenticating = MutableStateFlow(false)
    val isAuthenticating: StateFlow<Boolean> = _isAuthenticating.asStateFlow()

    private val _isFullPlayerVisible = MutableStateFlow(false)
    val isFullPlayerVisible: StateFlow<Boolean> = _isFullPlayerVisible.asStateFlow()

    private val _isQueueVisible = MutableStateFlow(false)
    val isQueueVisible: StateFlow<Boolean> = _isQueueVisible.asStateFlow()

    private val _activeSongForOptions = MutableStateFlow<SongEntity?>(null)
    val activeSongForOptions: StateFlow<SongEntity?> = _activeSongForOptions.asStateFlow()

    private val _queueNotification = MutableStateFlow<String?>(null)
    val queueNotification: StateFlow<String?> = _queueNotification.asStateFlow()

    private val _isLyricsVisible = MutableStateFlow(false)
    val isLyricsVisible: StateFlow<Boolean> = _isLyricsVisible.asStateFlow()

    private val _lyricsUiState = MutableStateFlow(LyricsUiState())
    val lyricsUiState: StateFlow<LyricsUiState> = _lyricsUiState.asStateFlow()

    private var lyricsJob: Job? = null
    private val _lyricsOffsets = java.util.concurrent.ConcurrentHashMap<String, Long>()

    val jamState: StateFlow<JamSessionState> = DriyJamManager.jamState

    private val _isJamDialogOpen = MutableStateFlow(false)
    val isJamDialogOpen: StateFlow<Boolean> = _isJamDialogOpen.asStateFlow()

    val activeUser: StateFlow<UserEntity?> = userRepo.activeUserFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private val _allRegisteredUsers = MutableStateFlow<List<UserEntity>>(emptyList())
    val allRegisteredUsers: StateFlow<List<UserEntity>> = _allRegisteredUsers.asStateFlow()

    val playerState: StateFlow<PlayerState> = DriyAudioPlayer.playerState

    val allSongs: StateFlow<List<SongEntity>> = musicRepo.getAllSongs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recentlyPlayedSongs: StateFlow<List<SongEntity>> = musicRepo.getRecentlyPlayedSongs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val mostSearchedSongs: StateFlow<List<SongEntity>> = musicRepo.getMostSearchedSongs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _recentSearchedSongs = MutableStateFlow<List<SongEntity>>(emptyList())
    val recentSearchedSongs: StateFlow<List<SongEntity>> = _recentSearchedSongs.asStateFlow()

    val downloadedSongs: StateFlow<List<SongEntity>> = musicRepo.getDownloadedSongs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val favoriteSongs: StateFlow<List<SongEntity>> = musicRepo.getFavoriteSongs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allFolders: StateFlow<List<FolderEntity>> = musicRepo.getAllFolders()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val foldersWithStats: StateFlow<List<FolderWithStats>> = combine(
        musicRepo.getAllFolders(),
        allSongs
    ) { folders, _ ->
        folders.map { folder ->
            val count = musicRepo.getSongCountInFolder(folder.id)
            val cover = musicRepo.getLatestSongCoverInFolder(folder.id)
            FolderWithStats(folder, count, cover)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val uploadedSongs: StateFlow<List<UploadedSongEntity>> = musicRepo.getAllUploadedSongs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val globalCommunitySongs: StateFlow<List<SongEntity>> = FirebaseMusicSyncManager.getGlobalCommunitySongsFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _activeSongForFolderSelection = MutableStateFlow<SongEntity?>(null)
    val activeSongForFolderSelection: StateFlow<SongEntity?> = _activeSongForFolderSelection.asStateFlow()

    private val _selectedSongFolderIds = MutableStateFlow<Set<String>>(emptySet())
    val selectedSongFolderIds: StateFlow<Set<String>> = _selectedSongFolderIds.asStateFlow()

    private val _activeFolder = MutableStateFlow<FolderEntity?>(null)
    val activeFolder: StateFlow<FolderEntity?> = _activeFolder.asStateFlow()

    @OptIn(ExperimentalCoroutinesApi::class)
    val activeFolderSongs: StateFlow<List<SongEntity>> = _activeFolder
        .flatMapLatest { folder ->
            if (folder != null) {
                musicRepo.getSongsInFolder(folder.id)
            } else {
                flowOf(emptyList())
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _selectedGenres = MutableStateFlow<Set<String>>(emptySet())
    val selectedGenres: StateFlow<Set<String>> = _selectedGenres.asStateFlow()

    private val _selectedArtists = MutableStateFlow<Set<String>>(emptySet())
    val selectedArtists: StateFlow<Set<String>> = _selectedArtists.asStateFlow()

    private val _artistSearchQuery = MutableStateFlow("")
    val artistSearchQuery: StateFlow<String> = _artistSearchQuery.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _downloadProgress = MutableStateFlow<Map<String, Float>>(emptyMap())
    val downloadProgress: StateFlow<Map<String, Float>> = _downloadProgress.asStateFlow()

    private val _favoriteArtistsSongs = MutableStateFlow<List<SongEntity>>(emptyList())
    val favoriteArtistsSongs: StateFlow<List<SongEntity>> = _favoriteArtistsSongs.asStateFlow()

    private val _isLoadingArtistSongs = MutableStateFlow(false)
    val isLoadingArtistSongs: StateFlow<Boolean> = _isLoadingArtistSongs.asStateFlow()

    val isNativeIslandDetected: Boolean = DynamicIslandDetector.isNativeDynamicIslandPresent(application)

    private val _islandMode = MutableStateFlow(DriyAudioPlayer.getCustomIslandMode())
    val islandMode: StateFlow<String> = _islandMode.asStateFlow()

    fun setIslandMode(mode: String) {
        _islandMode.value = mode
        DriyAudioPlayer.setCustomIslandMode(mode)
    }

    private val _sessionTerminatedMessage = MutableStateFlow<String?>(null)
    val sessionTerminatedMessage: StateFlow<String?> = _sessionTerminatedMessage.asStateFlow()

    fun clearSessionTerminatedMessage() {
        _sessionTerminatedMessage.value = null
    }

    fun startSessionMonitoringForUser(userId: String) {
        SingleDeviceSessionManager.startMonitoring(getApplication(), userId) { otherDevice ->
            handleSessionTerminatedByOtherDevice(otherDevice)
        }
    }

    private fun handleSessionTerminatedByOtherDevice(otherDevice: String) {
        viewModelScope.launch {
            DriyAudioPlayer.stop()
            com.example.ui.theme.ThemeManager.resetToDefaults()
            UserCloudSyncManager.clearLocalUserDataOnSignOut(getApplication())
            authManager.signOut()
            _selectedGenres.value = emptySet()
            _selectedArtists.value = emptySet()
            _favoriteArtistsSongs.value = emptyList()
            _recentSearchedSongs.value = emptyList()
            _sessionTerminatedMessage.value = "Tu cuenta se ha abierto en otro dispositivo ($otherDevice). Por seguridad, se ha cerrado la sesión en este teléfono."
            _currentScreen.value = Screen.Login
        }
    }

    init {
        com.example.ui.theme.ThemeManager.setOnThemeChangedListener { _, json ->
            val user = activeUser.value
            if (user != null) {
                viewModelScope.launch(Dispatchers.IO) {
                    userRepo.updateThemeConfig(user.id, json)
                }
            }
        }
        viewModelScope.launch {
            activeUser.collect { user ->
                if (user != null) {
                    com.example.ui.theme.ThemeManager.loadUserTheme(user.id, user.themeConfig)
                    if (user.photoUrl.startsWith("data:image") || (user.photoUrl.length > 300 && !user.photoUrl.startsWith("http"))) {
                        launch(Dispatchers.IO) {
                            try {
                                val cleanId = user.id.trim().lowercase()
                                val cleanBase64 = if (user.photoUrl.contains(",")) user.photoUrl.substringAfter(",") else user.photoUrl
                                val bytes = android.util.Base64.decode(cleanBase64.trim(), android.util.Base64.DEFAULT)
                                val avatarFile = File(getApplication<Application>().filesDir, "avatar_${cleanId}.jpg")
                                avatarFile.writeBytes(bytes)
                                userRepo.updatePhotoUrl(user.id, photoUrl = avatarFile.absolutePath, cloudPhotoUrl = user.photoUrl)
                            } catch (e: Exception) {
                                Log.w("DriyViewModel", "Failed to cache existing base64 avatar: ${e.message}")
                            }
                        }
                    }
                } else {
                    com.example.ui.theme.ThemeManager.resetToDefaults()
                }
            }
        }
        DriyAudioPlayer.localCatalogProvider = {
            val list = allSongs.value
            if (list.isNotEmpty()) list else com.example.data.seed.CatalogSeed.defaultSongs
        }
        viewModelScope.launch {
            musicRepo.ensureCatalogSeeded()
            checkInitialAuth()
            loadRegisteredUsers()
        }
        viewModelScope.launch {
            playerState.collect { state ->
                val song = state.currentSong
                DriyJamManager.updateCurrentSong(song)
                if (song != null && song.id != _lyricsUiState.value.songId) {
                    if (_isLyricsVisible.value) {
                        fetchLyricsForCurrentSong(force = false)
                    }
                }
            }
        }
        viewModelScope.launch {
            jamState.collect { state ->
                if (state is JamSessionState.Joined) {
                    val session = state.session
                    val songId = session.currentSongId
                    if (!songId.isNullOrBlank() && songId != playerState.value.currentSong?.id) {
                        val localSong = allSongs.value.firstOrNull { it.id == songId }
                        val songToPlay = localSong ?: SongEntity(
                            id = songId,
                            title = session.currentSongTitle ?: "Canción en Jam",
                            artist = session.currentSongArtist ?: "DriyMusic",
                            genre = "Jam",
                            album = "Sincronizado en Jam",
                            coverUrl = session.currentSongCover ?: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=500&q=80",
                            audioUrl = "https://www.youtube.com/watch?v=$songId",
                            durationSeconds = 210
                        )
                        playSong(songToPlay, listOf(songToPlay))
                    }
                }
            }
        }
    }

    private suspend fun loadRegisteredUsers() {
        val users = userRepo.getAllUsers()
        _allRegisteredUsers.value = users
    }

    private suspend fun checkInitialAuth() {
        userRepo.ensureAdminAccountSeeded()
        val user = authManager.getPersistedUser()
        if (user != null || userRepo.isUserLoggedIn()) {
            val activeUser = user ?: userRepo.getActiveUser()
            if (activeUser != null) {
                userRepo.setActiveUserId(activeUser.id)
                com.example.ui.theme.ThemeManager.loadUserTheme(activeUser.id, activeUser.themeConfig)
                UserCloudSyncManager.restoreUserDataFromCloud(getApplication(), activeUser.id)
                UserCloudSyncManager.startRealtimeUserSync(getApplication(), activeUser.id)
                startSessionMonitoringForUser(activeUser.id)
                val isDone = activeUser.isOnboarded || userRepo.isOnboardingCompleted()
                if (activeUser.favoriteArtists.isNotEmpty()) {
                    loadFavoriteArtistsSongs(activeUser.favoriteArtists)
                }
                if (isDone) {
                    _currentScreen.value = Screen.Home
                } else if (activeUser.favoriteGenres.size >= 4) {
                    _selectedGenres.value = activeUser.favoriteGenres.toSet()
                    _currentScreen.value = Screen.OnboardingArtist
                } else {
                    _currentScreen.value = Screen.OnboardingGenre
                }
            } else {
                userRepo.signOut()
                com.example.ui.theme.ThemeManager.resetToDefaults()
                _currentScreen.value = Screen.Login
            }
        } else {
            com.example.ui.theme.ThemeManager.resetToDefaults()
            _currentScreen.value = Screen.Login
        }
    }

    fun loadFavoriteArtistsSongs(artists: List<String>) {
        if (artists.isEmpty()) return
        viewModelScope.launch {
            _isLoadingArtistSongs.value = true
            val gatheredSongs = mutableListOf<SongEntity>()
            for (artist in artists.take(6)) {
                try {
                    val results = YouTubeService.searchYouTube("$artist official video")
                        .ifEmpty { YouTubeService.searchYouTube("$artist audio oficial") }
                    val artistTopSongs = results
                        .filter { it.durationSeconds in 60..390 }
                        .take(4).map { song ->
                            song.copy(artist = artist)
                        }
                    gatheredSongs.addAll(artistTopSongs)
                } catch (e: Exception) {
                    // continue
                }
            }
            if (gatheredSongs.isNotEmpty()) {
                val distinctSongs = gatheredSongs.distinctBy { it.id }
                _favoriteArtistsSongs.value = distinctSongs
                musicRepo.insertSongs(distinctSongs)
            }
            _isLoadingArtistSongs.value = false
        }
    }

    fun navigateTo(screen: Screen) {
        _currentScreen.value = screen
    }

    fun setFullPlayerVisible(visible: Boolean) {
        _isFullPlayerVisible.value = visible
    }

    fun setLyricsVisible(visible: Boolean) {
        _isLyricsVisible.value = visible
        if (visible) {
            fetchLyricsForCurrentSong(force = false)
        }
    }

    fun toggleLyricsVisible() {
        val next = !_isLyricsVisible.value
        _isLyricsVisible.value = next
        if (next) {
            fetchLyricsForCurrentSong(force = false)
        }
    }

    fun adjustLyricsOffsetForCurrentSong(deltaMs: Long) {
        val currentSong = playerState.value.currentSong ?: return
        val currentOffset = _lyricsOffsets[currentSong.id] ?: 0L
        val newOffset = (currentOffset + deltaMs).coerceIn(-15000L, 15000L)
        _lyricsOffsets[currentSong.id] = newOffset
        _lyricsUiState.value = _lyricsUiState.value.copy(syncOffsetMs = newOffset)
    }

    fun resetLyricsOffsetForCurrentSong() {
        val currentSong = playerState.value.currentSong ?: return
        _lyricsOffsets.remove(currentSong.id)
        _lyricsUiState.value = _lyricsUiState.value.copy(syncOffsetMs = 0L)
    }

    fun searchLyricsCustom(query: String) {
        val currentSong = playerState.value.currentSong ?: return
        lyricsJob?.cancel()
        lyricsJob = viewModelScope.launch {
            val savedOffset = _lyricsOffsets[currentSong.id] ?: 0L
            _lyricsUiState.value = LyricsUiState(
                isLoading = true,
                songId = currentSong.id,
                syncOffsetMs = savedOffset
            )
            try {
                val data = LrclibLyricsService.searchLyricsCustom(query, currentSong.durationSeconds)
                _lyricsUiState.value = LyricsUiState(
                    isLoading = false,
                    songId = currentSong.id,
                    lyricsData = data,
                    syncOffsetMs = savedOffset,
                    error = if (data == null) "No se encontró letra para '$query'" else null
                )
            } catch (e: Exception) {
                _lyricsUiState.value = LyricsUiState(
                    isLoading = false,
                    songId = currentSong.id,
                    lyricsData = null,
                    syncOffsetMs = savedOffset,
                    error = e.message
                )
            }
        }
    }

    fun fetchLyricsForCurrentSong(force: Boolean = false) {
        val currentSong = playerState.value.currentSong ?: return
        val savedOffset = _lyricsOffsets[currentSong.id] ?: 0L
        if (!force && _lyricsUiState.value.songId == currentSong.id && _lyricsUiState.value.lyricsData != null) {
            if (_lyricsUiState.value.syncOffsetMs != savedOffset) {
                _lyricsUiState.value = _lyricsUiState.value.copy(syncOffsetMs = savedOffset)
            }
            return
        }
        lyricsJob?.cancel()
        lyricsJob = viewModelScope.launch {
            _lyricsUiState.value = LyricsUiState(
                isLoading = true,
                songId = currentSong.id,
                syncOffsetMs = savedOffset
            )
            try {
                val data = LrclibLyricsService.fetchLyrics(currentSong)
                _lyricsUiState.value = LyricsUiState(
                    isLoading = false,
                    songId = currentSong.id,
                    lyricsData = data,
                    syncOffsetMs = savedOffset,
                    error = if (data == null) "No se encontró letra para esta canción" else null
                )
            } catch (e: Exception) {
                _lyricsUiState.value = LyricsUiState(
                    isLoading = false,
                    songId = currentSong.id,
                    lyricsData = null,
                    syncOffsetMs = savedOffset,
                    error = e.message
                )
            }
        }
    }

    // --- Jam (Group Listening) ---
    fun setJamDialogOpen(open: Boolean) {
        _isJamDialogOpen.value = open
    }

    fun createJamSession() {
        viewModelScope.launch {
            val user = activeUser.value ?: userRepo.getActiveUser()
            var song = playerState.value.currentSong
            if (song == null) {
                song = allSongs.value.firstOrNull() ?: com.example.data.seed.CatalogSeed.defaultSongs.first()
                playSong(song, listOf(song))
            }
            DriyJamManager.createSession(user, song)
        }
    }

    fun joinJamSession(code: String, onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            val user = activeUser.value ?: userRepo.getActiveUser()
            val result = DriyJamManager.joinSession(code, user)
            if (result.isSuccess) {
                val session = result.getOrNull()
                val songId = session?.currentSongId
                if (!songId.isNullOrBlank()) {
                    val localSong = allSongs.value.firstOrNull { it.id == songId }
                    val songToPlay = localSong ?: SongEntity(
                        id = songId,
                        title = session.currentSongTitle ?: "Canción en Jam",
                        artist = session.currentSongArtist ?: "DriyMusic",
                        genre = "Jam",
                        album = "Sincronizado en Jam",
                        coverUrl = session.currentSongCover ?: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=500&q=80",
                        audioUrl = "https://www.youtube.com/watch?v=$songId",
                        durationSeconds = 210
                    )
                    playSong(songToPlay, listOf(songToPlay))
                }
                onResult(true, "¡Conectado a la Jam creada por ${session?.hostName ?: "el anfitrión"}!")
            } else {
                onResult(false, result.exceptionOrNull()?.message ?: "No se pudo conectar a la Jam")
            }
        }
    }

    fun leaveJamSession() {
        DriyJamManager.leaveSession()
    }

    // --- Authentication & Recovery ---
    suspend fun checkUsernameTaken(username: String): Boolean {
        return userRepo.isUsernameTaken(username)
    }

    suspend fun findExistingAccount(username: String, phoneNumber: String): UserEntity? {
        return userRepo.findExistingAccount(username, phoneNumber)
    }

    suspend fun verifyIdentityForRecovery(firstName: String, lastName: String, phoneNumber: String): UserEntity? {
        return userRepo.findUserForRecovery(firstName, lastName, phoneNumber)
    }

    suspend fun resetUserPassword(userIdOrUsername: String, newPassword: String): Boolean {
        val result = userRepo.resetUserPassword(userIdOrUsername, newPassword)
        if (result) {
            showNotification("✓ Contraseña restablecida de manera segura")
            loadRegisteredUsers()
        }
        return result
    }

    suspend fun validateLoginCredentials(username: String, password: String, phoneNumber: String): String? {
        val cleanUsername = username.trim().removePrefix("@").lowercase()
        val cleanPhoneDigits = phoneNumber.filter { it.isDigit() }

        val result = userRepo.loginWithUserAndPhone(cleanUsername, password, cleanPhoneDigits)
        return if (result.isSuccess) {
            null
        } else {
            result.exceptionOrNull()?.message ?: "Error al verificar credenciales"
        }
    }

    fun registerUserWithPhone(
        firstName: String,
        lastName: String,
        username: String,
        password: String,
        phoneNumber: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        viewModelScope.launch {
            _isAuthenticating.value = true
            try {
                val cleanUsername = username.trim().removePrefix("@").lowercase()
                val cleanPhone = phoneNumber.filter { it.isDigit() }
                val isReservedAdminAccount = cleanUsername == "driyadmincompany" ||
                                             cleanUsername == "driycompany" ||
                                             cleanPhone == "928598496" ||
                                             cleanPhone == "921483434" ||
                                             cleanPhone == "950312209"
                if (isReservedAdminAccount) {
                    _isAuthenticating.value = false
                    withContext(Dispatchers.Main) {
                        onError("Esta cuenta o número están reservados para la administración de DriyStream. Si eres el dueño, por favor inicia sesión.")
                    }
                    return@launch
                }

                val existing = userRepo.findExistingAccount(cleanUsername, phoneNumber)
                if (existing != null) {
                    _isAuthenticating.value = false
                    withContext(Dispatchers.Main) {
                        onError("Ya existe una cuenta con el usuario '@$cleanUsername'. Por favor inicia sesión.")
                    }
                    return@launch
                }

                userRepo.registerUserWithPhone(
                    firstName = firstName,
                    lastName = lastName,
                    username = cleanUsername,
                    password = password,
                    phoneNumber = phoneNumber
                )
                SingleDeviceSessionManager.createAndRegisterSession(getApplication(), cleanUsername)
                startSessionMonitoringForUser(cleanUsername)
                loadRegisteredUsers()
                _isAuthenticating.value = false
                val cloudErr = userRepo.getLastCloudError()
                if (!cloudErr.isNullOrBlank()) {
                    showNotification("⚠️ Cuenta creada localmente (Falta activar Firestore en consola)")
                } else {
                    showNotification("🎉 Cuenta creada y sincronizada en la nube")
                }
                withContext(Dispatchers.Main) {
                    onSuccess()
                    _currentScreen.value = Screen.OnboardingGenre
                }
            } catch (e: Exception) {
                _isAuthenticating.value = false
                withContext(Dispatchers.Main) {
                    onError(e.message ?: "Error al registrar la cuenta")
                }
            }
        }
    }

    fun loginWithUserAndPhone(
        username: String,
        password: String,
        phoneNumber: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        viewModelScope.launch {
            _isAuthenticating.value = true
            val result = userRepo.loginWithUserAndPhone(
                username = username,
                password = password,
                phoneNumber = phoneNumber
            )
            _isAuthenticating.value = false
            result.onSuccess { user ->
                loadRegisteredUsers()
                SingleDeviceSessionManager.createAndRegisterSession(getApplication(), user.id)
                startSessionMonitoringForUser(user.id)
                UserCloudSyncManager.restoreUserDataFromCloud(getApplication(), user.id)
                UserCloudSyncManager.startRealtimeUserSync(getApplication(), user.id)
                showNotification("¡Bienvenido de nuevo, ${user.displayName}!")
                withContext(Dispatchers.Main) {
                    onSuccess()
                    if (user.isOnboarded) {
                        _currentScreen.value = Screen.Home
                    } else {
                        _currentScreen.value = Screen.OnboardingGenre
                    }
                }
            }.onFailure { err ->
                withContext(Dispatchers.Main) {
                    onError(err.message ?: "Credenciales incorrectas")
                }
            }
        }
    }

    fun loginWithGoogle(activityContext: Context, customName: String? = null) {
        viewModelScope.launch {
            _isAuthenticating.value = true
            val result = authManager.signInWithGoogleCredentialManager(activityContext, customName = customName)
            _isAuthenticating.value = false
            result.onSuccess { user ->
                loadRegisteredUsers()
                SingleDeviceSessionManager.createAndRegisterSession(getApplication(), user.id)
                startSessionMonitoringForUser(user.id)
                UserCloudSyncManager.restoreUserDataFromCloud(getApplication(), user.id)
                UserCloudSyncManager.startRealtimeUserSync(getApplication(), user.id)
                if (user.email.equals("driycompany@gmail.com", ignoreCase = true)) {
                    val tenYearsMillis = 3650L * 24 * 3600 * 1000
                    userRepo.updateSubscriptionExpiresAt(user.id, System.currentTimeMillis() + tenYearsMillis)
                    if (!user.isOnboarded) {
                        userRepo.completeOnboarding(user.id, listOf("Bad Bunny", "Feid", "Karol G"))
                    }
                    _currentScreen.value = Screen.Home
                } else if (user.isOnboarded) {
                    _currentScreen.value = Screen.Home
                } else {
                    _currentScreen.value = Screen.OnboardingGenre
                }
            }
        }
    }

    fun updateDisplayName(newName: String) {
        val user = activeUser.value ?: return
        val cleanName = newName.trim()
        if (cleanName.isBlank()) return
        viewModelScope.launch {
            userRepo.updateDisplayName(user.id, cleanName)
            loadRegisteredUsers()
        }
    }

    fun updatePhotoUrl(newPhotoUrl: String) {
        val user = activeUser.value ?: return
        viewModelScope.launch {
            userRepo.updatePhotoUrl(user.id, newPhotoUrl)
            showNotification("📸 Foto de perfil actualizada")
            loadRegisteredUsers()
        }
    }

    fun saveAndSetProfileImage(uri: Uri) {
        val user = activeUser.value ?: return
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val context = getApplication<Application>()
                val inputStream = context.contentResolver.openInputStream(uri)
                val originalBitmap = android.graphics.BitmapFactory.decodeStream(inputStream)
                inputStream?.close()

                if (originalBitmap != null) {
                    val size = minOf(originalBitmap.width, originalBitmap.height)
                    val x = (originalBitmap.width - size) / 2
                    val y = (originalBitmap.height - size) / 2
                    val cropped = android.graphics.Bitmap.createBitmap(originalBitmap, x, y, size, size)
                    val targetSize = minOf(size, 400)
                    val scaled = if (size > targetSize) {
                        android.graphics.Bitmap.createScaledBitmap(cropped, targetSize, targetSize, true)
                    } else {
                        cropped
                    }

                    // 1. Save to local app storage
                    val cleanId = user.id.trim().lowercase()
                    val localFile = File(context.filesDir, "avatar_${cleanId}.jpg")
                    FileOutputStream(localFile).use { out ->
                        scaled.compress(android.graphics.Bitmap.CompressFormat.JPEG, 85, out)
                    }

                    // 2. Compress into Base64 JPEG data URL for permanent cross-device & cloud sync
                    val byteStream = java.io.ByteArrayOutputStream()
                    scaled.compress(android.graphics.Bitmap.CompressFormat.JPEG, 80, byteStream)
                    val base64Bytes = byteStream.toByteArray()
                    val base64String = "data:image/jpeg;base64," + android.util.Base64.encodeToString(base64Bytes, android.util.Base64.NO_WRAP)

                    userRepo.updatePhotoUrl(user.id, photoUrl = localFile.absolutePath, cloudPhotoUrl = base64String)
                    showNotification("📸 Foto de perfil guardada con éxito")
                    loadRegisteredUsers()
                } else {
                    val cleanId = user.id.trim().lowercase()
                    val localFile = File(context.filesDir, "avatar_${cleanId}.jpg")
                    context.contentResolver.openInputStream(uri)?.use { input ->
                        FileOutputStream(localFile).use { out ->
                            input.copyTo(out)
                        }
                    }
                    userRepo.updatePhotoUrl(user.id, localFile.absolutePath)
                    showNotification("📸 Foto de perfil actualizada")
                    loadRegisteredUsers()
                }
            } catch (e: Exception) {
                Log.e("DriyViewModel", "Error saving profile image: ${e.message}", e)
                userRepo.updatePhotoUrl(user.id, uri.toString())
                showNotification("📸 Foto de perfil actualizada")
                loadRegisteredUsers()
            }
        }
    }

    fun signOut() {
        viewModelScope.launch {
            DriyAudioPlayer.stop()
            com.example.ui.theme.ThemeManager.resetToDefaults()
            SingleDeviceSessionManager.stopMonitoring()
            UserCloudSyncManager.clearLocalUserDataOnSignOut(getApplication())
            authManager.signOut()
            _selectedGenres.value = emptySet()
            _selectedArtists.value = emptySet()
            _favoriteArtistsSongs.value = emptyList()
            _recentSearchedSongs.value = emptyList()
            _currentScreen.value = Screen.Login
        }
    }

    fun deleteAccount(onComplete: () -> Unit = {}) {
        viewModelScope.launch {
            try {
                DriyAudioPlayer.stop()
                com.example.ui.theme.ThemeManager.resetToDefaults()
                SingleDeviceSessionManager.stopMonitoring()
                UserCloudSyncManager.clearLocalUserDataOnSignOut(getApplication())
                authManager.deleteAccount()
                _selectedGenres.value = emptySet()
                _selectedArtists.value = emptySet()
                _favoriteArtistsSongs.value = emptyList()
                _recentSearchedSongs.value = emptyList()
                _currentScreen.value = Screen.Login
                showNotification("Cuenta eliminada correctamente")
                loadRegisteredUsers()
                onComplete()
            } catch (e: Exception) {
                Log.e("DriyViewModel", "Error deleting account", e)
                showNotification("Error al eliminar cuenta")
            }
        }
    }

    // --- Onboarding Flow ---
    fun getGenres(): List<Genre> = musicRepo.getAllGenres()

    fun toggleGenreSelection(genreId: String) {
        val current = _selectedGenres.value.toMutableSet()
        if (current.contains(genreId)) {
            current.remove(genreId)
        } else {
            current.add(genreId)
        }
        _selectedGenres.value = current
    }

    fun submitGenres() {
        if (_selectedGenres.value.size >= 4) {
            val user = activeUser.value
            if (user != null) {
                viewModelScope.launch {
                    userRepo.saveSelectedGenres(user.id, _selectedGenres.value.toList())
                }
            }
            _currentScreen.value = Screen.OnboardingArtist
        }
    }

    fun setArtistSearchQuery(query: String) {
        _artistSearchQuery.value = query
    }

    fun getArtistsForOnboarding(): List<Artist> {
        val query = _artistSearchQuery.value
        return if (query.isNotBlank()) {
            musicRepo.searchArtists(query)
        } else {
            musicRepo.getArtistsForGenres(_selectedGenres.value.toList())
        }
    }

    fun toggleArtistSelection(artistName: String) {
        val current = _selectedArtists.value.toMutableSet()
        if (current.contains(artistName)) {
            current.remove(artistName)
        } else {
            current.add(artistName)
        }
        _selectedArtists.value = current
    }

    fun completeOnboarding() {
        if (_selectedArtists.value.size >= 4) {
            val user = activeUser.value
            val artistsList = _selectedArtists.value.toList()
            if (user != null) {
                viewModelScope.launch {
                    userRepo.completeOnboarding(user.id, artistsList)
                }
            }
            loadFavoriteArtistsSongs(artistsList)
            _currentScreen.value = Screen.Home
        }
    }

    // --- Predictive Search (Local + YouTube) ---
    private val _youtubeResults = MutableStateFlow<List<SongEntity>>(emptyList())
    private val _isSearching = MutableStateFlow(false)
    val isSearching: StateFlow<Boolean> = _isSearching.asStateFlow()
    private var searchJob: Job? = null

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
        searchJob?.cancel()

        if (query.isBlank()) {
            _youtubeResults.value = emptyList()
            _isSearching.value = false
            return
        }

        _isSearching.value = true
        searchJob = viewModelScope.launch {
            delay(200)
            try {
                if (query.trim().length >= 3) {
                    musicRepo.recordSearchQuery(query.trim())
                }
                val results = YouTubeService.searchYouTube(query)
                _youtubeResults.value = results

                if (results.isNotEmpty()) {
                    val currentSearched = _recentSearchedSongs.value.toMutableList()
                    results.take(6).forEach { r ->
                        currentSearched.removeAll { it.id == r.id }
                        currentSearched.add(0, r)
                    }
                    _recentSearchedSongs.value = currentSearched.take(25)
                    musicRepo.insertSongs(results.take(6))
                    musicRepo.recordSearchQuery(query.trim(), results.take(4))
                }
            } catch (e: Exception) {
                // ignore
            } finally {
                _isSearching.value = false
            }
        }
    }

    fun recordSongSearch(song: SongEntity) {
        viewModelScope.launch {
            musicRepo.insertSong(song)
            musicRepo.recordSearch(song.id)
        }
    }

    fun recordSearchQuery(query: String) {
        val trimmed = query.trim()
        if (trimmed.length < 2) return
        viewModelScope.launch {
            val local = allSongs.value.filter {
                it.title.contains(trimmed, ignoreCase = true) ||
                it.artist.contains(trimmed, ignoreCase = true)
            }
            val yt = _youtubeResults.value.filter {
                it.title.contains(trimmed, ignoreCase = true) ||
                it.artist.contains(trimmed, ignoreCase = true)
            }
            musicRepo.recordSearchQuery(trimmed, (local + yt).distinctBy { it.id })
        }
    }

    fun submitSearch(query: String) {
        val trimmed = query.trim()
        if (trimmed.isNotBlank()) {
            recordSearchQuery(trimmed)
            setSearchQuery(trimmed)
        }
    }

    fun playSongFromSearch(song: SongEntity, queue: List<SongEntity> = emptyList()) {
        recordSongSearch(song)
        playSong(song, queue)
    }

    val searchAutocompleteSuggestions: StateFlow<List<SongEntity>> = combine(
        allSongs,
        _searchQuery,
        _youtubeResults
    ) { songs, query, ytResults ->
        if (query.isBlank()) {
            emptyList()
        } else {
            val localMatches = songs.filter {
                it.title.contains(query, ignoreCase = true) ||
                it.artist.contains(query, ignoreCase = true) ||
                it.genre.contains(query, ignoreCase = true)
            }.take(4)
            val combined = (localMatches + ytResults).distinctBy { it.id }
            combined.take(12)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun isUserLoggedIn(): Boolean = userRepo.isUserLoggedIn()

    fun isSubscriptionActive(): Boolean {
        val user = activeUser.value
        if (user != null) {
            return user.isMasterAdmin || user.isSubscriptionActive
        }
        return userRepo.isUserLoggedIn()
    }

    // --- Playback Controls ---
    fun playSong(song: SongEntity, queue: List<SongEntity> = emptyList()) {
        if (!isSubscriptionActive()) {
            _queueNotification.value = "🔒 Acceso Bloqueado: Ingresa tu código de membresía para reproducir música."
            return
        }
        val downloadedMatch = downloadedSongs.value.find { it.id == song.id }
        val songToPlay = downloadedMatch ?: song
        val finalQueue = if (queue.isNotEmpty()) queue else listOf(songToPlay)
        DriyAudioPlayer.playSong(songToPlay, finalQueue)
        
        val currentSearched = _recentSearchedSongs.value.toMutableList()
        currentSearched.removeAll { it.id == songToPlay.id }
        currentSearched.add(0, songToPlay)
        _recentSearchedSongs.value = currentSearched.take(25)

        viewModelScope.launch {
            musicRepo.insertSong(songToPlay)
            musicRepo.recordPlay(songToPlay.id)
        }
        if (_isLyricsVisible.value) {
            fetchLyricsForCurrentSong(force = true)
        }
    }

    fun togglePlayPause() {
        DriyAudioPlayer.togglePlayPause()
    }

    fun playNext() {
        DriyAudioPlayer.playNext()
    }

    fun playPrevious() {
        DriyAudioPlayer.playPrevious()
    }

    fun seekTo(positionMs: Long) {
        DriyAudioPlayer.seekTo(positionMs)
    }

    fun toggleShuffle() {
        DriyAudioPlayer.toggleShuffle()
    }

    fun toggleSmartAutoplay() {
        val enabled = DriyAudioPlayer.toggleSmartAutoplay()
        val moodName = DriyAudioPlayer.playerState.value.autoplayMoodName ?: "tu estado de ánimo"
        showNotification(
            if (enabled) "✨ Smart Autoplay activado: música infinita según $moodName"
            else "⏸️ Autoplay desactivado"
        )
    }

    fun toggleSmartShuffle() {
        val isShuffle = DriyAudioPlayer.toggleSmartShuffle()
        val moodName = DriyAudioPlayer.playerState.value.autoplayMoodName ?: "tu estado de ánimo"
        showNotification(
            if (isShuffle) "🔀 Smart Shuffle: aleatorio inteligente según $moodName"
            else "▶️ Reproducción continua en orden"
        )
    }

    fun toggleRepeat() {
        DriyAudioPlayer.toggleRepeat()
    }

    fun setQueueVisible(visible: Boolean) {
        _isQueueVisible.value = visible
    }

    fun openSongOptions(song: SongEntity) {
        _activeSongForOptions.value = song
    }

    fun dismissSongOptions() {
        _activeSongForOptions.value = null
    }

    fun addToQueueNext(song: SongEntity) {
        DriyAudioPlayer.addToQueueNext(song)
        showNotification("⚡ '${song.title}' pasará a primera en la cola")
    }

    fun addToQueueEnd(song: SongEntity) {
        DriyAudioPlayer.addToQueueEnd(song)
        showNotification("📥 '${song.title}' agregada al final de la cola")
    }

    fun removeFromQueue(songId: String) {
        DriyAudioPlayer.removeFromQueue(songId)
    }

    fun clearQueue() {
        DriyAudioPlayer.clearQueue()
        showNotification("🗑️ Cola de reproducción vaciada")
    }

    private fun showNotification(msg: String) {
        _queueNotification.value = msg
        viewModelScope.launch {
            delay(2600)
            if (_queueNotification.value == msg) {
                _queueNotification.value = null
            }
        }
    }

    fun dismissQueueNotification() {
        _queueNotification.value = null
    }

    fun toggleFavorite(song: SongEntity) {
        viewModelScope.launch {
            musicRepo.insertSong(song)
            val currentFolders = musicRepo.getFolderIdsForSongOnce(song.id).toSet()
            val isCurrentlyFav = currentFolders.contains("favorites") || song.isFavorite

            if (!isCurrentlyFav) {
                // Instantly turn to favorite
                musicRepo.toggleFavorite(song.id, false)
                com.example.service.DriyAudioPlayer.updateSongFavorite(song.id, true)
                showNotification("❤️ Guardada en 'Favoritos'")
            }

            // Always open the folder selector so the user can save in whatever folder they want
            val updatedSong = song.copy(isFavorite = true)
            _activeSongForFolderSelection.value = updatedSong
            val folderIds = musicRepo.getFolderIdsForSongOnce(song.id).toMutableSet()
            folderIds.add("favorites")
            _selectedSongFolderIds.value = folderIds
        }
    }

    // --- Custom Folder Management ---
    fun openFolderSelector(song: SongEntity) {
        _activeSongForFolderSelection.value = song
        viewModelScope.launch {
            musicRepo.insertSong(song)
            val folderIds = musicRepo.getFolderIdsForSongOnce(song.id).toMutableSet()
            if (song.isFavorite) {
                folderIds.add("favorites")
            }
            _selectedSongFolderIds.value = folderIds
        }
    }

    fun dismissFolderSelector() {
        _activeSongForFolderSelection.value = null
    }

    fun toggleSongInFolder(folder: FolderEntity, song: SongEntity) {
        viewModelScope.launch {
            musicRepo.insertSong(song)
            val current = _selectedSongFolderIds.value
            val isCurrentlyIn = current.contains(folder.id)
            musicRepo.toggleSongInFolder(folder.id, song.id, isCurrentlyIn)
            val updated = if (isCurrentlyIn) current - folder.id else current + folder.id
            _selectedSongFolderIds.value = updated
            if (folder.isDefault || folder.id == "favorites") {
                val newFavStatus = !isCurrentlyIn
                _activeSongForFolderSelection.value = _activeSongForFolderSelection.value?.copy(isFavorite = newFavStatus)
                com.example.service.DriyAudioPlayer.updateSongFavorite(song.id, newFavStatus)
            }
            val msg = if (isCurrentlyIn) {
                if (folder.isDefault || folder.id == "favorites") "🤍 Removida de 'Favoritos'"
                else "❌ Removida de '${folder.name}'"
            } else {
                if (folder.isDefault || folder.id == "favorites") "❤️ Guardada en 'Favoritos'"
                else "📁 Guardada en '${folder.name}'"
            }
            showNotification(msg)
        }
    }

    fun createFolderAndAddSong(folderName: String, song: SongEntity?) {
        viewModelScope.launch {
            val trimmedName = folderName.trim().ifBlank { "Mi Carpeta" }
            val newFolderId = musicRepo.createFolder(trimmedName)
            if (song != null) {
                musicRepo.insertSong(song)
                musicRepo.addSongToFolder(newFolderId, song.id)
                _selectedSongFolderIds.value = _selectedSongFolderIds.value + newFolderId
                showNotification("📁 Carpeta '$trimmedName' creada y canción agregada")
            } else {
                showNotification("📁 Carpeta '$trimmedName' creada")
            }
        }
    }

    fun renameFolder(folderId: String, newName: String) {
        viewModelScope.launch {
            val trimmed = newName.trim().ifBlank { return@launch }
            musicRepo.updateFolderName(folderId, trimmed)
            if (_activeFolder.value?.id == folderId) {
                _activeFolder.value = _activeFolder.value?.copy(name = trimmed)
            }
            showNotification("✏️ Carpeta renombrada a '$trimmed'")
        }
    }

    fun deleteFolder(folder: FolderEntity) {
        viewModelScope.launch {
            if (folder.isDefault) return@launch
            musicRepo.deleteFolder(folder.id)
            if (_activeFolder.value?.id == folder.id) {
                _activeFolder.value = null
            }
            showNotification("🗑️ Carpeta '${folder.name}' eliminada")
        }
    }

    fun openFolderDetail(folder: FolderEntity) {
        _activeFolder.value = folder
    }

    fun closeFolderDetail() {
        _activeFolder.value = null
    }

    fun removeSongFromCurrentFolder(folderId: String, songId: String) {
        viewModelScope.launch {
            musicRepo.removeSongFromFolder(folderId, songId)
            showNotification("❌ Canción removida de la carpeta")
        }
    }

    // --- Offline Downloads ---
    fun scanDownloadedSongs() {
        viewModelScope.launch {
            showNotification("🔍 Buscando canciones en carpeta DriyStream...")
            val restored = musicRepo.scanAndRestoreDownloadedSongs()
            if (restored > 0) {
                showNotification("🎵 ¡Se encontraron y restauraron $restored canciones offline!")
            } else {
                showNotification("📁 Carpeta DriyStream verificada. Canciones al día.")
            }
        }
    }

    fun downloadSong(song: SongEntity) {
        if (song.isDownloaded) {
            viewModelScope.launch {
                musicRepo.removeDownload(song.id)
                showNotification("🗑️ '${song.title}' eliminada de tus descargas")
            }
            return
        }
        viewModelScope.launch {
            _downloadProgress.value = _downloadProgress.value + (song.id to 0.05f)
            showNotification("⏳ Descargando audio completo de '${song.title}'...")
            val result = musicRepo.downloadSong(song) { progress ->
                _downloadProgress.value = _downloadProgress.value + (song.id to progress)
            }
            _downloadProgress.value = _downloadProgress.value - song.id
            if (result.isSuccess) {
                showNotification("✓ '${song.title}' guardada en tu carpeta de Descargas (Offline disponible)")
            } else {
                showNotification("⚠️ Error al descargar audio de '${song.title}'")
            }
        }
    }

    fun openDownloadsFolder(context: Context) {
        try {
            val intent = Intent(DownloadManager.ACTION_VIEW_DOWNLOADS).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            try {
                val intent = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(Uri.parse(android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS).path), "*/*")
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(intent)
            } catch (ex: Exception) {
                showNotification("Abre la app 'Archivos' > 'Descargas' en tu dispositivo")
            }
        }
    }

    fun shareDownloadedSong(context: Context, song: SongEntity) {
        val uri = musicRepo.getSongShareUri(song)
        if (uri != null) {
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "audio/*"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "${song.title} - ${song.artist}")
                putExtra(Intent.EXTRA_TEXT, "Canción descargada: '${song.title}' de ${song.artist}")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val chooser = Intent.createChooser(intent, "Compartir canción").apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(chooser)
        } else {
            showNotification("Descarga la canción primero para compartir el archivo")
        }
    }

    fun getDownloadedFileSize(song: SongEntity): String? {
        val file = musicRepo.getDownloadedAudioFile(song) ?: return null
        val bytes = file.length()
        val mb = bytes.toDouble() / (1024 * 1024)
        return String.format(java.util.Locale.US, "%.1f MB", mb)
    }

    fun canDrawOverlays(): Boolean {
        return Settings.canDrawOverlays(getApplication())
    }

    fun openOverlaySettings(context: Context) {
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:${context.packageName}")
        ).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    }

    fun uploadMusicWork(
        title: String,
        composer: String,
        authorshipPercentage: String,
        artist: String,
        genre: String,
        approxDuration: String,
        releaseDate: String,
        audioUri: Uri,
        audioFileName: String,
        pdfUri: Uri?,
        pdfFileName: String?,
        coverUri: Uri?,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val context = getApplication<Application>()
                val uploadsDir = File(context.filesDir, "uploads")
                if (!uploadsDir.exists()) uploadsDir.mkdirs()

                val workId = "user_track_${UUID.randomUUID()}"
                val audioExtension = when {
                    audioFileName.endsWith(".wav", ignoreCase = true) -> "wav"
                    audioFileName.endsWith(".zip", ignoreCase = true) -> "zip"
                    audioFileName.endsWith(".m4a", ignoreCase = true) -> "m4a"
                    else -> "mp3"
                }

                val localAudioFile = File(uploadsDir, "${workId}.$audioExtension")
                context.contentResolver.openInputStream(audioUri)?.use { input ->
                    FileOutputStream(localAudioFile).use { output ->
                        input.copyTo(output)
                    }
                }

                var localPdfPath: String? = null
                if (pdfUri != null) {
                    val localPdfFile = File(uploadsDir, "${workId}_legal.pdf")
                    context.contentResolver.openInputStream(pdfUri)?.use { input ->
                        FileOutputStream(localPdfFile).use { output ->
                            input.copyTo(output)
                        }
                    }
                    localPdfPath = localPdfFile.absolutePath
                }

                var localCoverPath: String? = null
                if (coverUri != null) {
                    val localCoverFile = File(uploadsDir, "${workId}_cover.jpg")
                    context.contentResolver.openInputStream(coverUri)?.use { input ->
                        FileOutputStream(localCoverFile).use { output ->
                            input.copyTo(output)
                        }
                    }
                    localCoverPath = localCoverFile.absolutePath
                }

                val formatBadge = when {
                    audioFileName.endsWith(".wav", ignoreCase = true) -> "WAV"
                    audioFileName.endsWith(".zip", ignoreCase = true) -> "ZIP"
                    else -> "MP3"
                }

                val uploadedEntity = UploadedSongEntity(
                    id = workId,
                    title = title.trim(),
                    composer = composer.trim(),
                    authorshipPercentage = authorshipPercentage.trim().ifBlank { "100%" },
                    artist = artist.trim(),
                    genre = genre.trim().ifBlank { "Original" },
                    approxDuration = approxDuration.trim().ifBlank { "03:30" },
                    releaseDate = releaseDate.trim().ifBlank { "2026" },
                    audioFilePath = localAudioFile.absolutePath,
                    audioFileName = audioFileName,
                    audioFormatBadge = formatBadge,
                    pdfDocPath = localPdfPath,
                    pdfDocName = pdfFileName,
                    coverUrl = localCoverPath ?: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=500&q=80",
                    isCopyrightDeclared = true
                )

                musicRepo.saveUploadedSong(uploadedEntity)
                showNotification("🎉 Obra '$title' registrada exitosamente")

                withContext(Dispatchers.Main) {
                    onSuccess()
                }

                val currentUser = activeUser.value
                viewModelScope.launch(Dispatchers.IO) {
                    val result = FirebaseMusicSyncManager.publishSongToGlobalCloud(
                        uploadedSong = uploadedEntity,
                        audioFile = localAudioFile,
                        pdfFile = localPdfPath?.let { File(it) },
                        coverFile = localCoverPath?.let { File(it) },
                        uploaderEmail = currentUser?.email,
                        uploaderName = currentUser?.displayName
                    )
                    if (result.isSuccess) {
                        showNotification("🌐 '$title' ahora es visible para todos los usuarios en el feed")
                    }
                }

            } catch (e: Exception) {
                showNotification("Error al procesar los archivos: ${e.message}")
            }
        }
    }

    fun deleteUploadedSong(uploaded: UploadedSongEntity) {
        viewModelScope.launch {
            musicRepo.deleteUploadedSong(uploaded)
            showNotification("🗑️ Obra musical eliminada")
        }
    }

    private val _isSyncingCloud = MutableStateFlow(false)
    val isSyncingCloud: StateFlow<Boolean> = _isSyncingCloud.asStateFlow()

    fun syncWithCloud() {
        viewModelScope.launch {
            _isSyncingCloud.value = true
            val userId = activeUser.value?.id ?: userRepo.getActiveUser()?.id ?: authManager.getPersistedUser()?.id
            if (!userId.isNullOrBlank()) {
                val ok = UserCloudSyncManager.restoreUserDataFromCloud(getApplication(), userId)
                if (ok) {
                    showNotification("☁️ ¡Biblioteca y favoritos sincronizados desde la nube!")
                } else {
                    UserCloudSyncManager.syncUserFoldersAndFavoritesToCloud(getApplication(), userId)
                    showNotification("☁️ Sincronización con la nube completada")
                }
            } else {
                showNotification("Inicia sesión para sincronizar tus favoritos entre celulares")
            }
            _isSyncingCloud.value = false
        }
    }

    override fun onCleared() {
        super.onCleared()
        UserCloudSyncManager.stopRealtimeUserSync()
    }
}
