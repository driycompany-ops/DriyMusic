package com.example.ui.components

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.ui.res.painterResource
import com.example.R
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import coil.compose.AsyncImage
import com.example.data.model.JamParticipant
import com.example.data.model.JamSession
import com.example.data.model.JamSessionState
import com.example.data.model.UserEntity
import com.example.service.DriyJamManager
import com.example.service.PlayerState
import com.example.ui.theme.DriyBackground
import com.example.ui.theme.DriyDivider
import com.example.ui.theme.DriyGold
import com.example.ui.theme.DriySurface
import com.example.ui.theme.DriySurfaceVariant
import com.example.ui.theme.DriyTextPrimary
import com.example.ui.theme.DriyTextSecondary
import com.google.zxing.BinaryBitmap
import com.google.zxing.MultiFormatReader
import com.google.zxing.PlanarYUVLuminanceSource
import com.google.zxing.RGBLuminanceSource
import com.google.zxing.common.HybridBinarizer

private enum class JamSubScreen {
    CHOICE,
    JOINING
}

@Composable
fun JamDialog(
    isOpen: Boolean,
    onDismiss: () -> Unit,
    jamState: JamSessionState,
    currentUser: UserEntity?,
    playerState: PlayerState,
    onCreateJam: () -> Unit,
    onJoinJam: (String, (Boolean, String) -> Unit) -> Unit,
    onLeaveJam: () -> Unit
) {
    if (!isOpen) return

    val context = LocalContext.current
    var subScreen by remember { mutableStateOf(JamSubScreen.CHOICE) }
    var joinTab by remember { mutableIntStateOf(0) } // 0: Scan QR, 1: Enter Code
    var inputCode by remember { mutableStateOf("") }
    var isJoining by remember { mutableStateOf(false) }
    var joinError by remember { mutableStateOf<String?>(null) }
    var copiedCodeFeedback by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DriySurface,
        modifier = Modifier.padding(vertical = 12.dp),
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Image(
                        painter = painterResource(R.drawable.driymusic_logo),
                        contentDescription = "Logo DriyMusic",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .border(1.dp, DriyGold.copy(alpha = 0.6f), RoundedCornerShape(8.dp))
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Driy Jam",
                            color = DriyTextPrimary,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Sesión Grupal en Directo",
                            color = DriyTextSecondary,
                            fontSize = 11.sp
                        )
                    }
                }
                IconButton(onClick = onDismiss) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Cerrar",
                        tint = DriyTextSecondary
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                when (jamState) {
                    is JamSessionState.Idle -> {
                        when (subScreen) {
                            JamSubScreen.CHOICE -> {
                                ChoiceView(
                                    onCreateClick = {
                                        onCreateJam()
                                    },
                                    onJoinClick = {
                                        subScreen = JamSubScreen.JOINING
                                        joinError = null
                                    }
                                )
                            }
                            JamSubScreen.JOINING -> {
                                JoinView(
                                    joinTab = joinTab,
                                    onTabSelected = { joinTab = it },
                                    inputCode = inputCode,
                                    onInputChange = {
                                        inputCode = it
                                        joinError = null
                                    },
                                    isJoining = isJoining,
                                    errorMessage = joinError,
                                    onBackToChoice = {
                                        subScreen = JamSubScreen.CHOICE
                                        joinError = null
                                    },
                                    onConfirmCode = { codeToJoin ->
                                        if (codeToJoin.isBlank()) {
                                            joinError = "Ingresa o escanea un código de Jam válido"
                                            return@JoinView
                                        }
                                        if (inputCode.isBlank()) {
                                            inputCode = codeToJoin
                                        }
                                        isJoining = true
                                        joinError = null
                                        onJoinJam(codeToJoin) { success, msg ->
                                            isJoining = false
                                            if (!success) {
                                                joinError = msg
                                                joinTab = 1
                                            } else {
                                                Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                                            }
                                        }
                                    }
                                )
                            }
                        }
                    }
                    is JamSessionState.Hosting -> {
                        HostingView(
                            session = jamState.session,
                            qrBitmap = jamState.qrBitmap,
                            currentUser = currentUser,
                            copiedFeedback = copiedCodeFeedback,
                            onCopyCode = {
                                copyToClipboard(context, jamState.session.code)
                                copiedCodeFeedback = true
                            },
                            onShare = {
                                shareJamInvite(context, jamState.session.code)
                            },
                            onEndSession = onLeaveJam
                        )
                    }
                    is JamSessionState.Joined -> {
                        JoinedView(
                            session = jamState.session,
                            currentUser = currentUser,
                            onLeave = onLeaveJam
                        )
                    }
                }
            }
        },
        confirmButton = {}
    )
}

@Composable
private fun ChoiceView(
    onCreateClick: () -> Unit,
    onJoinClick: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            text = "Escucha música sincronizada con amigos en tiempo real:",
            color = DriyTextSecondary,
            fontSize = 13.sp,
            lineHeight = 18.sp
        )

        // Option 1: Create Jam
        Card(
            colors = CardDefaults.cardColors(containerColor = DriySurfaceVariant),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onCreateClick() }
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .clip(CircleShape)
                        .background(DriyGold.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.QrCode,
                        contentDescription = null,
                        tint = DriyGold,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Spacer(modifier = Modifier.width(14.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "Crear una Jam",
                            color = DriyTextPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(DriyGold.copy(alpha = 0.2f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text("Anfitrión", color = DriyGold, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = "Genera un código y QR para transmitir tu música en vivo a tus amigos.",
                        color = DriyTextSecondary,
                        fontSize = 11.sp,
                        lineHeight = 15.sp
                    )
                }
            }
        }

        // Option 2: Join Jam
        Card(
            colors = CardDefaults.cardColors(containerColor = DriySurfaceVariant),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onJoinClick() }
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF2196F3).copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.QrCodeScanner,
                        contentDescription = null,
                        tint = Color(0xFF64B5F6),
                        modifier = Modifier.size(24.dp)
                    )
                }
                Spacer(modifier = Modifier.width(14.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Unirme a una Jam",
                        color = DriyTextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = "Escanea el código QR del anfitrión o ingresa su código de grupo.",
                        color = DriyTextSecondary,
                        fontSize = 11.sp,
                        lineHeight = 15.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun HostingView(
    session: JamSession,
    qrBitmap: Bitmap?,
    currentUser: UserEntity?,
    copiedFeedback: Boolean,
    onCopyCode: () -> Unit,
    onShare: () -> Unit,
    onEndSession: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Status Badge
        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(20.dp))
                .background(DriyGold.copy(alpha = 0.2f))
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.FiberManualRecord,
                contentDescription = null,
                tint = DriyGold,
                modifier = Modifier.size(10.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "👑 ERES EL ANFITRIÓN DE LA JAM",
                color = DriyGold,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // QR Code Display
        if (qrBitmap != null) {
            Box(
                modifier = Modifier
                    .size(200.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color.White)
                    .padding(10.dp),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    bitmap = qrBitmap.asImageBitmap(),
                    contentDescription = "Código QR de Jam",
                    modifier = Modifier.fillMaxSize()
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Group Code with Tap-to-Copy
        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(12.dp))
                .background(DriySurfaceVariant)
                .clickable { onCopyCode() }
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "CÓDIGO DE GRUPO",
                    color = DriyTextSecondary,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = session.code,
                    color = DriyGold,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 2.sp
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Icon(
                imageVector = if (copiedFeedback) Icons.Default.Check else Icons.Default.ContentCopy,
                contentDescription = "Copiar código",
                tint = if (copiedFeedback) DriyGold else DriyTextSecondary,
                modifier = Modifier.size(20.dp)
            )
        }

        if (copiedFeedback) {
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "¡Código copiado al portapapeles!",
                color = DriyGold,
                fontSize = 11.sp
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Share Button
        Button(
            onClick = onShare,
            colors = ButtonDefaults.buttonColors(
                containerColor = DriySurfaceVariant,
                contentColor = DriyTextPrimary
            ),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(
                imageVector = Icons.Default.Share,
                contentDescription = null,
                modifier = Modifier.size(18.dp),
                tint = DriyGold
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text("Compartir Invitación con Amigos", fontSize = 13.sp)
        }

        Spacer(modifier = Modifier.height(14.dp))
        HorizontalDivider(color = DriyDivider)
        Spacer(modifier = Modifier.height(12.dp))

        // Currently Playing in Jam
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(DriySurfaceVariant)
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (!session.currentSongCover.isNullOrBlank()) {
                AsyncImage(
                    model = session.currentSongCover,
                    contentDescription = null,
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(8.dp)),
                    contentScale = ContentScale.Crop
                )
            } else {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(DriyBackground),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.MusicNote,
                        contentDescription = null,
                        tint = DriyGold
                    )
                }
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = session.currentSongTitle ?: "Reproduciendo música",
                    color = DriyTextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1
                )
                Text(
                    text = session.currentSongArtist ?: "DriyMusic Jam",
                    color = DriyTextSecondary,
                    fontSize = 11.sp,
                    maxLines = 1
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Participants List
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "👥 Usuarios unidos a tu Jam (${session.participants.size}):",
                color = DriyTextSecondary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "● En vivo",
                color = Color(0xFF4CAF50),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            session.participants.forEach { participant ->
                val isMe = participant.isHost || participant.id == currentUser?.id || participant.name == currentUser?.displayName
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(DriySurfaceVariant)
                        .padding(horizontal = 10.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(if (participant.isHost) DriyGold else DriyDivider),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = participant.name.take(1).uppercase(),
                            color = if (participant.isHost) DriyBackground else DriyTextPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = if (isMe && participant.isHost) "${participant.name} (Tú)" else participant.name,
                        color = DriyTextPrimary,
                        fontSize = 13.sp,
                        fontWeight = if (participant.isHost) FontWeight.Bold else FontWeight.Normal,
                        modifier = Modifier.weight(1f)
                    )
                    if (participant.isHost) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(DriyGold.copy(alpha = 0.2f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "👑 Creador",
                                color = DriyGold,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    } else {
                        Text(
                            text = "Oyente",
                            color = Color(0xFF4CAF50),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // End session button
        OutlinedButton(
            onClick = onEndSession,
            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFFF5252)),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Finalizar Jam Grupal", fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun JoinedView(
    session: JamSession,
    currentUser: UserEntity?,
    onLeave: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Status Badge
        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(20.dp))
                .background(Color(0xFF4CAF50).copy(alpha = 0.2f))
                .padding(horizontal = 14.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.FiberManualRecord,
                contentDescription = null,
                tint = Color(0xFF4CAF50),
                modifier = Modifier.size(10.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "CONECTADO A LA JAM",
                color = Color(0xFF4CAF50),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 👑 Dedicated Card for Jam Creator / Host
        Card(
            colors = CardDefaults.cardColors(containerColor = DriySurfaceVariant),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, DriyGold.copy(alpha = 0.6f), RoundedCornerShape(16.dp))
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "👑 CREADOR DE ESTA JAM",
                        color = DriyGold,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 1.sp
                    )
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(DriyGold.copy(alpha = 0.2f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text("Anfitrión", color = DriyGold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(DriyGold)
                            .border(2.dp, DriySurface, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = session.hostName.take(1).uppercase(),
                            color = DriyBackground,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = session.hostName,
                            color = DriyTextPrimary,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Código de grupo: ${session.code}",
                            color = DriyTextSecondary,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Currently Playing Song in Jam
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(DriySurfaceVariant)
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (!session.currentSongCover.isNullOrBlank()) {
                AsyncImage(
                    model = session.currentSongCover,
                    contentDescription = null,
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(8.dp)),
                    contentScale = ContentScale.Crop
                )
            } else {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(DriyBackground),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.MusicNote,
                        contentDescription = null,
                        tint = DriyGold
                    )
                }
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = session.currentSongTitle ?: "Audio en vivo",
                    color = DriyTextPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1
                )
                Text(
                    text = session.currentSongArtist ?: "DriyMusic Radio",
                    color = DriyTextSecondary,
                    fontSize = 12.sp,
                    maxLines = 1
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "⚡ Sincronizado en directo con ${session.hostName}",
                    color = DriyGold,
                    fontSize = 10.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 👥 Connected Users List
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "👥 Usuarios Unidos a la Jam (${session.participants.size}):",
                color = DriyTextSecondary,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "● En vivo",
                color = Color(0xFF4CAF50),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            session.participants.forEach { participant ->
                val isMe = participant.id == currentUser?.id ||
                        (!currentUser?.displayName.isNullOrBlank() && participant.name.equals(currentUser.displayName, ignoreCase = true)) ||
                        (!currentUser?.username.isNullOrBlank() && participant.name.contains(currentUser.username, ignoreCase = true))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(DriySurfaceVariant)
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(if (participant.isHost) DriyGold else DriyDivider),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = participant.name.take(1).uppercase(),
                            color = if (participant.isHost) DriyBackground else DriyTextPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = if (isMe && !participant.isHost) "${participant.name} (Tú)" else participant.name,
                        color = DriyTextPrimary,
                        fontSize = 13.sp,
                        fontWeight = if (participant.isHost) FontWeight.Bold else FontWeight.Normal,
                        modifier = Modifier.weight(1f)
                    )
                    if (participant.isHost) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(DriyGold.copy(alpha = 0.2f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "👑 Creador",
                                color = DriyGold,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    } else {
                        Text(
                            text = if (isMe) "Tú" else "Oyente",
                            color = Color(0xFF4CAF50),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        OutlinedButton(
            onClick = onLeave,
            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFFF5252)),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Salir de la Jam", fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun JoinView(
    joinTab: Int,
    onTabSelected: (Int) -> Unit,
    inputCode: String,
    onInputChange: (String) -> Unit,
    isJoining: Boolean,
    errorMessage: String?,
    onBackToChoice: () -> Unit,
    onConfirmCode: (String) -> Unit
) {
    val context = LocalContext.current

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onBackToChoice) {
                Text("← Volver a opciones", color = DriyGold, fontSize = 13.sp)
            }
            Spacer(modifier = Modifier.weight(1f))
        }

        // Tabs: Escanear QR vs Ingresar Código
        TabRow(
            selectedTabIndex = joinTab,
            containerColor = DriySurfaceVariant,
            contentColor = DriyGold,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[joinTab]),
                    color = DriyGold
                )
            }
        ) {
            Tab(
                selected = joinTab == 0,
                onClick = { onTabSelected(0) },
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.QrCodeScanner, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Escanear QR", fontSize = 12.sp)
                    }
                }
            )
            Tab(
                selected = joinTab == 1,
                onClick = { onTabSelected(1) },
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Keyboard, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Ingresar Código", fontSize = 12.sp)
                    }
                }
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (joinTab == 0) {
            // Camera Scanner Screen
            QrScannerCameraView(
                onCodeDetected = { code ->
                    onConfirmCode(code)
                },
                onQuickDemoCode = { demoCode ->
                    onConfirmCode(demoCode)
                },
                onSwitchToManual = {
                    onTabSelected(1)
                }
            )
        } else {
            // Manual Code Input
            Text(
                text = "Ingresa el código que te compartió el anfitrión (ejemplo: JAM-4821 o solo 4821):",
                color = DriyTextSecondary,
                fontSize = 12.sp,
                lineHeight = 17.sp
            )

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = inputCode,
                onValueChange = onInputChange,
                label = { Text("Código de Jam") },
                placeholder = { Text("JAM-XXXX o 1234") },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = DriyGold,
                    unfocusedBorderColor = DriyDivider,
                    focusedTextColor = DriyTextPrimary,
                    unfocusedTextColor = DriyTextPrimary,
                    focusedContainerColor = DriyBackground,
                    unfocusedContainerColor = DriyBackground
                ),
                modifier = Modifier.fillMaxWidth()
            )

            // Quick paste button
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp),
                horizontalArrangement = Arrangement.End
            ) {
                TextButton(
                    onClick = {
                        val clip = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                        val item = clip?.primaryClip?.getItemAt(0)
                        val text = item?.text?.toString() ?: ""
                        if (text.isNotBlank()) {
                            onInputChange(text)
                        }
                    }
                ) {
                    Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(14.dp), tint = DriyGold)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Pegar del Portapapeles", color = DriyGold, fontSize = 11.sp)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            if (!errorMessage.isNullOrBlank()) {
                Text(
                    text = errorMessage,
                    color = Color(0xFFFF5252),
                    fontSize = 12.sp,
                    lineHeight = 16.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
            }

            Button(
                onClick = { onConfirmCode(inputCode) },
                enabled = inputCode.isNotBlank() && !isJoining,
                colors = ButtonDefaults.buttonColors(
                    containerColor = DriyGold,
                    contentColor = DriyBackground
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                if (isJoining) {
                    CircularProgressIndicator(color = DriyBackground, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Conectando con la Jam...", fontWeight = FontWeight.Bold)
                } else {
                    Text("Unirme a la Jam", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun QrScannerCameraView(
    onCodeDetected: (String) -> Unit,
    onQuickDemoCode: (String) -> Unit,
    onSwitchToManual: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val activity = remember(context) { context.findActivity() }

    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }

    var permissionRequestAttempts by remember { mutableIntStateOf(0) }
    var isPermanentlyDenied by remember { mutableStateOf(false) }
    var cameraInitError by remember { mutableStateOf<String?>(null) }

    // Re-verify permission on ON_RESUME (e.g. when returning from Settings app)
    androidx.compose.runtime.DisposableEffect(lifecycleOwner) {
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
            if (event == androidx.lifecycle.Lifecycle.Event.ON_RESUME) {
                val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
                hasCameraPermission = granted
                if (granted) {
                    isPermanentlyDenied = false
                    cameraInitError = null
                }
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasCameraPermission = isGranted
        permissionRequestAttempts++
        if (!isGranted) {
            val rationale = activity?.let {
                ActivityCompat.shouldShowRequestPermissionRationale(it, Manifest.permission.CAMERA)
            } ?: false
            if (!rationale) {
                // Permanently denied by system (Android won't show the dialog anymore)
                isPermanentlyDenied = true
                Toast.makeText(
                    context,
                    "Android bloqueó la solicitud. Pulsa 'Abrir Ajustes' para activar la cámara.",
                    Toast.LENGTH_LONG
                ).show()
            } else {
                Toast.makeText(
                    context,
                    "Se requiere permiso de cámara para escanear el QR.",
                    Toast.LENGTH_SHORT
                ).show()
            }
        } else {
            isPermanentlyDenied = false
            cameraInitError = null
        }
    }

    // Photo picker launcher to scan QR from image or screenshot in gallery (zero permission required)
    val galleryPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            try {
                val inputStream = context.contentResolver.openInputStream(uri)
                val bitmap = BitmapFactory.decodeStream(inputStream)
                inputStream?.close()
                if (bitmap != null) {
                    val code = decodeQrFromBitmap(bitmap)
                    if (!code.isNullOrBlank()) {
                        Toast.makeText(context, "¡Código QR detectado!", Toast.LENGTH_SHORT).show()
                        onCodeDetected(code)
                    } else {
                        Toast.makeText(context, "No se encontró ningún código QR en la imagen", Toast.LENGTH_LONG).show()
                    }
                }
            } catch (e: Exception) {
                Toast.makeText(context, "Error al leer imagen: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    val infiniteTransition = rememberInfiniteTransition(label = "laser")
    val laserPosition by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "laser_y"
    )

    // Check if clipboard contains a Jam code to offer instant 1-tap join
    var clipboardCode by remember { mutableStateOf<String?>(null) }
    androidx.compose.runtime.LaunchedEffect(Unit) {
        try {
            val clip = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
            val item = clip?.primaryClip?.getItemAt(0)
            val text = item?.text?.toString()?.trim() ?: ""
            if (text.isNotBlank()) {
                val parsed = DriyJamManager.normalizeJamCode(text)
                if (parsed.isNotBlank() && (parsed.startsWith("JAM-") || parsed.length == 4)) {
                    clipboardCode = parsed
                }
            }
        } catch (ignored: Exception) {}
    }

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        if (!hasCameraPermission) {
            Card(
                colors = CardDefaults.cardColors(containerColor = DriySurfaceVariant),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(54.dp)
                            .clip(CircleShape)
                            .background(DriyGold.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.CameraAlt,
                            contentDescription = null,
                            tint = DriyGold,
                            modifier = Modifier.size(28.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = if (isPermanentlyDenied || permissionRequestAttempts > 0)
                            "Permiso de Cámara Bloqueado por Android"
                        else
                            "Permiso de Cámara Requerido",
                        color = DriyTextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = if (isPermanentlyDenied || permissionRequestAttempts > 0)
                            "El sistema Android bloqueó la solicitud automática porque se denegó previamente. Pulsa 'Abrir Ajustes de la App' y activa Cámara en la sección Permisos."
                        else
                            "Para escanear el código QR del grupo en tiempo real, concede acceso a la cámara de tu dispositivo:",
                        color = DriyTextSecondary,
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center,
                        lineHeight = 17.sp
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    if (isPermanentlyDenied || permissionRequestAttempts > 0) {
                        Button(
                            onClick = { openAppSettings(context) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = DriyGold,
                                contentColor = DriyBackground
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.Settings, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Abrir Ajustes de la App", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedButton(
                            onClick = {
                                permissionLauncher.launch(Manifest.permission.CAMERA)
                            },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = DriyGold),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Reintentar Solicitud", fontSize = 12.sp)
                        }
                    } else {
                        Button(
                            onClick = {
                                permissionLauncher.launch(Manifest.permission.CAMERA)
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = DriyGold,
                                contentColor = DriyBackground
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.CameraAlt, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Permitir Cámara", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        TextButton(
                            onClick = { openAppSettings(context) }
                        ) {
                            Icon(Icons.Default.Settings, contentDescription = null, modifier = Modifier.size(14.dp), tint = DriyTextSecondary)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Abrir Ajustes si no aparece el diálogo", color = DriyTextSecondary, fontSize = 11.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    HorizontalDivider(color = DriyDivider)
                    Spacer(modifier = Modifier.height(12.dp))

                    // Direct shortcut to manual code input
                    Button(
                        onClick = onSwitchToManual,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF2196F3).copy(alpha = 0.2f),
                            contentColor = Color(0xFF64B5F6)
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Keyboard, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Escribir Código Manualmente", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        } else if (cameraInitError != null) {
            Card(
                colors = CardDefaults.cardColors(containerColor = DriySurfaceVariant),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "⚠️ Cámara No Disponible",
                        color = Color(0xFFFFB74D),
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = cameraInitError ?: "No se pudo iniciar la cámara en este dispositivo o emulador.",
                        color = DriyTextSecondary,
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Button(
                        onClick = onSwitchToManual,
                        colors = ButtonDefaults.buttonColors(containerColor = DriyGold, contentColor = DriyBackground),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Keyboard, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Ingresar Código Manualmente", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        } else {
            // Camera Preview Viewport
            Box(
                modifier = Modifier
                    .size(240.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color.Black)
                    .border(2.dp, DriyGold, RoundedCornerShape(16.dp)),
                contentAlignment = Alignment.Center
            ) {
                var isScanningActive by remember { mutableStateOf(true) }

                AndroidView(
                    factory = { ctx ->
                        val previewView = PreviewView(ctx).apply {
                            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
                            scaleType = PreviewView.ScaleType.FILL_CENTER
                        }

                        val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                        cameraProviderFuture.addListener({
                            try {
                                val cameraProvider = cameraProviderFuture.get()
                                val hasBack = cameraProvider.hasCamera(CameraSelector.DEFAULT_BACK_CAMERA)
                                val hasFront = cameraProvider.hasCamera(CameraSelector.DEFAULT_FRONT_CAMERA)

                                if (!hasBack && !hasFront) {
                                    cameraInitError = "Este dispositivo o emulador no cuenta con una cámara física disponible."
                                    return@addListener
                                }

                                val preview = Preview.Builder().build().also {
                                    it.setSurfaceProvider(previewView.surfaceProvider)
                                }

                                val reader = MultiFormatReader()
                                val imageAnalysis = ImageAnalysis.Builder()
                                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                                    .build()

                                imageAnalysis.setAnalyzer(ContextCompat.getMainExecutor(ctx)) { imageProxy ->
                                    if (!isScanningActive) {
                                        imageProxy.close()
                                        return@setAnalyzer
                                    }
                                    try {
                                        val buffer = imageProxy.planes[0].buffer
                                        val bytes = ByteArray(buffer.remaining())
                                        buffer.get(bytes)
                                        val width = imageProxy.width
                                        val height = imageProxy.height
                                        val source = PlanarYUVLuminanceSource(
                                            bytes, width, height, 0, 0, width, height, false
                                        )
                                        val binaryBitmap = BinaryBitmap(HybridBinarizer(source))
                                        val result = reader.decodeWithState(binaryBitmap)
                                        val text = result.text
                                        if (text.isNotBlank()) {
                                            isScanningActive = false
                                            ContextCompat.getMainExecutor(ctx).execute {
                                                onCodeDetected(text)
                                            }
                                        }
                                    } catch (e: Exception) {
                                        // continuous scan frames
                                    } finally {
                                        reader.reset()
                                        imageProxy.close()
                                    }
                                }

                                cameraProvider.unbindAll()

                                val cameraSelector = if (hasBack) {
                                    CameraSelector.DEFAULT_BACK_CAMERA
                                } else {
                                    CameraSelector.DEFAULT_FRONT_CAMERA
                                }

                                cameraProvider.bindToLifecycle(
                                    lifecycleOwner,
                                    cameraSelector,
                                    preview,
                                    imageAnalysis
                                )
                            } catch (exc: Exception) {
                                android.util.Log.e("QrScanner", "Camera binding notice: ${exc.message}")
                                cameraInitError = "Error al iniciar cámara: ${exc.localizedMessage ?: "No disponible"}"
                            }
                        }, ContextCompat.getMainExecutor(ctx))
                        previewView
                    },
                    modifier = Modifier.fillMaxSize()
                )

                // Animated Laser Line
                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.85f)
                        .height(2.dp)
                        .background(DriyGold)
                )

                // Framing guidance text
                Text(
                    text = "Apunta la cámara al código QR",
                    color = Color.White.copy(alpha = 0.85f),
                    fontSize = 11.sp,
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 8.dp)
                )
            }
        }

        // Quick Clipboard suggestion banner if clipboard has a code
        if (!clipboardCode.isNullOrBlank()) {
            Spacer(modifier = Modifier.height(10.dp))
            Card(
                colors = CardDefaults.cardColors(containerColor = DriyGold.copy(alpha = 0.15f)),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onCodeDetected(clipboardCode!!) }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "📋 Código copiado en portapapeles",
                            color = DriyGold,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Código: ${clipboardCode}",
                            color = DriyTextPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                    Text(
                        text = "Unirme →",
                        color = DriyGold,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Option: Pick QR from image/screenshot in gallery
        Button(
            onClick = {
                galleryPickerLauncher.launch(
                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                )
            },
            colors = ButtonDefaults.buttonColors(
                containerColor = DriySurfaceVariant,
                contentColor = DriyTextPrimary
            ),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.Default.Image, contentDescription = null, tint = DriyGold, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("Escanear QR desde Foto o Captura", fontSize = 12.sp)
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Quick simulation / testing button (essential for emulators without camera QR support)
        Card(
            colors = CardDefaults.cardColors(containerColor = DriySurfaceVariant),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "💡 Prueba en Emulador",
                        color = DriyGold,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Simula escanear un código de prueba",
                        color = DriyTextSecondary,
                        fontSize = 10.sp
                    )
                }
                TextButton(
                    onClick = { onQuickDemoCode("JAM-7721") }
                ) {
                    Text("Probar JAM-7721", color = DriyGold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

private fun Context.findActivity(): Activity? {
    var ctx = this
    while (ctx is ContextWrapper) {
        if (ctx is Activity) return ctx
        ctx = ctx.baseContext
    }
    return null
}

private fun openAppSettings(context: Context) {
    try {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.fromParts("package", context.packageName, null)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
        Toast.makeText(context, "Abre Permisos > Cámara y actívalo", Toast.LENGTH_LONG).show()
    } catch (e: Exception) {
        try {
            val intent = Intent(Settings.ACTION_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (ignored: Exception) {
            Toast.makeText(context, "No se pudo abrir Ajustes", Toast.LENGTH_SHORT).show()
        }
    }
}

private fun decodeQrFromBitmap(bitmap: Bitmap): String? {
    return try {
        val width = bitmap.width
        val height = bitmap.height
        val pixels = IntArray(width * height)
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height)
        val source = RGBLuminanceSource(width, height, pixels)
        val binaryBitmap = BinaryBitmap(HybridBinarizer(source))
        MultiFormatReader().decodeWithState(binaryBitmap).text
    } catch (e: Exception) {
        null
    }
}

private fun copyToClipboard(context: Context, text: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val clip = ClipData.newPlainText("Driy Jam Code", text)
    clipboard.setPrimaryClip(clip)
    Toast.makeText(context, "Código copiado: $text", Toast.LENGTH_SHORT).show()
}

private fun shareJamInvite(context: Context, code: String) {
    val sendIntent = Intent().apply {
        action = Intent.ACTION_SEND
        putExtra(
            Intent.EXTRA_TEXT,
            "¡Únete a mi sesión en grupo en DriyMusic! 🎧 Escuchemos música sincronizada en tiempo real. Código: $code"
        )
        type = "text/plain"
    }
    val shareIntent = Intent.createChooser(sendIntent, "Invitar a Driy Jam")
    context.startActivity(shareIntent)
}
