package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.ui.draw.scale
import androidx.compose.ui.unit.Dp
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.SongEntity
import com.example.service.PlayerState
import com.example.ui.Screen
import com.example.ui.theme.DriyBackground
import com.example.ui.theme.DriyDivider
import com.example.ui.theme.DriyGold
import com.example.ui.theme.DriySurface
import com.example.ui.theme.DriyTextPrimary
import com.example.ui.theme.DriyTextSecondary

@Composable
fun DriyBottomNavBar(
    currentScreen: Screen,
    onNavigate: (Screen) -> Unit,
    isSubscribed: Boolean = true,
    modifier: Modifier = Modifier
) {
    NavigationBar(
        containerColor = DriySurface,
        tonalElevation = 8.dp,
        modifier = modifier.testTag("driy_bottom_nav_bar")
    ) {
        val items = listOf(
            Triple(Screen.Home, Icons.Default.Home, if (isSubscribed) "Inicio" else "Inicio 🔒"),
            Triple(Screen.Search, Icons.Default.Search, if (isSubscribed) "Explorar" else "Explorar 🔒"),
            Triple(Screen.Library, Icons.Default.LibraryMusic, if (isSubscribed) "Biblioteca" else "Biblioteca 🔒"),
            Triple(Screen.UploadMusic, Icons.Default.CloudUpload, if (isSubscribed) "Sube música" else "Sube 🔒"),
            Triple(Screen.Profile, if (isSubscribed) Icons.Default.Person else Icons.Default.Key, if (isSubscribed) "Perfil" else "Membresía")
        )

        items.forEach { (screen, icon, label) ->
            val isSelected = currentScreen == screen
            NavigationBarItem(
                selected = isSelected,
                onClick = { onNavigate(screen) },
                icon = {
                    Icon(
                        imageVector = icon,
                        contentDescription = label,
                        modifier = Modifier.size(24.dp)
                    )
                },
                label = {
                    Text(
                        text = label,
                        fontSize = 10.sp,
                        maxLines = 1,
                        fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = DriyGold,
                    selectedTextColor = DriyGold,
                    unselectedIconColor = if (!isSubscribed && screen == Screen.Profile) DriyGold.copy(alpha = 0.85f) else DriyTextSecondary,
                    unselectedTextColor = if (!isSubscribed && screen == Screen.Profile) DriyGold.copy(alpha = 0.85f) else DriyTextSecondary,
                    indicatorColor = Color.Transparent
                )
            )
        }
    }
}

@Composable
fun MiniPlayer(
    playerState: PlayerState,
    onTogglePlayPause: () -> Unit,
    onSkipNext: () -> Unit,
    onClickMiniPlayer: () -> Unit,
    onOpenLyrics: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val song = playerState.currentSong ?: return
    val progress = if (playerState.durationMs > 0) {
        (playerState.currentPositionMs.toFloat() / playerState.durationMs.toFloat()).coerceIn(0f, 1f)
    } else 0f

    Surface(
        color = DriySurface,
        shape = RoundedCornerShape(14.dp),
        shadowElevation = 10.dp,
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp, vertical = 6.dp)
            .clickable { onClickMiniPlayer() }
            .testTag("mini_player_surface")
    ) {
        Column {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                AsyncImage(
                    model = song.coverUrl,
                    contentDescription = song.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(46.dp)
                        .clip(RoundedCornerShape(8.dp))
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column(
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = song.title,
                        color = DriyTextPrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = song.artist,
                        color = DriyTextSecondary,
                        fontSize = 12.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                if (playerState.isPlaying) {
                    MiniWaveform(modifier = Modifier.padding(horizontal = 6.dp))
                }

                if (onOpenLyrics != null) {
                    IconButton(
                        onClick = onOpenLyrics,
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("mini_player_lyrics_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = "Ver Letra",
                            tint = DriyGold,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                IconButton(
                    onClick = onSkipNext,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.SkipNext,
                        contentDescription = "Siguiente",
                        tint = DriyTextPrimary,
                        modifier = Modifier.size(22.dp)
                    )
                }

                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(DriyGold)
                        .clickable { onTogglePlayPause() }
                        .testTag("mini_player_play_pause")
                ) {
                    Icon(
                        imageVector = if (playerState.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = if (playerState.isPlaying) "Pausar" else "Reproducir",
                        tint = DriyBackground,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(2.5.dp),
                color = DriyGold,
                trackColor = DriyDivider
            )
        }
    }
}

@Composable
fun MiniWaveform(modifier: Modifier = Modifier) {
    val infiniteTransition = rememberInfiniteTransition(label = "waveform")
    val bar1Height by infiniteTransition.animateFloat(
        initialValue = 4f,
        targetValue = 16f,
        animationSpec = infiniteRepeatable(tween(350, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "bar1"
    )
    val bar2Height by infiniteTransition.animateFloat(
        initialValue = 16f,
        targetValue = 6f,
        animationSpec = infiniteRepeatable(tween(420, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "bar2"
    )
    val bar3Height by infiniteTransition.animateFloat(
        initialValue = 8f,
        targetValue = 14f,
        animationSpec = infiniteRepeatable(tween(300, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "bar3"
    )

    Row(
        verticalAlignment = Alignment.Bottom,
        horizontalArrangement = Arrangement.spacedBy(2.dp),
        modifier = modifier.height(18.dp)
    ) {
        Box(
            modifier = Modifier
                .width(3.dp)
                .height(bar1Height.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(DriyGold)
        )
        Box(
            modifier = Modifier
                .width(3.dp)
                .height(bar2Height.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(DriyGold)
        )
        Box(
            modifier = Modifier
                .width(3.dp)
                .height(bar3Height.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(DriyGold)
        )
    }
}

@Composable
fun SongItemRow(
    song: SongEntity,
    isPlaying: Boolean,
    isCurrentSong: Boolean,
    downloadProgress: Float?,
    onPlay: () -> Unit,
    onToggleFavorite: () -> Unit,
    onDownload: () -> Unit,
    onOptionsClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier
            .fillMaxWidth()
            .clickable { onPlay() }
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .testTag("song_item_${song.id}")
    ) {
        Box(
            modifier = Modifier
                .size(52.dp)
                .clip(RoundedCornerShape(8.dp))
        ) {
            AsyncImage(
                model = song.coverUrl,
                contentDescription = song.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.matchParentSize()
            )
            if (isCurrentSong && isPlaying) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .matchParentSize()
                        .background(Color.Black.copy(alpha = 0.5f))
                ) {
                    MiniWaveform()
                }
            }
        }

        Spacer(modifier = Modifier.width(14.dp))

        Column(
            modifier = Modifier.weight(1f)
        ) {
            Text(
                text = song.title,
                color = if (isCurrentSong) DriyGold else DriyTextPrimary,
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(2.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (song.isDownloaded) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Descargada",
                        tint = DriyGold,
                        modifier = Modifier
                            .size(12.dp)
                            .padding(end = 4.dp)
                    )
                }
                Text(
                    text = "${song.artist} • ${formatDuration(song.durationSeconds)}",
                    color = DriyTextSecondary,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        IconButton(
            onClick = onDownload,
            modifier = Modifier.size(36.dp)
        ) {
            if (downloadProgress != null) {
                CircularProgressIndicator(
                    progress = { downloadProgress },
                    strokeWidth = 2.dp,
                    color = DriyGold,
                    modifier = Modifier.size(18.dp)
                )
            } else if (song.isDownloaded) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = "Descargada",
                    tint = DriyGold,
                    modifier = Modifier.size(20.dp)
                )
            } else {
                Icon(
                    imageVector = Icons.Default.Download,
                    contentDescription = "Descargar",
                    tint = DriyTextSecondary,
                    modifier = Modifier.size(20.dp)
                )
            }
        }

        AnimatedHeartButton(
            isFavorite = song.isFavorite,
            onClick = onToggleFavorite,
            size = 36.dp,
            iconSize = 20.dp
        )

        if (onOptionsClick != null) {
            IconButton(
                onClick = onOptionsClick,
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.MoreVert,
                    contentDescription = "Más opciones",
                    tint = DriyTextSecondary,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

@Composable
fun AnimatedHeartButton(
    isFavorite: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 36.dp,
    iconSize: Dp = 20.dp
) {
    val coroutineScope = rememberCoroutineScope()
    var optimisticIsFav by remember(isFavorite) { mutableStateOf(isFavorite) }
    val scale = remember { Animatable(1f) }
    val burstAlpha = remember { Animatable(0f) }
    val burstScale = remember { Animatable(0.5f) }

    val effectiveFavorite = optimisticIsFav

    val heartColor by animateColorAsState(
        targetValue = if (effectiveFavorite) DriyGold else DriyTextSecondary,
        animationSpec = tween(durationMillis = 180),
        label = "heart_color"
    )

    IconButton(
        onClick = {
            val nextState = !optimisticIsFav
            optimisticIsFav = nextState
            coroutineScope.launch {
                if (nextState) {
                    launch {
                        burstScale.snapTo(0.5f)
                        burstAlpha.snapTo(0.95f)
                        burstScale.animateTo(2.1f, tween(340, easing = FastOutSlowInEasing))
                        burstAlpha.animateTo(0f, tween(180, easing = LinearEasing))
                    }
                    scale.snapTo(0.72f)
                    scale.animateTo(1.65f, spring(dampingRatio = 0.35f, stiffness = 950f))
                    scale.animateTo(0.85f, spring(dampingRatio = 0.5f, stiffness = 700f))
                    scale.animateTo(1.15f, spring(dampingRatio = 0.6f, stiffness = 500f))
                    scale.animateTo(1.0f, spring(dampingRatio = 0.7f, stiffness = 350f))
                } else {
                    scale.snapTo(0.85f)
                    scale.animateTo(1.0f, spring(dampingRatio = 0.6f, stiffness = 400f))
                }
            }
            onClick()
        },
        modifier = modifier.size(size)
    ) {
        Box(contentAlignment = Alignment.Center) {
            if (burstAlpha.value > 0.01f) {
                Box(
                    modifier = Modifier
                        .size(iconSize * 1.9f)
                        .scale(burstScale.value)
                        .clip(CircleShape)
                        .background(DriyGold.copy(alpha = burstAlpha.value * 0.40f))
                        .border(
                            1.8.dp,
                            DriyGold.copy(alpha = burstAlpha.value * 0.85f),
                            CircleShape
                        )
                )
            }

            if (effectiveFavorite) {
                Box(
                    modifier = Modifier
                        .size(iconSize * 1.4f)
                        .clip(CircleShape)
                        .background(DriyGold.copy(alpha = 0.16f))
                )
            }

            Icon(
                imageVector = if (effectiveFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                contentDescription = if (effectiveFavorite) "Quitar de favoritos" else "Guardar en favoritos o carpetas",
                tint = heartColor,
                modifier = Modifier
                    .size(iconSize)
                    .scale(scale.value)
            )
        }
    }
}

@Composable
fun PredictiveSearchDropdown(
    suggestions: List<SongEntity>,
    searchQuery: String = "",
    isSearching: Boolean = false,
    onSelectSong: (SongEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    val shouldShow = searchQuery.isNotBlank() && (suggestions.isNotEmpty() || isSearching)

    AnimatedVisibility(
        visible = shouldShow,
        enter = fadeIn() + slideInVertically(),
        exit = fadeOut() + slideOutVertically(),
        modifier = modifier
    ) {
        Surface(
            color = DriySurface,
            shape = RoundedCornerShape(12.dp),
            shadowElevation = 12.dp,
            border = androidx.compose.foundation.BorderStroke(1.dp, DriyGold.copy(alpha = 0.3f)),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
        ) {
            Column(
                modifier = Modifier.padding(vertical = 8.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = if (isSearching) "Buscando en YouTube..." else "Sugerencias instantáneas (Toca para reproducir)",
                        color = DriyGold,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    if (isSearching) {
                        CircularProgressIndicator(
                            strokeWidth = 2.dp,
                            color = DriyGold,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }

                if (suggestions.isEmpty() && isSearching) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
                    ) {
                        Text(
                            text = "Buscando canciones y remixes para \"$searchQuery\"...",
                            color = DriyTextSecondary,
                            fontSize = 12.sp
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.height((suggestions.size * 60).coerceIn(60, 280).dp)
                    ) {
                        items(suggestions) { song ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onSelectSong(song) }
                                    .padding(horizontal = 16.dp, vertical = 8.dp)
                            ) {
                                AsyncImage(
                                    model = song.coverUrl,
                                    contentDescription = song.title,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .size(38.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = song.title,
                                        color = DriyTextPrimary,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Medium,
                                        maxLines = 1
                                    )
                                    Text(
                                        text = "${song.artist} • ${song.genre.uppercase()}",
                                        color = DriyTextSecondary,
                                        fontSize = 11.sp,
                                        maxLines = 1
                                    )
                                }
                                Icon(
                                    imageVector = Icons.Default.PlayArrow,
                                    contentDescription = "Reproducir ya",
                                    tint = DriyGold,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

fun formatDuration(seconds: Int): String {
    val m = seconds / 60
    val s = seconds % 60
    return String.format("%d:%02d", m, s)
}

fun formatDurationMs(millis: Long): String {
    val totalSeconds = (millis / 1000).toInt()
    return formatDuration(totalSeconds)
}
