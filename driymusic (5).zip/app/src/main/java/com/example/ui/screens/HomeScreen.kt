package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.SuggestionChipDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.ui.components.DriyUserAvatar
import com.example.R
import com.example.data.model.SongEntity
import com.example.data.model.UploadedSongEntity
import com.example.data.model.UserEntity
import com.example.service.PlayerState
import com.example.ui.components.PredictiveSearchDropdown
import com.example.ui.components.SongItemRow
import com.example.ui.theme.DriyBackground
import com.example.ui.theme.DriyDivider
import com.example.ui.theme.DriyGold
import com.example.ui.theme.DriySurface
import com.example.ui.theme.DriySurfaceVariant
import com.example.ui.theme.DriyTextPrimary
import com.example.ui.theme.DriyTextSecondary

@Composable
fun HomeScreen(
    user: UserEntity?,
    allSongs: List<SongEntity>,
    favoriteArtistsSongs: List<SongEntity> = emptyList(),
    isLoadingArtistSongs: Boolean = false,
    mostSearchedSongs: List<SongEntity> = emptyList(),
    recentSearchedSongs: List<SongEntity> = emptyList(),
    searchQuery: String,
    autocompleteSuggestions: List<SongEntity>,
    isSearching: Boolean = false,
    playerState: PlayerState,
    downloadProgress: Map<String, Float>,
    onSearchQueryChange: (String) -> Unit,
    onSubmitSearch: (String) -> Unit = {},
    onPlaySong: (SongEntity, List<SongEntity>) -> Unit,
    onSongSelectedFromSearch: (SongEntity) -> Unit = {},
    onToggleFavorite: (SongEntity) -> Unit,
    onDownloadSong: (SongEntity) -> Unit,
    onOpenSongOptions: (SongEntity) -> Unit = {},
    uploadedSongs: List<UploadedSongEntity> = emptyList(),
    globalCommunitySongs: List<SongEntity> = emptyList()
) {
    val selectedArtists = user?.favoriteArtists ?: emptyList()
    var selectedArtistFilter by remember { mutableStateOf<String?>(null) }

    val realArtistSongs = if (favoriteArtistsSongs.isNotEmpty()) {
        favoriteArtistsSongs
    } else {
        allSongs.filter { song -> selectedArtists.any { it.equals(song.artist, ignoreCase = true) } }
    }

    val displayedSongs = remember(selectedArtistFilter, realArtistSongs, allSongs, mostSearchedSongs) {
        if (selectedArtistFilter != null) {
            val filtered = realArtistSongs.filter { it.artist.contains(selectedArtistFilter!!, ignoreCase = true) }
            if (filtered.isNotEmpty()) filtered else allSongs.filter { it.artist.contains(selectedArtistFilter!!, ignoreCase = true) }
        } else {
            val list = mutableListOf<SongEntity>()
            mostSearchedSongs.forEach { s ->
                if (list.none { it.id == s.id }) list.add(s)
            }
            realArtistSongs.forEach { s ->
                if (list.none { it.id == s.id }) list.add(s)
            }
            allSongs.forEach { s ->
                if (list.none { it.id == s.id }) list.add(s)
            }
            list
        }
    }

    Surface(
        color = com.example.ui.theme.DriyScreenBackground,
        modifier = Modifier
            .fillMaxSize()
            .testTag("home_screen")
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // Header with DriyMusic Logo, App Name and Search Bar
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(com.example.ui.theme.DriyScreenBackground)
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Image(
                            painter = painterResource(R.drawable.driymusic_logo),
                            contentDescription = "DriyMusic Logo",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(42.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .border(1.dp, DriyGold.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                        )
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "DriyMusic",
                                    color = DriyGold,
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.Black,
                                    letterSpacing = 1.sp
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                val isSub = user?.isSubscriptionActive == true
                                Surface(
                                    color = if (isSub) androidx.compose.ui.graphics.Color(0xFF4CAF50) else DriyGold.copy(alpha = 0.25f),
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = if (isSub) "${user.getRemainingDays()}d" else "S/. 5/m",
                                        color = if (isSub) DriyBackground else DriyGold,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.5.dp)
                                    )
                                }
                            }
                            Text(
                                text = "Hola, ${user?.displayName?.split(" ")?.firstOrNull() ?: "Oyente"}",
                                color = DriyTextPrimary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    DriyUserAvatar(
                        photoUrl = user?.photoUrl,
                        userId = user?.id,
                        displayName = user?.displayName,
                        size = 38.dp,
                        borderColor = DriyGold.copy(alpha = 0.4f),
                        borderWidth = 1.dp
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = onSearchQueryChange,
                    placeholder = {
                        Text("Buscar canciones o artistas...", color = DriyTextSecondary, fontSize = 14.sp)
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Buscar",
                            tint = DriyGold,
                            modifier = Modifier.size(22.dp)
                        )
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { onSearchQueryChange("") }) {
                                Icon(
                                    imageVector = Icons.Default.Clear,
                                    contentDescription = "Limpiar",
                                    tint = DriyTextSecondary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = DriySurface,
                        unfocusedContainerColor = DriySurface,
                        focusedBorderColor = DriyGold,
                        unfocusedBorderColor = DriyDivider,
                        focusedTextColor = DriyTextPrimary,
                        unfocusedTextColor = DriyTextPrimary
                    ),
                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                        imeAction = androidx.compose.ui.text.input.ImeAction.Search
                    ),
                    keyboardActions = androidx.compose.foundation.text.KeyboardActions(
                        onSearch = {
                            val first = autocompleteSuggestions.firstOrNull()
                            if (first != null) {
                                onSongSelectedFromSearch(first)
                                onPlaySong(first, emptyList())
                                onSearchQueryChange("")
                            } else if (searchQuery.isNotBlank()) {
                                onSubmitSearch(searchQuery)
                            }
                        }
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("home_predictive_search_bar")
                )

                // Quick test suggestions chips
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp)
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("Soy Peor", "Your Love", "Believer", "Bad Bunny").forEach { term ->
                        SuggestionChip(
                            onClick = {
                                onSubmitSearch(term)
                            },
                            label = { Text("🔎 $term", fontSize = 11.sp) },
                            colors = SuggestionChipDefaults.suggestionChipColors(
                                containerColor = DriySurfaceVariant,
                                labelColor = DriyGold
                            ),
                            border = SuggestionChipDefaults.suggestionChipBorder(
                                enabled = true,
                                borderColor = DriyDivider
                            ),
                            shape = RoundedCornerShape(12.dp)
                        )
                    }
                }
            }

            PredictiveSearchDropdown(
                suggestions = autocompleteSuggestions,
                searchQuery = searchQuery,
                isSearching = isSearching,
                onSelectSong = { song ->
                    onSongSelectedFromSearch(song)
                    onPlaySong(song, emptyList())
                    onSearchQueryChange("")
                }
            )

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f),
                contentPadding = PaddingValues(bottom = 90.dp)
            ) {
                // Section 1: Most Searched Songs (> 3 searches)
                item {
                    val subtitle = if (mostSearchedSongs.isNotEmpty()) {
                        "Canciones que has buscado más de 3 veces (${mostSearchedSongs.size})"
                    } else {
                        "Busca cualquier tema más de 3 veces para fijarlo en tu inicio"
                    }
                    SectionHeader(
                        title = "Tus canciones más buscadas",
                        subtitle = subtitle
                    )

                    if (mostSearchedSongs.isNotEmpty()) {
                        LazyRow(
                            contentPadding = PaddingValues(horizontal = 16.dp),
                            horizontalArrangement = Arrangement.spacedBy(14.dp),
                            modifier = Modifier.padding(top = 10.dp, bottom = 18.dp)
                        ) {
                            items(mostSearchedSongs) { song ->
                                FeaturedSongCard(
                                    song = song,
                                    isPlaying = playerState.currentSong?.id == song.id && playerState.isPlaying,
                                    onPlay = { onPlaySong(song, mostSearchedSongs) }
                                )
                            }
                        }
                    } else {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = DriySurface),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 8.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(40.dp)
                                            .clip(CircleShape)
                                            .background(DriyGold.copy(alpha = 0.15f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.TrendingUp,
                                            contentDescription = null,
                                            tint = DriyGold,
                                            modifier = Modifier.size(22.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text(
                                            text = "Aún no tienes canciones frecuentes",
                                            color = DriyTextPrimary,
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "Las canciones que busques más de 3 veces (ej: busca 'Soy Peor' 4 veces) aparecerán automáticamente aquí.",
                                            color = DriyTextSecondary,
                                            fontSize = 12.sp
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(10.dp))
                                Row(
                                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    SuggestionChip(
                                        onClick = { onSubmitSearch("Soy Peor") },
                                        label = { Text("🔥 Buscar 'Soy Peor'", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                                        colors = SuggestionChipDefaults.suggestionChipColors(
                                            containerColor = DriyGold.copy(alpha = 0.15f),
                                            labelColor = DriyGold
                                        )
                                    )
                                    SuggestionChip(
                                        onClick = { onSubmitSearch("Your Love") },
                                        label = { Text("🎸 Buscar 'Your Love'", fontSize = 11.sp) },
                                        colors = SuggestionChipDefaults.suggestionChipColors(
                                            containerColor = DriySurfaceVariant,
                                            labelColor = DriyTextPrimary
                                        )
                                    )
                                }
                            }
                        }
                    }
                }

                // Section 2: Independent & Community Releases
                item {
                    SectionHeader(
                        title = "Escucha a estos nuevos artistas, te encantarán",
                        subtitle = if (uploadedSongs.isNotEmpty() || globalCommunitySongs.isNotEmpty()) {
                            "Canciones de nuestra comunidad global de artistas y creadores"
                        } else {
                            "Nuevos talentos independientes recomendados para ti"
                        }
                    )

                    val communityEmergingSongs = remember(uploadedSongs, globalCommunitySongs) {
                        val userSongsList = uploadedSongs.map { up ->
                            val durationParts = up.approxDuration.split(":")
                            val durationSec = if (durationParts.size == 2) {
                                (durationParts[0].toIntOrNull() ?: 3) * 60 + (durationParts[1].toIntOrNull() ?: 30)
                            } else {
                                up.approxDuration.toIntOrNull() ?: 210
                            }
                            SongEntity(
                                id = up.id,
                                title = up.title,
                                artist = up.artist,
                                genre = up.genre,
                                album = "Obra Registrada (${up.releaseDate})",
                                coverUrl = up.coverUrl ?: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=500&q=80",
                                audioUrl = up.audioFilePath,
                                durationSeconds = durationSec,
                                isDownloaded = true,
                                localFilePath = up.audioFilePath
                            )
                        }

                        val otherUsersCloudSongs = globalCommunitySongs.filter { cloudSong ->
                            userSongsList.none { it.id == cloudSong.id }
                        }

                        val sampleEmergingSongs = listOf(
                            SongEntity(
                                id = "emerging_1",
                                title = "Amanecer Índigo",
                                artist = "Sofía Del Valle",
                                genre = "Indie Pop",
                                album = "Sesión Acústica 2026",
                                coverUrl = "https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?w=500&q=80",
                                audioUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-8.mp3",
                                durationSeconds = 224,
                                isDownloaded = false
                            ),
                            SongEntity(
                                id = "emerging_2",
                                title = "Frecuencia Cero",
                                artist = "Mateo & Los Ecos",
                                genre = "Synthwave",
                                album = "Sencillo Original",
                                coverUrl = "https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?w=500&q=80",
                                audioUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-9.mp3",
                                durationSeconds = 248,
                                isDownloaded = false
                            ),
                            SongEntity(
                                id = "emerging_3",
                                title = "Noches de Neón",
                                artist = "Lucas Prado",
                                genre = "R&B Urbano",
                                album = "Estudio Independiente",
                                coverUrl = "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=500&q=80",
                                audioUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-10.mp3",
                                durationSeconds = 210,
                                isDownloaded = false
                            )
                        )

                        val combined = userSongsList + otherUsersCloudSongs
                        if (combined.size < 4) combined + sampleEmergingSongs else combined
                    }

                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                        modifier = Modifier.padding(top = 10.dp, bottom = 18.dp)
                    ) {
                        items(communityEmergingSongs) { song ->
                            NewArtistFeaturedCard(
                                song = song,
                                isUserUpload = uploadedSongs.any { it.id == song.id } || globalCommunitySongs.any { it.id == song.id },
                                isPlaying = playerState.currentSong?.id == song.id && playerState.isPlaying,
                                onPlay = { onPlaySong(song, communityEmergingSongs) }
                            )
                        }
                    }
                }

                // Section 3: Selected Artists Filters
                if (selectedArtists.isNotEmpty()) {
                    item {
                        SectionHeader(
                            title = "Tus artistas preferidos",
                            subtitle = if (selectedArtistFilter != null) "Filtrando por $selectedArtistFilter (toca de nuevo para ver todos)" else "Toca un artista para ver sus canciones"
                        )
                        LazyRow(
                            contentPadding = PaddingValues(horizontal = 16.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.padding(top = 10.dp, bottom = 18.dp)
                        ) {
                            items(selectedArtists) { artistName ->
                                ArtistBadge(
                                    artistName = artistName,
                                    isSelected = selectedArtistFilter == artistName,
                                    onClick = {
                                        selectedArtistFilter = if (selectedArtistFilter == artistName) null else artistName
                                    }
                                )
                            }
                        }
                    }
                }

                // Section 4: Songs Catalog
                item {
                    val sectionTitle = if (selectedArtistFilter != null) {
                        "Canciones de $selectedArtistFilter"
                    } else if (realArtistSongs.isNotEmpty()) {
                        "Éxitos de tus artistas favoritos"
                    } else {
                        "Catálogo de DriyMusic"
                    }
                    val sectionSubtitle = if (selectedArtistFilter != null) {
                        "Música real del artista lista para reproducir"
                    } else if (realArtistSongs.isNotEmpty()) {
                        "Canciones reales de ${selectedArtists.take(4).joinToString(", ")}"
                    } else {
                        "Música en alta fidelidad lista para sonar"
                    }
                    SectionHeader(
                        title = sectionTitle,
                        subtitle = sectionSubtitle
                    )
                }

                items(displayedSongs) { song ->
                    SongItemRow(
                        song = song,
                        isPlaying = playerState.isPlaying,
                        isCurrentSong = playerState.currentSong?.id == song.id,
                        downloadProgress = downloadProgress[song.id],
                        onPlay = { onPlaySong(song, displayedSongs) },
                        onToggleFavorite = { onToggleFavorite(song) },
                        onDownload = { onDownloadSong(song) },
                        onOptionsClick = { onOpenSongOptions(song) }
                    )
                }
            }
        }
    }
}

@Composable
private fun SectionHeader(title: String, subtitle: String) {
    Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
        Text(
            text = title,
            color = DriyTextPrimary,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = subtitle,
            color = DriyTextSecondary,
            fontSize = 12.sp
        )
    }
}

@Composable
private fun FeaturedSongCard(
    song: SongEntity,
    isPlaying: Boolean,
    onPlay: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = DriySurface),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier
            .width(150.dp)
            .clickable { onPlay() }
            .testTag("featured_song_${song.id}")
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Box(
                modifier = Modifier
                    .size(130.dp)
                    .clip(RoundedCornerShape(10.dp))
            ) {
                AsyncImage(
                    model = song.coverUrl,
                    contentDescription = song.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )

                if (song.searchCount > 3) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(6.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(DriyBackground.copy(alpha = 0.88f))
                            .border(1.dp, DriyGold.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "🔥 ${song.searchCount} búsquedas",
                            color = DriyGold,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(8.dp)
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(DriyGold)
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Reproducir",
                        tint = DriyBackground,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = song.title,
                color = DriyTextPrimary,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = song.artist,
                color = DriyTextSecondary,
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun ArtistBadge(
    artistName: String,
    isSelected: Boolean = false,
    onClick: () -> Unit = {}
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(if (isSelected) DriyGold else DriySurfaceVariant)
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Icon(
            imageVector = Icons.Default.Verified,
            contentDescription = null,
            tint = if (isSelected) DriyBackground else DriyGold,
            modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = artistName,
            color = if (isSelected) DriyBackground else DriyTextPrimary,
            fontSize = 13.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
        )
    }
}

@Composable
private fun NewArtistFeaturedCard(
    song: SongEntity,
    isUserUpload: Boolean,
    isPlaying: Boolean,
    onPlay: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = DriySurface),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier
            .width(160.dp)
            .clickable { onPlay() }
            .testTag("emerging_artist_card_${song.id}")
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Box(
                modifier = Modifier
                    .size(140.dp)
                    .clip(RoundedCornerShape(10.dp))
            ) {
                AsyncImage(
                    model = song.coverUrl,
                    contentDescription = song.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Box(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(6.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(DriyBackground.copy(alpha = 0.85f))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = if (isUserUpload) "Subido" else "Comunidad",
                        color = DriyGold,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(8.dp)
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(DriyGold)
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Reproducir",
                        tint = DriyBackground,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = song.title,
                color = DriyTextPrimary,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = song.artist,
                color = DriyGold,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}
