package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.LyricLine
import com.example.data.model.LyricsUiState
import com.example.data.model.SongEntity
import com.example.ui.theme.DriyBackground
import com.example.ui.theme.DriyDivider
import com.example.ui.theme.DriyGold
import com.example.ui.theme.DriySurface
import com.example.ui.theme.DriySurfaceVariant
import com.example.ui.theme.DriyTextPrimary
import com.example.ui.theme.DriyTextSecondary
import java.util.Locale

@Composable
fun SynchronizedLyricsView(
    song: SongEntity,
    currentPositionMs: Long,
    lyricsUiState: LyricsUiState,
    onSeekTo: (Long) -> Unit,
    onCloseLyrics: () -> Unit,
    onRetry: () -> Unit,
    onAdjustOffset: (Long) -> Unit = {},
    onResetOffset: () -> Unit = {},
    onCustomSearch: (String) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val listState = rememberLazyListState()
    val lyrics = lyricsUiState.lyricsData
    val syncedLines = lyrics?.syncedLyrics ?: emptyList()

    // Track user manual scrolling to pause auto-scroll briefly
    var userInteractingUntilMs by remember { mutableLongStateOf(0L) }
    var showCalibration by remember { mutableStateOf(false) }
    var showCustomSearchInput by remember { mutableStateOf(false) }
    var customSearchQuery by remember { mutableStateOf("") }
    val focusManager = LocalFocusManager.current

    // Effective position incorporates manual sync calibration offset
    val effectivePositionMs by remember(currentPositionMs, lyricsUiState.syncOffsetMs) {
        derivedStateOf {
            (currentPositionMs + lyricsUiState.syncOffsetMs).coerceAtLeast(0L)
        }
    }

    // Find currently active line index based on playback time and sync offset.
    // NOTE: returns -1 if before the first line, so line 0 is NOT prematurely highlighted during intro!
    val activeLineIndex by remember(effectivePositionMs, syncedLines) {
        derivedStateOf {
            if (syncedLines.isEmpty()) -1
            else {
                syncedLines.indexOfLast { it.timeMs <= effectivePositionMs }
            }
        }
    }

    // Auto-scroll to active lyric line smoothly
    LaunchedEffect(activeLineIndex) {
        val now = System.currentTimeMillis()
        if (activeLineIndex >= 0 && now > userInteractingUntilMs) {
            // Keep active line centered in viewport
            listState.animateScrollToItem(
                index = (activeLineIndex - 1).coerceAtLeast(0),
                scrollOffset = -120
            )
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .testTag("synchronized_lyrics_view")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp)
        ) {
            // Header: Title, artist, live badge & calibration toggle
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 10.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(DriyGold.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = null,
                            tint = DriyGold,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "LETRA EN VIVO",
                                color = DriyGold,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.sp
                            )
                            if (lyrics?.hasSync == true) {
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    color = DriyGold,
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = "SINCRONIZADA",
                                        color = DriyBackground,
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Black,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                        Text(
                            text = if (lyrics?.hasSync == true) "Toca cualquier verso para saltar a él" else "Letra de canción",
                            color = DriyTextSecondary,
                            fontSize = 11.sp
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Calibration button visible whenever synced lyrics are loaded
                    if (syncedLines.isNotEmpty()) {
                        val offsetSec = lyricsUiState.syncOffsetMs / 1000.0
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = if (lyricsUiState.syncOffsetMs != 0L) DriyGold.copy(alpha = 0.2f) else DriySurfaceVariant,
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (lyricsUiState.syncOffsetMs != 0L) DriyGold else DriyDivider
                            ),
                            modifier = Modifier
                                .clickable { showCalibration = !showCalibration }
                                .testTag("lyrics_calibration_toggle")
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Tune,
                                    contentDescription = "Calibrar sincronización",
                                    tint = if (lyricsUiState.syncOffsetMs != 0L) DriyGold else DriyTextSecondary,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (lyricsUiState.syncOffsetMs == 0L) "Calibrar" else "${if (offsetSec > 0) "+" else ""}${String.format(Locale.US, "%.1f", offsetSec)}s",
                                    color = if (lyricsUiState.syncOffsetMs != 0L) DriyGold else DriyTextPrimary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                    }

                    IconButton(
                        onClick = onCloseLyrics,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Cerrar letra",
                            tint = DriyTextSecondary,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }
            }

            // Expandable Sync Calibration Controls Panel
            AnimatedVisibility(
                visible = showCalibration && syncedLines.isNotEmpty(),
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                Surface(
                    color = DriySurface,
                    shape = RoundedCornerShape(14.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, DriyGold.copy(alpha = 0.35f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 10.dp)
                        .testTag("lyrics_calibration_panel")
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "⏱️ Ajuste de sincronización",
                                color = DriyGold,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            val offsetSec = lyricsUiState.syncOffsetMs / 1000.0
                            Text(
                                text = "Actual: ${if (offsetSec > 0) "+" else ""}${String.format(Locale.US, "%.2f", offsetSec)} s",
                                color = if (lyricsUiState.syncOffsetMs != 0L) DriyGold else DriyTextSecondary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.ExtraBold,
                                modifier = Modifier.testTag("lyrics_offset_value")
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "💡 ¿La letra va adelantada? Presiona [-0.5s]. ¿Va retrasada? Presiona [+0.5s].",
                            color = DriyTextSecondary,
                            fontSize = 10.5.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        // Quick adjustment buttons
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CalibrationPill(
                                label = "-1s",
                                onClick = { onAdjustOffset(-1000L) },
                                testTag = "lyrics_offset_minus_1s"
                            )
                            CalibrationPill(
                                label = "-0.5s",
                                onClick = { onAdjustOffset(-500L) },
                                testTag = "lyrics_offset_minus_half",
                                isPrimary = true
                            )
                            CalibrationPill(
                                label = "-0.25s",
                                onClick = { onAdjustOffset(-250L) },
                                testTag = "lyrics_offset_minus_quarter"
                            )

                            if (lyricsUiState.syncOffsetMs != 0L) {
                                Surface(
                                    color = DriySurfaceVariant,
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier
                                        .clickable { onResetOffset() }
                                        .testTag("lyrics_offset_reset")
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 6.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.RestartAlt,
                                            contentDescription = "Restablecer a 0",
                                            tint = DriyGold,
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Spacer(modifier = Modifier.width(2.dp))
                                        Text("0s", color = DriyGold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }

                            CalibrationPill(
                                label = "+0.25s",
                                onClick = { onAdjustOffset(250L) },
                                testTag = "lyrics_offset_plus_quarter"
                            )
                            CalibrationPill(
                                label = "+0.5s",
                                onClick = { onAdjustOffset(500L) },
                                testTag = "lyrics_offset_plus_half",
                                isPrimary = true
                            )
                            CalibrationPill(
                                label = "+1s",
                                onClick = { onAdjustOffset(1000L) },
                                testTag = "lyrics_offset_plus_1s"
                            )
                        }
                    }
                }
            }

            // Body: Loading, Error, Instrumental, Synced or Plain
            when {
                lyricsUiState.isLoading -> {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .fillMaxSize()
                            .weight(1f)
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            CircularProgressIndicator(
                                color = DriyGold,
                                strokeWidth = 2.5.dp,
                                modifier = Modifier.size(36.dp)
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = "Buscando letra sincronizada en LRCLIB...",
                                color = DriyGold,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Calibrando ritmo vocal para '${song.title}'",
                                color = DriyTextSecondary,
                                fontSize = 12.sp
                            )
                        }
                    }
                }

                lyrics?.isInstrumental == true -> {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .fillMaxSize()
                            .weight(1f)
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.padding(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.MusicNote,
                                contentDescription = null,
                                tint = DriyGold,
                                modifier = Modifier.size(54.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "Pista Instrumental",
                                color = DriyTextPrimary,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Esta canción no contiene letra vocal según el registro oficial.",
                                color = DriyTextSecondary,
                                fontSize = 13.sp,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }

                syncedLines.isNotEmpty() -> {
                    // Synced lines display
                    LazyColumn(
                        state = listState,
                        contentPadding = PaddingValues(top = 16.dp, bottom = 120.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp),
                        modifier = Modifier
                            .fillMaxSize()
                            .weight(1f)
                            .pointerInput(Unit) {
                                detectDragGestures { _, _ ->
                                    // Pause auto-scroll for 4 seconds when user drags manually
                                    userInteractingUntilMs = System.currentTimeMillis() + 4000L
                                }
                            }
                            .testTag("lyrics_synced_list")
                    ) {
                        // Intro banner when song is before the first lyric line
                        if (activeLineIndex < 0 && syncedLines.firstOrNull()?.timeMs != null) {
                            item(key = "intro_banner") {
                                Surface(
                                    color = DriySurfaceVariant.copy(alpha = 0.6f),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 12.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        horizontalArrangement = Arrangement.Center,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.MusicNote,
                                            contentDescription = null,
                                            tint = DriyGold,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = "♪ Introducción musical ♪",
                                            color = DriyGold,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                }
                            }
                        }

                        itemsIndexed(syncedLines, key = { index, line -> "$index-${line.timeMs}" }) { index, line ->
                            val isActive = index == activeLineIndex
                            val isPast = activeLineIndex >= 0 && index < activeLineIndex

                            LyricLineItem(
                                line = line,
                                isActive = isActive,
                                isPast = isPast,
                                onLineClick = {
                                    onSeekTo(line.timeMs)
                                    userInteractingUntilMs = System.currentTimeMillis() + 1000L
                                }
                            )
                        }
                    }
                }

                !lyrics?.plainLyrics.isNullOrBlank() -> {
                    // Plain text lyrics fallback
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .weight(1f)
                            .verticalScroll(rememberScrollState())
                            .padding(vertical = 16.dp)
                    ) {
                        Surface(
                            color = DriySurfaceVariant,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.padding(bottom = 16.dp)
                        ) {
                            Text(
                                text = "ℹ️ Letra completa disponible (no sincronizada)",
                                color = DriyGold,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }

                        Text(
                            text = lyrics!!.plainLyrics!!,
                            color = DriyTextPrimary,
                            fontSize = 17.sp,
                            lineHeight = 28.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                else -> {
                    // No lyrics found state with custom search feature
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .fillMaxSize()
                            .weight(1f)
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .padding(24.dp)
                                .verticalScroll(rememberScrollState())
                        ) {
                            Icon(
                                imageVector = Icons.Default.GraphicEq,
                                contentDescription = null,
                                tint = DriyTextSecondary,
                                modifier = Modifier.size(48.dp)
                            )
                            Spacer(modifier = Modifier.height(14.dp))
                            Text(
                                text = "Letra no encontrada en LRCLIB",
                                color = DriyTextPrimary,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Aún no se ha cargado la letra automática para '${song.title}'.",
                                color = DriyTextSecondary,
                                fontSize = 12.sp,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(18.dp))

                            Row(
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Button(
                                    onClick = onRetry,
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = DriyGold,
                                        contentColor = DriyBackground
                                    ),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.testTag("lyrics_retry_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Refresh,
                                        contentDescription = null,
                                        tint = DriyBackground,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Reintentar", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                }

                                OutlinedButton(
                                    onClick = { showCustomSearchInput = !showCustomSearchInput },
                                    colors = ButtonDefaults.outlinedButtonColors(
                                        contentColor = DriyGold
                                    ),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, DriyGold),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.testTag("lyrics_custom_search_toggle")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Search,
                                        contentDescription = null,
                                        tint = DriyGold,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Buscar manual", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                }
                            }

                            // Custom title/artist search input
                            AnimatedVisibility(
                                visible = showCustomSearchInput,
                                enter = fadeIn() + expandVertically(),
                                exit = fadeOut() + shrinkVertically()
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(top = 16.dp)
                                ) {
                                    OutlinedTextField(
                                        value = customSearchQuery,
                                        onValueChange = { customSearchQuery = it },
                                        label = { Text("Título o Artista") },
                                        placeholder = { Text("Ej: ${song.title.take(20)}") },
                                        singleLine = true,
                                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                                        keyboardActions = KeyboardActions(onSearch = {
                                            focusManager.clearFocus()
                                            if (customSearchQuery.isNotBlank()) {
                                                onCustomSearch(customSearchQuery)
                                            }
                                        }),
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = DriyGold,
                                            unfocusedBorderColor = DriyDivider,
                                            focusedTextColor = DriyTextPrimary,
                                            unfocusedTextColor = DriyTextPrimary,
                                            cursorColor = DriyGold
                                        ),
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("lyrics_custom_query_input")
                                    )
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Button(
                                        onClick = {
                                            focusManager.clearFocus()
                                            if (customSearchQuery.isNotBlank()) {
                                                onCustomSearch(customSearchQuery)
                                            }
                                        },
                                        enabled = customSearchQuery.isNotBlank(),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = DriyGold,
                                            contentColor = DriyBackground
                                        ),
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("lyrics_custom_search_submit")
                                    ) {
                                        Text("Buscar Letra en Base de Datos", fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Bottom gradient overlay for smooth fade out
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .height(48.dp)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color.Transparent, DriyBackground)
                    )
                )
        )
    }
}

@Composable
private fun CalibrationPill(
    label: String,
    onClick: () -> Unit,
    testTag: String,
    isPrimary: Boolean = false
) {
    Surface(
        color = if (isPrimary) DriyGold.copy(alpha = 0.25f) else DriySurfaceVariant,
        border = if (isPrimary) androidx.compose.foundation.BorderStroke(1.dp, DriyGold.copy(alpha = 0.6f)) else null,
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier
            .clickable { onClick() }
            .testTag(testTag)
    ) {
        Text(
            text = label,
            color = if (isPrimary) DriyGold else DriyTextPrimary,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
        )
    }
}

@Composable
private fun LyricLineItem(
    line: LyricLine,
    isActive: Boolean,
    isPast: Boolean,
    onLineClick: () -> Unit
) {
    val targetScale = if (isActive) 1.05f else 1.0f
    val scale by animateFloatAsState(targetValue = targetScale, label = "line_scale")

    val textColor by animateColorAsState(
        targetValue = when {
            isActive -> DriyGold
            isPast -> DriyTextPrimary.copy(alpha = 0.65f)
            else -> DriyTextSecondary.copy(alpha = 0.40f)
        },
        animationSpec = tween(280, easing = FastOutSlowInEasing),
        label = "line_color"
    )

    val fontSize = if (isActive) 23.sp else 18.sp
    val fontWeight = if (isActive) FontWeight.ExtraBold else FontWeight.SemiBold
    val lineHeight = if (isActive) 32.sp else 26.sp

    Surface(
        color = if (isActive) DriySurface.copy(alpha = 0.6f) else Color.Transparent,
        shape = RoundedCornerShape(12.dp),
        border = if (isActive) androidx.compose.foundation.BorderStroke(1.dp, DriyGold.copy(alpha = 0.35f)) else null,
        modifier = Modifier
            .fillMaxWidth()
            .scale(scale)
            .clickable { onLineClick() }
            .padding(horizontal = 4.dp, vertical = if (isActive) 6.dp else 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (isActive) {
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .clip(CircleShape)
                        .background(DriyGold)
                )
                Spacer(modifier = Modifier.width(10.dp))
            }

            Text(
                text = line.text.ifBlank { "♪" },
                color = textColor,
                fontSize = fontSize,
                fontWeight = fontWeight,
                lineHeight = lineHeight,
                modifier = Modifier.weight(1f)
            )
        }
    }
}
