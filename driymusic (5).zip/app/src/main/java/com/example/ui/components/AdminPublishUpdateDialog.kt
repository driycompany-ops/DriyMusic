package com.example.ui.components

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.BuildConfig
import com.example.service.DriyAppUpdater
import com.example.ui.theme.DriyBackground
import com.example.ui.theme.DriyGold
import com.example.ui.theme.DriySurface
import com.example.ui.theme.DriyTextPrimary
import com.example.ui.theme.DriyTextSecondary
import kotlinx.coroutines.launch

@Composable
fun AdminPublishUpdateDialog(
    isOpen: Boolean,
    onDismiss: () -> Unit
) {
    if (!isOpen) return

    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var versionCodeInput by remember { mutableStateOf((BuildConfig.VERSION_CODE + 1).toString()) }
    var versionNameInput by remember { mutableStateOf("1.1.0") }
    var apkUrlInput by remember { mutableStateOf(DriyAppUpdater.DEFAULT_DOWNLOAD_URL) }
    var notesInput by remember { mutableStateOf("• Nuevas funciones y más música\n• Rendimiento mejorado y corrección de errores") }
    var isForceUpdate by remember { mutableStateOf(false) }
    var isPublishing by remember { mutableStateOf(false) }

    Dialog(
        onDismissRequest = { if (!isPublishing) onDismiss() },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            color = DriySurface,
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.CloudUpload,
                        contentDescription = null,
                        tint = Color(0xFFAB47BC),
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Publicar Actualización OTA",
                        color = DriyTextPrimary,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(
                        onClick = onDismiss,
                        enabled = !isPublishing
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Cerrar", tint = DriyTextSecondary)
                    }
                }

                Text(
                    text = "Al guardar, todos los usuarios que abran la aplicación verán la ventana emergente para descargar e instalar la nueva versión.",
                    color = DriyTextSecondary,
                    fontSize = 12.sp,
                    lineHeight = 16.sp
                )

                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = versionCodeInput,
                    onValueChange = { versionCodeInput = it.filter { c -> c.isDigit() } },
                    label = { Text("Version Code (Número incremental)") },
                    placeholder = { Text("Ej: 2") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = DriyGold,
                        unfocusedBorderColor = DriyTextSecondary.copy(alpha = 0.4f),
                        focusedTextColor = DriyTextPrimary,
                        unfocusedTextColor = DriyTextPrimary
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = versionNameInput,
                    onValueChange = { versionNameInput = it },
                    label = { Text("Version Name (Nombre visible)") },
                    placeholder = { Text("Ej: 1.1.0") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = DriyGold,
                        unfocusedBorderColor = DriyTextSecondary.copy(alpha = 0.4f),
                        focusedTextColor = DriyTextPrimary,
                        unfocusedTextColor = DriyTextPrimary
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = apkUrlInput,
                    onValueChange = { apkUrlInput = it },
                    label = { Text("Enlace directo al APK (.apk)") },
                    placeholder = { Text("https://tuweb.com/driymusic.apk") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = DriyGold,
                        unfocusedBorderColor = DriyTextSecondary.copy(alpha = 0.4f),
                        focusedTextColor = DriyTextPrimary,
                        unfocusedTextColor = DriyTextPrimary
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = notesInput,
                    onValueChange = { notesInput = it },
                    label = { Text("Novedades de la versión (Notas de cambio)") },
                    minLines = 3,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = DriyGold,
                        unfocusedBorderColor = DriyTextSecondary.copy(alpha = 0.4f),
                        focusedTextColor = DriyTextPrimary,
                        unfocusedTextColor = DriyTextPrimary
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Checkbox(
                        checked = isForceUpdate,
                        onCheckedChange = { isForceUpdate = it },
                        colors = CheckboxDefaults.colors(checkedColor = DriyGold)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Obligatoria (No permite posponer)",
                        color = DriyTextPrimary,
                        fontSize = 13.sp
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        val code = versionCodeInput.toIntOrNull()
                        if (code == null || code <= BuildConfig.VERSION_CODE) {
                            Toast.makeText(context, "El Version Code debe ser mayor a ${BuildConfig.VERSION_CODE}", Toast.LENGTH_LONG).show()
                            return@Button
                        }
                        if (apkUrlInput.isBlank() || !apkUrlInput.startsWith("http")) {
                            Toast.makeText(context, "Por favor ingresa un enlace válido (https://...)", Toast.LENGTH_SHORT).show()
                            return@Button
                        }

                        isPublishing = true
                        coroutineScope.launch {
                            val res = DriyAppUpdater.publishNewVersion(
                                versionCode = code,
                                versionName = versionNameInput.ifBlank { "v$code.0" },
                                apkUrl = apkUrlInput,
                                releaseNotes = notesInput,
                                isForceUpdate = isForceUpdate
                            )
                            isPublishing = false
                            if (res.isSuccess) {
                                Toast.makeText(context, "¡Actualización publicada con éxito en Firestore!", Toast.LENGTH_LONG).show()
                                onDismiss()
                            } else {
                                Toast.makeText(context, "Error al publicar: ${res.exceptionOrNull()?.message}", Toast.LENGTH_LONG).show()
                            }
                        }
                    },
                    enabled = !isPublishing,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFAB47BC),
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                        .testTag("btn_save_publish_ota_update")
                ) {
                    if (isPublishing) {
                        CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                    } else {
                        Text("Lanzar Actualización a Usuarios", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
