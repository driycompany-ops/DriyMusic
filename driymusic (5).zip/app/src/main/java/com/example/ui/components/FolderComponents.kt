package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.draw.scale
import kotlinx.coroutines.launch
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.FolderEntity
import com.example.data.model.FolderWithStats
import com.example.data.model.SongEntity
import com.example.ui.theme.DriyBackground
import com.example.ui.theme.DriyDivider
import com.example.ui.theme.DriyGold
import com.example.ui.theme.DriySurface
import com.example.ui.theme.DriySurfaceVariant
import com.example.ui.theme.DriyTextPrimary
import com.example.ui.theme.DriyTextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FolderSelectionBottomSheet(
    song: SongEntity?,
    folders: List<FolderEntity>,
    selectedFolderIds: Set<String>,
    onDismiss: () -> Unit,
    onToggleFolder: (FolderEntity) -> Unit,
    onCreateFolder: (String) -> Unit
) {
    if (song == null) return
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var isCreatingFolder by remember { mutableStateOf(false) }
    var newFolderName by remember { mutableStateOf("") }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = DriyBackground,
        dragHandle = null
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(DriySurfaceVariant)
                ) {
                    AsyncImage(
                        model = song.coverUrl,
                        contentDescription = song.title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }
                Spacer(modifier = Modifier.width(14.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Guardar en carpetas",
                        color = DriyGold,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = song.title,
                        color = DriyTextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = song.artist,
                        color = DriyTextSecondary,
                        fontSize = 12.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(3.dp))
                    val isFavSaved = selectedFolderIds.contains("favorites") || (song.isFavorite && selectedFolderIds.contains("favorites"))
                    Surface(
                        color = if (isFavSaved) DriyGold.copy(alpha = 0.18f) else DriySurfaceVariant,
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Icon(
                                imageVector = if (isFavSaved) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                contentDescription = null,
                                tint = if (isFavSaved) DriyGold else DriyTextSecondary,
                                modifier = Modifier.size(11.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (isFavSaved) "En Favoritos" else "No en Favoritos",
                                color = if (isFavSaved) DriyGold else DriyTextSecondary,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Cerrar",
                        tint = DriyTextSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            HorizontalDivider(color = DriyDivider)
            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "Selecciona las carpetas donde quieres tener esta canción:",
                color = DriyTextSecondary,
                fontSize = 12.sp,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .height((folders.size * 68).coerceIn(70, 260).dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(folders, key = { it.id }) { folder ->
                    val isChecked = selectedFolderIds.contains(folder.id)
                    FolderSelectionItemRow(
                        folder = folder,
                        isChecked = isChecked,
                        onToggle = { onToggleFolder(folder) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            if (isCreatingFolder) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = DriySurface),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, DriyGold, RoundedCornerShape(12.dp))
                        .padding(bottom = 6.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "NUEVA CARPETA DE MÚSICA",
                            color = DriyGold,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = newFolderName,
                            onValueChange = { newFolderName = it },
                            placeholder = { Text("Ej: Gym, Carretera, Para Estudiar...", color = DriyTextSecondary, fontSize = 13.sp) },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = DriySurfaceVariant,
                                unfocusedContainerColor = DriySurfaceVariant,
                                focusedBorderColor = DriyGold,
                                unfocusedBorderColor = DriyDivider,
                                focusedTextColor = DriyTextPrimary,
                                unfocusedTextColor = DriyTextPrimary
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("new_folder_name_input")
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            TextButton(
                                onClick = {
                                    isCreatingFolder = false
                                    newFolderName = ""
                                }
                            ) {
                                Text("Cancelar", color = DriyTextSecondary)
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = {
                                    if (newFolderName.isNotBlank()) {
                                        onCreateFolder(newFolderName.trim())
                                        newFolderName = ""
                                        isCreatingFolder = false
                                    }
                                },
                                enabled = newFolderName.isNotBlank(),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = DriyGold,
                                    contentColor = DriyBackground
                                ),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.testTag("create_folder_submit_btn")
                            ) {
                                Text("Crear y Guardar", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            } else {
                OutlinedButton(
                    onClick = { isCreatingFolder = true },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = DriyGold
                    ),
                    border = ButtonDefaults.outlinedButtonBorder.copy(
                        brush = androidx.compose.ui.graphics.SolidColor(DriyGold)
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("open_create_folder_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.CreateNewFolder,
                        contentDescription = null,
                        tint = DriyGold,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "+ Crear nueva carpeta de música",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Button(
                onClick = onDismiss,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = DriyGold,
                    contentColor = DriyBackground
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("folder_selector_done_btn")
            ) {
                Text(
                    text = "Listo",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
private fun FolderSelectionItemRow(
    folder: FolderEntity,
    isChecked: Boolean,
    onToggle: () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    val iconScale = remember { Animatable(1f) }
    val burstAlpha = remember { Animatable(0f) }
    val burstScale = remember { Animatable(0.6f) }

    val isFavFolder = folder.isDefault || folder.id == "favorites"

    val containerColor by animateColorAsState(
        targetValue = if (isChecked) DriySurfaceVariant else DriySurface,
        animationSpec = tween(durationMillis = 200),
        label = "folder_container_color"
    )

    val borderColor by animateColorAsState(
        targetValue = if (isChecked) DriyGold.copy(alpha = 0.75f) else DriyDivider,
        animationSpec = tween(durationMillis = 200),
        label = "folder_border_color"
    )

    val heartColor by animateColorAsState(
        targetValue = if (isChecked) DriyGold else DriyTextSecondary,
        animationSpec = tween(durationMillis = 200),
        label = "folder_heart_color"
    )

    Card(
        colors = CardDefaults.cardColors(containerColor = containerColor),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(
                if (isChecked) 1.5.dp else 1.dp,
                borderColor,
                RoundedCornerShape(12.dp)
            )
            .clickable {
                coroutineScope.launch {
                    if (isFavFolder) {
                        launch {
                            burstScale.snapTo(0.6f)
                            burstAlpha.snapTo(0.85f)
                            burstScale.animateTo(1.7f, tween(300, easing = FastOutSlowInEasing))
                            burstAlpha.animateTo(0f, tween(150, easing = LinearEasing))
                        }
                    }
                    iconScale.animateTo(1.48f, spring(dampingRatio = 0.35f, stiffness = 850f))
                    iconScale.animateTo(0.88f, spring(dampingRatio = 0.5f, stiffness = 650f))
                    iconScale.animateTo(1.0f, spring(dampingRatio = 0.6f, stiffness = 400f))
                }
                onToggle()
            }
            .testTag("folder_item_${folder.id}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 11.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(
                            if (isFavFolder) {
                                if (isChecked) DriyGold.copy(alpha = 0.28f) else DriySurface
                            } else {
                                if (isChecked) DriyGold.copy(alpha = 0.15f) else DriySurface
                            }
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    if (isFavFolder && burstAlpha.value > 0.01f) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .scale(burstScale.value)
                                .clip(CircleShape)
                                .border(1.5.dp, DriyGold.copy(alpha = burstAlpha.value), CircleShape)
                        )
                    }

                    Icon(
                        imageVector = if (isFavFolder) {
                            if (isChecked) Icons.Default.Favorite else Icons.Default.FavoriteBorder
                        } else {
                            Icons.Default.Folder
                        },
                        contentDescription = null,
                        tint = if (isFavFolder) heartColor else if (isChecked) DriyGold else DriyTextSecondary,
                        modifier = Modifier
                            .size(20.dp)
                            .scale(iconScale.value)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = folder.name,
                            color = if (isChecked) DriyGold else DriyTextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        if (isFavFolder) {
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                color = if (isChecked) DriyGold.copy(alpha = 0.25f) else DriySurfaceVariant,
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = if (isChecked) "❤️ GUARDADA" else "DE FÁBRICA",
                                    color = if (isChecked) DriyGold else DriyTextSecondary,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                    Text(
                        text = if (isFavFolder) {
                            if (isChecked) "Canción guardada en tus Favoritos" else "Toca para agregar a Favoritos"
                        } else {
                            if (isChecked) "Canción guardada en esta carpeta" else "Toca para agregar a esta carpeta"
                        },
                        color = if (isChecked) DriyTextPrimary.copy(alpha = 0.8f) else DriyTextSecondary,
                        fontSize = 11.sp
                    )
                }
            }
            Checkbox(
                checked = isChecked,
                onCheckedChange = {
                    coroutineScope.launch {
                        iconScale.animateTo(1.35f, spring(dampingRatio = 0.4f, stiffness = 700f))
                        iconScale.animateTo(1.0f, spring(dampingRatio = 0.6f, stiffness = 400f))
                    }
                    onToggle()
                },
                colors = CheckboxDefaults.colors(
                    checkedColor = DriyGold,
                    uncheckedColor = DriyTextSecondary,
                    checkmarkColor = DriyBackground
                )
            )
        }
    }
}

@Composable
fun FolderRenameDialog(
    folder: FolderEntity?,
    onDismiss: () -> Unit,
    onConfirmRename: (String) -> Unit
) {
    if (folder == null) return
    var currentName by remember(folder.name) { mutableStateOf(folder.name) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DriySurface,
        title = {
            Text(
                text = "Cambiar nombre de la carpeta",
                color = DriyTextPrimary,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column {
                Text(
                    text = "Introduce el nuevo nombre para tu carpeta de música:",
                    color = DriyTextSecondary,
                    fontSize = 13.sp
                )
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(
                    value = currentName,
                    onValueChange = { currentName = it },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = DriySurfaceVariant,
                        unfocusedContainerColor = DriySurfaceVariant,
                        focusedBorderColor = DriyGold,
                        unfocusedBorderColor = DriyDivider,
                        focusedTextColor = DriyTextPrimary,
                        unfocusedTextColor = DriyTextPrimary
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("rename_folder_input")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (currentName.isNotBlank()) {
                        onConfirmRename(currentName.trim())
                        onDismiss()
                    }
                },
                enabled = currentName.isNotBlank(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = DriyGold,
                    contentColor = DriyBackground
                ),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.testTag("confirm_rename_folder_btn")
            ) {
                Text("Guardar", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar", color = DriyTextSecondary)
            }
        }
    )
}

@Composable
fun FolderCard(
    folderWithStats: FolderWithStats,
    onClick: () -> Unit,
    onRename: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    val folder = folderWithStats.folder
    val isDefault = folder.isDefault

    Card(
        colors = CardDefaults.cardColors(containerColor = DriySurface),
        shape = RoundedCornerShape(14.dp),
        modifier = modifier
            .fillMaxWidth()
            .border(
                1.dp,
                if (isDefault) DriyGold.copy(alpha = 0.4f) else DriyDivider,
                RoundedCornerShape(14.dp)
            )
            .clickable { onClick() }
            .testTag("folder_card_${folder.id}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(54.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (isDefault) DriyGold.copy(alpha = 0.25f) else DriySurfaceVariant),
                contentAlignment = Alignment.Center
            ) {
                if (folderWithStats.coverUrl != null) {
                    AsyncImage(
                        model = folderWithStats.coverUrl,
                        contentDescription = folder.name,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Icon(
                        imageVector = if (isDefault) Icons.Default.Favorite else Icons.Default.Folder,
                        contentDescription = null,
                        tint = DriyGold,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = folder.name,
                        color = DriyTextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (isDefault) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            color = DriyGold.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = "POR DEFECTO",
                                color = DriyGold,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "${folderWithStats.songCount} canciones",
                    color = DriyTextSecondary,
                    fontSize = 12.sp
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = onRename,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = "Cambiar nombre",
                        tint = DriyTextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                }
                if (!isDefault) {
                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Eliminar carpeta",
                            tint = Color(0xFFE57373),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun FolderDetailView(
    folder: FolderEntity,
    songs: List<SongEntity>,
    isPlaying: Boolean,
    currentSongId: String?,
    downloadProgress: Map<String, Float>,
    onBack: () -> Unit,
    onPlayAll: () -> Unit,
    onShuffleAll: () -> Unit,
    onPlaySong: (SongEntity, List<SongEntity>) -> Unit,
    onToggleFavorite: (SongEntity) -> Unit,
    onDownloadSong: (SongEntity) -> Unit,
    onOpenSongOptions: (SongEntity) -> Unit,
    onRenameFolder: () -> Unit,
    onDeleteFolder: () -> Unit,
    onRemoveSongFromFolder: (String) -> Unit,
    onSyncCloud: () -> Unit = {}
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DriyBackground)
            .testTag("folder_detail_view")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier.size(40.dp)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Volver a carpetas",
                        tint = DriyTextPrimary,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Carpeta",
                    color = DriyTextSecondary,
                    fontSize = 14.sp
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = onSyncCloud,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Sync,
                        contentDescription = "Sincronizar nube",
                        tint = DriyGold,
                        modifier = Modifier.size(20.dp)
                    )
                }
                IconButton(
                    onClick = onRenameFolder,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = "Renombrar carpeta",
                        tint = DriyGold,
                        modifier = Modifier.size(20.dp)
                    )
                }
                if (!folder.isDefault) {
                    IconButton(
                        onClick = onDeleteFolder,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Eliminar carpeta",
                            tint = Color(0xFFE57373),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(90.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(if (folder.isDefault) DriyGold.copy(alpha = 0.25f) else DriySurface)
                    .border(2.dp, DriyGold.copy(alpha = 0.6f), RoundedCornerShape(18.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (folder.isDefault) Icons.Default.Favorite else Icons.Default.Folder,
                    contentDescription = null,
                    tint = DriyGold,
                    modifier = Modifier.size(44.dp)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = folder.name,
                color = DriyTextPrimary,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
            Text(
                text = "${songs.size} canciones en esta carpeta",
                color = DriyGold,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium
            )

            Spacer(modifier = Modifier.height(14.dp))

            if (songs.isNotEmpty()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = onPlayAll,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = DriyGold,
                            contentColor = DriyBackground
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = null,
                            tint = DriyBackground,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Reproducir", fontWeight = FontWeight.Bold)
                    }

                    OutlinedButton(
                        onClick = onShuffleAll,
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = DriyGold
                        ),
                        border = ButtonDefaults.outlinedButtonBorder.copy(
                            brush = androidx.compose.ui.graphics.SolidColor(DriyGold)
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Shuffle,
                            contentDescription = null,
                            tint = DriyGold,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Aleatorio", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))
        HorizontalDivider(color = DriyDivider)

        if (songs.isEmpty()) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Folder,
                        contentDescription = null,
                        tint = DriyTextSecondary,
                        modifier = Modifier.size(56.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Esta carpeta no tiene canciones locales aún",
                        color = DriyTextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Si agregaste canciones desde otro celular o cuenta, pulsa el botón para traerlas de la nube.",
                        color = DriyTextSecondary,
                        fontSize = 13.sp,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = onSyncCloud,
                        colors = ButtonDefaults.buttonColors(containerColor = DriyGold, contentColor = DriyBackground),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Sync,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Sincronizar canciones de la nube", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(bottom = 90.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(songs, key = { it.id }) { song ->
                    SongItemRow(
                        song = song,
                        isPlaying = isPlaying,
                        isCurrentSong = currentSongId == song.id,
                        downloadProgress = downloadProgress[song.id],
                        onPlay = { onPlaySong(song, songs) },
                        onToggleFavorite = { onToggleFavorite(song) },
                        onDownload = { onDownloadSong(song) },
                        onOptionsClick = { onOpenSongOptions(song) }
                    )
                }
            }
        }
    }
}
