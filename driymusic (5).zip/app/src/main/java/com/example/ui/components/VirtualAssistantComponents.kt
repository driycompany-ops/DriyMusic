package com.example.ui.components

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AssistantAnimationMode
import com.example.data.model.AssistantAvatar
import com.example.data.model.VirtualAssistantCatalog
import com.example.service.VirtualAssistantManager
import com.example.ui.theme.DriyBackground
import com.example.ui.theme.DriyDivider
import com.example.ui.theme.DriyGold
import com.example.ui.theme.DriySurface
import com.example.ui.theme.DriySurfaceVariant
import com.example.ui.theme.DriyTextPrimary
import com.example.ui.theme.DriyTextSecondary
import kotlinx.coroutines.delay

/**
 * Animated sprite sheet renderer with 100% transparent background.
 * Supports:
 * - STANDING: Frame 0 (Standing upright by default)
 * - SITTING_DOWN: Sequence 0 -> 5 (bringing chair and sitting down after 1 min of inactivity)
 * - SEATED: Frame 5 (Comfortably seated on chair)
 * - CHANGING_MUSIC: Cycling through phone operation frames
 * - BLESSING: Reaching for card and holding it up
 */
@Composable
fun AnimatedSpriteAvatar(
    drawableRes: Int,
    totalFrames: Int = 6,
    animationMode: AssistantAnimationMode,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var bitmap by remember(drawableRes) {
        mutableStateOf<Bitmap?>(null)
    }

    LaunchedEffect(drawableRes) {
        bitmap = BitmapFactory.decodeResource(context.resources, drawableRes)
    }

    var currentFrame by remember(animationMode, drawableRes) {
        mutableIntStateOf(0)
    }

    LaunchedEffect(animationMode, drawableRes, totalFrames) {
        val safeFrames = totalFrames.coerceAtLeast(1)
        when (animationMode) {
            AssistantAnimationMode.STANDING -> {
                // Standing upright: calm, peaceful standing without rapid twitching
                if (safeFrames > 1) {
                    while (true) {
                        currentFrame = 0
                        delay(2200L)
                        currentFrame = 1
                        delay(800L)
                        if (safeFrames > 2) {
                            currentFrame = 2
                            delay(2200L)
                        }
                        if (safeFrames > 3) {
                            currentFrame = 3
                            delay(800L)
                        }
                    }
                } else {
                    currentFrame = 0
                }
            }
            AssistantAnimationMode.SITTING_DOWN -> {
                // Transitioning to sitting/sleeping
                for (f in 0 until safeFrames) {
                    currentFrame = f
                    delay(250L)
                }
                currentFrame = safeFrames - 1
            }
            AssistantAnimationMode.SEATED -> {
                // Seated or sleeping peacefully with Zzz
                if (safeFrames >= 4) {
                    while (true) {
                        currentFrame = safeFrames - 1
                        delay(1500L)
                        currentFrame = safeFrames - 2
                        delay(1500L)
                    }
                } else {
                    currentFrame = safeFrames - 1
                }
            }
            AssistantAnimationMode.CHANGING_MUSIC -> {
                // Loop phone operating animation
                while (true) {
                    for (f in 0 until safeFrames) {
                        currentFrame = f
                        delay(180L)
                    }
                }
            }
            AssistantAnimationMode.BLESSING -> {
                // Pulls out card and holds it up
                for (f in 0 until safeFrames) {
                    currentFrame = f
                    delay(170L)
                }
                while (true) {
                    delay(800L)
                    currentFrame = safeFrames - 1
                }
            }
            AssistantAnimationMode.LOVE -> {
                // Heart wave, finger heart, chest heart
                for (f in 0 until safeFrames) {
                    currentFrame = f
                    delay(300L)
                }
                while (true) {
                    currentFrame = safeFrames - 1
                    delay(1200L)
                    currentFrame = (safeFrames - 3).coerceAtLeast(1)
                    delay(1200L)
                }
            }
        }
    }

    val currentBmp = bitmap
    if (currentBmp != null && !currentBmp.isRecycled) {
        val frameWidth = (currentBmp.width / totalFrames).coerceAtLeast(1)
        val frameHeight = currentBmp.height

        val safeFrame = currentFrame.coerceIn(0, totalFrames - 1)
        val srcX = safeFrame * frameWidth

        Canvas(modifier = modifier) {
            val imageBitmap = currentBmp.asImageBitmap()
            drawImage(
                image = imageBitmap,
                srcOffset = IntOffset(srcX, 0),
                srcSize = IntSize(frameWidth, frameHeight),
                dstOffset = IntOffset.Zero,
                dstSize = IntSize(size.width.toInt(), size.height.toInt())
            )
        }
    } else {
        Box(
            modifier = modifier
                .clip(CircleShape)
                .background(Color.Transparent),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.SmartToy,
                contentDescription = null,
                tint = DriyGold,
                modifier = Modifier.size(24.dp)
            )
        }
    }
}

/**
 * Floating widget showing the virtual assistant avatar WITHOUT BACKGROUND.
 * The character stands/sits cleanly on top of the app.
 * Only visual thought bubbles (💭) appear with no audio noise.
 */
@Composable
fun FloatingAssistantWidget(
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val assistantState by VirtualAssistantManager.state.collectAsState()
    if (!assistantState.isEnabled) return

    val currentAvatar = remember(assistantState.selectedAvatarId) {
        VirtualAssistantCatalog.getById(assistantState.selectedAvatarId)
    }
    val isZoe = currentAvatar.id == "zoe"
    val isJungkook = currentAvatar.id == "jungkook"

    val (currentDrawableRes, frameCount) = when (assistantState.currentAnimationMode) {
        AssistantAnimationMode.CHANGING_MUSIC -> Pair(currentAvatar.changingMusicDrawableRes, currentAvatar.changingMusicFrames)
        AssistantAnimationMode.LOVE -> Pair(currentAvatar.loveDrawableRes, currentAvatar.loveFrames)
        AssistantAnimationMode.BLESSING -> {
            if (isJungkook || isZoe) Pair(currentAvatar.loveDrawableRes, currentAvatar.loveFrames)
            else Pair(currentAvatar.blessingDrawableRes, currentAvatar.totalFrames)
        }
        AssistantAnimationMode.SEATED,
        AssistantAnimationMode.SITTING_DOWN -> {
            if (isJungkook || isZoe) Pair(currentAvatar.sleepingDrawableRes, currentAvatar.sleepingFrames)
            else Pair(currentAvatar.idleDrawableRes, currentAvatar.totalFrames)
        }
        AssistantAnimationMode.STANDING -> Pair(currentAvatar.idleDrawableRes, currentAvatar.idleFrames)
    }

    Column(
        horizontalAlignment = Alignment.End,
        modifier = modifier
            .padding(end = 12.dp, bottom = 6.dp)
            .wrapContentSize()
    ) {
        // Silent Thought Bubble (Displays visual thought bubble like 💭 "hola")
        AnimatedVisibility(
            visible = !assistantState.thoughtText.isNullOrBlank(),
            enter = fadeIn() + scaleIn(),
            exit = fadeOut() + scaleOut()
        ) {
            Surface(
                color = DriySurface.copy(alpha = 0.95f),
                shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp, bottomStart = 16.dp, bottomEnd = 4.dp),
                shadowElevation = 8.dp,
                border = androidx.compose.foundation.BorderStroke(1.2.dp, DriyGold),
                modifier = Modifier
                    .padding(bottom = 6.dp)
                    .width(240.dp)
                    .clickable {
                        VirtualAssistantManager.standUpAndInteract()
                        onOpenSettings()
                    }
                    .testTag("assistant_thought_bubble")
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Text(
                        text = if (isJungkook) "💜" else if (isZoe) "🌸" else "💭",
                        fontSize = 16.sp
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = assistantState.customAvatarName,
                                color = DriyGold,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                            val statusNote = when (assistantState.currentAnimationMode) {
                                AssistantAnimationMode.SEATED -> if (isJungkook || isZoe) "(durmiendo 💤)" else "(descansando)"
                                AssistantAnimationMode.LOVE -> if (isZoe) "(dando besos 💋🌸)" else "(con amor 💜)"
                                AssistantAnimationMode.CHANGING_MUSIC -> if (isZoe) "(sacando celular 📱)" else "(en el teléfono 📱)"
                                else -> ""
                            }
                            if (statusNote.isNotEmpty()) {
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = statusNote,
                                    color = DriyTextSecondary,
                                    fontSize = 9.sp
                                )
                            }
                        }
                        Text(
                            text = assistantState.thoughtText ?: "",
                            color = DriyTextPrimary,
                            fontSize = 12.sp,
                            lineHeight = 16.sp
                        )
                    }
                }
            }
        }

        // Clean Avatar character WITHOUT background container (Totalmente transparente sin fondo)
        Row(
            verticalAlignment = Alignment.Bottom,
            horizontalArrangement = Arrangement.End
        ) {
            // Small Mic button to activate voice listening with audio ducking
            Surface(
                color = if (assistantState.isListening) Color(0xFF4CAF50) else DriySurface.copy(alpha = 0.9f),
                shape = CircleShape,
                shadowElevation = 6.dp,
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (assistantState.isListening) Color.White else DriyGold
                ),
                modifier = Modifier
                    .size(34.dp)
                    .clickable {
                        VirtualAssistantManager.toggleListening()
                    }
                    .testTag("floating_mic_button")
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = if (assistantState.isListening) Icons.Default.GraphicEq else Icons.Default.Mic,
                        contentDescription = "Hablar",
                        tint = if (assistantState.isListening) Color.White else DriyGold,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(6.dp))

            // Transparent animated character
            Box(
                modifier = Modifier
                    .clickable {
                        // Tapping avatar toggles voice listening or stands up
                        if (assistantState.isListening) {
                            VirtualAssistantManager.stopListening()
                        } else {
                            VirtualAssistantManager.startListeningSession()
                        }
                    }
                    .testTag("assistant_floating_avatar"),
                contentAlignment = Alignment.BottomCenter
            ) {
                // Subtle character shadow at feet
                Box(
                    modifier = Modifier
                        .size(width = 46.dp, height = 7.dp)
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.22f))
                )

                // Transparent animated character
                Box(
                    modifier = Modifier.size(width = 66.dp, height = 88.dp)
                ) {
                    AnimatedSpriteAvatar(
                        drawableRes = currentDrawableRes,
                        totalFrames = frameCount,
                        animationMode = assistantState.currentAnimationMode,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }

            Spacer(modifier = Modifier.width(4.dp))

            // Settings button
            Surface(
                color = DriySurface.copy(alpha = 0.85f),
                shape = CircleShape,
                shadowElevation = 4.dp,
                border = androidx.compose.foundation.BorderStroke(1.dp, DriyDivider),
                modifier = Modifier
                    .size(28.dp)
                    .clickable {
                        VirtualAssistantManager.standUpAndInteract()
                        onOpenSettings()
                    }
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Default.Tune,
                        contentDescription = "Configurar",
                        tint = DriyTextSecondary,
                        modifier = Modifier.size(15.dp)
                    )
                }
            }
        }
    }
}

/**
 * Assistant Management and Avatar Selector Sheet.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VirtualAssistantBottomSheet(
    visible: Boolean,
    onDismiss: () -> Unit
) {
    if (!visible) return
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val assistantState by VirtualAssistantManager.state.collectAsState()

    var showRenameDialog by remember { mutableStateOf(false) }
    var showCallingTitleDialog by remember { mutableStateOf(false) }
    var textCommandInput by remember { mutableStateOf("") }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = DriyBackground,
        dragHandle = null
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 18.dp)
                .padding(bottom = 24.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(DriyGold.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.SmartToy,
                            contentDescription = null,
                            tint = DriyGold,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Asistente Virtual",
                            color = DriyTextPrimary,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Solo responde cuando dices su nombre (sin ruidos ni cortes)",
                            color = DriyTextSecondary,
                            fontSize = 11.sp
                        )
                    }
                }
                IconButton(onClick = onDismiss) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Cerrar",
                        tint = DriyTextSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            HorizontalDivider(color = DriyDivider)
            Spacer(modifier = Modifier.height(14.dp))

            // Main Activation Switch (Default Disabled!)
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (assistantState.isEnabled) DriySurfaceVariant else DriySurface
                ),
                shape = RoundedCornerShape(14.dp),
                border = androidx.compose.foundation.BorderStroke(
                    1.2.dp,
                    if (assistantState.isEnabled) DriyGold else DriyDivider
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = if (assistantState.isEnabled) "Asistente Activado" else "Asistente Desactivado",
                                color = if (assistantState.isEnabled) DriyGold else DriyTextPrimary,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                            if (assistantState.isEnabled) {
                                Spacer(modifier = Modifier.width(8.dp))
                                Surface(
                                    color = DriyGold,
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = if (assistantState.currentAnimationMode == AssistantAnimationMode.SEATED) "SENTADO" else "PARADO",
                                        color = DriyBackground,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Black,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = if (assistantState.isEnabled)
                                "Estará parado. Si pasa más de 1 minuto sin órdenes, se sentará a descansar 💭"
                            else
                                "Actívalo cuando desees que tu avatar escuche tus órdenes.",
                            color = DriyTextSecondary,
                            fontSize = 11.sp,
                            lineHeight = 15.sp
                        )
                    }

                    Switch(
                        checked = assistantState.isEnabled,
                        onCheckedChange = { enabled ->
                            VirtualAssistantManager.setEnabled(enabled)
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = DriyBackground,
                            checkedTrackColor = DriyGold,
                            uncheckedThumbColor = DriyTextSecondary,
                            uncheckedTrackColor = DriySurfaceVariant
                        ),
                        modifier = Modifier.testTag("assistant_activation_switch")
                    )
                }
            }

            if (assistantState.isEnabled) {
                Spacer(modifier = Modifier.height(18.dp))

                // Custom Name & How He Calls You
                Text(
                    text = "PERSONALIZA TU VÍNCULO",
                    color = DriyGold,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = DriySurface),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .clickable { showRenameDialog = true }
                            .border(1.dp, DriyDivider, RoundedCornerShape(12.dp))
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(text = "Nombre del Avatar", color = DriyTextSecondary, fontSize = 10.sp)
                            Spacer(modifier = Modifier.height(2.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = assistantState.customAvatarName,
                                    color = DriyGold,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Icon(Icons.Default.Edit, contentDescription = null, tint = DriyGold, modifier = Modifier.size(13.dp))
                            }
                        }
                    }

                    Card(
                        colors = CardDefaults.cardColors(containerColor = DriySurface),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .clickable { showCallingTitleDialog = true }
                            .border(1.dp, DriyDivider, RoundedCornerShape(12.dp))
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(text = "Cómo te llamará a ti", color = DriyTextSecondary, fontSize = 10.sp)
                            Spacer(modifier = Modifier.height(2.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = assistantState.userCallingTitle,
                                    color = DriyGold,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Icon(Icons.Default.Edit, contentDescription = null, tint = DriyGold, modifier = Modifier.size(13.dp))
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Avatar Selector (Only 1 active at a time)
                Text(
                    text = "SELECCIONA TU AVATAR (SOLO 1 ACTIVO)",
                    color = DriyGold,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(10.dp))

                VirtualAssistantCatalog.avatars.forEach { avatar ->
                    val isSelected = avatar.id == assistantState.selectedAvatarId
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) DriySurfaceVariant else DriySurface
                        ),
                        shape = RoundedCornerShape(14.dp),
                        border = androidx.compose.foundation.BorderStroke(
                            width = if (isSelected) 1.5.dp else 1.dp,
                            color = if (isSelected) DriyGold else DriyDivider
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 10.dp)
                            .clickable { VirtualAssistantManager.selectAvatar(avatar.id) }
                            .testTag("avatar_card_${avatar.id}")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Transparent preview of standing pose (Frame 0)
                            Box(
                                modifier = Modifier
                                    .size(54.dp, 64.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Color.Transparent),
                                contentAlignment = Alignment.Center
                            ) {
                                AnimatedSpriteAvatar(
                                    drawableRes = avatar.idleDrawableRes,
                                    totalFrames = avatar.idleFrames,
                                    animationMode = AssistantAnimationMode.STANDING,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = avatar.name,
                                        color = DriyTextPrimary,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Surface(
                                        color = if (isSelected) DriyGold else DriySurface,
                                        shape = RoundedCornerShape(4.dp)
                                    ) {
                                        Text(
                                            text = avatar.badge,
                                            color = if (isSelected) DriyBackground else DriyTextSecondary,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                        )
                                    }
                                    if (avatar.hasVoiceAudio) {
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Surface(
                                            color = Color(0xFF673AB7).copy(alpha = 0.35f),
                                            shape = RoundedCornerShape(4.dp)
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.VolumeUp,
                                                    contentDescription = null,
                                                    tint = Color(0xFFD1C4E9),
                                                    modifier = Modifier.size(10.dp)
                                                )
                                                Spacer(modifier = Modifier.width(2.dp))
                                                Text(
                                                    text = "Voz Real",
                                                    color = Color(0xFFD1C4E9),
                                                    fontSize = 8.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                        }
                                    }
                                }
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = avatar.description,
                                    color = DriyTextSecondary,
                                    fontSize = 11.sp,
                                    lineHeight = 15.sp,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }

                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier
                                    .size(26.dp)
                                    .clip(CircleShape)
                                    .background(if (isSelected) DriyGold else Color.Transparent)
                                    .border(1.5.dp, if (isSelected) DriyGold else DriyTextSecondary, CircleShape)
                            ) {
                                if (isSelected) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = "Activo",
                                        tint = DriyBackground,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))
                HorizontalDivider(color = DriyDivider)
                Spacer(modifier = Modifier.height(14.dp))

                // Microphone & Voice Commands Section
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "ÓRDENES POR VOZ",
                            color = DriyGold,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "Solo responderá cuando digas \"${assistantState.customAvatarName}\"",
                            color = DriyTextSecondary,
                            fontSize = 12.sp
                        )
                    }

                    Surface(
                        color = if (assistantState.isListening) Color(0xFF4CAF50).copy(alpha = 0.2f) else DriySurfaceVariant,
                        shape = RoundedCornerShape(20.dp),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (assistantState.isListening) Color(0xFF4CAF50) else DriyDivider
                        ),
                        modifier = Modifier.clickable {
                            VirtualAssistantManager.toggleListening()
                        }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (assistantState.isListening) Icons.Default.Mic else Icons.Default.MicOff,
                                contentDescription = null,
                                tint = if (assistantState.isListening) Color(0xFF4CAF50) else DriyTextSecondary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (assistantState.isListening) "Escuchando" else "Micrófono Pausado",
                                color = if (assistantState.isListening) Color(0xFF4CAF50) else DriyTextSecondary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Direct Quick Chips to test song searches & orders immediately
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    CommandQuickChip(
                        icon = Icons.Default.Favorite,
                        label = "\"${assistantState.customAvatarName} te amo\"",
                        onClick = {
                            VirtualAssistantManager.processCommand("${assistantState.customAvatarName} te amo", isDirectChip = true)
                        }
                    )
                    CommandQuickChip(
                        icon = Icons.Default.Favorite,
                        label = "\"${assistantState.customAvatarName} te quiero\"",
                        onClick = {
                            VirtualAssistantManager.processCommand("${assistantState.customAvatarName} te quiero", isDirectChip = true)
                        }
                    )
                    CommandQuickChip(
                        icon = Icons.Default.Favorite,
                        label = "\"${assistantState.customAvatarName} dame un beso\"",
                        onClick = {
                            VirtualAssistantManager.processCommand("${assistantState.customAvatarName} dame un beso", isDirectChip = true)
                        }
                    )
                    CommandQuickChip(
                        icon = Icons.Default.PlayArrow,
                        label = "\"${assistantState.customAvatarName} reproduce musica\"",
                        onClick = {
                            VirtualAssistantManager.processCommand("${assistantState.customAvatarName} reproduce musica", isDirectChip = true)
                        }
                    )
                    CommandQuickChip(
                        icon = Icons.Default.Pause,
                        label = "\"${assistantState.customAvatarName} pon pausa\"",
                        onClick = {
                            VirtualAssistantManager.processCommand("${assistantState.customAvatarName} pon pausa", isDirectChip = true)
                        }
                    )
                    CommandQuickChip(
                        icon = Icons.Default.Pause,
                        label = "\"${assistantState.customAvatarName} pausala\"",
                        onClick = {
                            VirtualAssistantManager.processCommand("${assistantState.customAvatarName} pausala", isDirectChip = true)
                        }
                    )
                    CommandQuickChip(
                        icon = Icons.Default.Pause,
                        label = "\"${assistantState.customAvatarName} deten la musica\"",
                        onClick = {
                            VirtualAssistantManager.processCommand("${assistantState.customAvatarName} deten la musica", isDirectChip = true)
                        }
                    )
                    CommandQuickChip(
                        icon = Icons.Default.FastRewind,
                        label = "\"${assistantState.customAvatarName} retrocede\"",
                        onClick = {
                            VirtualAssistantManager.processCommand("${assistantState.customAvatarName} retrocede", isDirectChip = true)
                        }
                    )
                    CommandQuickChip(
                        icon = Icons.Default.FastRewind,
                        label = "\"${assistantState.customAvatarName} vuelve a la cancion anterior\"",
                        onClick = {
                            VirtualAssistantManager.processCommand("${assistantState.customAvatarName} vuelve a la cancion anterior", isDirectChip = true)
                        }
                    )
                    CommandQuickChip(
                        icon = Icons.Default.FastRewind,
                        label = "\"${assistantState.customAvatarName} regresa\"",
                        onClick = {
                            VirtualAssistantManager.processCommand("${assistantState.customAvatarName} regresa", isDirectChip = true)
                        }
                    )
                    CommandQuickChip(
                        icon = Icons.Default.FastForward,
                        label = "\"${assistantState.customAvatarName} avance\"",
                        onClick = {
                            VirtualAssistantManager.processCommand("${assistantState.customAvatarName} avance", isDirectChip = true)
                        }
                    )
                    CommandQuickChip(
                        icon = Icons.Default.VolumeUp,
                        label = "\"${assistantState.customAvatarName} suba volumen\"",
                        onClick = {
                            VirtualAssistantManager.processCommand("${assistantState.customAvatarName} suba volumen", isDirectChip = true)
                        }
                    )
                    CommandQuickChip(
                        icon = Icons.Default.VolumeUp,
                        label = "\"${assistantState.customAvatarName} baje el volumen\"",
                        onClick = {
                            VirtualAssistantManager.processCommand("${assistantState.customAvatarName} baje el volumen", isDirectChip = true)
                        }
                    )
                    CommandQuickChip(
                        icon = Icons.Default.GraphicEq,
                        label = "\"${assistantState.customAvatarName} ¿qué canción está sonando?\"",
                        onClick = {
                            VirtualAssistantManager.processCommand("${assistantState.customAvatarName} que cancion esta sonando", isDirectChip = true)
                        }
                    )
                    CommandQuickChip(
                        icon = Icons.Default.VolumeUp,
                        label = "\"${assistantState.customAvatarName} sube el volumen\"",
                        onClick = {
                            VirtualAssistantManager.processCommand("${assistantState.customAvatarName} sube el volumen", isDirectChip = true)
                        }
                    )
                    CommandQuickChip(
                        icon = Icons.Default.VolumeUp,
                        label = "\"${assistantState.customAvatarName} baja el volumen\"",
                        onClick = {
                            VirtualAssistantManager.processCommand("${assistantState.customAvatarName} baja el volumen", isDirectChip = true)
                        }
                    )
                    CommandQuickChip(
                        icon = Icons.Default.VolumeUp,
                        label = "\"${assistantState.customAvatarName} pon el volumen al 50%\"",
                        onClick = {
                            VirtualAssistantManager.processCommand("${assistantState.customAvatarName} pon el volumen al 50%", isDirectChip = true)
                        }
                    )
                    CommandQuickChip(
                        icon = Icons.Default.VolumeUp,
                        label = "\"${assistantState.customAvatarName} silencia el audio\"",
                        onClick = {
                            VirtualAssistantManager.processCommand("${assistantState.customAvatarName} silencia el audio", isDirectChip = true)
                        }
                    )
                    CommandQuickChip(
                        icon = Icons.Default.VolumeUp,
                        label = "\"${assistantState.customAvatarName} activa el sonido\"",
                        onClick = {
                            VirtualAssistantManager.processCommand("${assistantState.customAvatarName} activa el sonido", isDirectChip = true)
                        }
                    )
                    CommandQuickChip(
                        icon = Icons.Default.PlayArrow,
                        label = "\"${assistantState.customAvatarName} reproduce la canción Bohemian Rhapsody\"",
                        onClick = {
                            VirtualAssistantManager.processCommand("${assistantState.customAvatarName} reproduce la cancion Bohemian Rhapsody", isDirectChip = true)
                        }
                    )
                    CommandQuickChip(
                        icon = Icons.Default.PlayArrow,
                        label = "\"${assistantState.customAvatarName} pon la música Despacito\"",
                        onClick = {
                            VirtualAssistantManager.processCommand("${assistantState.customAvatarName} pon la musica Despacito", isDirectChip = true)
                        }
                    )
                    CommandQuickChip(
                        icon = Icons.Default.PlayArrow,
                        label = "\"${assistantState.customAvatarName} reproduce música de Shakira\"",
                        onClick = {
                            VirtualAssistantManager.processCommand("${assistantState.customAvatarName} reproduce musica de Shakira", isDirectChip = true)
                        }
                    )
                    CommandQuickChip(
                        icon = Icons.Default.PlayArrow,
                        label = "\"${assistantState.customAvatarName} pon canciones de Queen\"",
                        onClick = {
                            VirtualAssistantManager.processCommand("${assistantState.customAvatarName} pon canciones de Queen", isDirectChip = true)
                        }
                    )
                    CommandQuickChip(
                        icon = Icons.Default.GraphicEq,
                        label = "\"${assistantState.customAvatarName} pon una lista de reproducción de salsa\"",
                        onClick = {
                            VirtualAssistantManager.processCommand("${assistantState.customAvatarName} pon una lista de reproduccion de salsa", isDirectChip = true)
                        }
                    )
                    CommandQuickChip(
                        icon = Icons.Default.GraphicEq,
                        label = "\"${assistantState.customAvatarName} reproduce música para estudiar\"",
                        onClick = {
                            VirtualAssistantManager.processCommand("${assistantState.customAvatarName} reproduce musica para estudiar", isDirectChip = true)
                        }
                    )
                    CommandQuickChip(
                        icon = Icons.Default.GraphicEq,
                        label = "\"${assistantState.customAvatarName} reproduce música para entrenar\"",
                        onClick = {
                            VirtualAssistantManager.processCommand("${assistantState.customAvatarName} reproduce musica para entrenar", isDirectChip = true)
                        }
                    )
                    CommandQuickChip(
                        icon = Icons.Default.FastForward,
                        label = "\"${assistantState.customAvatarName} pasa a la siguiente canción\"",
                        onClick = {
                            VirtualAssistantManager.processCommand("${assistantState.customAvatarName} pasa a la siguiente cancion", isDirectChip = true)
                        }
                    )
                    CommandQuickChip(
                        icon = Icons.Default.FastRewind,
                        label = "\"${assistantState.customAvatarName} pon la canción anterior\"",
                        onClick = {
                            VirtualAssistantManager.processCommand("${assistantState.customAvatarName} pon la cancion anterior", isDirectChip = true)
                        }
                    )
                    CommandQuickChip(
                        icon = Icons.Default.Pause,
                        label = "\"${assistantState.customAvatarName} pausa la música\"",
                        onClick = {
                            VirtualAssistantManager.processCommand("${assistantState.customAvatarName} pausa la musica", isDirectChip = true)
                        }
                    )
                    CommandQuickChip(
                        icon = Icons.Default.PlayArrow,
                        label = "\"${assistantState.customAvatarName} reanuda la música\"",
                        onClick = {
                            VirtualAssistantManager.processCommand("${assistantState.customAvatarName} reanuda la musica", isDirectChip = true)
                        }
                    )
                    CommandQuickChip(
                        icon = Icons.Default.AutoAwesome,
                        label = "\"Dame tu bedi ${assistantState.customAvatarName}\"",
                        onClick = {
                            VirtualAssistantManager.processCommand("dame tu bedi ${assistantState.customAvatarName}", isDirectChip = true)
                        }
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Custom Command Input for testing
                OutlinedTextField(
                    value = textCommandInput,
                    onValueChange = { textCommandInput = it },
                    placeholder = {
                        Text("Ej: ${assistantState.customAvatarName} reproduce Your Love de The Outfield...", color = DriyTextSecondary, fontSize = 12.sp)
                    },
                    trailingIcon = {
                        if (textCommandInput.isNotBlank()) {
                            IconButton(onClick = {
                                VirtualAssistantManager.processCommand(textCommandInput, isDirectChip = true)
                                textCommandInput = ""
                            }) {
                                Icon(Icons.Default.PlayArrow, contentDescription = "Enviar", tint = DriyGold)
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = DriySurface,
                        unfocusedContainerColor = DriySurface,
                        focusedBorderColor = DriyGold,
                        unfocusedBorderColor = DriyDivider,
                        focusedTextColor = DriyTextPrimary,
                        unfocusedTextColor = DriyTextPrimary
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }

    // Rename Avatar Dialog
    if (showRenameDialog) {
        var newName by remember { mutableStateOf(assistantState.customAvatarName) }
        AlertDialog(
            onDismissRequest = { showRenameDialog = false },
            containerColor = DriySurface,
            title = {
                Text(
                    text = "Nombre de tu Asistente",
                    color = DriyTextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            },
            text = {
                Column {
                    Text(
                        text = "¿Cómo quieres llamar a tu avatar? (ejemplo: Jorge, Jorgito...)",
                        color = DriyTextSecondary,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = newName,
                        onValueChange = { newName = it },
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = DriyGold,
                            unfocusedBorderColor = DriyDivider,
                            focusedTextColor = DriyTextPrimary,
                            unfocusedTextColor = DriyTextPrimary
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        VirtualAssistantManager.setCustomAvatarName(newName)
                        showRenameDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DriyGold, contentColor = DriyBackground)
                ) {
                    Text("Guardar", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showRenameDialog = false }) {
                    Text("Cancelar", color = DriyTextSecondary)
                }
            }
        )
    }

    // How Avatar Calls You Dialog
    if (showCallingTitleDialog) {
        var newTitle by remember { mutableStateOf(assistantState.userCallingTitle) }
        AlertDialog(
            onDismissRequest = { showCallingTitleDialog = false },
            containerColor = DriySurface,
            title = {
                Text(
                    text = "¿Cómo quieres que te llame?",
                    color = DriyTextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            },
            text = {
                Column {
                    Text(
                        text = "Elige la forma en que ${assistantState.customAvatarName} te llamará en sus pensamientos (ejemplo: mi rey, jefe, patrón, hermano):",
                        color = DriyTextSecondary,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = newTitle,
                        onValueChange = { newTitle = it },
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = DriyGold,
                            unfocusedBorderColor = DriyDivider,
                            focusedTextColor = DriyTextPrimary,
                            unfocusedTextColor = DriyTextPrimary
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        VirtualAssistantManager.setUserCallingTitle(newTitle)
                        showCallingTitleDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DriyGold, contentColor = DriyBackground)
                ) {
                    Text("Guardar", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showCallingTitleDialog = false }) {
                    Text("Cancelar", color = DriyTextSecondary)
                }
            }
        )
    }
}

@Composable
private fun CommandQuickChip(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    onClick: () -> Unit
) {
    Surface(
        color = DriySurfaceVariant,
        shape = RoundedCornerShape(20.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, DriyGold.copy(alpha = 0.4f)),
        modifier = Modifier.clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = DriyGold,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = label,
                color = DriyTextPrimary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}
