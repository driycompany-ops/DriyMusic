package com.example.ui.theme

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import android.util.Log
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

data class AppThemeState(
    val accentColor: Color = Color(0xFFE6B800),         // Marcos, bordes, botones, highlights
    val textColor: Color = Color(0xFFEDEDED),           // Letras, títulos principales
    val textSecondaryColor: Color = Color(0xFFA0A0A0), // Letras secundarias
    val backgroundColor: Color = Color(0xFF121212),     // Color de fondo
    val surfaceColor: Color = Color(0xFF1E1E1E),        // Tarjetas y contenedores
    val backgroundPhotoUri: String? = null,             // Foto de fondo (null = color sólido)
    val backgroundDim: Float = 0.55f                    // Nivel de oscurecimiento (0.15 a 0.90)
)

object ThemeManager {
    private const val TAG = "ThemeManager"
    private const val KEY_ACCENT = "accent_color"
    private const val KEY_TEXT = "text_color"
    private const val KEY_BG_COLOR = "bg_color"
    private const val KEY_SURFACE_COLOR = "surface_color"
    private const val KEY_BG_PHOTO = "bg_photo_uri"
    private const val KEY_BG_DIM = "bg_dim"

    val DEFAULT_THEME = AppThemeState(
        accentColor = Color(0xFFE6B800),
        textColor = Color(0xFFEDEDED),
        textSecondaryColor = Color(0xFFA0A0A0),
        backgroundColor = Color(0xFF121212),
        surfaceColor = Color(0xFF1E1E1E),
        backgroundPhotoUri = null,
        backgroundDim = 0.55f
    )

    private var appContext: Context? = null
    private var activeUserId: String? = null
    private val _themeState = MutableStateFlow(DEFAULT_THEME)
    val themeState: StateFlow<AppThemeState> = _themeState.asStateFlow()

    private var onThemeChangedListener: ((AppThemeState, String) -> Unit)? = null

    fun setOnThemeChangedListener(listener: ((state: AppThemeState, json: String) -> Unit)?) {
        this.onThemeChangedListener = listener
    }

    /**
     * Initializes ThemeManager on app start.
     * If a user is actively logged in, their personalized theme is loaded.
     * If no user is logged in (guest / login screen), resets to DEFAULT_THEME.
     */
    fun init(context: Context) {
        appContext = context.applicationContext
        val authPrefs = context.getSharedPreferences("driystream_auth_prefs", Context.MODE_PRIVATE)
        val isLoggedIn = authPrefs.getBoolean("is_logged_in", false)
        val currentUserId = authPrefs.getString("active_user_id", null)

        if (isLoggedIn && !currentUserId.isNullOrBlank()) {
            loadUserTheme(currentUserId)
        } else {
            resetToDefaults()
        }
    }

    /**
     * Loads and activates the appearance personalized for a specific logged-in user.
     */
    fun loadUserTheme(userId: String?, configJson: String? = null) {
        if (userId.isNullOrBlank()) {
            resetToDefaults()
            return
        }

        activeUserId = userId
        val cleanId = userId.trim().removePrefix("@").lowercase()

        // 1. If explicit JSON config is provided (e.g., from UserEntity or Firestore)
        if (!configJson.isNullOrBlank()) {
            val state = deserializeTheme(configJson)
            _themeState.value = state
            saveToUserPrefs(cleanId, state)
            return
        }

        // 2. Otherwise try loading from per-user SharedPreferences
        val sp = getUserPrefs(cleanId)
        if (sp != null && sp.contains(KEY_ACCENT)) {
            val state = readStateFromPrefs(sp)
            _themeState.value = state
        } else {
            _themeState.value = DEFAULT_THEME
        }
    }

    /**
     * Resets the active appearance back to the default Driy theme.
     * Clears user session association so changes never bleed into Login or other accounts.
     */
    fun resetToDefaults() {
        val wasLoggedIn = activeUserId != null
        activeUserId = null
        _themeState.value = DEFAULT_THEME

        // If explicitly reset while in profile dialog, notify persistence
        if (wasLoggedIn) {
            onThemeChangedListener?.invoke(DEFAULT_THEME, "")
        }
    }

    fun setAccentColor(color: Color) {
        val current = _themeState.value
        val updated = current.copy(accentColor = color)
        applyAndPersist(updated)
    }

    fun setTextColor(color: Color) {
        val current = _themeState.value
        val updated = current.copy(
            textColor = color,
            textSecondaryColor = color.copy(alpha = 0.7f)
        )
        applyAndPersist(updated)
    }

    fun setBackgroundColor(color: Color) {
        val current = _themeState.value
        val surfaceDerived = deriveSurfaceColor(color)
        val updated = current.copy(
            backgroundColor = color,
            surfaceColor = surfaceDerived
        )
        applyAndPersist(updated)
    }

    fun setBackgroundPhoto(context: Context, uri: Uri?) {
        if (uri == null) {
            clearBackgroundPhoto()
            return
        }
        val targetUser = activeUserId?.trim()?.removePrefix("@")?.lowercase() ?: "active"
        try {
            val internalFile = File(context.filesDir, "custom_bg_wallpaper_$targetUser.jpg")
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(internalFile).use { output ->
                    input.copyTo(output)
                }
            }
            val localPath = internalFile.absolutePath
            val current = _themeState.value
            val updated = current.copy(backgroundPhotoUri = localPath)
            applyAndPersist(updated)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to copy background wallpaper: ${e.message}", e)
            val uriStr = uri.toString()
            val current = _themeState.value
            val updated = current.copy(backgroundPhotoUri = uriStr)
            applyAndPersist(updated)
        }
    }

    fun setPresetBackgroundPhoto(url: String) {
        val current = _themeState.value
        val updated = current.copy(backgroundPhotoUri = url)
        applyAndPersist(updated)
    }

    fun clearBackgroundPhoto() {
        val current = _themeState.value
        val updated = current.copy(backgroundPhotoUri = null)
        applyAndPersist(updated)
    }

    fun setBackgroundDim(dim: Float) {
        val clamped = dim.coerceIn(0.15f, 0.90f)
        val current = _themeState.value
        val updated = current.copy(backgroundDim = clamped)
        applyAndPersist(updated)
    }

    fun applyPreset(
        accent: Color,
        text: Color,
        bg: Color,
        photo: String? = null,
        dim: Float = 0.55f
    ) {
        val surface = deriveSurfaceColor(bg)
        val updated = AppThemeState(
            accentColor = accent,
            textColor = text,
            textSecondaryColor = text.copy(alpha = 0.7f),
            backgroundColor = bg,
            surfaceColor = surface,
            backgroundPhotoUri = photo,
            backgroundDim = dim
        )
        applyAndPersist(updated)
    }

    private fun applyAndPersist(state: AppThemeState) {
        _themeState.value = state
        val uid = activeUserId?.trim()?.removePrefix("@")?.lowercase()
        if (!uid.isNullOrBlank()) {
            saveToUserPrefs(uid, state)
            val serialized = serializeTheme(state)
            onThemeChangedListener?.invoke(state, serialized)
        }
    }

    private fun getUserPrefs(userId: String): SharedPreferences? {
        val ctx = appContext ?: return null
        return ctx.getSharedPreferences("driystream_theme_user_$userId", Context.MODE_PRIVATE)
    }

    private fun saveToUserPrefs(userId: String, state: AppThemeState) {
        val sp = getUserPrefs(userId) ?: return
        sp.edit()
            .putString(KEY_ACCENT, colorToHex(state.accentColor))
            .putString(KEY_TEXT, colorToHex(state.textColor))
            .putString(KEY_BG_COLOR, colorToHex(state.backgroundColor))
            .putString(KEY_SURFACE_COLOR, colorToHex(state.surfaceColor))
            .apply {
                if (state.backgroundPhotoUri != null) {
                    putString(KEY_BG_PHOTO, state.backgroundPhotoUri)
                } else {
                    remove(KEY_BG_PHOTO)
                }
                putFloat(KEY_BG_DIM, state.backgroundDim)
            }
            .apply()
    }

    private fun readStateFromPrefs(sp: SharedPreferences): AppThemeState {
        val accent = sp.getString(KEY_ACCENT, null)?.let { parseColorHex(it) } ?: DEFAULT_THEME.accentColor
        val text = sp.getString(KEY_TEXT, null)?.let { parseColorHex(it) } ?: DEFAULT_THEME.textColor
        val bg = sp.getString(KEY_BG_COLOR, null)?.let { parseColorHex(it) } ?: DEFAULT_THEME.backgroundColor
        val surface = sp.getString(KEY_SURFACE_COLOR, null)?.let { parseColorHex(it) } ?: deriveSurfaceColor(bg)
        val photo = sp.getString(KEY_BG_PHOTO, null)
        val dim = sp.getFloat(KEY_BG_DIM, 0.55f)

        return AppThemeState(
            accentColor = accent,
            textColor = text,
            textSecondaryColor = text.copy(alpha = 0.7f),
            backgroundColor = bg,
            surfaceColor = surface,
            backgroundPhotoUri = photo,
            backgroundDim = dim
        )
    }

    fun serializeTheme(state: AppThemeState): String {
        return try {
            val json = JSONObject()
            json.put("accent", colorToHex(state.accentColor))
            json.put("text", colorToHex(state.textColor))
            json.put("bg", colorToHex(state.backgroundColor))
            json.put("surface", colorToHex(state.surfaceColor))
            json.put("photo", state.backgroundPhotoUri ?: "")
            json.put("dim", state.backgroundDim.toDouble())
            json.toString()
        } catch (e: Exception) {
            ""
        }
    }

    fun deserializeTheme(jsonStr: String): AppThemeState {
        if (jsonStr.isBlank()) return DEFAULT_THEME
        return try {
            val json = JSONObject(jsonStr)
            val accent = json.optString("accent").takeIf { it.isNotBlank() }?.let { parseColorHex(it) } ?: DEFAULT_THEME.accentColor
            val text = json.optString("text").takeIf { it.isNotBlank() }?.let { parseColorHex(it) } ?: DEFAULT_THEME.textColor
            val bg = json.optString("bg").takeIf { it.isNotBlank() }?.let { parseColorHex(it) } ?: DEFAULT_THEME.backgroundColor
            val surface = json.optString("surface").takeIf { it.isNotBlank() }?.let { parseColorHex(it) } ?: deriveSurfaceColor(bg)
            val photo = json.optString("photo").takeIf { it.isNotBlank() }
            val dim = json.optDouble("dim", 0.55).toFloat()

            AppThemeState(
                accentColor = accent,
                textColor = text,
                textSecondaryColor = text.copy(alpha = 0.7f),
                backgroundColor = bg,
                surfaceColor = surface,
                backgroundPhotoUri = photo,
                backgroundDim = dim
            )
        } catch (e: Exception) {
            Log.w(TAG, "Failed to parse theme JSON: ${e.message}")
            DEFAULT_THEME
        }
    }

    private fun deriveSurfaceColor(bg: Color): Color {
        return if (bg == Color.Black) {
            Color(0xFF181818)
        } else {
            Color(
                red = (bg.red + 0.08f).coerceAtMost(0.24f),
                green = (bg.green + 0.08f).coerceAtMost(0.24f),
                blue = (bg.blue + 0.08f).coerceAtMost(0.24f),
                alpha = 1.0f
            )
        }
    }

    fun colorToHex(color: Color): String {
        val argb = color.toArgb()
        return String.format("#%08X", argb)
    }

    fun parseColorHex(hex: String): Color? {
        return try {
            Color(android.graphics.Color.parseColor(hex))
        } catch (e: Exception) {
            null
        }
    }
}
