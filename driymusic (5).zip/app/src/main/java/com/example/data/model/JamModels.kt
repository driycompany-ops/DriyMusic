package com.example.data.model

import android.graphics.Bitmap

data class JamParticipant(
    val id: String,
    val name: String,
    val avatarUrl: String? = null,
    val isHost: Boolean = false,
    val joinedAt: Long = System.currentTimeMillis()
)

data class JamSession(
    val code: String,
    val hostId: String,
    val hostName: String,
    val currentSongId: String? = null,
    val currentSongTitle: String? = null,
    val currentSongArtist: String? = null,
    val currentSongCover: String? = null,
    val participants: List<JamParticipant> = emptyList(),
    val isPlaying: Boolean = true,
    val positionMs: Long = 0L,
    val createdAt: Long = System.currentTimeMillis()
)

sealed interface JamSessionState {
    object Idle : JamSessionState
    data class Hosting(
        val session: JamSession,
        val qrBitmap: Bitmap?
    ) : JamSessionState
    data class Joined(
        val session: JamSession
    ) : JamSessionState
}
