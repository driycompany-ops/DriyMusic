package com.example.data.model

enum class AssistantAnimationMode {
    STANDING,        // De pie por defecto
    SITTING_DOWN,    // Jorge: trayendo silla y sentándose / Jungkook: acostándose
    SEATED,          // Jorge: sentado en silla / Jungkook: durmiendo plácidamente con Zzz
    CHANGING_MUSIC,  // Animación cambiando música con el teléfono
    BLESSING,        // Jorge: sacando la carta de bendición
    LOVE             // Jungkook: Saludo corazón, corazones con las manos y beso
}

data class AssistantAvatar(
    val id: String,
    val name: String,
    val defaultCallingTitle: String,
    val description: String,
    val badge: String,
    val idleDrawableRes: Int,
    val changingMusicDrawableRes: Int,
    val blessingDrawableRes: Int,
    val sleepingDrawableRes: Int = idleDrawableRes,
    val loveDrawableRes: Int = blessingDrawableRes,
    val idleFrames: Int = 6,
    val changingMusicFrames: Int = 6,
    val sleepingFrames: Int = 4,
    val loveFrames: Int = 5,
    val totalFrames: Int = 6,
    val hasVoiceAudio: Boolean = false,
    val changeSongAudioRes: Int? = null,
    val loveAudioRes: Int? = null,
    val greetingAudioRes: Int? = null,
    val resumeSongAudioRes: Int? = null,
    val pauseSongAudioRes: Int? = null,
    val previousSongAudioRes: Int? = null,
    val muteAudioRes: Int? = null,
    val volume50AudioRes: Int? = null,
    val volumeDownAudioRes: Int? = null,
    val volumeUpAudioRes: Int? = null,
    val currentSongAudioRes: Int? = null
)

data class VirtualAssistantState(
    val isEnabled: Boolean = false,
    val selectedAvatarId: String = "jorge_luna",
    val customAvatarName: String = "Jorge",
    val userCallingTitle: String = "mi rey",
    val isListening: Boolean = false,
    val currentAnimationMode: AssistantAnimationMode = AssistantAnimationMode.STANDING,
    val thoughtText: String? = null,
    val thoughtTimestamp: Long = 0L,
    val lastHeardCommand: String? = null,
    val lastInteractionTimeMs: Long = System.currentTimeMillis()
)
