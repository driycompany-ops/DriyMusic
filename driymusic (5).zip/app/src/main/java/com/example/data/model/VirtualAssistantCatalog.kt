package com.example.data.model

import com.example.R

object VirtualAssistantCatalog {
    val avatars = listOf(
        AssistantAvatar(
            id = "zoe",
            name = "Zoe",
            defaultCallingTitle = "amor",
            description = "Chica anime mística y dulce. Espera atenta parada, saca su celular para controlar tu música, envía besos con corazones y medita hasta dormirse 🌸",
            badge = "Anime ✨",
            idleDrawableRes = R.drawable.zoe_standing,
            changingMusicDrawableRes = R.drawable.zoe_changing_music,
            blessingDrawableRes = R.drawable.zoe_love,
            sleepingDrawableRes = R.drawable.zoe_sleeping,
            loveDrawableRes = R.drawable.zoe_love,
            idleFrames = 3,
            changingMusicFrames = 5,
            sleepingFrames = 4,
            loveFrames = 5,
            totalFrames = 3,
            hasVoiceAudio = false
        ),
        AssistantAvatar(
            id = "jorge_luna",
            name = "Jorge Luna",
            defaultCallingTitle = "mi rey",
            description = "Comediante, rey de la improvisación. Te acompaña parado, se sienta tras 1 min, da su bendición y cambia música en silencio 💭.",
            badge = "Estrella",
            idleDrawableRes = R.drawable.jorge_luna_sentandoce,
            changingMusicDrawableRes = R.drawable.cambiando_la_musica,
            blessingDrawableRes = R.drawable.carta_jorge,
            sleepingDrawableRes = R.drawable.jorge_luna_sentandoce,
            loveDrawableRes = R.drawable.carta_jorge,
            idleFrames = 6,
            changingMusicFrames = 6,
            sleepingFrames = 6,
            loveFrames = 6,
            totalFrames = 6,
            hasVoiceAudio = false
        ),
        AssistantAvatar(
            id = "jungkook",
            name = "Jungkook",
            defaultCallingTitle = "ARMY",
            description = "Golden Maknae de BTS • Habla en coreano con voz oficial, cambia tu música, duerme y responde con amor y corazones 💜",
            badge = "BTS K-POP ⭐",
            idleDrawableRes = R.drawable.jungkook_standing,
            changingMusicDrawableRes = R.drawable.jungkook_changing_music,
            blessingDrawableRes = R.drawable.jungkook_love,
            sleepingDrawableRes = R.drawable.jungkook_sleeping,
            loveDrawableRes = R.drawable.jungkook_love,
            idleFrames = 4,
            changingMusicFrames = 6,
            sleepingFrames = 4,
            loveFrames = 5,
            totalFrames = 4,
            hasVoiceAudio = true,
            changeSongAudioRes = R.raw.jk_cambiando_cancion,
            loveAudioRes = R.raw.jk_tambien_te_amo,
            greetingAudioRes = R.raw.jk_saludo,
            resumeSongAudioRes = R.raw.jk_renaudando_musica,
            pauseSongAudioRes = R.raw.jk_pausando_musica,
            previousSongAudioRes = R.raw.jk_cancion_anterior,
            muteAudioRes = R.raw.jk_silenciando_audio,
            volume50AudioRes = R.raw.jk_musica_al_50,
            volumeDownAudioRes = R.raw.jk_bajando_volumen,
            volumeUpAudioRes = R.raw.jk_subiendo_volumen,
            currentSongAudioRes = R.raw.jk_esta_sonando
        ),
        AssistantAvatar(
            id = "dj_neon",
            name = "DJ Neón",
            defaultCallingTitle = "patrón",
            description = "Maestro de los beats urbanos y mezclas nocturnas. Atento a cada cambio de ritmo.",
            badge = "Electrónico",
            idleDrawableRes = R.drawable.jorge_luna_sentandoce,
            changingMusicDrawableRes = R.drawable.cambiando_la_musica,
            blessingDrawableRes = R.drawable.carta_jorge,
            sleepingDrawableRes = R.drawable.jorge_luna_sentandoce,
            loveDrawableRes = R.drawable.carta_jorge,
            idleFrames = 6,
            changingMusicFrames = 6,
            sleepingFrames = 6,
            loveFrames = 6,
            totalFrames = 6,
            hasVoiceAudio = false
        ),
        AssistantAvatar(
            id = "maestro_ritmo",
            name = "Maestro Ritmo",
            defaultCallingTitle = "jefe",
            description = "Especialista en playlists legendarias y vibras musicales para todo momento.",
            badge = "Clásico",
            idleDrawableRes = R.drawable.jorge_luna_sentandoce,
            changingMusicDrawableRes = R.drawable.cambiando_la_musica,
            blessingDrawableRes = R.drawable.carta_jorge,
            sleepingDrawableRes = R.drawable.jorge_luna_sentandoce,
            loveDrawableRes = R.drawable.carta_jorge,
            idleFrames = 6,
            changingMusicFrames = 6,
            sleepingFrames = 6,
            loveFrames = 6,
            totalFrames = 6,
            hasVoiceAudio = false
        )
    )

    fun getById(id: String): AssistantAvatar {
        return avatars.firstOrNull { it.id == id } ?: avatars.first()
    }
}
