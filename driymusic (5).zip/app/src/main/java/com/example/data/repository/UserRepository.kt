package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.example.data.db.DriyDatabase
import com.example.data.model.UserEntity
import com.example.service.FirebaseUserManager
import com.example.util.PasswordHasher
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

class UserRepository(private val context: Context) {
    private val database = DriyDatabase.getInstance(context)
    private val userDao = database.userDao()
    private val firebaseUserManager = FirebaseUserManager(context)
    private val prefs: SharedPreferences = context.getSharedPreferences("driystream_auth_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_ACTIVE_USER_ID = "active_user_id"
        private const val KEY_IS_LOGGED_IN = "is_logged_in"
        private const val KEY_IS_ONBOARDED = "is_onboarded"
        private const val DEFAULT_ADMIN_PASSWORD_HASH = "pbkdf_v1\$a1b2c3d4e5f60718293a4b5c6d7e8f90\$87fd463b07fec89dd44742ef274b9974c4dbe2f1d3cf86e81c6a60d21db0dd4a"
    }

    private val _activeUserId = MutableStateFlow<String?>(
        if (prefs.getBoolean(KEY_IS_LOGGED_IN, false)) prefs.getString(KEY_ACTIVE_USER_ID, null) else null
    )
    val activeUserId = _activeUserId.asStateFlow()

    @OptIn(ExperimentalCoroutinesApi::class)
    val activeUserFlow: Flow<UserEntity?> = _activeUserId.flatMapLatest { userId ->
        if (userId.isNullOrBlank() || !isUserLoggedIn()) {
            flowOf(null)
        } else {
            userDao.getUserByIdFlow(userId)
        }
    }

    fun setActiveUserId(userId: String?) {
        _activeUserId.value = userId
        if (userId != null) {
            prefs.edit()
                .putString(KEY_ACTIVE_USER_ID, userId)
                .putBoolean(KEY_IS_LOGGED_IN, true)
                .apply()
        } else {
            prefs.edit()
                .remove(KEY_ACTIVE_USER_ID)
                .putBoolean(KEY_IS_LOGGED_IN, false)
                .apply()
        }
    }

    suspend fun getActiveUser(): UserEntity? = withContext(Dispatchers.IO) {
        if (!isUserLoggedIn()) return@withContext null
        val currentUserId = _activeUserId.value ?: prefs.getString(KEY_ACTIVE_USER_ID, null)
        if (currentUserId != null) {
            userDao.getUserById(currentUserId)
                ?: userDao.getUserByUsername(currentUserId)
        } else {
            null
        }
    }

    suspend fun getAllUsers(): List<UserEntity> = withContext(Dispatchers.IO) {
        userDao.getAllRegisteredUsers()
    }

    fun isUserLoggedIn(): Boolean {
        return prefs.getBoolean(KEY_IS_LOGGED_IN, false)
    }

    fun isOnboardingCompleted(): Boolean {
        return prefs.getBoolean(KEY_IS_ONBOARDED, false)
    }

    fun setOnboardingCompleted(completed: Boolean) {
        prefs.edit().putBoolean(KEY_IS_ONBOARDED, completed).apply()
    }

    suspend fun isUsernameTaken(username: String): Boolean = withContext(Dispatchers.IO) {
        firebaseUserManager.isUsernameTaken(username)
    }

    suspend fun isPhoneRegistered(phoneNumber: String): Boolean = withContext(Dispatchers.IO) {
        firebaseUserManager.findExistingAccount("", phoneNumber) != null
    }

    fun getLastCloudError(): String? = firebaseUserManager.lastCloudError

    suspend fun findExistingAccount(username: String, phoneNumber: String): UserEntity? = withContext(Dispatchers.IO) {
        firebaseUserManager.findExistingAccount(username, phoneNumber)
    }

    suspend fun findUserForRecovery(firstName: String, lastName: String, phoneNumber: String): UserEntity? = withContext(Dispatchers.IO) {
        firebaseUserManager.findUserForRecovery(firstName, lastName, phoneNumber)
    }

    suspend fun resetUserPassword(userIdOrUsername: String, newPassword: String): Boolean = withContext(Dispatchers.IO) {
        firebaseUserManager.resetUserPassword(userIdOrUsername, newPassword)
    }

    suspend fun registerUserWithPhone(
        firstName: String,
        lastName: String,
        username: String,
        password: String,
        phoneNumber: String
    ): UserEntity = withContext(Dispatchers.IO) {
        val user = firebaseUserManager.registerUser(
            firstName = firstName,
            lastName = lastName,
            username = username,
            password = password,
            phoneNumber = phoneNumber
        )
        setActiveUserId(user.id)
        user
    }

    suspend fun loginWithUserAndPhone(
        username: String,
        password: String,
        phoneNumber: String
    ): Result<UserEntity> = withContext(Dispatchers.IO) {
        val result = firebaseUserManager.loginUser(
            username = username,
            password = password,
            phoneNumber = phoneNumber
        )
        result.onSuccess { user ->
            setActiveUserId(user.id)
        }
        result
    }

    suspend fun saveSelectedGenres(userId: String, genres: List<String>) = withContext(Dispatchers.IO) {
        userDao.updateFavoriteGenres(userId, genres)
        try {
            FirebaseFirestore.getInstance().collection("driystream_users")
                .document(userId)
                .update("favoriteGenres", genres)
                .await()
        } catch (e: Exception) {
            // offline fallback
        }
    }

    suspend fun completeOnboarding(userId: String, artists: List<String>) = withContext(Dispatchers.IO) {
        setOnboardingCompleted(true)
        userDao.updateFavoriteArtistsAndOnboarding(userId, artists, isOnboarded = true)
        try {
            FirebaseFirestore.getInstance().collection("driystream_users")
                .document(userId)
                .update(mapOf("favoriteArtists" to artists, "isOnboarded" to true))
                .await()
        } catch (e: Exception) {
            // offline fallback
        }
    }

    suspend fun updateDisplayName(userId: String, displayName: String) = withContext(Dispatchers.IO) {
        userDao.updateDisplayName(userId, displayName)
        try {
            FirebaseFirestore.getInstance().collection("driystream_users")
                .document(userId)
                .update("displayName", displayName)
                .await()
        } catch (e: Exception) {
            // offline fallback
        }
    }

    suspend fun updatePhotoUrl(userId: String, photoUrl: String, cloudPhotoUrl: String = photoUrl) = withContext(Dispatchers.IO) {
        userDao.updatePhotoUrl(userId, photoUrl)
        try {
            val firestore = FirebaseFirestore.getInstance()
            val map = mapOf("photoUrl" to cloudPhotoUrl)
            firestore.collection("driystream_users")
                .document(userId)
                .set(map, com.google.firebase.firestore.SetOptions.merge())
                .await()
            val clean = userId.trim().removePrefix("@").lowercase()
            if (clean != userId) {
                firestore.collection("driystream_users")
                    .document(clean)
                    .set(map, com.google.firebase.firestore.SetOptions.merge())
                    .await()
            }
        } catch (e: Exception) {
            // offline fallback
        }
    }

    suspend fun updateThemeConfig(userId: String, themeConfig: String) = withContext(Dispatchers.IO) {
        userDao.updateThemeConfig(userId, themeConfig)
        try {
            val firestore = FirebaseFirestore.getInstance()
            val map = mapOf("themeConfig" to themeConfig)
            firestore.collection("driystream_users")
                .document(userId)
                .set(map, com.google.firebase.firestore.SetOptions.merge())
                .await()
            val clean = userId.trim().removePrefix("@").lowercase()
            if (clean != userId) {
                firestore.collection("driystream_users")
                    .document(clean)
                    .set(map, com.google.firebase.firestore.SetOptions.merge())
                    .await()
            }
        } catch (e: Exception) {
            // offline fallback
        }
    }

    suspend fun updateSubscriptionExpiresAt(userId: String, expiresAt: Long) = withContext(Dispatchers.IO) {
        userDao.updateSubscriptionExpiresAt(userId, expiresAt)
        try {
            FirebaseFirestore.getInstance().collection("driystream_users")
                .document(userId)
                .update("subscriptionExpiresAt", expiresAt)
                .await()
        } catch (e: Exception) {
            // offline fallback
        }
    }

    suspend fun ensureAdminAccountSeeded() = withContext(Dispatchers.IO) {
        try {
            val existingLocal = userDao.getUserById("driyadmincompany")
            if (existingLocal != null && existingLocal.passwordHash.isNotBlank()) {
                return@withContext
            }

            val tenYearsMillis = 3650L * 24 * 3600 * 1000
            val adminExpiresAt = System.currentTimeMillis() + tenYearsMillis

            var initialHash = DEFAULT_ADMIN_PASSWORD_HASH
            try {
                val firestore = FirebaseFirestore.getInstance()
                val cloudDoc = firestore.collection("driystream_users").document("driyadmincompany").get().await()
                if (cloudDoc.exists()) {
                    val cloudHash = cloudDoc.getString("passwordHash")
                    if (!cloudHash.isNullOrBlank()) {
                        initialHash = cloudHash
                    }
                }
            } catch (_: Exception) {
                // offline fallback
            }

            val adminEntity = UserEntity(
                id = "driyadmincompany",
                displayName = "driy company",
                email = "driycompany@gmail.com",
                photoUrl = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400&q=80",
                favoriteGenres = listOf("Reggaetón", "Pop", "Rock", "Cumbia"),
                favoriteArtists = emptyList(),
                isOnboarded = true,
                createdAt = 1700000000000L,
                firstName = "driy",
                lastName = "company",
                username = "DriyAdmincompany",
                passwordHash = initialHash,
                phoneNumber = "928598496",
                subscriptionExpiresAt = adminExpiresAt
            )

            // Persist adminEntity in Room DB so local flows immediately resolve it
            userDao.insertUser(adminEntity)

            try {
                val adminMap = hashMapOf<String, Any>(
                    "id" to "driyadmincompany",
                    "username" to "DriyAdmincompany",
                    "firstName" to "driy",
                    "lastName" to "company",
                    "displayName" to "driy company",
                    "email" to "driycompany@gmail.com",
                    "phoneNumber" to "928598496",
                    "passwordHash" to adminEntity.passwordHash,
                    "isOnboarded" to true,
                    "createdAt" to adminEntity.createdAt,
                    "subscriptionExpiresAt" to adminExpiresAt
                )
                val firestore = FirebaseFirestore.getInstance()
                firestore.collection("driystream_users").document("driyadmincompany").set(adminMap).await()
                firestore.collection("driystream_users").document("DriyAdmincompany").set(adminMap).await()
            } catch (_: Exception) {
                // offline fallback
            }
        } catch (_: Exception) {
            // ignore
        }
    }

    suspend fun signInWithGoogle(
        googleId: String = "google_user_1029",
        name: String = "Usuario",
        email: String = "usuario@driystream.com",
        photoUrl: String = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400&q=80"
    ): UserEntity = withContext(Dispatchers.IO) {
        val existing = userDao.getUserById(googleId)
        val tenYearsMillis = 3650L * 24 * 3600 * 1000
        val isAdminEmail = email.equals("driycompany@gmail.com", ignoreCase = true) ||
                           email.equals("juaneduramirezhu@gmail.com", ignoreCase = true) ||
                           email.contains("admin", ignoreCase = true)
        val user = existing?.copy(
            subscriptionExpiresAt = if (isAdminEmail) maxOf(existing.subscriptionExpiresAt, System.currentTimeMillis() + tenYearsMillis) else existing.subscriptionExpiresAt
        ) ?: UserEntity(
            id = googleId,
            displayName = if (isAdminEmail && (name.isBlank() || name == "Usuario")) "driy company" else name,
            email = email,
            photoUrl = photoUrl,
            username = if (isAdminEmail) "driycompany" else email.substringBefore("@"),
            createdAt = System.currentTimeMillis(),
            firstName = if (isAdminEmail) "driy" else "",
            lastName = if (isAdminEmail) "company" else "",
            phoneNumber = if (isAdminEmail) "928598496" else "",
            subscriptionExpiresAt = if (isAdminEmail) System.currentTimeMillis() + tenYearsMillis else 0L
        )
        userDao.insertUser(user)
        setActiveUserId(user.id)
        user
    }

    suspend fun signOut() = withContext(Dispatchers.IO) {
        setActiveUserId(null)
        prefs.edit().clear().apply()
    }

    suspend fun deleteUser(userId: String?) = withContext(Dispatchers.IO) {
        setActiveUserId(null)
        prefs.edit().clear().apply()
        if (!userId.isNullOrBlank()) {
            userDao.deleteUserById(userId)
        }
        userDao.clearAllUsers()
    }
}
