package com.example.data.model

data class LyricLine(
    val timeMs: Long,
    val text: String
)

data class LyricsData(
    val trackName: String = "",
    val artistName: String = "",
    val albumName: String = "",
    val durationSeconds: Int = 0,
    val syncedLyrics: List<LyricLine> = emptyList(),
    val plainLyrics: String? = null,
    val isInstrumental: Boolean = false,
    val hasSync: Boolean = false
)

data class LyricsUiState(
    val isLoading: Boolean = false,
    val songId: String? = null,
    val lyricsData: LyricsData? = null,
    val error: String? = null,
    val syncOffsetMs: Long = 0L
)
