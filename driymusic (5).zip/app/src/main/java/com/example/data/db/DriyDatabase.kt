package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.example.data.model.ActivationCodeEntity
import com.example.data.model.Converters
import com.example.data.model.FolderEntity
import com.example.data.model.FolderSongCrossRef
import com.example.data.model.SongEntity
import com.example.data.model.UploadedSongEntity
import com.example.data.model.UserEntity

@Database(
    entities = [UserEntity::class, SongEntity::class, FolderEntity::class, FolderSongCrossRef::class, UploadedSongEntity::class, ActivationCodeEntity::class],
    version = 8,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class DriyDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun songDao(): SongDao
    abstract fun folderDao(): FolderDao
    abstract fun uploadedSongDao(): UploadedSongDao
    abstract fun activationCodeDao(): ActivationCodeDao

    companion object {
        @Volatile
        private var INSTANCE: DriyDatabase? = null

        fun getInstance(context: Context): DriyDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    DriyDatabase::class.java,
                    "driystream_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
