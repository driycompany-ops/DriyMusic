package com.example.data.repository

import android.app.DownloadManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.media.MediaMetadataRetriever
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.util.Log
import androidx.core.content.FileProvider
import com.example.data.db.DriyDatabase
import com.example.data.model.Artist
import com.example.data.model.FolderEntity
import com.example.data.model.FolderSongCrossRef
import com.example.data.model.Genre
import com.example.data.model.SongEntity
import com.example.data.model.UploadedSongEntity
import com.example.data.seed.CatalogSeed
import com.example.service.UserCloudSyncManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.UUID
import javax.crypto.Cipher
import javax.crypto.spec.SecretKeySpec
import org.json.JSONObject

class MusicRepository(private val context: Context) {
    private val database = DriyDatabase.getInstance(context)
    private val songDao = database.songDao()
    private val folderDao = database.folderDao()
    private val uploadedSongDao = database.uploadedSongDao()

    suspend fun ensureCatalogSeeded() = withContext(Dispatchers.IO) {
        songDao.insertSongs(CatalogSeed.defaultSongs)
        val favFolder = folderDao.getFolderById("favorites")
        if (favFolder == null) {
            folderDao.insertFolder(
                FolderEntity(
                    id = "favorites",
                    name = "Favoritos",
                    isDefault = true
                )
            )
        }
        val favoriteSongsList = songDao.getFavoriteSongs().firstOrNull() ?: emptyList()
        favoriteSongsList.forEach { s ->
            folderDao.addSongToFolder(FolderSongCrossRef("favorites", s.id))
        }

        // Automatic scan & restoration of pre-existing offline songs from DriyStream folder
        val restored = scanAndRestoreDownloadedSongs()
        if (restored > 0) {
            Log.d("MusicRepository", "Seeded catalog and restored $restored downloaded songs from DriyStream")
        }
    }

    fun getAllSongs(): Flow<List<SongEntity>> = songDao.getAllSongs()

    suspend fun insertSong(song: SongEntity) = withContext(Dispatchers.IO) {
        songDao.insertSongs(listOf(song))
    }

    suspend fun insertSongs(songs: List<SongEntity>) = withContext(Dispatchers.IO) {
        songDao.insertSongs(songs)
    }

    fun getFavoriteSongs(): Flow<List<SongEntity>> = songDao.getFavoriteSongs()
    fun getDownloadedSongs(): Flow<List<SongEntity>> = songDao.getDownloadedSongs()
    fun getRecentlyPlayedSongs(): Flow<List<SongEntity>> = songDao.getRecentlyPlayedSongs()
    fun getMostSearchedSongs(): Flow<List<SongEntity>> = songDao.getMostSearchedSongs()
    fun getSongsByGenre(genre: String): Flow<List<SongEntity>> = songDao.getSongsByGenre(genre)

    fun getRecommendedSongs(artists: List<String>): Flow<List<SongEntity>> {
        return if (artists.isEmpty()) {
            songDao.getAllSongs()
        } else {
            songDao.getSongsByArtists(artists)
        }
    }

    fun searchSongs(query: String): Flow<List<SongEntity>> = songDao.searchSongs(query)

    suspend fun getSongById(id: String): SongEntity? = withContext(Dispatchers.IO) {
        songDao.getSongById(id)
    }

    suspend fun toggleFavorite(songId: String, currentStatus: Boolean) = withContext(Dispatchers.IO) {
        val newStatus = !currentStatus
        songDao.updateFavorite(songId, newStatus)
        if (newStatus) {
            folderDao.addSongToFolder(FolderSongCrossRef("favorites", songId))
        } else {
            folderDao.removeSongFromFolder("favorites", songId)
        }
        UserCloudSyncManager.syncUserFoldersAndFavoritesToCloud(context)
    }

    fun getAllFolders(): Flow<List<FolderEntity>> = folderDao.getAllFolders()

    suspend fun createFolder(name: String): String = withContext(Dispatchers.IO) {
        val id = UUID.randomUUID().toString()
        folderDao.insertFolder(
            FolderEntity(
                id = id,
                name = name.trim().ifBlank { "Mi Carpeta" },
                isDefault = false
            )
        )
        UserCloudSyncManager.syncUserFoldersAndFavoritesToCloud(context)
        id
    }

    suspend fun updateFolderName(folderId: String, newName: String) = withContext(Dispatchers.IO) {
        folderDao.updateFolderName(folderId, newName.trim())
        UserCloudSyncManager.syncUserFoldersAndFavoritesToCloud(context)
    }

    suspend fun deleteFolder(folderId: String) = withContext(Dispatchers.IO) {
        folderDao.deleteSongsInFolder(folderId)
        folderDao.deleteFolder(folderId)
        UserCloudSyncManager.syncUserFoldersAndFavoritesToCloud(context)
    }

    fun getSongsInFolder(folderId: String): Flow<List<SongEntity>> = folderDao.getSongsInFolder(folderId)
    fun getFolderIdsForSong(songId: String): Flow<List<String>> = folderDao.getFolderIdsForSong(songId)

    suspend fun getFolderIdsForSongOnce(songId: String): List<String> = withContext(Dispatchers.IO) {
        folderDao.getFolderIdsForSongOnce(songId)
    }

    suspend fun toggleSongInFolder(folderId: String, songId: String, isInFolder: Boolean) = withContext(Dispatchers.IO) {
        if (isInFolder) {
            folderDao.removeSongFromFolder(folderId, songId)
            if (folderId == "favorites") {
                songDao.updateFavorite(songId, false)
            }
        } else {
            folderDao.addSongToFolder(FolderSongCrossRef(folderId, songId))
            if (folderId == "favorites") {
                songDao.updateFavorite(songId, true)
            }
        }
        UserCloudSyncManager.syncUserFoldersAndFavoritesToCloud(context)
    }

    suspend fun addSongToFolder(folderId: String, songId: String) = withContext(Dispatchers.IO) {
        folderDao.addSongToFolder(FolderSongCrossRef(folderId, songId))
        if (folderId == "favorites") {
            songDao.updateFavorite(songId, true)
        }
        UserCloudSyncManager.syncUserFoldersAndFavoritesToCloud(context)
    }

    suspend fun removeSongFromFolder(folderId: String, songId: String) = withContext(Dispatchers.IO) {
        folderDao.removeSongFromFolder(folderId, songId)
        if (folderId == "favorites") {
            songDao.updateFavorite(songId, false)
        }
        UserCloudSyncManager.syncUserFoldersAndFavoritesToCloud(context)
    }

    suspend fun getSongCountInFolder(folderId: String): Int = withContext(Dispatchers.IO) {
        folderDao.getSongCountInFolder(folderId)
    }

    suspend fun getLatestSongCoverInFolder(folderId: String): String? = withContext(Dispatchers.IO) {
        folderDao.getLatestSongCoverInFolder(folderId)
    }

    fun getAllUploadedSongs(): Flow<List<UploadedSongEntity>> = uploadedSongDao.getAllUploadedSongs()

    suspend fun saveUploadedSong(uploaded: UploadedSongEntity) = withContext(Dispatchers.IO) {
        uploadedSongDao.insertUploadedSong(uploaded)
        val durationParts = uploaded.approxDuration.split(":")
        val durationSec = if (durationParts.size == 2) {
            (durationParts[0].toIntOrNull() ?: 3) * 60 + (durationParts[1].toIntOrNull() ?: 30)
        } else {
            uploaded.approxDuration.toIntOrNull() ?: 210
        }
        val songEntity = SongEntity(
            id = uploaded.id,
            title = uploaded.title,
            artist = uploaded.artist,
            genre = uploaded.genre,
            album = "Obra Registrada (${uploaded.releaseDate})",
            coverUrl = uploaded.coverUrl ?: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=500&q=80",
            audioUrl = uploaded.audioFilePath,
            durationSeconds = durationSec,
            isDownloaded = true,
            localFilePath = uploaded.audioFilePath
        )
        songDao.insertSongs(listOf(songEntity))
    }

    suspend fun deleteUploadedSong(uploaded: UploadedSongEntity) = withContext(Dispatchers.IO) {
        uploadedSongDao.deleteUploadedSong(uploaded)
        try { File(uploaded.audioFilePath).delete() } catch (_: Exception) {}
        uploaded.pdfDocPath?.let { try { File(it).delete() } catch (_: Exception) {} }
    }

    suspend fun recordPlay(songId: String) = withContext(Dispatchers.IO) {
        songDao.recordPlay(songId, System.currentTimeMillis())
    }

    suspend fun recordSearch(songId: String) = withContext(Dispatchers.IO) {
        songDao.recordSearch(songId, System.currentTimeMillis())
    }

    suspend fun recordSearchQuery(query: String, matchedSongs: List<SongEntity> = emptyList()) = withContext(Dispatchers.IO) {
        val clean = query.trim()
        if (clean.length < 2) return@withContext
        val now = System.currentTimeMillis()
        matchedSongs.forEach { song ->
            val existing = songDao.getSongById(song.id)
            if (existing != null) {
                songDao.recordSearch(song.id, now)
            } else {
                songDao.insertSongs(listOf(song.copy(searchCount = 1, lastSearchedAt = now)))
            }
        }
        songDao.recordSearchByQuery(clean, now)
    }

    suspend fun downloadSong(song: SongEntity, onProgress: (Float) -> Unit): Result<String> = withContext(Dispatchers.IO) {
        try {
            val downloadsDir = File(context.filesDir, "downloads")
            if (!downloadsDir.exists()) downloadsDir.mkdirs()

            // 1. If song is already downloaded and file exists with valid full audio size (> 50KB), export and return
            val localCandidate = listOf(
                song.localFilePath?.let { File(it) },
                File(downloadsDir, "${song.id}.m4a"),
                File(downloadsDir, "${song.id}.mp3"),
                File(downloadsDir, "${song.id}.aac"),
                File(downloadsDir, "${song.id}.wav")
            ).firstOrNull { it != null && it.exists() && it.length() > 50_000 }

            if (localCandidate != null) {
                val exportedPath = exportToPublicFiles(localCandidate, song)
                songDao.updateDownloadStatus(song.id, true, exportedPath)
                onProgress(1.0f)
                return@withContext Result.success(exportedPath)
            }

            onProgress(0.06f)

            // 2. If song points to a direct online audio stream (mp3/m4a/wav) that is not YouTube
            if (song.audioUrl.startsWith("http") &&
                !song.audioUrl.contains("youtube.com") &&
                !song.audioUrl.contains("youtu.be") &&
                (song.audioUrl.endsWith(".mp3") || song.audioUrl.endsWith(".m4a") || song.audioUrl.endsWith(".wav") || song.audioUrl.endsWith(".aac"))
            ) {
                val tempFile = File(downloadsDir, "${song.id}_direct.tmp")
                val ok = downloadFromUrl(song.audioUrl, tempFile, onProgress)
                if (ok && tempFile.exists() && tempFile.length() > 50_000) {
                    val finalPath = exportToPublicFiles(tempFile, song)
                    tempFile.delete()
                    songDao.updateDownloadStatus(song.id, true, finalPath)
                    onProgress(1.0f)
                    return@withContext Result.success(finalPath)
                }
            }

            // 3. Resolve FULL STUDIO SONG via SoundCloud API (high fidelity, full duration tracks)
            val scFile = resolveAndDownloadSoundCloud(song, downloadsDir, onProgress)
            if (scFile != null && scFile.exists() && scFile.length() > 50_000) {
                val finalPath = exportToPublicFiles(scFile, song)
                scFile.delete()
                songDao.updateDownloadStatus(song.id, true, finalPath)
                onProgress(1.0f)
                return@withContext Result.success(finalPath)
            }

            // 4. Resolve FULL STUDIO SONG via JioSaavn Official 320kbps Stream
            val saavnFile = resolveAndDownloadJioSaavn(song, downloadsDir, onProgress)
            if (saavnFile != null && saavnFile.exists() && saavnFile.length() > 50_000) {
                val finalPath = exportToPublicFiles(saavnFile, song)
                saavnFile.delete()
                songDao.updateDownloadStatus(song.id, true, finalPath)
                onProgress(1.0f)
                return@withContext Result.success(finalPath)
            }

            // 5. Fallback to Jamendo / Archive music sources
            val freeFile = resolveAndDownloadFreeMusic(song, downloadsDir, onProgress)
            if (freeFile != null && freeFile.exists() && freeFile.length() > 50_000) {
                val finalPath = exportToPublicFiles(freeFile, song)
                freeFile.delete()
                songDao.updateDownloadStatus(song.id, true, finalPath)
                onProgress(1.0f)
                return@withContext Result.success(finalPath)
            }

            Result.failure(Exception("No se pudo obtener el audio completo de '${song.title}'"))
        } catch (e: Exception) {
            Log.e("MusicRepository", "Download error: ${e.message}", e)
            Result.failure(e)
        }
    }

    private data class ScoredSoundCloudCandidate(
        val score: Int,
        val track: JSONObject,
        val progUrl: String?,
        val hlsUrl: String?,
        val clientId: String,
        val title: String,
        val user: String,
        val durationSec: Int
    )

    private fun scoreSoundCloudCandidate(
        song: SongEntity,
        candidateTitle: String,
        candidateUser: String,
        candidatePublisherArtist: String,
        candidateDurationSec: Int
    ): Int {
        val targetTitle = song.title.lowercase().trim()
        val targetArtist = song.artist.lowercase().trim()
        val cTitle = candidateTitle.lowercase().trim()
        val cUser = candidateUser.lowercase().trim()
        val cPubArtist = candidatePublisherArtist.lowercase().trim()

        // 1. Exclude previews/snippets
        if (candidateDurationSec in 1..59) return -999

        // 2. Immediate disqualify for bad keywords (covers, edits, pitch, karaoke, etc.)
        val bannedKeywords = listOf(
            "slowed", "reverb", "8d", "16d", "sped up", "speed up", "nightcore",
            "karaoke", "instrumental", "tribute", "tributo", "parodia", "parody",
            "tutorial", "bass boosted", "pitch shifted", "acapella", "a capella",
            "mashup", "1 hour", "1 hora", "10 hour", "loop", "extended mix"
        )
        for (banned in bannedKeywords) {
            if (cTitle.contains(banned) || cUser.contains(banned)) return -999
        }

        // Cover check: if original song title doesn't say "cover", reject any cover candidate
        if (!targetTitle.contains("cover") && (cTitle.contains("cover") || cUser.contains("cover"))) return -999

        // 3. Conditional penalties
        if (!targetTitle.contains("remix") && cTitle.contains("remix")) return -500
        if (!targetTitle.contains("acoustic") && !targetTitle.contains("acustic") &&
            (cTitle.contains("acoustic") || cTitle.contains("acústic") || cTitle.contains("acustico") || cTitle.contains("acústico"))
        ) return -500
        if (!targetTitle.contains("live") && !targetTitle.contains("en vivo") &&
            (cTitle.contains("live") || cTitle.contains("en vivo") || cTitle.contains("en directo"))
        ) return -500
        if (!targetTitle.contains("anti") && cTitle.contains("anti")) return -500

        var score = 0

        // 4. Official distributor / Publisher artist match (e.g. Sony, Bighit, Warner label uploads)
        if (cPubArtist.isNotBlank()) {
            val pubMatches = cPubArtist.contains(targetArtist) || targetArtist.contains(cPubArtist) ||
                targetArtist.split(" ", ",", "&", "feat").any { it.trim().length > 2 && cPubArtist.contains(it.trim()) }
            if (pubMatches) {
                score += 65
            }
        }

        // 5. User / Uploader channel match
        if (cUser.isNotBlank()) {
            val userMatches = cUser.contains(targetArtist) || targetArtist.contains(cUser) ||
                targetArtist.split(" ", ",", "&", "feat").any { it.trim().length > 2 && cUser.contains(it.trim()) }
            if (userMatches) {
                score += 45
            }
        }

        // 6. Candidate title has artist tokens
        val artistTokens = targetArtist.split(" ", ",", "&", "feat", "-").map { it.trim() }.filter { it.length > 2 }
        if (artistTokens.any { cTitle.contains(it) }) {
            score += 25
        }

        // 7. Title exactness & clean title comparison
        val cleanTargetTitle = targetTitle.replace(Regex("\\(.*?\\)|\\[.*?\\]"), " ")
            .replace(Regex("[^a-záéíóúüñ0-9 ]"), " ").trim()
        val cleanCandTitle = cTitle.replace(Regex("\\(.*?\\)|\\[.*?\\]"), " ")
            .replace(Regex("[^a-záéíóúüñ0-9 ]"), " ").trim()

        if (cleanCandTitle == cleanTargetTitle) {
            score += 40
        } else if (cleanCandTitle.startsWith(cleanTargetTitle) || cleanCandTitle.contains(cleanTargetTitle)) {
            score += 30
        } else {
            val targetWords = cleanTargetTitle.split(" ").filter { it.length > 2 }
            val matchingWords = targetWords.count { cleanCandTitle.contains(it) }
            score += (matchingWords * 10)
        }

        // Bonus for official audio keywords in title
        if (cTitle.contains("official") || cTitle.contains("oficial") || cTitle.contains("audio original") || cTitle.contains("original mix")) {
            score += 15
        }

        // 8. Duration precision
        if (song.durationSeconds > 30 && candidateDurationSec > 0) {
            val diff = Math.abs(candidateDurationSec - song.durationSeconds)
            when {
                diff <= 4 -> score += 50
                diff <= 10 -> score += 35
                diff <= 20 -> score += 20
                diff <= 35 -> score += 5
                diff > 50 -> score -= 50
                diff > 90 -> return -999 // Unacceptable duration deviation
            }
        } else if (candidateDurationSec in 90..450) {
            score += 10
        }

        return score
    }

    private fun resolveAndDownloadSoundCloud(
        song: SongEntity,
        downloadsDir: File,
        onProgress: (Float) -> Unit
    ): File? {
        val candidates = smartParseCandidates(song.title, song.artist)
        val clientIds = listOf("V7f0p2q7JD4voO1Esqg6bwwtNYcYAtLC", "iZIs9mchVcX5lhVRdekQWmUAUISRa1ir")

        val scoredTracks = mutableListOf<ScoredSoundCloudCandidate>()
        val seenTrackIds = mutableSetOf<Long>()

        for (clientId in clientIds) {
            for (query in candidates) {
                try {
                    val encoded = URLEncoder.encode(query, "UTF-8")
                    val searchUrl = "https://api-v2.soundcloud.com/search/tracks?q=$encoded&client_id=$clientId&limit=10"
                    val conn = URL(searchUrl).openConnection() as HttpURLConnection
                    conn.connectTimeout = 6000
                    conn.readTimeout = 6000
                    conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64)")
                    if (conn.responseCode != 200) continue

                    val jsonText = conn.inputStream.bufferedReader().use { it.readText() }
                    val root = JSONObject(jsonText)
                    val collection = root.optJSONArray("collection") ?: continue

                    for (i in 0 until collection.length()) {
                        val track = collection.getJSONObject(i)
                        val trackId = track.optLong("id", 0L)
                        if (trackId != 0L && !seenTrackIds.add(trackId)) continue

                        val durationMs = track.optLong("duration", 0L)
                        val durationSec = (durationMs / 1000).toInt()
                        if (durationSec < 60) continue

                        val media = track.optJSONObject("media") ?: continue
                        val transcodings = media.optJSONArray("transcodings") ?: continue

                        var progUrl: String? = null
                        var hlsUrl: String? = null

                        for (j in 0 until transcodings.length()) {
                            val tc = transcodings.getJSONObject(j)
                            val format = tc.optJSONObject("format")
                            val protocol = format?.optString("protocol") ?: ""
                            val url = tc.optString("url")
                            if (protocol == "progressive" && progUrl == null) {
                                progUrl = url
                            } else if (protocol == "hls" && hlsUrl == null) {
                                hlsUrl = url
                            }
                        }

                        // Skip DRM-only tracks
                        if (progUrl.isNullOrBlank() && hlsUrl.isNullOrBlank()) continue

                        val tTitle = track.optString("title", "")
                        val userObj = track.optJSONObject("user")
                        val username = userObj?.optString("username", "") ?: ""
                        val pubObj = track.optJSONObject("publisher_metadata")
                        val pubArtist = pubObj?.optString("artist", "") ?: ""

                        val score = scoreSoundCloudCandidate(
                            song = song,
                            candidateTitle = tTitle,
                            candidateUser = username,
                            candidatePublisherArtist = pubArtist,
                            candidateDurationSec = durationSec
                        )

                        if (score > 0) {
                            scoredTracks.add(
                                ScoredSoundCloudCandidate(
                                    score = score,
                                    track = track,
                                    progUrl = progUrl,
                                    hlsUrl = hlsUrl,
                                    clientId = clientId,
                                    title = tTitle,
                                    user = username,
                                    durationSec = durationSec
                                )
                            )
                        }
                    }
                } catch (e: Exception) {
                    Log.w("MusicRepository", "SoundCloud search note for '$query': ${e.message}")
                }
                if (scoredTracks.any { it.score >= 90 }) break
            }
            if (scoredTracks.any { it.score >= 90 }) break
        }

        // Sort descending by match score
        scoredTracks.sortByDescending { it.score }

        for (cand in scoredTracks) {
            Log.i("MusicRepository", "Attempting download candidate: '${cand.title}' by '${cand.user}' (score: ${cand.score}, dur: ${cand.durationSec}s)")

            // 1. Try progressive direct stream first
            if (!cand.progUrl.isNullOrBlank()) {
                try {
                    val streamConn = URL("${cand.progUrl}?client_id=${cand.clientId}").openConnection() as HttpURLConnection
                    streamConn.setRequestProperty("User-Agent", "Mozilla/5.0")
                    if (streamConn.responseCode == 200) {
                        val sJson = JSONObject(streamConn.inputStream.bufferedReader().use { it.readText() })
                        val directMp3Url = sJson.optString("url")
                        if (directMp3Url.startsWith("http")) {
                            val tempOut = File(downloadsDir, "${song.id}_sc.mp3")
                            if (downloadFromUrl(directMp3Url, tempOut, onProgress) && tempOut.length() > 50_000) {
                                Log.i("MusicRepository", "Successfully downloaded original matching track (prog): '${cand.title}' (score: ${cand.score})")
                                return tempOut
                            }
                        }
                    }
                } catch (e: Exception) {
                    Log.w("MusicRepository", "Prog download failed for '${cand.title}': ${e.message}")
                }
            }

            // 2. Try HLS stream if progressive is not available or failed
            if (!cand.hlsUrl.isNullOrBlank()) {
                try {
                    val hlsConn = URL("${cand.hlsUrl}?client_id=${cand.clientId}").openConnection() as HttpURLConnection
                    hlsConn.setRequestProperty("User-Agent", "Mozilla/5.0")
                    if (hlsConn.responseCode == 200) {
                        val hJson = JSONObject(hlsConn.inputStream.bufferedReader().use { it.readText() })
                        val m3u8Url = hJson.optString("url")
                        if (m3u8Url.startsWith("http")) {
                            val tempOut = File(downloadsDir, "${song.id}_sc.m4a")
                            if (downloadHlsStream(m3u8Url, tempOut, onProgress) && tempOut.length() > 50_000) {
                                Log.i("MusicRepository", "Successfully downloaded original matching track (hls): '${cand.title}' (score: ${cand.score})")
                                return tempOut
                            }
                        }
                    }
                } catch (e: Exception) {
                    Log.w("MusicRepository", "HLS download failed for '${cand.title}': ${e.message}")
                }
            }
        }
        return null
    }

    private fun downloadHlsStream(
        m3u8Url: String,
        targetFile: File,
        onProgress: (Float) -> Unit
    ): Boolean {
        return try {
            val conn = URL(m3u8Url).openConnection() as HttpURLConnection
            conn.connectTimeout = 8000
            conn.readTimeout = 8000
            conn.setRequestProperty("User-Agent", "Mozilla/5.0")
            if (conn.responseCode != 200) return false

            val m3u8Content = conn.inputStream.bufferedReader().use { it.readText() }
            var initUrl: String? = null
            val initRegex = Regex("""#EXT-X-MAP:URI="([^"]+)"""")
            val initMatch = initRegex.find(m3u8Content)
            if (initMatch != null) {
                initUrl = initMatch.groupValues[1]
            }

            val lines = m3u8Content.split("\n")
            val segments = lines.map { it.trim() }
                .filter { it.isNotBlank() && !it.startsWith("#") }
            if (segments.isEmpty()) return false

            val fos = FileOutputStream(targetFile)

            if (!initUrl.isNullOrBlank()) {
                val resolvedInitUrl = if (initUrl.startsWith("http")) initUrl else resolveRelativeUrl(m3u8Url, initUrl)
                try {
                    val initConn = URL(resolvedInitUrl).openConnection() as HttpURLConnection
                    initConn.connectTimeout = 6000
                    initConn.readTimeout = 6000
                    initConn.setRequestProperty("User-Agent", "Mozilla/5.0")
                    if (initConn.responseCode == 200) {
                        initConn.inputStream.use { it.copyTo(fos) }
                    }
                } catch (e: Exception) {
                    Log.w("MusicRepository", "Init segment fetch notice: ${e.message}")
                }
            }

            val totalSegments = segments.size
            for (idx in segments.indices) {
                val segUrlRaw = segments[idx]
                val segUrl = if (segUrlRaw.startsWith("http")) segUrlRaw else resolveRelativeUrl(m3u8Url, segUrlRaw)
                try {
                    val segConn = URL(segUrl).openConnection() as HttpURLConnection
                    segConn.connectTimeout = 8000
                    segConn.readTimeout = 8000
                    segConn.setRequestProperty("User-Agent", "Mozilla/5.0")
                    if (segConn.responseCode == 200) {
                        segConn.inputStream.use { it.copyTo(fos) }
                    }
                } catch (e: Exception) {
                    Log.w("MusicRepository", "Segment $idx fetch notice: ${e.message}")
                }

                val prog = (0.10f + (idx.toFloat() / totalSegments.toFloat()) * 0.88f).coerceIn(0.10f, 0.98f)
                onProgress(prog)
            }
            fos.flush()
            fos.close()
            targetFile.exists() && targetFile.length() > 50_000
        } catch (e: Exception) {
            Log.e("MusicRepository", "HLS download error: ${e.message}")
            false
        }
    }

    private fun resolveRelativeUrl(base: String, relative: String): String {
        return try {
            URL(URL(base), relative).toString()
        } catch (e: Exception) {
            relative
        }
    }

    private data class ScoredSaavnCandidate(
        val score: Int,
        val title: String,
        val encryptedUrl: String,
        val durationSec: Int
    )

    private fun scoreJioSaavnCandidate(
        song: SongEntity,
        rTitle: String,
        primaryArtists: List<String>,
        singers: String,
        candidateDurationSec: Int
    ): Int {
        val targetTitle = song.title.lowercase().trim()
        val targetArtist = song.artist.lowercase().trim()
        val cTitle = rTitle.lowercase().trim()
        val cSingers = singers.lowercase().trim()

        if (candidateDurationSec in 1..59) return -999

        val bannedKeywords = listOf(
            "slowed", "reverb", "8d", "16d", "sped up", "speed up", "nightcore",
            "karaoke", "instrumental", "tribute", "tributo", "parodia", "parody",
            "tutorial", "bass boosted", "pitch shifted", "acapella", "a capella",
            "mashup", "1 hour", "1 hora", "loop"
        )
        for (banned in bannedKeywords) {
            if (cTitle.contains(banned)) return -999
        }

        if (!targetTitle.contains("cover") && cTitle.contains("cover")) return -999
        if (!targetTitle.contains("remix") && cTitle.contains("remix")) return -500
        if (!targetTitle.contains("acoustic") && !targetTitle.contains("acustic") &&
            (cTitle.contains("acoustic") || cTitle.contains("acústic") || cTitle.contains("acustico") || cTitle.contains("acústico"))
        ) return -500

        // Disqualify known cover mills on JioSaavn
        val coverMakers = listOf(
            "tommymuzzic", "boostereo", "audino", "nexeri", "nxsser",
            "chill darling", "nyae", "eyeroze", "melodyz town", "softkarma",
            "nøvacore", "novacore", "alain le malin"
        )
        if (primaryArtists.any { pa -> coverMakers.any { cm -> pa.lowercase().contains(cm) } }) {
            return -999
        }

        var score = 0
        val artistMatches = primaryArtists.any { pa ->
            val pLow = pa.lowercase().trim()
            pLow.contains(targetArtist) || targetArtist.contains(pLow) ||
                targetArtist.split(" ", ",", "&", "feat").any { it.trim().length > 2 && pLow.contains(it.trim()) }
        } || cSingers.contains(targetArtist)

        if (artistMatches) {
            score += 65
        } else {
            score -= 60
        }

        val cleanTargetTitle = targetTitle.replace(Regex("\\(.*?\\)|\\[.*?\\]"), " ")
            .replace(Regex("[^a-záéíóúüñ0-9 ]"), " ").trim()
        val cleanCandTitle = cTitle.replace(Regex("\\(.*?\\)|\\[.*?\\]"), " ")
            .replace(Regex("[^a-záéíóúüñ0-9 ]"), " ").trim()

        if (cleanCandTitle == cleanTargetTitle) {
            score += 40
        } else if (cleanCandTitle.startsWith(cleanTargetTitle) || cleanCandTitle.contains(cleanTargetTitle)) {
            score += 25
        }

        if (song.durationSeconds > 30 && candidateDurationSec > 0) {
            val diff = Math.abs(candidateDurationSec - song.durationSeconds)
            when {
                diff <= 4 -> score += 45
                diff <= 10 -> score += 30
                diff <= 20 -> score += 15
                diff > 45 -> score -= 50
                diff > 90 -> return -999
            }
        }

        return score
    }

    private fun resolveAndDownloadJioSaavn(
        song: SongEntity,
        downloadsDir: File,
        onProgress: (Float) -> Unit
    ): File? {
        val candidates = smartParseCandidates(song.title, song.artist)
        for (query in candidates) {
            try {
                val encoded = URLEncoder.encode(query, "UTF-8")
                val url = "https://www.jiosaavn.com/api.php?__call=search.getResults&_format=json&_marker=0&api_version=4&ctx=web6dot0&n=10&p=1&q=$encoded"
                val conn = URL(url).openConnection() as HttpURLConnection
                conn.connectTimeout = 6000
                conn.readTimeout = 6000
                conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64)")
                if (conn.responseCode != 200) continue

                val json = conn.inputStream.bufferedReader().use { it.readText() }
                val root = JSONObject(json)
                val results = root.optJSONArray("results") ?: continue

                val scoredList = mutableListOf<ScoredSaavnCandidate>()

                for (i in 0 until results.length()) {
                    val r = results.getJSONObject(i)
                    val rTitle = r.optString("title", "")
                    val moreInfo = r.optJSONObject("more_info") ?: continue
                    val encUrl = moreInfo.optString("encrypted_media_url")
                    if (encUrl.isNullOrBlank()) continue

                    val durStr = moreInfo.optString("duration", "0")
                    val durationSec = durStr.toIntOrNull() ?: 0

                    val artistMap = moreInfo.optJSONObject("artistMap")
                    val primaryArtistsArray = artistMap?.optJSONArray("primary_artists")
                    val primaryArtists = mutableListOf<String>()
                    if (primaryArtistsArray != null) {
                        for (aIdx in 0 until primaryArtistsArray.length()) {
                            val aObj = primaryArtistsArray.getJSONObject(aIdx)
                            val name = aObj.optString("name", "")
                            if (name.isNotBlank()) primaryArtists.add(name)
                        }
                    }
                    val singers = moreInfo.optString("singers", "")

                    val score = scoreJioSaavnCandidate(song, rTitle, primaryArtists, singers, durationSec)
                    if (score > 0) {
                        scoredList.add(ScoredSaavnCandidate(score, rTitle, encUrl, durationSec))
                    }
                }

                scoredList.sortByDescending { it.score }

                for (cand in scoredList) {
                    val decryptedUrl = decryptJioSaavnMediaUrl(cand.encryptedUrl)
                    if (!decryptedUrl.isNullOrBlank() && decryptedUrl.startsWith("http")) {
                        val highQualityUrl = decryptedUrl.replace("_96.mp4", "_320.mp4")
                            .replace("_160.mp4", "_320.mp4")
                        val tempOut = File(downloadsDir, "${song.id}_saavn.m4a")
                        if (downloadFromUrl(highQualityUrl, tempOut, onProgress) && tempOut.length() > 50_000) {
                            Log.i("MusicRepository", "Downloaded high-fidelity track from JioSaavn for '${song.title}': '${cand.title}' (score: ${cand.score})")
                            return tempOut
                        }
                    }
                }
            } catch (e: Exception) {
                Log.w("MusicRepository", "JioSaavn notice for '$query': ${e.message}")
            }
        }
        return null
    }

    private fun decryptJioSaavnMediaUrl(encryptedUrl: String): String? {
        return try {
            val key = "38346591".toByteArray(Charsets.UTF_8)
            val keySpec = SecretKeySpec(key, "DES")
            val cipher = Cipher.getInstance("DES/ECB/PKCS5Padding")
            cipher.init(Cipher.DECRYPT_MODE, keySpec)
            val decoded = Base64.decode(encryptedUrl, Base64.DEFAULT)
            val decryptedBytes = cipher.doFinal(decoded)
            String(decryptedBytes, Charsets.UTF_8).trim()
        } catch (e: Exception) {
            Log.w("MusicRepository", "DES decrypt notice: ${e.message}")
            null
        }
    }

    private fun resolveAndDownloadFreeMusic(
        song: SongEntity,
        downloadsDir: File,
        onProgress: (Float) -> Unit
    ): File? {
        val targetArtist = song.artist.lowercase().trim()
        val targetTitle = song.title.lowercase().trim()

        val cleanQuery = "${song.title} ${song.artist}".trim()
        val encoded = URLEncoder.encode(cleanQuery, "UTF-8")
        try {
            val jamendoUrl = "https://api.jamendo.com/v3.0/tracks/?client_id=56d30c95&format=json&limit=5&search=$encoded"
            val conn = URL(jamendoUrl).openConnection() as HttpURLConnection
            conn.connectTimeout = 5000
            conn.readTimeout = 5000
            conn.setRequestProperty("User-Agent", "Mozilla/5.0")
            if (conn.responseCode == 200) {
                val root = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
                val results = root.optJSONArray("results")
                if (results != null && results.length() > 0) {
                    for (i in 0 until results.length()) {
                        val item = results.getJSONObject(i)
                        val jArtist = item.optString("artist_name", "").lowercase().trim()
                        val jTitle = item.optString("name", "").lowercase().trim()

                        // Strict matching: never return random royalty-free elevator music for mainstream songs
                        val artistMatches = jArtist.isNotBlank() && (jArtist.contains(targetArtist) || targetArtist.contains(jArtist))
                        val titleMatches = jTitle.isNotBlank() && (jTitle.contains(targetTitle) || targetTitle.contains(jTitle))

                        if (!artistMatches && !titleMatches) continue

                        val audio = item.optString("audio")
                        if (!audio.isNullOrBlank() && audio.startsWith("http")) {
                            val tempOut = File(downloadsDir, "${song.id}_jamendo.mp3")
                            if (downloadFromUrl(audio, tempOut, onProgress) && tempOut.length() > 50_000) {
                                return tempOut
                            }
                        }
                    }
                }
            }
        } catch (e: Exception) {
            // ignore
        }
        return null
    }

    private fun smartParseCandidates(rawTitle: String, rawArtist: String): List<String> {
        val candidates = mutableListOf<String>()

        val cleanArtist = rawArtist.replace(Regex("(?i)\\b(vevo|records|music|official|canal|topic)\\b"), " ")
            .replace(Regex("[\"\'~_]"), " ").trim()

        val featRegex = Regex("(?i)(?:feat\\.?|ft\\.?|featuring|con)\\s+([a-zA-Z0-9áéíóúüñÁÉÍÓÚÜÑ ]+)")
        val featMatch = featRegex.find(rawTitle)
        val featArtist = featMatch?.groupValues?.getOrNull(1)?.replace(Regex("[)\\]]"), "")?.trim() ?: ""

        var cleanTitle = rawTitle.replace(Regex("\\(.*?\\)|\\[.*?\\]"), " ")
        cleanTitle = cleanTitle.replace(Regex("(?i)\\b(official|video|audio|remix|lyric|lyrics|feat|ft|hd|4k|videoclip|musical|video oficial)\\b"), " ")
        cleanTitle = cleanTitle.replace(Regex("[\"\'~_]"), " ").trim()

        if (cleanTitle.isNotBlank() && cleanArtist.isNotBlank()) {
            candidates.add("$cleanTitle $cleanArtist")
            candidates.add("$cleanArtist $cleanTitle")
        }

        if (featArtist.isNotBlank() && cleanTitle.isNotBlank() && cleanArtist.isNotBlank()) {
            candidates.add("$cleanTitle $featArtist $cleanArtist")
            candidates.add("$cleanArtist $cleanTitle $featArtist")
        }

        if (cleanTitle.contains("-")) {
            val parts = cleanTitle.split("-", limit = 2)
            val p0 = parts[0].trim()
            val p1 = parts[1].trim()
            if (p0.isNotBlank() && p1.isNotBlank()) {
                candidates.add("$p0 $p1")
                candidates.add("$p1 $p0")
                candidates.add(p1)
            }
        }

        if (cleanTitle.isNotBlank()) {
            candidates.add(cleanTitle)
        }

        return candidates.map { it.replace(Regex("\\s+"), " ").trim() }
            .filter { it.length > 1 }
            .distinct()
    }

    private fun downloadFromUrl(
        audioUrl: String,
        targetFile: File,
        onProgress: (Float) -> Unit
    ): Boolean {
        return try {
            val conn = URL(audioUrl).openConnection() as HttpURLConnection
            conn.connectTimeout = 10000
            conn.readTimeout = 15000
            conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64)")
            conn.instanceFollowRedirects = true
            val totalBytes = conn.contentLength
            val inputStream = conn.inputStream
            val outputStream = FileOutputStream(targetFile)
            val buffer = ByteArray(16384)
            var bytesRead: Int
            var downloadedBytes = 0

            while (inputStream.read(buffer).also { bytesRead = it } != -1) {
                outputStream.write(buffer, 0, bytesRead)
                downloadedBytes += bytesRead
                if (totalBytes > 0) {
                    val progress = (0.10f + (downloadedBytes.toFloat() / totalBytes.toFloat()) * 0.88f).coerceIn(0.10f, 0.98f)
                    onProgress(progress)
                }
            }
            outputStream.flush()
            outputStream.close()
            inputStream.close()
            targetFile.exists() && targetFile.length() > 50_000
        } catch (e: Exception) {
            Log.e("MusicRepository", "Download from URL failed: ${e.message}")
            false
        }
    }

    /**
     * Finds or creates a SINGLE unified DriyStream folder on the device storage.
     * Checks if a 'DriyStream' (or 'driystream') folder already exists in Music or Downloads
     * to avoid creating duplicate folders.
     */
    fun getOrCreateDriyStreamFolder(): File {
        // 1. Check if a folder named driystream (case-insensitive) already exists in Music
        val publicMusic = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC)
        if (publicMusic.exists()) {
            val existing = publicMusic.listFiles()?.firstOrNull { it.isDirectory && it.name.equals("DriyStream", ignoreCase = true) }
            if (existing != null) return existing
        }

        // 2. Check if a folder named driystream already exists in Downloads
        val publicDownloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        if (publicDownloads.exists()) {
            val existing = publicDownloads.listFiles()?.firstOrNull { it.isDirectory && it.name.equals("DriyStream", ignoreCase = true) }
            if (existing != null) return existing
        }

        // 3. Check in app external files dir
        val extMusic = context.getExternalFilesDir(Environment.DIRECTORY_MUSIC)
        if (extMusic != null && extMusic.exists()) {
            val existing = extMusic.listFiles()?.firstOrNull { it.isDirectory && it.name.equals("DriyStream", ignoreCase = true) }
            if (existing != null) return existing
        }

        // 4. Default: create single unified folder in Music/DriyStream
        val canonical = File(publicMusic, "DriyStream")
        try {
            if (!canonical.exists()) {
                canonical.mkdirs()
            }
            if (canonical.exists()) return canonical
        } catch (e: Exception) {
            Log.w("MusicRepository", "Could not create Music/DriyStream: ${e.message}")
        }

        val fallback = File(publicDownloads, "DriyStream")
        if (!fallback.exists()) fallback.mkdirs()
        return fallback
    }

    /**
     * Returns all potential directory candidates where DriyStream audio files could exist
     * from previous app installations.
     */
    fun getAllDriyStreamCandidateFolders(): List<File> {
        val folders = mutableListOf<File>()
        folders.add(getOrCreateDriyStreamFolder())

        val publicMusic = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC)
        if (publicMusic.exists()) {
            publicMusic.listFiles()?.filter { it.isDirectory && it.name.equals("DriyStream", ignoreCase = true) }?.let { folders.addAll(it) }
        }

        val publicDownloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        if (publicDownloads.exists()) {
            publicDownloads.listFiles()?.filter { it.isDirectory && it.name.equals("DriyStream", ignoreCase = true) }?.let { folders.addAll(it) }
        }

        context.getExternalFilesDir(Environment.DIRECTORY_MUSIC)?.let { dir ->
            if (dir.exists()) {
                dir.listFiles()?.filter { it.isDirectory && it.name.equals("DriyStream", ignoreCase = true) }?.let { folders.addAll(it) }
                folders.add(File(dir, "DriyStream"))
            }
        }

        context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)?.let { dir ->
            if (dir.exists()) {
                folders.add(File(dir, "DriyStream"))
            }
        }

        folders.add(File(context.filesDir, "downloads"))

        return folders.filter { it.exists() && it.isDirectory }.distinctBy { it.absolutePath }
    }

    /**
     * Scans for existing audio files in the DriyStream folder (from previous installations or downloads),
     * recovers them, matches them with catalog songs (or creates local entries), and marks them as downloaded
     * so users never lose their offline songs upon reinstalling.
     */
    suspend fun scanAndRestoreDownloadedSongs(): Int = withContext(Dispatchers.IO) {
        var restoredCount = 0
        try {
            val candidateDirs = getAllDriyStreamCandidateFolders()
            val allSongsList = songDao.getAllSongs().firstOrNull() ?: emptyList()
            val validAudioExtensions = setOf("mp3", "m4a", "wav", "aac", "ogg", "flac")

            val foundAudioFiles = mutableListOf<File>()
            for (dir in candidateDirs) {
                val files = dir.listFiles()?.filter { file ->
                    file.isFile && file.length() > 20_000 && validAudioExtensions.contains(file.extension.lowercase())
                }
                if (files != null) {
                    foundAudioFiles.addAll(files)
                }
            }

            val uniqueFiles = foundAudioFiles.distinctBy { it.name.lowercase() }
            Log.d("MusicRepository", "Found ${uniqueFiles.size} audio files in DriyStream directories")

            val retriever = MediaMetadataRetriever()

            for (file in uniqueFiles) {
                var tagTitle = ""
                var tagArtist = ""
                var tagAlbum = ""
                var tagGenre = ""
                var tagDurationSec = 180

                try {
                    retriever.setDataSource(file.absolutePath)
                    tagTitle = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)?.trim() ?: ""
                    tagArtist = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)?.trim() ?: ""
                    tagAlbum = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM)?.trim() ?: ""
                    tagGenre = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_GENRE)?.trim() ?: ""
                    val durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
                    if (durationMs != null && durationMs > 0) {
                        tagDurationSec = (durationMs / 1000).toInt()
                    }
                } catch (e: Exception) {
                    // ignore metadata error
                }

                val nameNoExt = file.nameWithoutExtension.trim()
                val parsedArtist = if (nameNoExt.contains(" - ")) nameNoExt.substringBefore(" - ").trim() else ""
                val parsedTitle = if (nameNoExt.contains(" - ")) nameNoExt.substringAfter(" - ").trim() else nameNoExt

                val finalTitle = tagTitle.ifBlank { parsedTitle }
                val finalArtist = tagArtist.ifBlank { parsedArtist }

                // 1. Check if matches catalog song
                val matchedSong = allSongsList.firstOrNull { s ->
                    s.id.equals(nameNoExt, ignoreCase = true) ||
                    "${cleanFileName(s.artist)} - ${cleanFileName(s.title)}".equals(nameNoExt, ignoreCase = true) ||
                    (finalTitle.isNotBlank() && s.title.equals(finalTitle, ignoreCase = true) && (finalArtist.isBlank() || s.artist.equals(finalArtist, ignoreCase = true))) ||
                    nameNoExt.contains(s.title, ignoreCase = true)
                }

                if (matchedSong != null) {
                    songDao.updateDownloadStatus(matchedSong.id, true, file.absolutePath)
                    restoredCount++
                    Log.i("MusicRepository", "Restored catalog song: ${matchedSong.title} from ${file.name}")
                } else {
                    // 2. Standalone offline song not in default catalog
                    val offlineId = "offline_${nameNoExt.hashCode().toUInt().toString(16)}"
                    val existingSong = songDao.getSongById(offlineId)
                    if (existingSong == null) {
                        val offlineSong = SongEntity(
                            id = offlineId,
                            title = finalTitle.ifBlank { nameNoExt },
                            artist = finalArtist.ifBlank { "DriyStream Offline" },
                            genre = tagGenre.ifBlank { "Descargas" },
                            album = tagAlbum.ifBlank { "DriyStream" },
                            coverUrl = "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=500&q=80",
                            audioUrl = file.absolutePath,
                            durationSeconds = tagDurationSec,
                            isFavorite = false,
                            isDownloaded = true,
                            localFilePath = file.absolutePath
                        )
                        songDao.insertSongs(listOf(offlineSong))
                        restoredCount++
                        Log.i("MusicRepository", "Restored standalone offline song: ${offlineSong.title} from ${file.name}")
                    } else {
                        songDao.updateDownloadStatus(existingSong.id, true, file.absolutePath)
                    }
                }
            }

            try {
                retriever.release()
            } catch (e: Exception) {
                // ignore
            }

            // Also check MediaStore for audio registered under DriyStream
            try {
                val resolver = context.contentResolver
                val projection = arrayOf(
                    MediaStore.Audio.Media._ID,
                    MediaStore.Audio.Media.TITLE,
                    MediaStore.Audio.Media.ARTIST,
                    MediaStore.Audio.Media.DATA
                )
                val selection = "${MediaStore.Audio.Media.DATA} LIKE '%DriyStream%' OR ${MediaStore.Audio.Media.DATA} LIKE '%driystream%'"
                resolver.query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, projection, selection, null, null)?.use { cursor ->
                    val dataCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
                    val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                    val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                    while (cursor.moveToNext()) {
                        val path = cursor.getString(dataCol)
                        val title = cursor.getString(titleCol) ?: ""
                        val artist = cursor.getString(artistCol) ?: ""
                        if (!path.isNullOrBlank()) {
                            val f = File(path)
                            if (f.exists() && f.length() > 20_000) {
                                val match = allSongsList.firstOrNull { s ->
                                    s.title.equals(title, ignoreCase = true) || path.contains(cleanFileName(s.title), ignoreCase = true)
                                }
                                if (match != null && !match.isDownloaded) {
                                    songDao.updateDownloadStatus(match.id, true, path)
                                    restoredCount++
                                }
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                Log.w("MusicRepository", "MediaStore scan notice: ${e.message}")
            }

        } catch (e: Exception) {
            Log.e("MusicRepository", "Error scanning downloaded songs: ${e.message}", e)
        }
        restoredCount
    }

    private fun exportToPublicFiles(sourceFile: File, song: SongEntity): String {
        val safeTitle = cleanFileName(song.title)
        val safeArtist = cleanFileName(song.artist)
        val extension = if (sourceFile.name.endsWith(".mp3", ignoreCase = true)) "mp3" else "m4a"
        val mimeType = if (extension == "mp3") "audio/mpeg" else "audio/mp4"
        val fileName = "$safeArtist - $safeTitle.$extension"

        val downloadsDir = File(context.filesDir, "downloads")
        if (!downloadsDir.exists()) downloadsDir.mkdirs()
        val internalFile = File(downloadsDir, "${song.id}.$extension")
        if (sourceFile.absolutePath != internalFile.absolutePath) {
            sourceFile.copyTo(internalFile, overwrite = true)
        }

        val exportedPaths = mutableListOf<String>()

        // 1. Export to the unified single DriyStream folder (no duplicates)
        try {
            val driyDir = getOrCreateDriyStreamFolder()
            val targetFile = File(driyDir, fileName)
            sourceFile.copyTo(targetFile, overwrite = true)
            exportedPaths.add(targetFile.absolutePath)
            Log.i("MusicRepository", "Exported single copy to unified DriyStream folder: ${targetFile.absolutePath}")
        } catch (e: Exception) {
            Log.w("MusicRepository", "Unified DriyStream copy notice: ${e.message}")
        }

        // 2. Register in Android MediaStore so system media scanner sees it
        try {
            val resolver = context.contentResolver
            val audioValues = ContentValues().apply {
                put(MediaStore.Audio.Media.DISPLAY_NAME, fileName)
                put(MediaStore.Audio.Media.TITLE, song.title)
                put(MediaStore.Audio.Media.ARTIST, song.artist)
                put(MediaStore.Audio.Media.ALBUM, song.album)
                put(MediaStore.Audio.Media.MIME_TYPE, mimeType)
                put(MediaStore.Audio.Media.IS_MUSIC, 1)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    put(MediaStore.Audio.Media.RELATIVE_PATH, "${Environment.DIRECTORY_MUSIC}/DriyStream")
                    put(MediaStore.Audio.Media.IS_PENDING, 1)
                }
            }
            val audioUri = resolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, audioValues)
            if (audioUri != null) {
                resolver.openOutputStream(audioUri)?.use { outStream ->
                    sourceFile.inputStream().use { inStream -> inStream.copyTo(outStream) }
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    audioValues.clear()
                    audioValues.put(MediaStore.Audio.Media.IS_PENDING, 0)
                    resolver.update(audioUri, audioValues, null, null)
                }
                Log.i("MusicRepository", "Exported to MediaStore Audio: $fileName")
            }
        } catch (e: Exception) {
            Log.w("MusicRepository", "MediaStore Audio insert notice: ${e.message}")
        }

        try {
            if (exportedPaths.isNotEmpty()) {
                MediaScannerConnection.scanFile(
                    context,
                    exportedPaths.toTypedArray(),
                    Array(exportedPaths.size) { mimeType },
                    null
                )
            }
        } catch (e: Exception) {
            Log.w("MusicRepository", "MediaScanner notice: ${e.message}")
        }

        return internalFile.absolutePath
    }

    fun getDownloadedAudioFile(song: SongEntity): File? {
        val safeTitle = cleanFileName(song.title)
        val safeArtist = cleanFileName(song.artist)
        val driyDir = getOrCreateDriyStreamFolder()
        val internalDir = File(context.filesDir, "downloads")

        val candidates = mutableListOf<File?>()
        candidates.add(song.localFilePath?.let { File(it) })
        candidates.add(File(driyDir, "$safeArtist - $safeTitle.mp3"))
        candidates.add(File(driyDir, "$safeArtist - $safeTitle.m4a"))
        candidates.add(File(driyDir, "$safeArtist - $safeTitle.wav"))

        for (dir in getAllDriyStreamCandidateFolders()) {
            candidates.add(File(dir, "$safeArtist - $safeTitle.mp3"))
            candidates.add(File(dir, "$safeArtist - $safeTitle.m4a"))
            candidates.add(File(dir, "${song.id}.mp3"))
            candidates.add(File(dir, "${song.id}.m4a"))
        }

        candidates.add(File(internalDir, "${song.id}.m4a"))
        candidates.add(File(internalDir, "${song.id}.mp3"))
        candidates.add(File(internalDir, "${song.id}.aac"))
        candidates.add(File(internalDir, "${song.id}.wav"))

        return candidates.firstOrNull { it != null && it.exists() && it.length() > 20_000 }
    }

    fun getSongShareUri(song: SongEntity): Uri? {
        val file = getDownloadedAudioFile(song) ?: return null
        return try {
            FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        } catch (e: Exception) {
            Log.e("MusicRepository", "Failed to create share URI: ${e.message}")
            null
        }
    }

    private fun cleanFileName(str: String): String {
        return str.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().ifEmpty { "Pista" }
    }

    suspend fun removeDownload(songId: String) = withContext(Dispatchers.IO) {
        val song = songDao.getSongById(songId)
        val safeTitle = cleanFileName(song?.title ?: songId)
        val safeArtist = cleanFileName(song?.artist ?: "")

        val downloadsDir = File(context.filesDir, "downloads")
        File(downloadsDir, "${songId}.m4a").takeIf { it.exists() }?.delete()
        File(downloadsDir, "${songId}.mp3").takeIf { it.exists() }?.delete()
        File(downloadsDir, "${songId}.aac").takeIf { it.exists() }?.delete()
        File(downloadsDir, "${songId}.wav").takeIf { it.exists() }?.delete()

        song?.localFilePath?.let { path ->
            val file = File(path)
            if (file.exists()) file.delete()
        }

        try {
            val publicDownloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            File(publicDownloadsDir, "$safeArtist - $safeTitle.mp3").takeIf { it.exists() }?.delete()
            File(publicDownloadsDir, "$safeArtist - $safeTitle.m4a").takeIf { it.exists() }?.delete()
            File(File(publicDownloadsDir, "DriyStream"), "$safeArtist - $safeTitle.mp3").takeIf { it.exists() }?.delete()
            File(File(publicDownloadsDir, "DriyStream"), "$safeArtist - $safeTitle.m4a").takeIf { it.exists() }?.delete()
            val extMusicDir = File(context.getExternalFilesDir(Environment.DIRECTORY_MUSIC), "DriyStream")
            File(extMusicDir, "$safeArtist - $safeTitle.mp3").takeIf { it.exists() }?.delete()
            File(extMusicDir, "$safeArtist - $safeTitle.m4a").takeIf { it.exists() }?.delete()
        } catch (e: Exception) {
            // ignore
        }

        songDao.updateDownloadStatus(songId, false, null)
    }

    fun getAllGenres(): List<Genre> = CatalogSeed.genres
    fun getAllArtists(): List<Artist> = CatalogSeed.artists

    fun getArtistsForGenres(genreIds: List<String>): List<Artist> {
        val matches = CatalogSeed.artists.filter { artist ->
            genreIds.any { genreId -> artist.genre.equals(genreId, ignoreCase = true) }
        }
        return if (matches.size >= 4) matches else CatalogSeed.artists
    }

    fun searchArtists(query: String): List<Artist> {
        if (query.isBlank()) return CatalogSeed.artists
        return CatalogSeed.artists.filter {
            it.name.contains(query, ignoreCase = true) || it.genre.contains(query, ignoreCase = true)
        }
    }
}
