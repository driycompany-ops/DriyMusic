package com.example

import android.app.Application
import android.util.Log
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ProcessLifecycleOwner
import com.example.service.DriyAudioPlayer
import com.google.firebase.FirebaseApp

class DriyApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        try {
            if (FirebaseApp.getApps(this).isEmpty()) {
                FirebaseApp.initializeApp(this)
            }
        } catch (e: Exception) {
            Log.w("DriyApplication", "FirebaseApp init notice: ${e.message}")
        }
        try {
            com.example.ui.theme.ThemeManager.init(this)
        } catch (e: Exception) {
            Log.e("DriyApplication", "ThemeManager init error: ${e.message}")
        }
        try {
            DriyAudioPlayer.init(this)
        } catch (e: Exception) {
            Log.e("DriyApplication", "DriyAudioPlayer init error: ${e.message}")
        }
        try {
            com.example.service.VirtualAssistantManager.init(this)
        } catch (e: Exception) {
            Log.e("DriyApplication", "VirtualAssistantManager init error: ${e.message}")
        }
        try {
            ProcessLifecycleOwner.get().lifecycle.addObserver(object : DefaultLifecycleObserver {
                override fun onStart(owner: LifecycleOwner) {
                    try {
                        DriyAudioPlayer.setAppForegroundState(isForeground = true)
                    } catch (e: Exception) {
                        // ignore
                    }
                }

                override fun onStop(owner: LifecycleOwner) {
                    try {
                        DriyAudioPlayer.setAppForegroundState(isForeground = false)
                        com.example.service.YouTubeAudioPlayer.keepAliveInBackground()
                    } catch (e: Exception) {
                        // ignore
                    }
                }
            })
        } catch (e: Exception) {
            Log.w("DriyApplication", "Lifecycle observer notice: ${e.message}")
        }
    }
}
