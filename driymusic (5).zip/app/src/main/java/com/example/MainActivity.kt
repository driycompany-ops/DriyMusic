package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import com.example.ui.theme.DriyGold
import com.example.ui.theme.DriySurface
import com.example.ui.theme.DriyTextPrimary
import com.example.ui.theme.DriyTextSecondary
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.example.ui.components.SubscriptionLockScreen
import com.example.ui.components.SubscriptionPlanDialog
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.SongEntity
import com.example.ui.DriyViewModel
import com.example.ui.Screen
import com.example.ui.components.DriyBottomNavBar
import com.example.ui.components.FloatingAssistantWidget
import com.example.ui.components.FolderSelectionBottomSheet
import com.example.ui.components.FullPlayerModal
import com.example.ui.components.MiniPlayer
import com.example.ui.components.QueueModal
import com.example.ui.components.QueueNotificationBanner
import com.example.ui.components.SongActionBottomSheet
import com.example.ui.components.VirtualAssistantBottomSheet
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LibraryScreen
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.OnboardingArtistScreen
import com.example.ui.screens.OnboardingGenreScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.SearchScreen
import com.example.ui.screens.UploadMusicScreen
import com.example.ui.theme.DriyStreamTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val themeState by com.example.ui.theme.ThemeManager.themeState.collectAsStateWithLifecycle()
            DriyStreamTheme(themeState = themeState) {
                DriyStreamAppRoot()
            }
        }
    }
}

@Composable
fun DriyStreamAppRoot(viewModel: DriyViewModel = viewModel()) {
    val context = LocalContext.current

    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val isFullPlayerVisible by viewModel.isFullPlayerVisible.collectAsStateWithLifecycle()
    val isLyricsVisible by viewModel.isLyricsVisible.collectAsStateWithLifecycle()
    val lyricsUiState by viewModel.lyricsUiState.collectAsStateWithLifecycle()
    val playerState by viewModel.playerState.collectAsStateWithLifecycle()

    val activeUser by viewModel.activeUser.collectAsStateWithLifecycle()
    val jamState by viewModel.jamState.collectAsStateWithLifecycle()
    val allRegisteredUsers by viewModel.allRegisteredUsers.collectAsStateWithLifecycle()
    val allSongs by viewModel.allSongs.collectAsStateWithLifecycle()
    val downloadedSongs by viewModel.downloadedSongs.collectAsStateWithLifecycle()
    val favoriteSongs by viewModel.favoriteSongs.collectAsStateWithLifecycle()

    val selectedGenres by viewModel.selectedGenres.collectAsStateWithLifecycle()
    val selectedArtists by viewModel.selectedArtists.collectAsStateWithLifecycle()
    val artistSearchQuery by viewModel.artistSearchQuery.collectAsStateWithLifecycle()

    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val autocompleteSuggestions by viewModel.searchAutocompleteSuggestions.collectAsStateWithLifecycle()
    val isSearching by viewModel.isSearching.collectAsStateWithLifecycle()

    val downloadProgress by viewModel.downloadProgress.collectAsStateWithLifecycle()
    val isAuthenticating by viewModel.isAuthenticating.collectAsStateWithLifecycle()

    val favoriteArtistsSongs by viewModel.favoriteArtistsSongs.collectAsStateWithLifecycle()
    val isLoadingArtistSongs by viewModel.isLoadingArtistSongs.collectAsStateWithLifecycle()
    val islandMode by viewModel.islandMode.collectAsStateWithLifecycle()

    val isQueueVisible by viewModel.isQueueVisible.collectAsStateWithLifecycle()
    val activeSongForOptions by viewModel.activeSongForOptions.collectAsStateWithLifecycle()
    val queueNotification by viewModel.queueNotification.collectAsStateWithLifecycle()

    val allFolders by viewModel.allFolders.collectAsStateWithLifecycle()
    val foldersWithStats by viewModel.foldersWithStats.collectAsStateWithLifecycle()
    val activeSongForFolderSelection by viewModel.activeSongForFolderSelection.collectAsStateWithLifecycle()
    val selectedSongFolderIds by viewModel.selectedSongFolderIds.collectAsStateWithLifecycle()
    val activeFolder by viewModel.activeFolder.collectAsStateWithLifecycle()
    val activeFolderSongs by viewModel.activeFolderSongs.collectAsStateWithLifecycle()

    val uploadedSongs by viewModel.uploadedSongs.collectAsStateWithLifecycle()
    val globalCommunitySongs by viewModel.globalCommunitySongs.collectAsStateWithLifecycle()
    val mostSearchedSongs by viewModel.mostSearchedSongs.collectAsStateWithLifecycle()
    val recentlyPlayedSongs by viewModel.recentlyPlayedSongs.collectAsStateWithLifecycle()
    val recentSearchedSongs by viewModel.recentSearchedSongs.collectAsStateWithLifecycle()
    val sessionTerminatedMessage by viewModel.sessionTerminatedMessage.collectAsStateWithLifecycle()
    val isSyncingCloud by viewModel.isSyncingCloud.collectAsStateWithLifecycle()

    val isSubscribed = remember(activeUser) {
        val user = activeUser
        if (user == null) {
            viewModel.isUserLoggedIn()
        } else {
            user.isMasterAdmin || user.isSubscriptionActive
        }
    }

    var showSubscriptionDialogInRoot by remember { mutableStateOf(false) }
    var subscriptionInitialTabInRoot by remember { mutableIntStateOf(0) }

    var showAssistantSheetInRoot by remember { mutableStateOf(false) }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { }

    val audioPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            com.example.service.VirtualAssistantManager.startListeningSession()
        }
    }

    var availableUpdateInfo by remember { mutableStateOf<com.example.service.AppUpdateInfo?>(null) }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
        // Automatic In-App OTA Update Check in background
        try {
            kotlinx.coroutines.delay(1500L)
            val update = com.example.service.DriyAppUpdater.checkForUpdate()
            if (update != null) {
                availableUpdateInfo = update
            }
        } catch (_: Exception) {}
    }

    BackHandler(enabled = isFullPlayerVisible || (currentScreen != Screen.Home && currentScreen != Screen.Login)) {
        if (isFullPlayerVisible) {
            if (isLyricsVisible) {
                viewModel.setLyricsVisible(false)
            } else {
                viewModel.setFullPlayerVisible(false)
            }
        } else {
            when (currentScreen) {
                Screen.Search, Screen.Library, Screen.UploadMusic, Screen.Profile -> viewModel.navigateTo(Screen.Home)
                Screen.OnboardingArtist -> viewModel.navigateTo(Screen.OnboardingGenre)
                else -> { }
            }
        }
    }

    val isMainTabScreen = currentScreen in listOf(Screen.Home, Screen.Search, Screen.Library, Screen.UploadMusic, Screen.Profile)
    val themeState by com.example.ui.theme.ThemeManager.themeState.collectAsStateWithLifecycle()

    Box(
        modifier = Modifier.fillMaxSize()
    ) {
        // Active YouTube Audio Engine mounted with real layout dimensions so Chromium does not suspend playback
        Box(
            modifier = Modifier
                .size(320.dp, 180.dp)
                .align(Alignment.BottomEnd)
        ) {
            AndroidView(
                factory = { ctx ->
                    com.example.service.YouTubeAudioPlayer.getOrCreateWebView(ctx)
                },
                modifier = Modifier.fillMaxSize()
            )
        }

        // Main app background layer covering the webview completely
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(themeState.backgroundColor)
        )

        if (!themeState.backgroundPhotoUri.isNullOrBlank()) {
            coil.compose.AsyncImage(
                model = themeState.backgroundPhotoUri,
                contentDescription = null,
                contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(androidx.compose.ui.graphics.Color.Black.copy(alpha = themeState.backgroundDim))
            )
        }

        Scaffold(
            containerColor = if (themeState.backgroundPhotoUri.isNullOrBlank()) themeState.backgroundColor else androidx.compose.ui.graphics.Color.Transparent,
            bottomBar = {
                if (isMainTabScreen) {
                    Column(
                        modifier = Modifier.background(
                            if (themeState.backgroundPhotoUri.isNullOrBlank()) {
                                themeState.backgroundColor
                            } else {
                                themeState.backgroundColor.copy(alpha = 0.90f)
                            }
                        )
                    ) {
                        if (isSubscribed && playerState.currentSong != null) {
                            MiniPlayer(
                                playerState = playerState,
                                onTogglePlayPause = { viewModel.togglePlayPause() },
                                onSkipNext = { viewModel.playNext() },
                                onClickMiniPlayer = { viewModel.setFullPlayerVisible(true) },
                                onOpenLyrics = {
                                    viewModel.setLyricsVisible(true)
                                    viewModel.setFullPlayerVisible(true)
                                }
                            )
                        }

                        DriyBottomNavBar(
                            currentScreen = currentScreen,
                            isSubscribed = isSubscribed,
                            onNavigate = { viewModel.navigateTo(it) }
                        )
                    }
                }
            },
            modifier = Modifier.fillMaxSize()
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                Crossfade(targetState = currentScreen, label = "screen_transition") { screen ->
                    when (screen) {
                        Screen.Login -> {
                            LoginScreen(
                                isAuthenticating = isAuthenticating,
                                onCheckUsernameTaken = { username -> viewModel.checkUsernameTaken(username) },
                                onCheckPhoneTaken = { phone -> viewModel.findExistingAccount("", phone) != null },
                                onFindAccountByPhone = { phone -> viewModel.findExistingAccount("", phone) },
                                onValidateLoginCredentials = { username, password, phone ->
                                    viewModel.validateLoginCredentials(username, password, phone)
                                },
                                onVerifyIdentityForRecovery = { firstName, lastName, phone ->
                                    viewModel.verifyIdentityForRecovery(firstName, lastName, phone)
                                },
                                onResetPassword = { userIdOrUsername, newPassword ->
                                    viewModel.resetUserPassword(userIdOrUsername, newPassword)
                                },
                                onRegisterUser = { firstName, lastName, username, password, phone, onSuccess, onError ->
                                    viewModel.registerUserWithPhone(
                                        firstName = firstName,
                                        lastName = lastName,
                                        username = username,
                                        password = password,
                                        phoneNumber = phone,
                                        onSuccess = onSuccess,
                                        onError = onError
                                    )
                                },
                                onLoginUser = { username, password, phone, onSuccess, onError ->
                                    viewModel.loginWithUserAndPhone(
                                        username = username,
                                        password = password,
                                        phoneNumber = phone,
                                        onSuccess = onSuccess,
                                        onError = onError
                                    )
                                },
                                onLoginWithGoogle = {}
                            )
                        }

                        Screen.OnboardingGenre -> {
                            OnboardingGenreScreen(
                                genres = viewModel.getGenres(),
                                selectedGenreIds = selectedGenres,
                                onToggleGenre = { viewModel.toggleGenreSelection(it) },
                                onContinue = { viewModel.submitGenres() }
                            )
                        }

                        Screen.OnboardingArtist -> {
                            OnboardingArtistScreen(
                                artists = viewModel.getArtistsForOnboarding(),
                                selectedArtistNames = selectedArtists,
                                searchQuery = artistSearchQuery,
                                onSearchQueryChange = { viewModel.setArtistSearchQuery(it) },
                                onToggleArtist = { viewModel.toggleArtistSelection(it) },
                                onFinish = { viewModel.completeOnboarding() }
                            )
                        }

                        Screen.Home -> {
                            if (!isSubscribed && activeUser?.isMasterAdmin != true) {
                                SubscriptionLockScreen(
                                    featureName = "el Inicio y Streaming",
                                    onRequestPlan = {
                                        subscriptionInitialTabInRoot = 0
                                        showSubscriptionDialogInRoot = true
                                    },
                                    onRedeemCode = {
                                        subscriptionInitialTabInRoot = 1
                                        showSubscriptionDialogInRoot = true
                                    },
                                    onGoToMembresia = { viewModel.navigateTo(Screen.Profile) }
                                )
                            } else {
                                HomeScreen(
                                    user = activeUser,
                                    allSongs = allSongs,
                                    favoriteArtistsSongs = favoriteArtistsSongs,
                                    isLoadingArtistSongs = isLoadingArtistSongs,
                                    mostSearchedSongs = mostSearchedSongs,
                                    recentSearchedSongs = recentSearchedSongs,
                                    searchQuery = searchQuery,
                                    autocompleteSuggestions = autocompleteSuggestions,
                                    isSearching = isSearching,
                                    playerState = playerState,
                                    downloadProgress = downloadProgress,
                                    onSearchQueryChange = { viewModel.setSearchQuery(it) },
                                    onSubmitSearch = { viewModel.submitSearch(it) },
                                    onPlaySong = { song, queue -> viewModel.playSong(song, queue) },
                                    onSongSelectedFromSearch = { viewModel.playSongFromSearch(it) },
                                    onToggleFavorite = { viewModel.toggleFavorite(it) },
                                    onDownloadSong = { viewModel.downloadSong(it) },
                                    onOpenSongOptions = { viewModel.openSongOptions(it) },
                                    uploadedSongs = uploadedSongs,
                                    globalCommunitySongs = globalCommunitySongs
                                )
                            }
                        }

                        Screen.Search -> {
                            if (!isSubscribed && activeUser?.isMasterAdmin != true) {
                                SubscriptionLockScreen(
                                    featureName = "Explorar y Búsqueda de Música",
                                    onRequestPlan = {
                                        subscriptionInitialTabInRoot = 0
                                        showSubscriptionDialogInRoot = true
                                    },
                                    onRedeemCode = {
                                        subscriptionInitialTabInRoot = 1
                                        showSubscriptionDialogInRoot = true
                                    },
                                    onGoToMembresia = { viewModel.navigateTo(Screen.Profile) }
                                )
                            } else {
                                SearchScreen(
                                    allSongs = allSongs,
                                    genres = viewModel.getGenres(),
                                    playerState = playerState,
                                    downloadProgress = downloadProgress,
                                    onPlaySong = { song, queue -> viewModel.playSong(song, queue) },
                                    onSongSelectedFromSearch = { viewModel.playSongFromSearch(it) },
                                    onToggleFavorite = { viewModel.toggleFavorite(it) },
                                    onDownloadSong = { viewModel.downloadSong(it) },
                                    onOpenSongOptions = { viewModel.openSongOptions(it) }
                                )
                            }
                        }

                        Screen.Library -> {
                            if (!isSubscribed && activeUser?.isMasterAdmin != true) {
                                SubscriptionLockScreen(
                                    featureName = "tu Biblioteca y Descargas",
                                    onRequestPlan = {
                                        subscriptionInitialTabInRoot = 0
                                        showSubscriptionDialogInRoot = true
                                    },
                                    onRedeemCode = {
                                        subscriptionInitialTabInRoot = 1
                                        showSubscriptionDialogInRoot = true
                                    },
                                    onGoToMembresia = { viewModel.navigateTo(Screen.Profile) }
                                )
                            } else {
                                LibraryScreen(
                                    downloadedSongs = downloadedSongs,
                                    allSongs = allSongs,
                                    foldersWithStats = foldersWithStats,
                                    activeFolder = activeFolder,
                                    activeFolderSongs = activeFolderSongs,
                                    playerState = playerState,
                                    downloadProgress = downloadProgress,
                                    onPlaySong = { song, queue -> viewModel.playSong(song, queue) },
                                    onToggleFavorite = { viewModel.toggleFavorite(it) },
                                    onDownloadSong = { viewModel.downloadSong(it) },
                                    onOpenSongOptions = { viewModel.openSongOptions(it) },
                                    onOpenDownloadsFolder = { viewModel.openDownloadsFolder(context) },
                                    onScanDownloads = { viewModel.scanDownloadedSongs() },
                                    onOpenFolderDetail = { folder -> viewModel.openFolderDetail(folder) },
                                    onCloseFolderDetail = { viewModel.closeFolderDetail() },
                                    onCreateFolder = { name -> viewModel.createFolderAndAddSong(name, null) },
                                    onRenameFolder = { id, newName -> viewModel.renameFolder(id, newName) },
                                    onDeleteFolder = { folder -> viewModel.deleteFolder(folder) },
                                    onRemoveSongFromFolder = { folderId, songId -> viewModel.removeSongFromCurrentFolder(folderId, songId) },
                                    onSyncCloud = { viewModel.syncWithCloud() },
                                    isSyncingCloud = isSyncingCloud
                                )
                            }
                        }

                        Screen.UploadMusic -> {
                            if (!isSubscribed && activeUser?.isMasterAdmin != true) {
                                SubscriptionLockScreen(
                                    featureName = "Subir y Registrar Obras",
                                    onRequestPlan = {
                                        subscriptionInitialTabInRoot = 0
                                        showSubscriptionDialogInRoot = true
                                    },
                                    onRedeemCode = {
                                        subscriptionInitialTabInRoot = 1
                                        showSubscriptionDialogInRoot = true
                                    },
                                    onGoToMembresia = { viewModel.navigateTo(Screen.Profile) }
                                )
                            } else {
                                UploadMusicScreen(
                                    uploadedSongs = uploadedSongs,
                                    playerState = playerState,
                                    onUploadSong = { title, composer, authorshipPercentage, artist, genre, approxDuration, releaseDate, audioUri, audioFileName, pdfUri, pdfFileName, coverUri, onSuccess ->
                                        viewModel.uploadMusicWork(
                                            title = title,
                                            composer = composer,
                                            authorshipPercentage = authorshipPercentage,
                                            artist = artist,
                                            genre = genre,
                                            approxDuration = approxDuration,
                                            releaseDate = releaseDate,
                                            audioUri = audioUri,
                                            audioFileName = audioFileName,
                                            pdfUri = pdfUri,
                                            pdfFileName = pdfFileName,
                                            coverUri = coverUri,
                                            onSuccess = onSuccess
                                        )
                                    },
                                    onPlayUploadedSong = { uploaded ->
                                        val durationParts = uploaded.approxDuration.split(":")
                                        val durationSec = if (durationParts.size == 2) {
                                            (durationParts[0].toIntOrNull() ?: 3) * 60 + (durationParts[1].toIntOrNull() ?: 30)
                                        } else {
                                            uploaded.approxDuration.toIntOrNull() ?: 210
                                        }
                                        val song = SongEntity(
                                            id = uploaded.id,
                                            title = uploaded.title,
                                            artist = uploaded.artist,
                                            genre = uploaded.genre,
                                            album = "Obra Registrada (${uploaded.releaseDate})",
                                            coverUrl = uploaded.coverUrl ?: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=500&q=80",
                                            audioUrl = uploaded.audioFilePath,
                                            durationSeconds = durationSec,
                                            isDownloaded = true,
                                            localFilePath = uploaded.audioFilePath
                                        )
                                        viewModel.playSong(song)
                                    },
                                    onDeleteUploadedSong = { uploaded ->
                                        viewModel.deleteUploadedSong(uploaded)
                                    }
                                )
                            }
                        }

                        Screen.Profile -> {
                            ProfileScreen(
                                user = activeUser,
                                allRegisteredUsers = allRegisteredUsers,
                                isNativeIslandDetected = viewModel.isNativeIslandDetected,
                                islandMode = islandMode,
                                onSetIslandMode = { mode -> viewModel.setIslandMode(mode) },
                                hasOverlayPermission = viewModel.canDrawOverlays(),
                                onRequestOverlayPermission = { viewModel.openOverlaySettings(context) },
                                jamState = jamState,
                                playerState = playerState,
                                onCreateJam = { viewModel.createJamSession() },
                                onJoinJam = { code, cb -> viewModel.joinJamSession(code, cb) },
                                onLeaveJam = { viewModel.leaveJamSession() },
                                onUpdateDisplayName = { newName -> viewModel.updateDisplayName(newName) },
                                onUpdatePhotoUri = { uri -> viewModel.saveAndSetProfileImage(uri) },
                                onUpdatePresetPhoto = { url -> viewModel.updatePhotoUrl(url) },
                                onSignOut = { viewModel.signOut() },
                                onDeleteAccount = { viewModel.deleteAccount() }
                            )
                        }
                    }
                }
            }
        }

        val isCurrentSongFavorite = playerState.currentSong?.let { curr ->
            favoriteSongs.any { it.id == curr.id } || curr.isFavorite
        } ?: false

        FullPlayerModal(
            visible = isFullPlayerVisible,
            playerState = playerState,
            downloadProgress = playerState.currentSong?.let { downloadProgress[it.id] },
            isLyricsVisible = isLyricsVisible,
            lyricsUiState = lyricsUiState,
            isFavorite = isCurrentSongFavorite,
            onToggleLyrics = { viewModel.toggleLyricsVisible() },
            onRetryLyrics = { viewModel.fetchLyricsForCurrentSong(force = true) },
            onAdjustLyricsOffset = { deltaMs -> viewModel.adjustLyricsOffsetForCurrentSong(deltaMs) },
            onResetLyricsOffset = { viewModel.resetLyricsOffsetForCurrentSong() },
            onCustomSearchLyrics = { query -> viewModel.searchLyricsCustom(query) },
            onDismiss = { viewModel.setFullPlayerVisible(false) },
            onTogglePlayPause = { viewModel.togglePlayPause() },
            onNext = { viewModel.playNext() },
            onPrev = { viewModel.playPrevious() },
            onSeekTo = { viewModel.seekTo(it) },
            onToggleShuffle = { viewModel.toggleSmartShuffle() },
            onToggleRepeat = { viewModel.toggleRepeat() },
            onToggleFavorite = { viewModel.toggleFavorite(it) },
            onDownload = { viewModel.downloadSong(it) },
            onOpenQueue = { viewModel.setQueueVisible(true) }
        )

        QueueModal(
            visible = isQueueVisible,
            playerState = playerState,
            onDismiss = { viewModel.setQueueVisible(false) },
            onPlaySong = { song -> viewModel.playSong(song, playerState.queue) },
            onRemoveFromQueue = { songId -> viewModel.removeFromQueue(songId) },
            onClearQueue = { viewModel.clearQueue() },
            onToggleAutoplay = { viewModel.toggleSmartAutoplay() }
        )

        SongActionBottomSheet(
            song = activeSongForOptions,
            onDismiss = { viewModel.dismissSongOptions() },
            onPlayNow = { song -> viewModel.playSong(song) },
            onPlayNext = { song -> viewModel.addToQueueNext(song) },
            onAddToQueueEnd = { song -> viewModel.addToQueueEnd(song) },
            onToggleFavorite = { song -> viewModel.toggleFavorite(song) },
            onDownload = { song -> viewModel.downloadSong(song) },
            onShareSong = { song -> viewModel.shareDownloadedSong(context, song) },
            onOpenDownloads = { viewModel.openDownloadsFolder(context) },
            onOpenFolderSelector = { song -> viewModel.openFolderSelector(song) }
        )

        FolderSelectionBottomSheet(
            song = activeSongForFolderSelection,
            folders = allFolders,
            selectedFolderIds = selectedSongFolderIds,
            onDismiss = { viewModel.dismissFolderSelector() },
            onToggleFolder = { folder ->
                activeSongForFolderSelection?.let { song ->
                    viewModel.toggleSongInFolder(folder, song)
                }
            },
            onCreateFolder = { folderName ->
                viewModel.createFolderAndAddSong(folderName, activeSongForFolderSelection)
            }
        )

        QueueNotificationBanner(
            message = queueNotification,
            onDismiss = { viewModel.dismissQueueNotification() },
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = if (playerState.currentSong != null) 140.dp else 80.dp)
        )

        // Floating Virtual Assistant Widget
        if (isMainTabScreen && !isFullPlayerVisible) {
            FloatingAssistantWidget(
                onOpenSettings = {
                    if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                        audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    }
                    showAssistantSheetInRoot = true
                },
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(bottom = if (playerState.currentSong != null) 130.dp else 70.dp)
            )
        }

        VirtualAssistantBottomSheet(
            visible = showAssistantSheetInRoot,
            onDismiss = { showAssistantSheetInRoot = false }
        )

        // Subscription Dialog Accessible from Any Locked Screen
        SubscriptionPlanDialog(
            isOpen = showSubscriptionDialogInRoot,
            onDismiss = { showSubscriptionDialogInRoot = false },
            user = activeUser,
            initialTab = subscriptionInitialTabInRoot,
            onCodeRedeemedSuccessfully = {
                showSubscriptionDialogInRoot = false
            }
        )

        // Single Device Active Session Warning Modal
        if (sessionTerminatedMessage != null) {
            AlertDialog(
                onDismissRequest = { viewModel.clearSessionTerminatedMessage() },
                containerColor = DriySurface,
                icon = {
                    Icon(
                        imageVector = Icons.Default.PhoneAndroid,
                        contentDescription = null,
                        tint = DriyGold,
                        modifier = Modifier.size(36.dp)
                    )
                },
                title = {
                    Text(
                        text = "Sesión cerrada en este dispositivo",
                        fontWeight = FontWeight.Bold,
                        color = DriyTextPrimary
                    )
                },
                text = {
                    Text(
                        text = sessionTerminatedMessage ?: "",
                        color = DriyTextSecondary
                    )
                },
                confirmButton = {
                    Button(
                        onClick = { viewModel.clearSessionTerminatedMessage() },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = DriyGold,
                            contentColor = Color.Black
                        )
                    ) {
                        Text("Entendido", fontWeight = FontWeight.Bold)
                    }
                }
            )
        }

        // In-App OTA Update Dialog
        if (availableUpdateInfo != null) {
            com.example.ui.components.AppUpdateDialog(
                updateInfo = availableUpdateInfo,
                onDismiss = { availableUpdateInfo = null }
            )
        }
    }
}
