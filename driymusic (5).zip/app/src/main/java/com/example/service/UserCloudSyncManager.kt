package com.example.service

import android.content.Context
import android.util.Log
import com.example.data.db.DriyDatabase
import com.example.data.model.FolderEntity
import com.example.data.model.FolderSongCrossRef
import com.example.data.model.SongEntity
import com.example.data.seed.CatalogSeed
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

object UserCloudSyncManager {
    private const val TAG = "UserCloudSync"
    private const val USERS_COLLECTION = "driystream_users"

    private val syncScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var realtimeListenerRegistration: ListenerRegistration? = null
    private var activeListeningUserId: String? = null
    private var lastLocalPushTimestamp: Long = 0L

    private fun getActiveUserId(context: Context): String? {
        val prefs = context.getSharedPreferences("driystream_auth_prefs", Context.MODE_PRIVATE)
        return prefs.getString("active_user_id", null)?.takeIf { it.isNotBlank() }
    }

    /**
     * Pushes user's current favorite songs, custom folders, and full song metadata to Firestore.
     * Including full song metadata guarantees that any other device (Celular B) will immediately
     * have all song info (title, artist, covers, stream URLs) in its local database.
     */
    suspend fun syncUserFoldersAndFavoritesToCloud(context: Context, explicitUserId: String? = null) = withContext(Dispatchers.IO) {
        val userId = explicitUserId ?: getActiveUserId(context) ?: return@withContext
        try {
            val db = DriyDatabase.getInstance(context)
            val songDao = db.songDao()
            val folderDao = db.folderDao()

            val favoriteSongIds = songDao.getFavoriteSongIds()
            val customFolders = folderDao.getAllCustomFoldersList()
            val favFolderSongIds = folderDao.getSongIdsInFolderOnce("favorites")
            val allFolderSongIds = folderDao.getAllReferencedSongIds()

            // Combine all song IDs referenced in favorites or any folder
            val allNeededSongIds = (favoriteSongIds + favFolderSongIds + allFolderSongIds).distinct()

            // Build full metadata list for each referenced song
            val syncedSongsPayload = allNeededSongIds.mapNotNull { songId ->
                val song = songDao.getSongById(songId) ?: CatalogSeed.defaultSongs.firstOrNull { it.id == songId }
                song?.let {
                    hashMapOf(
                        "id" to it.id,
                        "title" to it.title,
                        "artist" to it.artist,
                        "genre" to it.genre,
                        "album" to it.album,
                        "coverUrl" to it.coverUrl,
                        "audioUrl" to it.audioUrl,
                        "durationSeconds" to it.durationSeconds,
                        "isFavorite" to (favoriteSongIds.contains(it.id) || it.isFavorite)
                    )
                }
            }

            val foldersPayload = customFolders.map { folder ->
                val songIds = folderDao.getSongIdsInFolderOnce(folder.id)
                val folderSongsPayload = songIds.mapNotNull { sId ->
                    val s = songDao.getSongById(sId) ?: CatalogSeed.defaultSongs.firstOrNull { it.id == sId }
                    s?.let {
                        hashMapOf(
                            "id" to it.id,
                            "title" to it.title,
                            "artist" to it.artist,
                            "genre" to it.genre,
                            "album" to it.album,
                            "coverUrl" to it.coverUrl,
                            "audioUrl" to it.audioUrl,
                            "durationSeconds" to it.durationSeconds
                        )
                    }
                }
                hashMapOf(
                    "id" to folder.id,
                    "name" to folder.name,
                    "isDefault" to folder.isDefault,
                    "createdAt" to folder.createdAt,
                    "songIds" to songIds,
                    "songs" to folderSongsPayload
                )
            }

            val activeUser = db.userDao().getUserById(userId)
            val firestore = FirebaseFirestore.getInstance()
            val pushTimestamp = System.currentTimeMillis()
            lastLocalPushTimestamp = pushTimestamp

            val payload = hashMapOf<String, Any>(
                "favoriteSongIds" to favoriteSongIds,
                "userFolders" to foldersPayload,
                "syncedSongs" to syncedSongsPayload,
                "lastFoldersSyncedAt" to pushTimestamp
            )

            if (activeUser != null) {
                if (activeUser.photoUrl.isNotBlank()) {
                    if (activeUser.photoUrl.startsWith("http") || activeUser.photoUrl.startsWith("data:image")) {
                        payload["photoUrl"] = activeUser.photoUrl
                    } else {
                        val file = java.io.File(activeUser.photoUrl)
                        if (file.exists() && file.length() > 0) {
                            try {
                                val bytes = file.readBytes()
                                val b64 = "data:image/jpeg;base64," + android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP)
                                payload["photoUrl"] = b64
                            } catch (e: Exception) {
                                payload["photoUrl"] = activeUser.photoUrl
                            }
                        } else {
                            payload["photoUrl"] = activeUser.photoUrl
                        }
                    }
                }
                if (activeUser.themeConfig.isNotBlank()) {
                    payload["themeConfig"] = activeUser.themeConfig
                }
            }

            withTimeoutOrNull(6000L) {
                firestore.collection(USERS_COLLECTION).document(userId)
                    .set(payload, SetOptions.merge())
                    .await()
            }
            Log.d(TAG, "Pushed ${favoriteSongIds.size} favorites, ${syncedSongsPayload.size} full song metadata records, and ${foldersPayload.size} folders to cloud for user '$userId'")
        } catch (e: Exception) {
            Log.w(TAG, "Failed to sync folders and favorites to cloud: ${e.message}")
        }
    }

    /**
     * Restores user's favorites, folders, and FULL song entities from Firestore into local Room DB.
     * Perfect for when the user logs into a new phone (Celular B) or reopens the app.
     */
    suspend fun restoreUserDataFromCloud(context: Context, userId: String): Boolean = withContext(Dispatchers.IO) {
        if (userId.isBlank()) return@withContext false
        try {
            val firestore = FirebaseFirestore.getInstance()
            val doc = withTimeoutOrNull(7000L) {
                firestore.collection(USERS_COLLECTION).document(userId).get().await()
            } ?: return@withContext false

            if (!doc.exists()) {
                Log.d(TAG, "User document for '$userId' does not exist in Firestore")
                return@withContext false
            }

            restoreFromDocumentSnapshot(context, doc, userId)
        } catch (e: Exception) {
            Log.e(TAG, "Error restoring user data from cloud: ${e.message}", e)
            false
        }
    }

    /**
     * Core restore logic from a Firestore DocumentSnapshot.
     * Inserts all missing SongEntity items into Room first, so that queries and joins succeed.
     */
    suspend fun restoreFromDocumentSnapshot(context: Context, doc: DocumentSnapshot, userId: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val db = DriyDatabase.getInstance(context)
            val userDao = db.userDao()
            val songDao = db.songDao()
            val folderDao = db.folderDao()

            // 0. Restore photoUrl & themeConfig from Firestore
            val cloudPhotoUrl = doc.getString("photoUrl")
            if (!cloudPhotoUrl.isNullOrBlank()) {
                val cleanUser = userId.trim().lowercase()
                var resolvedPhotoUrl = cloudPhotoUrl
                if (cloudPhotoUrl.startsWith("data:image") || (cloudPhotoUrl.length > 300 && !cloudPhotoUrl.startsWith("http"))) {
                    try {
                        val cleanBase64 = if (cloudPhotoUrl.contains(",")) cloudPhotoUrl.substringAfter(",") else cloudPhotoUrl
                        val bytes = android.util.Base64.decode(cleanBase64.trim(), android.util.Base64.DEFAULT)
                        val avatarFile = java.io.File(context.filesDir, "avatar_${cleanUser}.jpg")
                        avatarFile.writeBytes(bytes)
                        resolvedPhotoUrl = avatarFile.absolutePath
                    } catch (e: Exception) {
                        Log.w(TAG, "Error decoding cloud base64 avatar: ${e.message}")
                    }
                }
                userDao.updatePhotoUrl(userId, resolvedPhotoUrl)
            }
            val cloudThemeConfig = doc.getString("themeConfig")
            if (!cloudThemeConfig.isNullOrBlank()) {
                userDao.updateThemeConfig(userId, cloudThemeConfig)
                com.example.ui.theme.ThemeManager.loadUserTheme(userId, cloudThemeConfig)
            }

            @Suppress("UNCHECKED_CAST")
            val favoriteSongIds = (doc.get("favoriteSongIds") as? List<*>)?.mapNotNull { it as? String } ?: emptyList()
            @Suppress("UNCHECKED_CAST")
            val foldersRaw = (doc.get("userFolders") as? List<*>)?.filterIsInstance<Map<String, Any>>() ?: emptyList()
            @Suppress("UNCHECKED_CAST")
            val syncedSongsRaw = (doc.get("syncedSongs") as? List<*>)?.filterIsInstance<Map<String, Any>>() ?: emptyList()

            // 1. Parse and collect all song entities from 'syncedSongs' and from folder maps
            val songsToInsert = mutableMapOf<String, SongEntity>()

            for (sMap in syncedSongsRaw) {
                val sId = sMap["id"] as? String ?: continue
                val sTitle = sMap["title"] as? String ?: "Canción"
                val sArtist = sMap["artist"] as? String ?: "Artista"
                val sGenre = sMap["genre"] as? String ?: "Música"
                val sAlbum = sMap["album"] as? String ?: "DriyMusic"
                val sCover = sMap["coverUrl"] as? String ?: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=500&q=80"
                val sAudio = sMap["audioUrl"] as? String ?: ""
                val sDuration = ((sMap["durationSeconds"] as? Number)?.toInt()) ?: 210
                val sIsFav = (sMap["isFavorite"] as? Boolean) ?: favoriteSongIds.contains(sId)

                songsToInsert[sId] = SongEntity(
                    id = sId,
                    title = sTitle,
                    artist = sArtist,
                    genre = sGenre,
                    album = sAlbum,
                    coverUrl = sCover,
                    audioUrl = sAudio,
                    durationSeconds = sDuration,
                    isFavorite = sIsFav,
                    isDownloaded = false,
                    localFilePath = null
                )
            }

            // Also check songs embedded inside folder objects
            for (fMap in foldersRaw) {
                @Suppress("UNCHECKED_CAST")
                val fSongs = (fMap["songs"] as? List<*>)?.filterIsInstance<Map<String, Any>>() ?: emptyList()
                for (sMap in fSongs) {
                    val sId = sMap["id"] as? String ?: continue
                    if (!songsToInsert.containsKey(sId)) {
                        val sTitle = sMap["title"] as? String ?: "Canción"
                        val sArtist = sMap["artist"] as? String ?: "Artista"
                        val sGenre = sMap["genre"] as? String ?: "Música"
                        val sAlbum = sMap["album"] as? String ?: "DriyMusic"
                        val sCover = sMap["coverUrl"] as? String ?: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=500&q=80"
                        val sAudio = sMap["audioUrl"] as? String ?: ""
                        val sDuration = ((sMap["durationSeconds"] as? Number)?.toInt()) ?: 210

                        songsToInsert[sId] = SongEntity(
                            id = sId,
                            title = sTitle,
                            artist = sArtist,
                            genre = sGenre,
                            album = sAlbum,
                            coverUrl = sCover,
                            audioUrl = sAudio,
                            durationSeconds = sDuration,
                            isFavorite = favoriteSongIds.contains(sId),
                            isDownloaded = false,
                            localFilePath = null
                        )
                    }
                }
            }

            // 2. Guarantee recovery for any referenced song ID that had no synced payload (e.g. legacy sync)
            val allFolderSongIds = foldersRaw.flatMap { fMap ->
                @Suppress("UNCHECKED_CAST")
                (fMap["songIds"] as? List<*>)?.mapNotNull { it as? String } ?: emptyList()
            }
            val allReferencedIds = (favoriteSongIds + allFolderSongIds).distinct()

            for (refId in allReferencedIds) {
                if (!songsToInsert.containsKey(refId)) {
                    val existing = songDao.getSongById(refId)
                    if (existing != null) {
                        songsToInsert[refId] = existing
                    } else {
                        // Check CatalogSeed
                        val catalogSong = CatalogSeed.defaultSongs.firstOrNull { it.id == refId }
                        if (catalogSong != null) {
                            songsToInsert[refId] = catalogSong.copy(isFavorite = favoriteSongIds.contains(refId))
                        } else {
                            // Recover with valid player metadata so the song is NEVER blank or missing
                            val isYt = refId.length == 11 && !refId.contains(" ")
                            val audioUrl = if (isYt) "https://www.youtube.com/watch?v=$refId" else ""
                            val coverUrl = if (isYt) "https://i.ytimg.com/vi/$refId/hqdefault.jpg" else "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=500&q=80"
                            songsToInsert[refId] = SongEntity(
                                id = refId,
                                title = "Canción ($refId)",
                                artist = "Artista Sincronizado",
                                genre = "Variado",
                                album = "Colección Nube",
                                coverUrl = coverUrl,
                                audioUrl = audioUrl,
                                durationSeconds = 210,
                                isFavorite = favoriteSongIds.contains(refId),
                                isDownloaded = false,
                                localFilePath = null
                            )
                        }
                    }
                }
            }

            // Insert all recovered/synced songs into Room database so queries and joins work!
            if (songsToInsert.isNotEmpty()) {
                songDao.insertSongs(songsToInsert.values.toList())
                Log.d(TAG, "Restored and inserted ${songsToInsert.size} songs into local database for user '$userId'")
            }

            // 3. Restore favorite songs
            songDao.clearAllFavorites()
            folderDao.deleteSongsInFolder("favorites")
            if (folderDao.getFolderById("favorites") == null) {
                folderDao.insertFolder(FolderEntity(id = "favorites", name = "Favoritos", isDefault = true))
            }
            for (songId in favoriteSongIds) {
                songDao.updateFavorite(songId, true)
                folderDao.addSongToFolder(FolderSongCrossRef("favorites", songId))
            }

            // 4. Restore custom folders and their assigned songs
            folderDao.clearCustomFolders()
            for (folderMap in foldersRaw) {
                val fId = folderMap["id"] as? String ?: continue
                if (fId == "favorites") continue
                val fName = folderMap["name"] as? String ?: "Carpeta"
                val fCreated = (folderMap["createdAt"] as? Long)
                    ?: ((folderMap["createdAt"] as? Number)?.toLong())
                    ?: System.currentTimeMillis()
                @Suppress("UNCHECKED_CAST")
                val songIds = (folderMap["songIds"] as? List<*>)?.mapNotNull { it as? String } ?: emptyList()

                folderDao.insertFolder(
                    FolderEntity(
                        id = fId,
                        name = fName,
                        isDefault = false,
                        createdAt = fCreated
                    )
                )
                folderDao.deleteSongsInFolder(fId)
                for (sId in songIds) {
                    folderDao.addSongToFolder(FolderSongCrossRef(fId, sId))
                }
            }

            Log.d(TAG, "Successfully restored ${favoriteSongIds.size} favorites and ${foldersRaw.size} custom folders for user '$userId' from cloud")
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error in restoreFromDocumentSnapshot: ${e.message}", e)
            false
        }
    }

    /**
     * Starts real-time listening on Firestore for changes made by other devices (Celular A -> Celular B).
     */
    fun startRealtimeUserSync(context: Context, userId: String) {
        if (userId.isBlank()) return
        if (activeListeningUserId == userId && realtimeListenerRegistration != null) return

        stopRealtimeUserSync()
        activeListeningUserId = userId

        try {
            val firestore = FirebaseFirestore.getInstance()
            realtimeListenerRegistration = firestore.collection(USERS_COLLECTION)
                .document(userId)
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        Log.w(TAG, "Realtime cloud sync listen failed: ${error.message}")
                        return@addSnapshotListener
                    }
                    if (snapshot != null && snapshot.exists()) {
                        val cloudSyncTime = snapshot.getLong("lastFoldersSyncedAt") ?: 0L
                        // Only trigger restore if cloud has a newer change than our last local push
                        if (cloudSyncTime > lastLocalPushTimestamp) {
                            Log.d(TAG, "Real-time cloud update detected from another device, updating local library...")
                            syncScope.launch {
                                restoreFromDocumentSnapshot(context, snapshot, userId)
                            }
                        }
                    }
                }
            Log.d(TAG, "Started real-time cloud sync listener for user '$userId'")
        } catch (e: Exception) {
            Log.w(TAG, "Could not start real-time sync listener: ${e.message}")
        }
    }

    /**
     * Stops the real-time Firestore listener.
     */
    fun stopRealtimeUserSync() {
        try {
            realtimeListenerRegistration?.remove()
            realtimeListenerRegistration = null
            activeListeningUserId = null
        } catch (e: Exception) {
            Log.w(TAG, "Error stopping real-time listener: ${e.message}")
        }
    }

    /**
     * Clears local user favorites and custom folders when signing out so that
     * another account or fresh session starts clean.
     */
    suspend fun clearLocalUserDataOnSignOut(context: Context) = withContext(Dispatchers.IO) {
        try {
            stopRealtimeUserSync()
            val db = DriyDatabase.getInstance(context)
            db.songDao().clearAllFavorites()
            val folderDao = db.folderDao()
            folderDao.clearCustomFolders()
            folderDao.clearAllFolderSongs()
            if (folderDao.getFolderById("favorites") == null) {
                folderDao.insertFolder(FolderEntity(id = "favorites", name = "Favoritos", isDefault = true))
            }
            Log.d(TAG, "Cleared local folders and favorites on sign out")
        } catch (e: Exception) {
            Log.w(TAG, "Error clearing local data on sign out: ${e.message}")
        }
    }
}
