package com.example.service

import android.content.Context
import android.util.Log
import com.example.data.model.SongEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

/**
 * Instant Audio Cache Manager for Zero-Latency Track Switching (Gapless Playback).
 * Preloads the first 5 seconds of the next song in the playback queue in the background.
 */
object InstantAudioCacheManager {
    private const val TAG = "InstantAudioCache"
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var appContext: Context? = null

    private val _preloadedSongId = MutableStateFlow<String?>(null)
    val preloadedSongId: StateFlow<String?> = _preloadedSongId.asStateFlow()

    private val _isPreloading = MutableStateFlow(false)
    val isPreloading: StateFlow<Boolean> = _isPreloading.asStateFlow()

    private var currentPreloadJob: Job? = null
    private val cachedAudioFiles = ConcurrentHashMap<String, File>()

    fun init(context: Context) {
        appContext = context.applicationContext
    }

    /**
     * Preloads the next upcoming song in the queue:
     * 1. Fetches lyrics into memory cache so they illuminate instantly.
     * 2. For YouTube streaming, warms up the standby browser engine to buffer the first 5 seconds.
     * 3. For direct audio, pre-downloads the first 512KB-1MB chunk for instant local file seek.
     */
    fun preloadNextSong(song: SongEntity?) {
        if (song == null) return
        val ctx = appContext ?: return

        if (_preloadedSongId.value == song.id) {
            Log.d(TAG, "Song '${song.title}' already preloaded in cache")
            return
        }

        currentPreloadJob?.cancel()
        currentPreloadJob = scope.launch {
            _isPreloading.value = true
            try {
                Log.i(TAG, "⚡ [Cero Espera] Pre-cargando primeros segundos de: ${song.title} - ${song.artist}")

                // 1. Preload lyrics in background into LRCLIB cache
                try {
                    LrclibLyricsService.fetchLyrics(song)
                } catch (e: Exception) {
                    // non-fatal
                }

                // 2. Determine source type
                val isYouTube = song.audioUrl.contains("youtube.com") ||
                        song.audioUrl.contains("youtu.be") ||
                        !song.audioUrl.startsWith("http") ||
                        song.audioUrl.length < 15

                if (isYouTube) {
                    val videoId = if (song.audioUrl.contains("v=")) {
                        song.audioUrl.substringAfter("v=").substringBefore("&").substringBefore("?")
                    } else if (song.audioUrl.contains("youtu.be/")) {
                        song.audioUrl.substringAfter("youtu.be/").substringBefore("?").substringBefore("&")
                    } else {
                        song.id
                    }
                    YouTubeAudioPlayer.preload(videoId)
                } else {
                    // Direct audio file (mp3/m4a/wav)
                    preloadDirectAudioChunk(ctx, song)
                    _preloadedSongId.value = song.id
                    DriyAudioPlayer.onSongPreloaded(song.id)
                }
            } catch (e: Exception) {
                Log.w(TAG, "Preload notice for '${song.title}': ${e.message}")
            } finally {
                _isPreloading.value = false
            }
        }
    }

    fun onPreloadCompleted(videoId: String) {
        _preloadedSongId.value = videoId
        _isPreloading.value = false
        Log.i(TAG, "⚡ [Cero Espera] Buffer de 5 segundos precargado para: $videoId (Gapless listo)")
        DriyAudioPlayer.onSongPreloaded(videoId)
    }

    fun isSongPreloaded(songId: String): Boolean {
        return _preloadedSongId.value == songId
    }

    fun clearPreload() {
        _preloadedSongId.value = null
        _isPreloading.value = false
    }

    private fun preloadDirectAudioChunk(context: Context, song: SongEntity) {
        try {
            val cacheDir = File(context.cacheDir, "instant_audio_cache").apply { mkdirs() }
            val cacheFile = File(cacheDir, "${song.id}.part")
            if (cacheFile.exists() && cacheFile.length() > 64 * 1024) {
                cachedAudioFiles[song.id] = cacheFile
                return
            }

            val client = OkHttpClient.Builder()
                .connectTimeout(4, TimeUnit.SECONDS)
                .readTimeout(5, TimeUnit.SECONDS)
                .build()

            // Pre-download first 512KB (first 15-30 seconds of standard audio)
            val request = Request.Builder()
                .url(song.audioUrl)
                .header("Range", "bytes=0-524287")
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful || response.code == 206) {
                    val bytes = response.body?.bytes()
                    if (bytes != null && bytes.isNotEmpty()) {
                        FileOutputStream(cacheFile).use { fos ->
                            fos.write(bytes)
                        }
                        cachedAudioFiles[song.id] = cacheFile
                        Log.i(TAG, "Cached direct audio chunk (${bytes.size} bytes) for ${song.title}")
                    }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error caching direct audio chunk: ${e.message}")
        }
    }

    fun getCachedFile(songId: String): File? {
        val f = cachedAudioFiles[songId]
        if (f != null && f.exists() && f.length() > 0) return f
        val local = File(appContext?.cacheDir, "instant_audio_cache/${songId}.part")
        return if (local.exists() && local.length() > 0) local else null
    }
}
