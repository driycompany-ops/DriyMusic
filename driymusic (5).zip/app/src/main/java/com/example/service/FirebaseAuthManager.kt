package com.example.service

import android.content.Context
import android.util.Log
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import com.example.data.model.UserEntity
import com.example.data.repository.UserRepository
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

class FirebaseAuthManager(
    private val context: Context,
    private val userRepository: UserRepository
) {
    private val credentialManager = CredentialManager.create(context)
    private val firebaseAuth: FirebaseAuth? by lazy {
        try {
            if (FirebaseApp.getApps(context).isNotEmpty()) {
                FirebaseAuth.getInstance()
            } else {
                null
            }
        } catch (e: Exception) {
            Log.w(TAG, "FirebaseApp not initialized, will operate with local persistence", e)
            null
        }
    }

    companion object {
        private const val TAG = "FirebaseAuthManager"
        const val DEFAULT_WEB_CLIENT_ID = "162474433274-asou9sntp074salv7tvnao73upmnhstr.apps.googleusercontent.com"
    }

    suspend fun getPersistedUser(): UserEntity? = withContext(Dispatchers.IO) {
        if (userRepository.isUserLoggedIn()) {
            return@withContext userRepository.getActiveUser()
        }
        null
    }

    suspend fun signInWithGoogleCredentialManager(
        activityContext: Context,
        serverClientId: String = DEFAULT_WEB_CLIENT_ID,
        customName: String? = null
    ): Result<UserEntity> = withContext(Dispatchers.IO) {
        try {
            val googleIdOption = GetGoogleIdOption.Builder()
                .setFilterByAuthorizedAccounts(false)
                .setServerClientId(serverClientId)
                .setAutoSelectEnabled(false)
                .build()

            val credentialRequest = GetCredentialRequest.Builder()
                .addCredentialOption(googleIdOption)
                .build()

            val result = credentialManager.getCredential(
                context = activityContext,
                request = credentialRequest
            )

            val credential = result.credential
            if (credential is CustomCredential && credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val googleIdTokenCredential = GoogleIdTokenCredential.createFrom(credential.data)
                val idToken = googleIdTokenCredential.idToken
                var firebaseUser: FirebaseUser? = null

                if (firebaseAuth != null) {
                    try {
                        val authCredential = GoogleAuthProvider.getCredential(idToken, null)
                        val authResult = firebaseAuth!!.signInWithCredential(authCredential).await()
                        firebaseUser = authResult.user
                    } catch (e: Exception) {
                        Log.w(TAG, "FirebaseAuth.signInWithCredential failed: ${e.message}")
                    }
                }

                val userId = firebaseUser?.uid ?: googleIdTokenCredential.id
                val chosenName = if (!customName.isNullOrBlank()) {
                    customName.trim()
                } else {
                    firebaseUser?.displayName ?: googleIdTokenCredential.displayName ?: "Oyente DriyMusic"
                }
                val email = firebaseUser?.email ?: googleIdTokenCredential.id
                val photoUrl = firebaseUser?.photoUrl?.toString() ?: googleIdTokenCredential.profilePictureUri?.toString()
                    ?: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400&q=80"

                val user = userRepository.signInWithGoogle(
                    googleId = userId,
                    name = chosenName,
                    email = email,
                    photoUrl = photoUrl
                )
                return@withContext Result.success(user)
            } else {
                throw IllegalStateException("Tipo de credencial inesperado: ${credential::class.java.name}")
            }
        } catch (e: GetCredentialCancellationException) {
            Log.d(TAG, "User cancelled Google Sign-In")
            return@withContext Result.failure(e)
        } catch (e: Exception) {
            Log.w(TAG, "Credential Manager fallback: ${e.message}")
            val chosenName = if (!customName.isNullOrBlank()) customName.trim() else "Andriy"
            val safeId = "user_" + chosenName.lowercase().replace(" ", "_").ifEmpty { "oyente" }
            val fallbackUser = userRepository.signInWithGoogle(
                googleId = safeId,
                name = chosenName,
                email = "${chosenName.lowercase().replace(" ", "")}@driystream.com",
                photoUrl = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400&q=80"
            )
            return@withContext Result.success(fallbackUser)
        }
    }

    suspend fun signOut() = withContext(Dispatchers.IO) {
        try {
            firebaseAuth?.signOut()
            credentialManager.clearCredentialState(ClearCredentialStateRequest())
        } catch (e: Exception) {
            Log.e(TAG, "Error clearing credential state: ${e.message}")
        }
        userRepository.signOut()
    }

    suspend fun deleteAccount(): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val user = userRepository.getActiveUser()
            val userId = user?.id ?: ""
            val rawUsername = user?.username ?: userId
            val cleanUsername = rawUsername.trim().removePrefix("@").lowercase()
            val cleanPhone = (user?.phoneNumber ?: "").filter { it.isDigit() }
            val userEmail = user?.email ?: ""

            Log.d(TAG, "Initiating permanent account deletion for '$cleanUsername' (id: $userId, phone: $cleanPhone)")

            // 1. Attempt deletion from Firebase Auth if current user exists
            try {
                firebaseAuth?.currentUser?.delete()?.await()
            } catch (e: Exception) {
                Log.w(TAG, "FirebaseAuth currentUser delete skipped or failed: ${e.message}")
            }

            // 2. Comprehensive deletion from Firestore driystream_users & sessions
            try {
                val firestore = com.google.firebase.firestore.FirebaseFirestore.getInstance()

                // Direct document deletions
                val docIdsToDelete = listOfNotNull(
                    userId.takeIf { it.isNotBlank() },
                    cleanUsername.takeIf { it.isNotBlank() },
                    rawUsername.takeIf { it.isNotBlank() }
                ).distinct()

                for (docId in docIdsToDelete) {
                    try {
                        firestore.collection("driystream_users").document(docId).delete().await()
                        firestore.collection("driystream_sessions").document(docId).delete().await()
                    } catch (e: Exception) {
                        Log.w(TAG, "Error deleting docId '$docId': ${e.message}")
                    }
                }

                // Query and purge by username field
                if (cleanUsername.isNotBlank()) {
                    try {
                        val byUsername = firestore.collection("driystream_users")
                            .whereEqualTo("username", cleanUsername)
                            .get()
                            .await()
                        for (doc in byUsername.documents) {
                            doc.reference.delete().await()
                        }
                    } catch (e: Exception) {
                        Log.w(TAG, "Error purging docs by username: ${e.message}")
                    }
                }

                // Query and purge by phone field
                if (cleanPhone.isNotBlank()) {
                    try {
                        val byPhone = firestore.collection("driystream_users")
                            .whereEqualTo("phoneNumber", cleanPhone)
                            .get()
                            .await()
                        for (doc in byPhone.documents) {
                            doc.reference.delete().await()
                        }
                    } catch (e: Exception) {
                        Log.w(TAG, "Error purging docs by phone: ${e.message}")
                    }
                }

                // Query and purge by email field
                if (userEmail.isNotBlank()) {
                    try {
                        val byEmail = firestore.collection("driystream_users")
                            .whereEqualTo("email", userEmail)
                            .get()
                            .await()
                        for (doc in byEmail.documents) {
                            doc.reference.delete().await()
                        }
                    } catch (e: Exception) {
                        Log.w(TAG, "Error purging docs by email: ${e.message}")
                    }
                }

                // Write tombstone to driystream_deleted_accounts to permanently prevent re-login
                val deletedInfo = hashMapOf<String, Any>(
                    "deletedAt" to System.currentTimeMillis(),
                    "username" to cleanUsername,
                    "phoneNumber" to cleanPhone
                )
                if (cleanUsername.isNotBlank()) {
                    firestore.collection("driystream_deleted_accounts").document(cleanUsername).set(deletedInfo).await()
                }
                if (cleanPhone.isNotBlank()) {
                    firestore.collection("driystream_deleted_accounts").document(cleanPhone).set(deletedInfo).await()
                }
                Log.d(TAG, "Firestore completely cleared and tombstone written for '$cleanUsername'")
            } catch (e: Exception) {
                Log.w(TAG, "Firestore cleanup exception: ${e.message}")
            }

            // 3. Clear from Global User Sync store
            try {
                GlobalUserSyncClient.deleteUserGlobal(cleanUsername, cleanPhone)
            } catch (e: Exception) {
                Log.w(TAG, "GlobalUserSync delete error: ${e.message}")
            }

            // 4. Clear Credential Manager
            try {
                credentialManager.clearCredentialState(ClearCredentialStateRequest())
            } catch (e: Exception) {
                // Ignore
            }

            // 5. Clear local Room database and preferences
            userRepository.deleteUser(userId)
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "Error in deleteAccount: ${e.message}", e)
            userRepository.deleteUser(null)
            Result.success(Unit)
        }
    }
}
