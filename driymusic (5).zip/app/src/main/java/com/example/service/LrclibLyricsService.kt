package com.example.service

import android.util.Log
import com.example.data.model.LyricLine
import com.example.data.model.LyricsData
import com.example.data.model.SongEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.text.Normalizer
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern
import kotlin.math.abs

object LrclibLyricsService {
    private const val TAG = "LrclibLyricsService"
    private const val BASE_URL = "https://lrclib.net/api"

    private val client = OkHttpClient.Builder()
        .connectTimeout(6, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    // In-memory cache by song ID and normalized query
    private val lyricsCache = ConcurrentHashMap<String, LyricsData>()

    /**
     * Cleans common YouTube/metadata artifacts from song titles (e.g. "(Official Video)", "feat. X", "[HD]")
     */
    fun cleanTrackTitle(title: String): String {
        var cleaned = title
        // Remove URLs if any
        cleaned = cleaned.replace(Regex("(?i)\\b(https?://\\S+|www\\.\\S+)\\b"), "")
        // Remove trailing descriptors after pipe or double slash (e.g. "Song | Video Oficial")
        cleaned = cleaned.replace(Regex("(?i)\\|.*$"), "")
        cleaned = cleaned.replace(Regex("(?i)//.*$"), "")
        // Remove parenthesized video/audio descriptors
        cleaned = cleaned.replace(
            Regex("(?i)\\((?:official|video oficial|official video|official audio|audio oficial|letra|lyrics?|videoclip|clip oficial|video|audio|visualizer|360 visualizer|lyric video|video lyric|prod\\.?\\s*by[^)]*|en vivo|live|remastered|4k|hd|hq|version)[^)]*\\)"),
            " "
        )
        cleaned = cleaned.replace(
            Regex("(?i)\\[(?:official|video oficial|official video|official audio|audio oficial|letra|lyrics?|videoclip|clip oficial|video|audio|visualizer|360 visualizer|lyric video|video lyric|prod\\.?\\s*by[^\\]]*|en vivo|live|remastered|4k|hd|hq|version)[^\\]]*\\]"),
            " "
        )
        // Remove standalone descriptive noise words
        cleaned = cleaned.replace(
            Regex("(?i)\\b(official video|video oficial|official audio|audio oficial|video clip|videoclip oficial|lyric video|video con letra|official lyric|official visualizer)\\b"),
            " "
        )
        cleaned = cleaned.replace(
            Regex("(?i)\\b(official|videoclip|visualizer|remastered|hd|4k|hq)\\b"),
            " "
        )
        // Remove feat. / ft. expressions
        cleaned = cleaned.replace(Regex("(?i)\\b(feat|ft|featuring)\\.?\\s+[^,-|/()]+"), " ")
        cleaned = cleaned.replace(Regex("(?i)\\b(feat|ft|featuring)\\.?\\b"), " ")
        cleaned = cleaned.replace(Regex("(?i)\\b(feat|ft|featuring)\\."), " ")
        // Remove empty brackets/parentheses
        cleaned = cleaned.replace(Regex("\\(\\s*\\)|\\[\\s*\\]|\\{\\s*\\}"), " ")
        // Remove special punctuation, quotes
        cleaned = cleaned.replace(Regex("[\"'_~`#]"), " ")
        // Normalize whitespace
        cleaned = cleaned.replace(Regex("\\s+"), " ").trim()
        return cleaned
    }

    /**
     * Cleans common YouTube artist/channel artifacts (e.g. "Bad Bunny - Topic", "KarolGVEVO", "Coldplay Channel")
     */
    fun cleanArtistName(artist: String): String {
        var cleaned = artist
        // YouTube Auto-generated Topic channels
        cleaned = cleaned.replace(Regex("(?i)\\s*-\\s*topic$"), "")
        // VEVO suffixes (e.g. "KarolGVEVO", "DuaLipaVEVO")
        cleaned = cleaned.replace(Regex("(?i)vevo$"), "")
        // Standalone channel noise words
        cleaned = cleaned.replace(Regex("(?i)\\b(vevo|official|channel|records|music|topic|canal|entertainment)\\b"), " ")
        cleaned = cleaned.replace(Regex("\\(.*?\\)|\\[.*?\\]"), " ")
        cleaned = cleaned.replace(Regex("[\"'_~`#]"), " ")
        cleaned = cleaned.replace(Regex("\\s+"), " ").trim()
        return cleaned
    }

    data class CandidatePair(
        val trackName: String,
        val artistName: String
    )

    /**
     * Generates potential (track, artist) candidate pairs from song title and artist.
     * Handles formats like "Artist - Title", "Title - Artist", "Artist: Title", multiple artists, etc.
     */
    fun generateCandidatePairs(rawTitle: String, rawArtist: String): List<CandidatePair> {
        val pairs = mutableListOf<CandidatePair>()
        val cleanedTitle = cleanTrackTitle(rawTitle)
        val cleanedArtist = cleanArtistName(rawArtist)

        // Check if raw title contains " - ", " – ", " — "
        val dashRegex = Regex(" [-—–] ")
        if (rawTitle.contains(dashRegex)) {
            val parts = rawTitle.split(dashRegex, limit = 2)
            if (parts.size == 2) {
                val p0 = parts[0].trim()
                val p1 = parts[1].trim()
                val cleanP0 = cleanTrackTitle(p0)
                val cleanP1 = cleanTrackTitle(p1)
                val cleanArtP0 = cleanArtistName(p0)
                val cleanArtP1 = cleanArtistName(p1)

                // Usually in YouTube "Artist - Title", so cleanP1 is track, cleanArtP0 is artist
                if (cleanP1.isNotBlank()) {
                    if (cleanArtP0.isNotBlank()) {
                        pairs.add(CandidatePair(cleanP1, cleanArtP0))
                    }
                    if (cleanedArtist.isNotBlank() && !cleanedArtist.equals("YouTube", ignoreCase = true)) {
                        pairs.add(CandidatePair(cleanP1, cleanedArtist))
                    }
                }
                // Reverse case: "Title - Artist"
                if (cleanP0.isNotBlank()) {
                    if (cleanArtP1.isNotBlank()) {
                        pairs.add(CandidatePair(cleanP0, cleanArtP1))
                    }
                    if (cleanedArtist.isNotBlank() && !cleanedArtist.equals("YouTube", ignoreCase = true)) {
                        pairs.add(CandidatePair(cleanP0, cleanedArtist))
                    }
                }
            }
        }

        // Colon separator (e.g. "Quevedo: Bzrp Music Sessions, Vol. 52")
        if (rawTitle.contains(":")) {
            val parts = rawTitle.split(":", limit = 2)
            if (parts.size == 2) {
                val cleanP0 = cleanTrackTitle(parts[0])
                val cleanP1 = cleanTrackTitle(parts[1])
                if (cleanP1.isNotBlank() && cleanP0.isNotBlank()) {
                    pairs.add(CandidatePair(cleanP1, cleanP0))
                }
            }
        }

        // Standard pair: cleanTrackTitle(rawTitle) and cleanArtistName(rawArtist)
        if (cleanedTitle.isNotBlank() && cleanedArtist.isNotBlank() && !cleanedArtist.equals("YouTube", ignoreCase = true)) {
            pairs.add(CandidatePair(cleanedTitle, cleanedArtist))
        }

        // If artist has multiple collaborators (e.g. "Karol G, Shakira" or "Feid & Young Miko"), add primary artist
        val primaryArtist = cleanedArtist.split(Regex("(?i)[,&x]|\\b(ft\\.?|feat\\.?|y)\\b")).firstOrNull()?.trim()
        if (!primaryArtist.isNullOrBlank() && primaryArtist != cleanedArtist) {
            if (cleanedTitle.isNotBlank()) {
                pairs.add(CandidatePair(cleanedTitle, primaryArtist))
            }
            // Also apply to parts if present
            if (rawTitle.contains(dashRegex)) {
                val parts = rawTitle.split(dashRegex, limit = 2)
                if (parts.size == 2) {
                    val cleanP1 = cleanTrackTitle(parts[1].trim())
                    if (cleanP1.isNotBlank()) {
                        pairs.add(CandidatePair(cleanP1, primaryArtist))
                    }
                }
            }
        }

        // Raw fallback
        if (rawTitle.isNotBlank() && rawArtist.isNotBlank() && !rawArtist.equals("YouTube", ignoreCase = true)) {
            pairs.add(CandidatePair(rawTitle.trim(), rawArtist.trim()))
        }

        return pairs.distinct()
    }

    suspend fun fetchLyrics(song: SongEntity): LyricsData? = withContext(Dispatchers.IO) {
        val cacheKey = song.id
        lyricsCache[cacheKey]?.let { return@withContext it }

        val candidatePairs = generateCandidatePairs(song.title, song.artist)
        val targetDuration = song.durationSeconds

        // 1. Try exact matches on /api/get with duration for each candidate pair
        for (pair in candidatePairs) {
            if (targetDuration > 0) {
                val exactWithDuration = tryGetLyrics(pair.trackName, pair.artistName, targetDuration)
                if (exactWithDuration != null && (exactWithDuration.syncedLyrics.isNotEmpty() || !exactWithDuration.plainLyrics.isNullOrBlank() || exactWithDuration.isInstrumental)) {
                    lyricsCache[cacheKey] = exactWithDuration
                    return@withContext exactWithDuration
                }
            }
        }

        // 2. Try exact matches on /api/get WITHOUT duration parameter
        // This handles small duration differences (e.g. 2-5 sec YouTube video intro vs album track)
        for (pair in candidatePairs) {
            val exactWithoutDuration = tryGetLyrics(pair.trackName, pair.artistName, null)
            if (exactWithoutDuration != null && (exactWithoutDuration.syncedLyrics.isNotEmpty() || !exactWithoutDuration.plainLyrics.isNullOrBlank() || exactWithoutDuration.isInstrumental)) {
                // If it has synced lyrics, verify duration is reasonably close (within 20s or duration is unknown)
                val diff = if (targetDuration > 0 && exactWithoutDuration.durationSeconds > 0) {
                    abs(exactWithoutDuration.durationSeconds - targetDuration)
                } else 0

                if (diff <= 20) {
                    lyricsCache[cacheKey] = exactWithoutDuration
                    return@withContext exactWithoutDuration
                }
            }
        }

        // 3. Try structured search /api/search?track_name=...&artist_name=...
        for (pair in candidatePairs) {
            val structuredResults = trySearchStructured(pair.trackName, pair.artistName)
            if (structuredResults.isNotEmpty()) {
                val best = findBestLyricsMatch(structuredResults, pair.trackName, pair.artistName, targetDuration)
                if (best != null) {
                    lyricsCache[cacheKey] = best
                    return@withContext best
                }
            }
        }

        // 4. Try general search /api/search?q=... with distinct search queries
        val cleanedTitle = cleanTrackTitle(song.title)
        val cleanedArtist = cleanArtistName(song.artist)
        val searchQueries = mutableListOf<String>()

        for (pair in candidatePairs.take(3)) {
            searchQueries.add("${pair.trackName} ${pair.artistName}")
            searchQueries.add(pair.trackName)
        }
        searchQueries.add("$cleanedTitle $cleanedArtist")
        searchQueries.add(cleanedTitle)
        searchQueries.add("${song.title} ${song.artist}")

        for (q in searchQueries.distinct().filter { it.isNotBlank() }) {
            val queryResults = trySearchQueryAll(q)
            if (queryResults.isNotEmpty()) {
                val best = findBestLyricsMatch(queryResults, cleanedTitle, cleanedArtist, targetDuration)
                if (best != null) {
                    lyricsCache[cacheKey] = best
                    return@withContext best
                }
            }
        }

        null
    }

    /**
     * Custom search allowing the user to search lyrics with custom text if YouTube title is obscure.
     */
    suspend fun searchLyricsCustom(query: String, targetDurationSec: Int = 0): LyricsData? = withContext(Dispatchers.IO) {
        if (query.isBlank()) return@withContext null
        val cleanQ = query.trim()
        val candidates = trySearchQueryAll(cleanQ)
        findBestLyricsMatch(candidates, cleanQ, "", targetDurationSec)
    }

    private fun tryGetLyrics(trackName: String, artistName: String, durationSec: Int?): LyricsData? {
        return try {
            val encTrack = URLEncoder.encode(trackName, "UTF-8")
            val encArtist = URLEncoder.encode(artistName, "UTF-8")
            var url = "$BASE_URL/get?track_name=$encTrack&artist_name=$encArtist"
            if (durationSec != null && durationSec > 0) {
                url += "&duration=$durationSec"
            }

            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "DriyMusic-Android/1.0 (https://ai.studio)")
                .header("Accept", "application/json")
                .get()
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string() ?: return null
                    parseLyricsJson(JSONObject(body))
                } else {
                    null
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "tryGetLyrics error for $trackName - $artistName: ${e.message}")
            null
        }
    }

    private fun trySearchStructured(trackName: String, artistName: String): List<LyricsData> {
        return try {
            val encTrack = URLEncoder.encode(trackName, "UTF-8")
            val encArtist = URLEncoder.encode(artistName, "UTF-8")
            val url = "$BASE_URL/search?track_name=$encTrack&artist_name=$encArtist"

            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "DriyMusic-Android/1.0 (https://ai.studio)")
                .header("Accept", "application/json")
                .get()
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string() ?: return emptyList()
                    val array = JSONArray(body)
                    val list = mutableListOf<LyricsData>()
                    for (i in 0 until array.length()) {
                        val item = array.optJSONObject(i) ?: continue
                        list.add(parseLyricsJson(item))
                    }
                    list
                } else {
                    emptyList()
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "trySearchStructured error for $trackName - $artistName: ${e.message}")
            emptyList()
        }
    }

    private fun trySearchQueryAll(query: String): List<LyricsData> {
        return try {
            val encQuery = URLEncoder.encode(query, "UTF-8")
            val url = "$BASE_URL/search?q=$encQuery"

            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "DriyMusic-Android/1.0 (https://ai.studio)")
                .header("Accept", "application/json")
                .get()
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string() ?: return emptyList()
                    val array = JSONArray(body)
                    val list = mutableListOf<LyricsData>()
                    for (i in 0 until minOf(array.length(), 15)) {
                        val item = array.optJSONObject(i) ?: continue
                        list.add(parseLyricsJson(item))
                    }
                    list
                } else {
                    emptyList()
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "trySearchQueryAll error for '$query': ${e.message}")
            emptyList()
        }
    }

    /**
     * Finds the best match candidate from search results.
     * Prioritizes candidates with synced lyrics whose duration closely matches targetDuration.
     * Prevents picking live or remix versions that run out of sync.
     */
    fun findBestLyricsMatch(
        candidates: List<LyricsData>,
        targetTitle: String,
        targetArtist: String,
        targetDurationSec: Int
    ): LyricsData? {
        if (candidates.isEmpty()) return null

        var bestCandidate: LyricsData? = null
        var bestScore = Int.MIN_VALUE

        for (candidate in candidates) {
            val score = calculateMatchScore(candidate, targetTitle, targetArtist, targetDurationSec)
            if (score > bestScore) {
                bestScore = score
                bestCandidate = candidate
            }
        }

        // Only return if it meets a reasonable threshold
        return if (bestScore > 0) bestCandidate else null
    }

    private fun calculateMatchScore(
        candidate: LyricsData,
        targetTitle: String,
        targetArtist: String,
        targetDurationSec: Int
    ): Int {
        var score = 0

        val hasSync = candidate.syncedLyrics.isNotEmpty()
        val hasPlain = !candidate.plainLyrics.isNullOrBlank()

        if (hasSync) {
            score += 150
        } else if (hasPlain) {
            score += 40
        } else if (candidate.isInstrumental) {
            score += 30
        } else {
            return -1000 // no lyrics at all
        }

        // Duration accuracy - CRITICAL for timing sync!
        if (targetDurationSec > 0 && candidate.durationSeconds > 0) {
            val diff = abs(candidate.durationSeconds - targetDurationSec)
            when {
                diff <= 2 -> score += 120 // virtually identical length
                diff <= 4 -> score += 90  // typical video intro/outro padding
                diff <= 7 -> score += 60  // small video intro padding
                diff <= 12 -> score += 20 // moderate discrepancy
                diff <= 20 -> score -= 10
                diff <= 35 -> score -= 60
                else -> {
                    // Massive difference (>35s), likely a live version, extended mix, or wrong track!
                    score -= 160
                }
            }
        }

        // Track title similarity
        val normCandidateTitle = normalizeForMatching(candidate.trackName)
        val normTargetTitle = normalizeForMatching(targetTitle)
        if (normCandidateTitle.isNotBlank() && normTargetTitle.isNotBlank()) {
            if (normCandidateTitle == normTargetTitle) {
                score += 100
            } else if (normCandidateTitle.contains(normTargetTitle) || normTargetTitle.contains(normCandidateTitle)) {
                score += 70
            } else {
                val targetWords = normTargetTitle.split(" ").filter { it.length > 2 }
                val candidateWords = normCandidateTitle.split(" ").filter { it.length > 2 }
                val common = targetWords.intersect(candidateWords.toSet()).size
                if (common > 0) {
                    score += common * 25
                } else {
                    score -= 40
                }
            }
        }

        // Artist similarity
        val normCandidateArtist = normalizeForMatching(candidate.artistName)
        val normTargetArtist = normalizeForMatching(targetArtist)
        if (normCandidateArtist.isNotBlank() && normTargetArtist.isNotBlank()) {
            if (normCandidateArtist == normTargetArtist) {
                score += 80
            } else if (normCandidateArtist.contains(normTargetArtist) || normTargetArtist.contains(normCandidateArtist)) {
                score += 50
            } else {
                val targetArtistWords = normTargetArtist.split(" ").filter { it.length > 2 }
                val candidateArtistWords = normCandidateArtist.split(" ").filter { it.length > 2 }
                val common = targetArtistWords.intersect(candidateArtistWords.toSet()).size
                if (common > 0) {
                    score += common * 20
                } else {
                    score -= 30
                }
            }
        }

        return score
    }

    private fun normalizeForMatching(str: String): String {
        val nfd = Normalizer.normalize(str.lowercase(), Normalizer.Form.NFD)
        return nfd.replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
            .replace(Regex("[^a-z0-9 ]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    private fun parseLyricsJson(obj: JSONObject): LyricsData {
        val track = obj.optString("trackName").ifBlank { obj.optString("name", "") }
        val artist = obj.optString("artistName", "")
        val album = obj.optString("albumName", "")
        val duration = obj.optDouble("duration", 0.0).toInt()
        val instrumental = obj.optBoolean("instrumental", false)
        val rawPlain = obj.optString("plainLyrics", "").trim().takeIf { it.isNotBlank() }
        val rawSynced = obj.optString("syncedLyrics", "").trim().takeIf { it.isNotBlank() }

        val syncedLines = if (!rawSynced.isNullOrBlank()) {
            parseLrcString(rawSynced)
        } else {
            emptyList()
        }

        return LyricsData(
            trackName = track,
            artistName = artist,
            albumName = album,
            durationSeconds = duration,
            syncedLyrics = syncedLines,
            plainLyrics = rawPlain,
            isInstrumental = instrumental,
            hasSync = syncedLines.isNotEmpty()
        )
    }

    /**
     * Parses LRC timestamp format:
     * Supports:
     * - [offset:+/-ms] headers to calibrate file-wide timing
     * - Multiple timestamps on a single line: [00:12.34][01:45.67] Chorus line
     * - Standard [mm:ss.xx] or [mm:ss.xxx] line content
     */
    fun parseLrcString(lrcContent: String): List<LyricLine> {
        val lines = mutableListOf<LyricLine>()
        if (lrcContent.isBlank()) return lines

        var fileOffsetMs = 0L
        val offsetPattern = Pattern.compile("^\\[offset:\\s*([+-]?\\d+)\\]", Pattern.CASE_INSENSITIVE)
        for (line in lrcContent.lines()) {
            val trimmed = line.trim()
            val m = offsetPattern.matcher(trimmed)
            if (m.find()) {
                fileOffsetMs = m.group(1)?.toLongOrNull() ?: 0L
                break
            }
        }

        val timestampPattern = Pattern.compile("\\[(\\d{1,2}):(\\d{2})(?:[.:](\\d{2,3}))?\\]")

        for (rawLine in lrcContent.lines()) {
            val trimmed = rawLine.trim()
            if (trimmed.isBlank()) continue

            // Ignore metadata tags like [ti:], [ar:], [al:], [by:], [re:], [ve:], [offset:], [length:]
            if (isMetadataTag(trimmed)) continue

            val matcher = timestampPattern.matcher(trimmed)
            val timestamps = mutableListOf<Long>()
            while (matcher.find()) {
                val minStr = matcher.group(1) ?: "0"
                val secStr = matcher.group(2) ?: "0"
                val fracStr = matcher.group(3) ?: "0"

                val min = minStr.toLongOrNull() ?: 0L
                val sec = secStr.toLongOrNull() ?: 0L
                val frac = when (fracStr.length) {
                    2 -> (fracStr.toLongOrNull() ?: 0L) * 10L
                    3 -> fracStr.toLongOrNull() ?: 0L
                    1 -> (fracStr.toLongOrNull() ?: 0L) * 100L
                    else -> 0L
                }

                val timeMs = (min * 60L + sec) * 1000L + frac + fileOffsetMs
                timestamps.add(timeMs.coerceAtLeast(0L))
            }

            val text = timestampPattern.matcher(trimmed).replaceAll("").trim()
            if (timestamps.isNotEmpty()) {
                for (t in timestamps) {
                    lines.add(LyricLine(timeMs = t, text = text))
                }
            }
        }

        return lines.sortedBy { it.timeMs }
    }

    private fun isMetadataTag(line: String): Boolean {
        val lower = line.lowercase()
        return lower.startsWith("[ti:") || lower.startsWith("[ar:") ||
                lower.startsWith("[al:") || lower.startsWith("[by:") ||
                lower.startsWith("[offset:") || lower.startsWith("[re:") ||
                lower.startsWith("[ve:") || lower.startsWith("[length:")
    }
}
