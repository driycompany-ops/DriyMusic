package com.example.service

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.example.data.model.SongEntity
import com.example.data.seed.CatalogSeed
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

data class PlayerState(
    val currentSong: SongEntity? = null,
    val isPlaying: Boolean = false,
    val currentPositionMs: Long = 0L,
    val durationMs: Long = 0L,
    val isBuffering: Boolean = false,
    val isShuffle: Boolean = false,
    val isRepeat: Boolean = false,
    val isSmartAutoplay: Boolean = true,
    val autoplayMoodName: String? = null,
    val autoplayVibeDescription: String? = null,
    val queue: List<SongEntity> = emptyList(),
    val preloadedSongId: String? = null,
    val isNativeIslandDetected: Boolean = false,
    val isOverlayPermitted: Boolean = false
)

object DriyAudioPlayer {
    private const val TAG = "DriyAudioPlayer"
    private var mediaPlayer: MediaPlayer? = null
    private val handler = Handler(Looper.getMainLooper())

    private val _playerState = MutableStateFlow(PlayerState())
    val playerState: StateFlow<PlayerState> = _playerState.asStateFlow()

    private var appContext: Context? = null
    private var isAppForeground: Boolean = true
    private val failedVideoIds = mutableSetOf<String>()
    private var isAudioActuallyPlaying = false

    private val playerScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var isFetchingSimilar = false
    private var preloadJob: kotlinx.coroutines.Job? = null
    private var playbackWatchdogJob: kotlinx.coroutines.Job? = null

    var localCatalogProvider: (() -> List<SongEntity>)? = null

    private val progressRunnable = object : Runnable {
        override fun run() {
            val player = mediaPlayer
            if (player != null) {
                try {
                    if (player.isPlaying) {
                        val duration = player.duration.toLong().takeIf { it > 0 } ?: _playerState.value.durationMs
                        val pos = player.currentPosition.toLong()
                        _playerState.value = _playerState.value.copy(
                            currentPositionMs = pos,
                            durationMs = duration
                        )
                        appContext?.let { ctx ->
                            DriyAudioService.updatePlayback(ctx, true, pos, duration)
                        }
                    }
                } catch (e: Exception) {
                    // ignore
                }
            }
            if (_playerState.value.isPlaying && mediaPlayer != null) {
                handler.postDelayed(this, 500)
            }
        }
    }

    fun isNetworkAvailable(context: Context): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
        val activeNetwork = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(activeNetwork) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    fun init(context: Context) {
        appContext = context.applicationContext
        YouTubeAudioPlayer.init(context)
        InstantAudioCacheManager.init(context)
        val hasNative = DynamicIslandDetector.isNativeDynamicIslandPresent(context)
        _playerState.value = _playerState.value.copy(isNativeIslandDetected = hasNative)
    }

    fun onSongPreloaded(songId: String) {
        _playerState.value = _playerState.value.copy(preloadedSongId = songId)
    }

    fun setAppForegroundState(isForeground: Boolean) {
        isAppForeground = isForeground
        appContext?.let { ctx ->
            updateOverlayService(ctx)
        }
    }

    fun ensureAudioFocusAndVolume(context: Context) {
        try {
            val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
            audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0)
            val maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            val currentVol = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
            if (currentVol < (maxVol * 0.4f)) {
                audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, (maxVol * 0.85f).toInt(), 0)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Audio volume setup notice: ${e.message}")
        }
    }

    fun playSong(song: SongEntity, newQueue: List<SongEntity> = emptyList()) {
        val ctx = appContext ?: return
        ensureAudioFocusAndVolume(ctx)
        isAudioActuallyPlaying = false

        val queue = if (newQueue.isNotEmpty()) newQueue else listOf(song)
        releasePlayer()

        val mood = SmartMoodEngine.detectSongMood(song)
        val vibeDesc = SmartMoodEngine.getAutoplayVibeDescription(song)
        val moodName = "${mood.emoji} ${mood.name}"

        // 1. If downloaded file exists, play it directly with native MediaPlayer (100% Offline)
        val downloadsDir = File(ctx.filesDir, "downloads")
        val cleanTitle = song.title.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim()
        val cleanArtist = song.artist.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim()
        val pubDownloadsDir = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS)
        val driyPubDir = File(pubDownloadsDir, "DriyStream")

        val effectiveLocalFile = listOf(
            song.localFilePath?.let { File(it) },
            File(downloadsDir, "${song.id}.m4a"),
            File(downloadsDir, "${song.id}.mp3"),
            File(downloadsDir, "${song.id}.aac"),
            File(downloadsDir, "${song.id}.wav"),
            File(pubDownloadsDir, "$cleanArtist - $cleanTitle.mp3"),
            File(pubDownloadsDir, "$cleanArtist - $cleanTitle.m4a"),
            File(driyPubDir, "$cleanArtist - $cleanTitle.mp3"),
            File(driyPubDir, "$cleanArtist - $cleanTitle.m4a")
        ).firstOrNull { it != null && it.exists() && it.length() > 2000 }

        if (effectiveLocalFile != null) {
            Log.i(TAG, "Playing downloaded offline song: ${song.title} from ${effectiveLocalFile.absolutePath} (size: ${effectiveLocalFile.length()} bytes)")
            val updatedSong = song.copy(isDownloaded = true, localFilePath = effectiveLocalFile.absolutePath)
            playWithMediaPlayer(effectiveLocalFile.absolutePath, updatedSong, queue)
            return
        }

        // 1.5. If direct audio was pre-cached in instant audio cache, play it immediately!
        val cachedChunk = InstantAudioCacheManager.getCachedFile(song.id)
        if (cachedChunk != null && cachedChunk.exists() && cachedChunk.length() > 64 * 1024) {
            Log.i(TAG, "⚡ [Cero Espera] Playing from instant audio pre-cache: ${song.title}")
            playWithMediaPlayer(cachedChunk.absolutePath, song, queue)
            return
        }

        // 2. If direct online audio URL (mp3/ogg/wav) that is not YouTube:
        val isDirectAudio = !song.audioUrl.contains("youtube.com") &&
                !song.audioUrl.contains("youtu.be") &&
                song.audioUrl.startsWith("http") &&
                (song.audioUrl.endsWith(".mp3") || song.audioUrl.endsWith(".m4a") || song.audioUrl.endsWith(".wav"))

        if (isDirectAudio) {
            playWithMediaPlayer(song.audioUrl, song, queue)
            return
        }

        // 3. YouTube audio playback for the user's selected song (Requires network)
        if (!isNetworkConnected(ctx)) {
            Log.w(TAG, "Device is offline and song '${song.title}' has not been downloaded.")
            _playerState.value = _playerState.value.copy(
                currentSong = song,
                isPlaying = false,
                isBuffering = false,
                autoplayMoodName = moodName,
                autoplayVibeDescription = vibeDesc
            )
            return
        }

        val videoId = if (song.audioUrl.contains("v=")) {
            song.audioUrl.substringAfter("v=").substringBefore("&").substringBefore("?")
        } else if (song.audioUrl.contains("youtu.be/")) {
            song.audioUrl.substringAfter("youtu.be/").substringBefore("?").substringBefore("&")
        } else {
            song.id
        }

        _playerState.value = _playerState.value.copy(
            currentSong = song,
            isPlaying = true,
            isBuffering = true,
            currentPositionMs = 0L,
            durationMs = song.durationSeconds * 1000L,
            autoplayMoodName = moodName,
            autoplayVibeDescription = vibeDesc,
            queue = queue
        )

        // Check if queue has 1 or fewer upcoming songs to preload related streams
        val currentIndex = queue.indexOfFirst { it.id == song.id }
        val remaining = if (currentIndex >= 0) queue.size - 1 - currentIndex else 0
        if (remaining <= 1 && _playerState.value.isSmartAutoplay) {
            preloadAutoplaySongs(song)
        }

        DriyAudioService.startService(ctx, song)
        updateOverlayService(ctx)
        YouTubeAudioPlayer.play(videoId)

        // Playback Watchdog: Self-heal if the stream hangs or is blocked without requiring app restart
        playbackWatchdogJob?.cancel()
        playbackWatchdogJob = playerScope.launch {
            kotlinx.coroutines.delay(6500L)
            if (!isAudioActuallyPlaying && _playerState.value.isBuffering) {
                Log.w(TAG, "Watchdog triggered: Song '${song.title}' ($videoId) stuck buffering. Self-recovering...")
                YouTubeAudioPlayer.forceReload(videoId)
                kotlinx.coroutines.delay(4500L)
                if (!isAudioActuallyPlaying && _playerState.value.isBuffering) {
                    Log.w(TAG, "Watchdog: Still stuck after reload. Triggering alternative stream fallback...")
                    onVideoPlaybackFailed(videoId, 100)
                }
            }
        }

        // ⚡ Preload next upcoming song in queue for zero-latency gapless transition
        val nextSong = if (currentIndex in 0 until queue.size - 1) queue[currentIndex + 1] else null
        if (nextSong != null) {
            InstantAudioCacheManager.preloadNextSong(nextSong)
        }
    }

    fun isNetworkConnected(context: Context): Boolean {
        return try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
            val active = cm.activeNetwork ?: return false
            val caps = cm.getNetworkCapabilities(active) ?: return false
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        } catch (e: Exception) {
            true
        }
    }

    fun onVideoPlaybackStarted() {
        playbackWatchdogJob?.cancel()
        isAudioActuallyPlaying = true
        _playerState.value = _playerState.value.copy(
            isPlaying = true,
            isBuffering = false
        )
        // ⚡ Preload next track in queue once current track starts
        val current = _playerState.value.currentSong
        val queue = _playerState.value.queue
        val currentIndex = queue.indexOfFirst { it.id == current?.id }
        val nextSong = if (currentIndex in 0 until queue.size - 1) queue[currentIndex + 1] else null
        if (nextSong != null) {
            InstantAudioCacheManager.preloadNextSong(nextSong)
        }

        appContext?.let { ctx ->
            _playerState.value.currentSong?.let { song ->
                DriyAudioService.updatePlayback(ctx, true, _playerState.value.currentPositionMs, _playerState.value.durationMs)
                updateOverlayService(ctx)
            }
        }
    }

    fun onVideoTimeUpdate(posMs: Long, durMs: Long) {
        if (posMs > 0) {
            playbackWatchdogJob?.cancel()
            isAudioActuallyPlaying = true
        }
        val effectiveDur = if (durMs > 0) durMs else _playerState.value.durationMs
        _playerState.value = _playerState.value.copy(
            currentPositionMs = posMs,
            durationMs = effectiveDur,
            isPlaying = true,
            isBuffering = false
        )
        // ⚡ If nearing end of current track (within last 8 seconds), ensure next song buffer is primed for Gapless playback!
        if (effectiveDur > 12000L && (effectiveDur - posMs) in 1000L..8000L) {
            val current = _playerState.value.currentSong
            val queue = _playerState.value.queue
            val currentIndex = queue.indexOfFirst { it.id == current?.id }
            val nextSong = if (currentIndex in 0 until queue.size - 1) queue[currentIndex + 1] else null
            if (nextSong != null && _playerState.value.preloadedSongId != nextSong.id) {
                InstantAudioCacheManager.preloadNextSong(nextSong)
            }
        }
        appContext?.let { ctx ->
            DriyAudioService.updatePlayback(ctx, true, posMs, effectiveDur)
            updateOverlayService(ctx)
        }
    }

    fun onVideoPlaybackFailed(videoId: String, errorCode: Int) {
        playbackWatchdogJob?.cancel()
        val current = _playerState.value.currentSong ?: return
        Log.w(TAG, "Video $videoId failed with error $errorCode for song: ${current.title} - ${current.artist}")
        if (errorCode != 100 && errorCode != 101 && errorCode != 150 && errorCode != 2 && errorCode != 5) {
            Log.w(TAG, "Ignoring non-playback error code: $errorCode")
            return
        }
        failedVideoIds.add(videoId)
        isAudioActuallyPlaying = false
        playerScope.launch(Dispatchers.IO) {
            try {
                val query = "${current.title} ${current.artist} audio"
                val alternatives = YouTubeService.searchYouTube(query)
                    .filter { it.id != videoId && !failedVideoIds.contains(it.id) }
                val nextVid = alternatives.firstOrNull()
                if (nextVid != null) {
                    Log.i(TAG, "Alternative video found for ${current.title}: ${nextVid.id}")
                    withContext(Dispatchers.Main) {
                        val updatedSong = current.copy(
                            id = nextVid.id,
                            audioUrl = "https://www.youtube.com/watch?v=${nextVid.id}"
                        )
                        playSong(updatedSong, _playerState.value.queue.map { if (it.id == current.id) updatedSong else it })
                    }
                } else {
                    withContext(Dispatchers.Main) {
                        _playerState.value = _playerState.value.copy(
                            isPlaying = false,
                            isBuffering = false
                        )
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error resolving alternative video: ${e.message}")
                withContext(Dispatchers.Main) {
                    _playerState.value = _playerState.value.copy(
                        isPlaying = false,
                        isBuffering = false
                    )
                }
            }
        }
    }

    private fun playWithMediaPlayer(audioSource: String, song: SongEntity, queue: List<SongEntity>) {
        val ctx = appContext ?: return
        YouTubeAudioPlayer.stop()
        releasePlayer()

        val mood = SmartMoodEngine.detectSongMood(song)
        val vibeDesc = SmartMoodEngine.getAutoplayVibeDescription(song)
        val moodName = "${mood.emoji} ${mood.name}"

        _playerState.value = _playerState.value.copy(
            currentSong = song,
            isPlaying = true,
            isBuffering = true,
            currentPositionMs = 0L,
            durationMs = song.durationSeconds * 1000L,
            autoplayMoodName = moodName,
            autoplayVibeDescription = vibeDesc,
            queue = queue
        )

        val currentIndex = queue.indexOfFirst { it.id == song.id }
        val remaining = if (currentIndex >= 0) queue.size - 1 - currentIndex else 0
        if (remaining <= 1 && _playerState.value.isSmartAutoplay) {
            preloadAutoplaySongs(song)
        }

        DriyAudioService.startService(ctx, song)

        // ⚡ Preload next upcoming track for gapless playback
        val nextSong = if (currentIndex in 0 until queue.size - 1) queue[currentIndex + 1] else null
        if (nextSong != null) {
            InstantAudioCacheManager.preloadNextSong(nextSong)
        }

        try {
            val player = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .build()
                )
                setWakeMode(ctx, android.os.PowerManager.PARTIAL_WAKE_LOCK)
                if (audioSource.startsWith("/")) {
                    setDataSource(audioSource)
                } else {
                    setDataSource(ctx, Uri.parse(audioSource))
                }
                setOnPreparedListener { mp ->
                    isAudioActuallyPlaying = true
                    mp.start()
                    val actualDuration = mp.duration.toLong().takeIf { it > 0 } ?: (song.durationSeconds * 1000L)
                    _playerState.value = _playerState.value.copy(
                        isPlaying = true,
                        isBuffering = false,
                        durationMs = actualDuration
                    )
                    handler.removeCallbacks(progressRunnable)
                    handler.post(progressRunnable)
                    DriyAudioService.updatePlayback(ctx, true, 0L, actualDuration)
                    updateOverlayService(ctx)
                }
                setOnCompletionListener {
                    isAudioActuallyPlaying = false
                    onSongCompleted()
                }
                setOnErrorListener { _, what, extra ->
                    Log.w(TAG, "MediaPlayer network error ($what, $extra)")
                    isAudioActuallyPlaying = false
                    playNext()
                    true
                }
                prepareAsync()
            }
            mediaPlayer = player
        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialize media player: ${e.message}", e)
            playNext()
        }
    }

    fun togglePlayPause() {
        val ctx = appContext ?: return
        val currentSong = _playerState.value.currentSong ?: return
        val isCurrentlyPlaying = _playerState.value.isPlaying

        if (mediaPlayer != null) {
            mediaPlayer?.let { player ->
                if (isCurrentlyPlaying) {
                    player.pause()
                    isAudioActuallyPlaying = false
                    _playerState.value = _playerState.value.copy(isPlaying = false)
                    handler.removeCallbacks(progressRunnable)
                } else {
                    ensureAudioFocusAndVolume(ctx)
                    player.start()
                    isAudioActuallyPlaying = true
                    _playerState.value = _playerState.value.copy(isPlaying = true)
                    handler.post(progressRunnable)
                }
            }
            DriyAudioService.updatePlayback(ctx, _playerState.value.isPlaying, _playerState.value.currentPositionMs, _playerState.value.durationMs)
            updateOverlayService(ctx)
            return
        }

        // YouTube audio toggle
        if (isCurrentlyPlaying) {
            YouTubeAudioPlayer.pause()
            isAudioActuallyPlaying = false
            _playerState.value = _playerState.value.copy(isPlaying = false)
        } else {
            ensureAudioFocusAndVolume(ctx)
            YouTubeAudioPlayer.resume()
            isAudioActuallyPlaying = true
            _playerState.value = _playerState.value.copy(isPlaying = true)
        }
        DriyAudioService.updatePlayback(ctx, _playerState.value.isPlaying, _playerState.value.currentPositionMs, _playerState.value.durationMs)
        updateOverlayService(ctx)
    }

    fun duckAudio(duck: Boolean) {
        val volFactor = if (duck) 0.30f else 1.0f
        val ytVol = if (duck) 30 else 100
        try {
            mediaPlayer?.setVolume(volFactor, volFactor)
        } catch (_: Exception) {}
        YouTubeAudioPlayer.setVolume(ytVol)
    }

    fun seekTo(positionMs: Long) {
        val ctx = appContext
        if (mediaPlayer != null) {
            try {
                mediaPlayer?.seekTo(positionMs.toInt())
            } catch (e: Exception) {
                Log.e(TAG, "Seek error", e)
            }
            _playerState.value = _playerState.value.copy(currentPositionMs = positionMs)
            ctx?.let { DriyAudioService.updatePlayback(it, _playerState.value.isPlaying, positionMs, _playerState.value.durationMs) }
            return
        }
        YouTubeAudioPlayer.seekTo(positionMs / 1000f)
        _playerState.value = _playerState.value.copy(currentPositionMs = positionMs)
        ctx?.let { DriyAudioService.updatePlayback(it, _playerState.value.isPlaying, positionMs, _playerState.value.durationMs) }
    }

    fun onSongCompleted() {
        val state = _playerState.value
        val currentSong = state.currentSong
        if (state.isRepeat && currentSong != null) {
            playSong(currentSong, state.queue)
            return
        }
        val queue = state.queue
        val currentIndex = queue.indexOfFirst { it.id == currentSong?.id }

        if (currentIndex in 0 until queue.size - 1) {
            val nextSong = queue[currentIndex + 1]
            playSong(nextSong, queue)
            if (queue.size - 1 - (currentIndex + 1) <= 1 && state.isSmartAutoplay) {
                preloadAutoplaySongs(nextSong)
            }
            return
        }

        if (currentSong != null) {
            if (state.isSmartAutoplay) {
                triggerDynamicAutoplay(currentSong)
            } else {
                _playerState.value = _playerState.value.copy(isPlaying = false, currentPositionMs = 0L)
            }
        } else {
            playNext()
        }
    }

    fun playNext() {
        val state = _playerState.value
        val queue = state.queue
        val currentSong = state.currentSong

        if (queue.isEmpty() && currentSong != null) {
            triggerDynamicAutoplay(currentSong)
            return
        }

        if (queue.isEmpty()) return

        val currentIndex = queue.indexOfFirst { it.id == currentSong?.id }
        if (state.isShuffle) {
            val nextIndex = queue.indices.random()
            val nextSong = queue[nextIndex]
            playSong(nextSong, queue)
            if (state.isSmartAutoplay) preloadAutoplaySongs(nextSong)
        } else if (currentIndex in 0 until queue.size - 1) {
            val nextSong = queue[currentIndex + 1]
            playSong(nextSong, queue)
            if (queue.size - 1 - (currentIndex + 1) <= 1 && state.isSmartAutoplay) {
                preloadAutoplaySongs(nextSong)
            }
        } else if (currentSong != null) {
            triggerDynamicAutoplay(currentSong)
        } else {
            playSong(queue.first(), queue)
        }
    }

    fun playPrevious() {
        val state = _playerState.value
        val queue = state.queue
        if (queue.isEmpty()) return

        val currentIndex = queue.indexOfFirst { it.id == state.currentSong?.id }
        val prevIndex = if (currentIndex <= 0) queue.size - 1 else currentIndex - 1
        playSong(queue[prevIndex], queue)
    }

    fun toggleShuffle() {
        _playerState.value = _playerState.value.copy(isShuffle = !_playerState.value.isShuffle)
    }

    fun toggleRepeat() {
        _playerState.value = _playerState.value.copy(isRepeat = !_playerState.value.isRepeat)
    }

    fun addToQueueNext(song: SongEntity) {
        val state = _playerState.value
        val currentSong = state.currentSong
        if (currentSong == null) {
            playSong(song, listOf(song))
            return
        }
        val queue = state.queue.toMutableList()
        queue.removeAll { it.id == song.id }
        val currentIndex = queue.indexOfFirst { it.id == currentSong.id }
        val insertIndex = if (currentIndex >= 0) currentIndex + 1 else 0
        queue.add(insertIndex.coerceAtMost(queue.size), song)
        _playerState.value = _playerState.value.copy(queue = queue)
    }

    fun addToQueueEnd(song: SongEntity) {
        val state = _playerState.value
        if (state.currentSong == null) {
            playSong(song, listOf(song))
            return
        }
        val queue = state.queue.toMutableList()
        queue.removeAll { it.id == song.id }
        queue.add(song)
        _playerState.value = _playerState.value.copy(queue = queue)
    }

    fun removeFromQueue(songId: String) {
        val state = _playerState.value
        val queue = state.queue.filter { it.id != songId }
        _playerState.value = _playerState.value.copy(queue = queue)
    }

    fun clearQueue() {
        val state = _playerState.value
        val current = state.currentSong
        _playerState.value = _playerState.value.copy(queue = if (current != null) listOf(current) else emptyList())
    }

    fun stop() {
        val ctx = appContext
        isAudioActuallyPlaying = false
        releasePlayer()
        YouTubeAudioPlayer.stop()
        _playerState.value = _playerState.value.copy(isPlaying = false, currentPositionMs = 0L)
        ctx?.let {
            DriyAudioService.updatePlayback(it, false, 0L, _playerState.value.durationMs)
            updateOverlayService(it)
        }
    }

    fun setCustomIslandMode(mode: String) {
        val ctx = appContext ?: return
        val prefs = ctx.getSharedPreferences("driystream_audio_prefs", Context.MODE_PRIVATE)
        prefs.edit().putString("island_mode", mode).apply()
        updateOverlayService(ctx)
    }

    fun getCustomIslandMode(): String {
        val ctx = appContext ?: return "AUTO"
        val prefs = ctx.getSharedPreferences("driystream_audio_prefs", Context.MODE_PRIVATE)
        return prefs.getString("island_mode", "AUTO") ?: "AUTO"
    }

    private fun updateOverlayService(context: Context) {
        val state = _playerState.value
        val song = state.currentSong
        val mode = getCustomIslandMode()

        val shouldShowOverlay = when (mode) {
            "FORCE_OVERLAY" -> song != null && !isAppForeground
            "FORCE_NATIVE" -> false
            "DISABLED" -> false
            else -> song != null && !isAppForeground && !state.isNativeIslandDetected
        }

        if (shouldShowOverlay) {
            DynamicIslandService.show(context, song?.title ?: "", song?.artist ?: "", state.isPlaying)
        } else {
            DynamicIslandService.hide(context)
        }
    }

    private fun releasePlayer() {
        playbackWatchdogJob?.cancel()
        isAudioActuallyPlaying = false
        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
        } catch (e: Exception) {
            // ignore
        }
        mediaPlayer = null
        handler.removeCallbacks(progressRunnable)
    }

    fun toggleSmartAutoplay(): Boolean {
        val newState = !_playerState.value.isSmartAutoplay
        _playerState.value = _playerState.value.copy(isSmartAutoplay = newState)
        if (newState) {
            val song = _playerState.value.currentSong
            if (song != null) {
                preloadAutoplaySongs(song)
            }
        }
        return newState
    }

    fun toggleSmartShuffle(): Boolean {
        val nextShuffle = !_playerState.value.isShuffle
        _playerState.value = _playerState.value.copy(
            isShuffle = nextShuffle,
            isSmartAutoplay = true
        )
        if (_playerState.value.currentSong != null) {
            preloadAutoplaySongs(_playerState.value.currentSong!!)
        }
        return nextShuffle
    }

    fun preloadAutoplaySongs(currentSong: SongEntity) {
        if (!_playerState.value.isSmartAutoplay) return

        val mood = SmartMoodEngine.detectSongMood(currentSong)
        val vibeDesc = SmartMoodEngine.getAutoplayVibeDescription(currentSong)
        val moodName = "${mood.emoji} ${mood.name}"

        _playerState.value = _playerState.value.copy(
            autoplayMoodName = moodName,
            autoplayVibeDescription = vibeDesc
        )

        preloadJob?.cancel()
        preloadJob = playerScope.launch {
            isFetchingSimilar = true
            try {
                val currentQueue = _playerState.value.queue
                val seenIds = (currentQueue.map { it.id } + currentSong.id).toMutableSet()

                // 1. Immediately inject local catalog recommendations ONLY if matching the EXACT musical universe
                val localCatalog = localCatalogProvider?.invoke() ?: CatalogSeed.defaultSongs
                val localMatches = SmartMoodEngine.findLocalCatalogRecommendations(currentSong, localCatalog, seenIds)
                    .filter { YouTubeService.isIndividualSong(it.title, it.durationSeconds, maxDurationSeconds = 300) }
                    .take(2)
                if (localMatches.isNotEmpty()) {
                    seenIds.addAll(localMatches.map { it.id })
                    val immediateQueue = (currentQueue + localMatches).distinctBy { it.id }
                    _playerState.value = _playerState.value.copy(queue = immediateQueue)
                }

                // 2. Concurrently fetch online YouTube related streams (individual songs <= 5 min)
                val isOnline = appContext?.let { isNetworkConnected(it) } ?: false
                if (isOnline) {
                    try {
                        val ytStreams = YouTubeService.getRelatedStreams(currentSong, maxResults = 8)
                            .filter {
                                it.id != currentSong.id &&
                                !seenIds.contains(it.id) &&
                                YouTubeService.isIndividualSong(it.title, it.durationSeconds, maxDurationSeconds = 300)
                            }

                        if (ytStreams.isNotEmpty()) {
                            seenIds.addAll(ytStreams.map { it.id })
                            val activeQueue = _playerState.value.queue
                            val currentIndex = activeQueue.indexOfFirst { it.id == currentSong.id }
                            val prefix = if (currentIndex >= 0) activeQueue.take(currentIndex + 1) else listOf(currentSong)
                            val remainingOld = if (currentIndex >= 0) activeQueue.drop(currentIndex + 1) else emptyList()

                            // Place real online artist radio streams directly after the current song!
                            val enrichedQueue = (prefix + ytStreams + remainingOld).distinctBy { it.id }
                            _playerState.value = _playerState.value.copy(queue = enrichedQueue)
                            Log.i(TAG, "Autoplay added ${ytStreams.size} related individual songs for '${currentSong.title}' (${mood.name})")
                        }
                    } catch (e: Exception) {
                        Log.w(TAG, "Preload online fetch notice: ${e.message}")
                    }
                }
            } catch (e: Exception) {
                if (e !is kotlinx.coroutines.CancellationException) {
                    Log.w(TAG, "Error preloading autoplay songs: ${e.message}")
                }
            } finally {
                isFetchingSimilar = false
            }
        }
    }

    fun triggerDynamicAutoplay(finishedSong: SongEntity) {
        if (!_playerState.value.isSmartAutoplay) {
            _playerState.value = _playerState.value.copy(isPlaying = false, currentPositionMs = 0L)
            return
        }

        _playerState.value = _playerState.value.copy(isBuffering = true)
        val mood = SmartMoodEngine.detectSongMood(finishedSong)
        val vibeDesc = SmartMoodEngine.getAutoplayVibeDescription(finishedSong)
        val moodName = "${mood.emoji} ${mood.name}"

        _playerState.value = _playerState.value.copy(
            autoplayMoodName = moodName,
            autoplayVibeDescription = vibeDesc
        )

        preloadJob?.cancel()
        preloadJob = playerScope.launch {
            isFetchingSimilar = true
            try {
                val currentQueue = _playerState.value.queue
                val seenIds = (currentQueue.map { it.id } + finishedSong.id).toMutableSet()

                // 1. Consult YouTube API or Related Streams first (individual songs <= 5 min)
                val isOnline = appContext?.let { isNetworkConnected(it) } ?: false
                var onlineMatches: List<SongEntity> = emptyList()

                if (isOnline) {
                    try {
                        onlineMatches = YouTubeService.getRelatedStreams(finishedSong, maxResults = 8)
                            .filter {
                                it.id != finishedSong.id &&
                                !seenIds.contains(it.id) &&
                                YouTubeService.isIndividualSong(it.title, it.durationSeconds, maxDurationSeconds = 300)
                            }
                    } catch (e: Exception) {
                        Log.w(TAG, "Autoplay YouTube search notice: ${e.message}")
                    }
                }

                // 2. Local catalog recommendations ONLY if matching the exact musical universe and <= 5 min
                val localCatalog = localCatalogProvider?.invoke() ?: CatalogSeed.defaultSongs
                val localMatches = SmartMoodEngine.findLocalCatalogRecommendations(finishedSong, localCatalog, seenIds)
                    .filter { YouTubeService.isIndividualSong(it.title, it.durationSeconds, maxDurationSeconds = 300) }
                    .take(4)

                // 3. Pool similar songs: online related streams FIRST, then local matches
                val similarSongs = (onlineMatches + localMatches).distinctBy { it.id }

                if (similarSongs.isNotEmpty()) {
                    val songToPlay = similarSongs.first()
                    val appendList = similarSongs.take(8)
                    val updatedQueue = (currentQueue + appendList).distinctBy { it.id }

                    Log.i(TAG, "Autoplay starting individual song '${songToPlay.title}' by ${songToPlay.artist} (${songToPlay.durationSeconds}s, Mood: ${mood.name}). Enqueued ${appendList.size} tracks.")
                    withContext(Dispatchers.Main) {
                        playSong(songToPlay, updatedQueue)
                    }
                } else {
                    val targetUniverse = SmartMoodEngine.detectMusicUniverse(finishedSong)
                    val fallback = localCatalog.firstOrNull {
                        it.id != finishedSong.id &&
                        SmartMoodEngine.detectMusicUniverse(it) == targetUniverse &&
                        YouTubeService.isIndividualSong(it.title, it.durationSeconds, maxDurationSeconds = 300)
                    }
                    if (fallback != null) {
                        withContext(Dispatchers.Main) {
                            playSong(fallback, currentQueue + fallback)
                        }
                    } else {
                        Log.i(TAG, "No similar individual songs found for universe ${targetUniverse.displayName}.")
                        withContext(Dispatchers.Main) {
                            _playerState.value = _playerState.value.copy(isPlaying = false, currentPositionMs = 0L)
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Autoplay recommendation error: ${e.message}", e)
                val targetUniverse = SmartMoodEngine.detectMusicUniverse(finishedSong)
                val localCatalog = localCatalogProvider?.invoke() ?: CatalogSeed.defaultSongs
                val fallback = localCatalog.firstOrNull { it.id != finishedSong.id && SmartMoodEngine.detectMusicUniverse(it) == targetUniverse }
                if (fallback != null) {
                    withContext(Dispatchers.Main) {
                        playSong(fallback, listOf(fallback))
                    }
                }
            } finally {
                isFetchingSimilar = false
                _playerState.value = _playerState.value.copy(isBuffering = false)
            }
        }
    }

    fun updateSongFavorite(songId: String, isFavorite: Boolean) {
        val current = _playerState.value.currentSong
        if (current != null && current.id == songId) {
            _playerState.value = _playerState.value.copy(
                currentSong = current.copy(isFavorite = isFavorite)
            )
        }
        val updatedQueue = _playerState.value.queue.map {
            if (it.id == songId) it.copy(isFavorite = isFavorite) else it
        }
        _playerState.value = _playerState.value.copy(queue = updatedQueue)
    }
}

