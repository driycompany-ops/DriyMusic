package com.example.service

import com.example.data.model.MoodCatalog
import com.example.data.model.MoodItem
import com.example.data.model.SongEntity
import com.example.data.seed.CatalogSeed
import java.text.Normalizer

enum class MusicUniverse(val displayName: String, val searchMixTerms: String) {
    URBANO_LATINO("Urbano Latino", "trap latino r&b urbano reggaeton"),
    ROCK_INDIE("Rock / Indie", "rock indie alternative"),
    ANGLO_POP_RNB("Pop & R&B", "pop r&b"),
    HIP_HOP_ANGLO("Hip-Hop", "hip hop rap"),
    ELECTRONICA("Electrónica", "electronic edm dance"),
    INDIE_FOLK_SAD("Indie / Acústico", "indie folk acoustic")
}

object SmartMoodEngine {

    // Extended mapping of artists to related artists with 100% style, genre & mood affinity
    private val relatedArtistsMap = mapOf(
        // Urbano Latino: Reggaetón, Trap Latino, R&B Latino, Pop Urbano, Dancehall
        "micro tdh" to listOf("Rels B", "Danny Ocean", "Big Soto", "Alvaro Diaz", "Mora", "Feid", "Rauw Alejandro", "Piso 21", "Corina Smith", "Lasso", "Adso", "Paulo Londra", "Mau y Ricky"),
        "rels b" to listOf("Micro TDH", "Alvaro Diaz", "Danny Ocean", "Mora", "Quevedo", "C. Tangana", "Duki", "Dillom"),
        "danny ocean" to listOf("Micro TDH", "Rels B", "Lasso", "Piso 21", "Camilo", "Sebastian Yatra", "Mau y Ricky", "Manuel Turizo"),
        "big soto" to listOf("Micro TDH", "Trainer", "Neutro Shorty", "Akapellah", "Mora", "Eladio Carrión", "Bizarrap", "Jeeiph"),
        "neutro shorty" to listOf("Big Soto", "Micro TDH", "Akapellah", "Trainer", "Eladio Carrión", "Myke Towers"),
        "akapellah" to listOf("Micro TDH", "Big Soto", "Neutro Shorty", "Duki", "Trueno", "Canserbero"),
        "alvaro diaz" to listOf("Rauw Alejandro", "Mora", "Feid", "Micro TDH", "Rels B", "Young Miko", "Tainy", "Sen Senra"),
        "mora" to listOf("Feid", "Bad Bunny", "Rauw Alejandro", "Jhayco", "Micro TDH", "Alvaro Diaz", "Quevedo", "Eladio Carrión"),
        "piso 21" to listOf("Micro TDH", "Danny Ocean", "Manuel Turizo", "Sebastian Yatra", "Mau y Ricky", "Feid"),
        "corina smith" to listOf("Micro TDH", "Lasso", "Alvaro Diaz", "Mora", "Greeicy", "Young Miko", "Noriel"),
        "lasso" to listOf("Micro TDH", "Danny Ocean", "Camilo", "Sebastian Yatra", "Mau y Ricky", "Morat"),
        "paulo londra" to listOf("Duki", "Lit Killah", "Tiago PZK", "Micro TDH", "Bizarrap", "Feid"),
        "bad bunny" to listOf("Rauw Alejandro", "Feid", "Mora", "Jhayco", "Myke Towers", "Tainy", "Anuel AA", "Eladio Carrión", "Chencho Corleone"),
        "feid" to listOf("Rauw Alejandro", "Bad Bunny", "Mora", "Ryan Castro", "Blessd", "Manuel Turizo", "Jhayco", "Quevedo"),
        "karol g" to listOf("Shakira", "Becky G", "Natti Natasha", "Feid", "Bad Bunny", "Rosalía", "Greeicy", "Anuel AA"),
        "shakira" to listOf("Karol G", "Maluma", "Rosalía", "Jennifer Lopez", "Ricky Martin", "Camilo", "Carlos Vives"),
        "j balvin" to listOf("Bad Bunny", "Maluma", "Ozuna", "Daddy Yankee", "Nicky Jam", "Sech", "Zion & Lennox"),
        "maluma" to listOf("J Balvin", "Ozuna", "Daddy Yankee", "Sebastian Yatra", "Camilo", "Nicky Jam"),
        "ozuna" to listOf("Bad Bunny", "Anuel AA", "Daddy Yankee", "J Balvin", "Wisin & Yandel", "Nicky Jam"),
        "daddy yankee" to listOf("Don Omar", "Wisin & Yandel", "Bad Bunny", "Ozuna", "Farruko", "Nicky Jam"),
        "anuel aa" to listOf("Ozuna", "Bad Bunny", "Myke Towers", "Eladio Carrión", "Bryant Myers", "Farruko"),
        "quevedo" to listOf("Bizarrap", "Feid", "Duki", "Saiko", "Mora", "Tiago PZK", "Lola Indigo", "Rels B"),
        "bizarrap" to listOf("Duki", "Quevedo", "Tiago PZK", "Trueno", "Milo J", "Nicki Nicole", "Nathy Peluso"),
        "rosalia" to listOf("C. Tangana", "Tokischa", "Rauw Alejandro", "Karol G", "Kali Uchis", "Arca"),
        "peso pluma" to listOf("Junior H", "Natanael Cano", "Fuerza Regida", "Eslabon Armado", "Gabito Ballesteros"),
        "rauw alejandro" to listOf("Bad Bunny", "Feid", "Alvaro Diaz", "Mora", "Lyanno", "Jay Wheeler"),
        "myke towers" to listOf("Bad Bunny", "Eladio Carrión", "Mora", "Jhayco", "Anuel AA"),
        "eladio carrión" to listOf("Myke Towers", "Bad Bunny", "Duki", "Trueno", "Mora"),

        // Rock / Indie / Alternative
        "two feet" to listOf("Dennis Lloyd", "Chase Atlantic", "Arctic Monkeys", "The Neighbourhood", "Sub Urban", "Grandson"),
        "dennis lloyd" to listOf("Two Feet", "Chase Atlantic", "Sub Urban", "The Neighbourhood"),
        "arctic monkeys" to listOf("The Strokes", "The Neighbourhood", "Cage The Elephant", "Franz Ferdinand", "Miles Kane", "Foals"),
        "the outfield" to listOf("Toto", "Bryan Adams", "The Police", "Rick Springfield", "Foreigner", "Journey"),
        "queen" to listOf("David Bowie", "Led Zeppelin", "Elton John", "The Beatles", "Aerosmith", "Guns N' Roses"),
        "imagine dragons" to listOf("OneRepublic", "Coldplay", "Fall Out Boy", "Twenty One Pilots", "The Script", "Bastille"),
        "coldplay" to listOf("Keane", "The Killers", "OneRepublic", "U2", "Snow Patrol", "The Fray", "Oasis"),
        "linkin park" to listOf("Evanescence", "Papa Roach", "Three Days Grace", "System of a Down", "Limp Bizkit", "Green Day"),
        "the strokes" to listOf("Arctic Monkeys", "The White Stripes", "Franz Ferdinand", "Interpol", "Phoenix"),

        // Pop & R&B Anglo
        "the weeknd" to listOf("Dua Lipa", "Post Malone", "Joji", "Bruno Mars", "The Neighbourhood", "Doja Cat"),
        "dua lipa" to listOf("The Weeknd", "Miley Cyrus", "Doja Cat", "Olivia Rodrigo", "Ava Max", "Katy Perry"),
        "taylor swift" to listOf("Olivia Rodrigo", "Sabrina Carpenter", "Lana Del Rey", "Gracie Abrams", "Phoebe Bridgers"),
        "bruno mars" to listOf("Anderson .Paak", "Silk Sonic", "The Weeknd", "Michael Jackson", "Justin Timberlake", "Charlie Puth"),
        "billie eilish" to listOf("Finneas", "Lorde", "Lana Del Rey", "Olivia Rodrigo", "Melanie Martinez", "Girl in Red"),
        "justin bieber" to listOf("Shawn Mendes", "Charlie Puth", "Zayn", "The Weeknd", "Ed Sheeran", "Harry Styles"),
        "ed sheeran" to listOf("James Arthur", "Shawn Mendes", "Lewis Capaldi", "Sam Smith", "George Ezra"),
        "harry styles" to listOf("Zayn", "Niall Horan", "Shawn Mendes", "Louis Tomlinson", "Conan Gray"),
        "sza" to listOf("Frank Ocean", "Summer Walker", "Jhené Aiko", "Kali Uchis", "Kehlani", "Solange"),
        "frank ocean" to listOf("Daniel Caesar", "Tyler, The Creator", "Brent Faiyaz", "Steve Lacy", "SZA", "Blood Orange"),

        // Hip-Hop / Rap Anglo
        "drake" to listOf("Travis Scott", "Future", "Kendrick Lamar", "J. Cole", "Post Malone", "21 Savage"),
        "kendrick lamar" to listOf("J. Cole", "Drake", "ASAP Rocky", "ScHoolboy Q", "Joey Badass", "Tyler, The Creator"),
        "travis scott" to listOf("Playboi Carti", "Don Toliver", "Future", "Metro Boomin", "Lil Uzi Vert", "Drake"),
        "xxxtentacion" to listOf("Juice WRLD", "Lil Peep", "Trippie Redd", "Ski Mask The Slump God", "Post Malone"),
        "macklemore" to listOf("Ryan Lewis", "B.o.B", "Eminem", "Flo Rida", "Pitbull"),

        // Electronica
        "avicii" to listOf("Kygo", "Swedish House Mafia", "Alesso", "Martin Garrix", "Calvin Harris", "David Guetta"),
        "daft punk" to listOf("Justice", "Kavinsky", "Deadmau5", "Empire of the Sun", "The Chemical Brothers"),
        "calvin harris" to listOf("David Guetta", "Tiësto", "Avicii", "Major Lazer", "Zedd", "Galantis"),
        "petit biscuit" to listOf("Odesza", "Flume", "Kasbo", "San Holo", "Shallou", "FKJ"),

        // Indie Folk / Sad / Acoustic
        "lord huron" to listOf("Cigarettes After Sex", "The Paper Kites", "Gregory Alan Isakov", "Fleet Foxes", "Hozier", "Vance Joy"),
        "cigarettes after sex" to listOf("Lord Huron", "The Marías", "Beach House", "Lana Del Rey", "Men I Trust", "Mac DeMarco"),
        "mon laferte" to listOf("Natalia Lafourcade", "Carla Morrison", "Julieta Venegas", "Silvana Estrada", "Cami")
    )

    /**
     * Accurately detects which Musical Universe a song belongs to based on artist, genre, and keywords.
     * Prevents genre mismatches (e.g. jumping from Micro TDH Latin Urban to Two Feet Indie Rock).
     */
    fun detectMusicUniverse(song: SongEntity): MusicUniverse {
        val artist = song.artist.lowercase().trim()
        val title = song.title.lowercase().trim()
        val genre = song.genre.lowercase().trim()

        val urbanoKeywords = listOf(
            "micro tdh", "bad bunny", "feid", "rauw alejandro", "mora", "jhayco", "myke towers",
            "eladio carrión", "eladio carrion", "anuel", "quevedo", "duki", "trueno", "milo j",
            "bizarrap", "tiago pzk", "rels b", "danny ocean", "big soto", "trainer", "neutro shorty",
            "akapellah", "corina smith", "adso", "lasso", "mau y ricky", "piso 21", "camilo",
            "sebastian yatra", "maluma", "j balvin", "ozuna", "daddy yankee", "don omar", "farruko",
            "wisin", "yandel", "zion", "nicky jam", "sech", "alvaro diaz", "ryan castro", "blessd",
            "manuel turizo", "paulo londra", "lit killah", "khea", "cazzu", "nicki nicole",
            "nathy peluso", "rosalia", "rosalía", "c. tangana", "tokischa", "young miko", "saiko",
            "junior h", "natanael cano", "peso pluma", "fuerza regida", "lenny tavarez", "tainy"
        )
        if (urbanoKeywords.any { artist.contains(it) || it.contains(artist) }) {
            return MusicUniverse.URBANO_LATINO
        }

        val rockKeywords = listOf(
            "two feet", "arctic monkeys", "the outfield", "queen", "imagine dragons", "coldplay",
            "linkin park", "the strokes", "the neighbourhood", "cage the elephant", "toto",
            "bryan adams", "the police", "journey", "david bowie", "led zeppelin", "elton john",
            "the beatles", "aerosmith", "guns n' roses", "onerepublic", "one republic", "fall out boy",
            "twenty one pilots", "bastille", "keane", "the killers", "u2", "oasis", "green day",
            "radiohead", "nirvana", "foals", "dennis lloyd", "chase atlantic", "sub urban"
        )
        if (rockKeywords.any { artist.contains(it) || it.contains(artist) }) {
            return MusicUniverse.ROCK_INDIE
        }

        val hipHopKeywords = listOf(
            "drake", "kendrick lamar", "travis scott", "xxxtentacion", "juice wrld", "lil peep",
            "trippie redd", "playboi carti", "don toliver", "future", "metro boomin", "lil uzi vert",
            "21 savage", "j cole", "j. cole", "asap rocky", "tyler the creator", "macklemore", "eminem"
        )
        if (hipHopKeywords.any { artist.contains(it) || it.contains(artist) }) {
            return MusicUniverse.HIP_HOP_ANGLO
        }

        val electroKeywords = listOf(
            "avicii", "daft punk", "calvin harris", "petit biscuit", "kygo", "swedish house mafia",
            "alesso", "martin garrix", "david guetta", "tiesto", "tiësto", "zedd", "skrillex",
            "marshmello", "flume", "odesza", "san holo"
        )
        if (electroKeywords.any { artist.contains(it) || it.contains(artist) }) {
            return MusicUniverse.ELECTRONICA
        }

        val popAngloKeywords = listOf(
            "the weeknd", "dua lipa", "taylor swift", "bruno mars", "billie eilish", "justin bieber",
            "ed sheeran", "harry styles", "post malone", "shawn mendes", "charlie puth", "olivia rodrigo",
            "sabrina carpenter", "ariana grande", "selena gomez", "miley cyrus", "doja cat", "sza",
            "frank ocean", "daniel caesar", "brent faiyaz", "steve lacy", "joji", "khalid"
        )
        if (popAngloKeywords.any { artist.contains(it) || it.contains(artist) }) {
            return MusicUniverse.ANGLO_POP_RNB
        }

        val folkKeywords = listOf(
            "lord huron", "cigarettes after sex", "mon laferte", "lana del rey", "the marías", "the marias",
            "beach house", "men i trust", "mac demarco", "phoebe bridgers", "clairo", "carla morrison",
            "natalia lafourcade", "julieta venegas", "silvana estrada"
        )
        if (folkKeywords.any { artist.contains(it) || it.contains(artist) }) {
            return MusicUniverse.INDIE_FOLK_SAD
        }

        // Secondary detection by title and genre tokens
        if (genre.contains("reggaeton") || genre.contains("trap latino") || genre.contains("urbano") ||
            genre.contains("latin") || title.contains("reggaeton") || title.contains("dembow") ||
            title.contains("perreo") || (title.contains("remix") && (title.contains("á") || title.contains("é") || title.contains("í") || title.contains("ó") || title.contains("ú") || title.contains("ñ")))
        ) {
            return MusicUniverse.URBANO_LATINO
        }

        if (genre.contains("rock") || genre.contains("indie") || genre.contains("metal")) {
            return MusicUniverse.ROCK_INDIE
        }

        if (genre.contains("electronica") || genre.contains("dance") || genre.contains("edm") || genre.contains("house")) {
            return MusicUniverse.ELECTRONICA
        }

        if (genre.contains("hiphop") || genre.contains("rap")) {
            return MusicUniverse.HIP_HOP_ANGLO
        }

        if (genre.contains("pop") || genre.contains("rnb")) {
            return MusicUniverse.ANGLO_POP_RNB
        }

        return MusicUniverse.URBANO_LATINO
    }

    /**
     * Determines the most fitting mood label for the current song.
     */
    fun detectSongMood(song: SongEntity): MoodItem {
        val lowerTitle = song.title.lowercase()
        val lowerArtist = song.artist.lowercase()

        // 1. Exact ID match from MoodCatalog
        MoodCatalog.moods.firstOrNull { it.songIds.contains(song.id) }?.let { return it }

        // 2. Keyword heuristic
        if (lowerTitle.contains("sad") || lowerTitle.contains("party's over") || lowerTitle.contains("loverman") ||
            lowerTitle.contains("falta de querer") || lowerTitle.contains("jocelyn") || lowerTitle.contains("lovely") ||
            lowerTitle.contains("llorar") || lowerArtist.contains("xxxtentacion") || lowerArtist.contains("billie eilish")
        ) {
            return MoodCatalog.moods.first { it.id == "triste" }
        }

        if (lowerTitle.contains("fe!n") || lowerTitle.contains("in the end") || lowerTitle.contains("sicko") ||
            lowerTitle.contains("humble") || lowerArtist.contains("linkin park") || lowerArtist.contains("carti")
        ) {
            return MoodCatalog.moods.first { it.id == "molesto" }
        }

        if (lowerTitle.contains("believer") || lowerTitle.contains("can't hold us") || lowerTitle.contains("do i wanna") ||
            lowerTitle.contains("fuego") || lowerTitle.contains("perreo") || lowerArtist.contains("imagine dragons") ||
            lowerArtist.contains("macklemore")
        ) {
            return MoodCatalog.moods.first { it.id == "motivado" }
        }

        if (lowerTitle.contains("night we met") || lowerTitle.contains("apocalypse") || lowerTitle.contains("pink + white") ||
            lowerTitle.contains("drowning") || lowerArtist.contains("lord huron") || lowerArtist.contains("cigarettes after sex")
        ) {
            return MoodCatalog.moods.first { it.id == "pensativo" }
        }

        if (lowerTitle.contains("sunset lover") || lowerTitle.contains("kill bill") || lowerTitle.contains("cafe") ||
            lowerTitle.contains("café") || lowerTitle.contains("besame") || lowerTitle.contains("bésame") ||
            lowerTitle.contains("amame") || lowerTitle.contains("ámame") || lowerArtist.contains("petit biscuit") ||
            lowerArtist.contains("two feet") || lowerArtist.contains("danny ocean") || lowerArtist.contains("micro tdh")
        ) {
            return MoodCatalog.moods.first { it.id == "relajado" }
        }

        // 3. Fallback based on universe
        return when (detectMusicUniverse(song)) {
            MusicUniverse.URBANO_LATINO -> MoodCatalog.moods.first { it.id == "feliz" }
            MusicUniverse.ROCK_INDIE -> MoodCatalog.moods.first { it.id == "motivado" }
            MusicUniverse.ANGLO_POP_RNB -> MoodCatalog.moods.first { it.id == "pensativo" }
            MusicUniverse.HIP_HOP_ANGLO -> MoodCatalog.moods.first { it.id == "motivado" }
            MusicUniverse.ELECTRONICA -> MoodCatalog.moods.first { it.id == "feliz" }
            MusicUniverse.INDIE_FOLK_SAD -> MoodCatalog.moods.first { it.id == "pensativo" }
        }
    }

    /**
     * Generates a descriptive banner for the Smart Autoplay session.
     */
    fun getAutoplayVibeDescription(song: SongEntity): String {
        val universe = detectMusicUniverse(song)
        val mood = detectSongMood(song)
        return "Smart Autoplay: ${universe.displayName} • ${mood.emoji} ${mood.name} • Radio de ${song.artist}"
    }

    /**
     * Builds intelligent search queries for individual song recommendations (Spotify-style autoplay).
     * Strictly targets individual singles under 5 minutes; excludes mixes, sessions, and compilations.
     */
    fun buildSearchQueriesForSong(song: SongEntity): List<String> {
        val artist = song.artist.trim()
        val artistLower = artist.lowercase()
        val universe = detectMusicUniverse(song)
        val relatedArtists = findRelatedArtists(artistLower)

        val queries = mutableListOf<String>()

        // 1. Same artist individual official singles
        queries.add("$artist canciones audio oficial")
        queries.add("$artist tema audio oficial")

        // 2. Cross-artist recommendations strictly within the same musical universe
        if (relatedArtists.isNotEmpty()) {
            val shuffled = relatedArtists.shuffled()
            val picked1 = shuffled.firstOrNull()
            val picked2 = shuffled.getOrNull(1)
            val picked3 = shuffled.getOrNull(2)

            if (picked1 != null) {
                queries.add("$picked1 cancion audio oficial")
            }
            if (picked2 != null) {
                queries.add("$picked2 cancion audio oficial")
            }
            if (picked3 != null) {
                queries.add("$picked3 audio oficial")
            }
        }

        // 3. Universe and genre targeted individual song query (NO "mix" keyword!)
        queries.add("${universe.displayName} cancion audio oficial")

        return queries.distinct()
    }

    /**
     * Finds related artists from our rich music graph.
     */
    fun findRelatedArtists(artistName: String): List<String> {
        val lower = artistName.lowercase().trim()
        for ((key, list) in relatedArtistsMap) {
            if (lower.contains(key) || key.contains(lower)) {
                return list
            }
        }
        return emptyList()
    }

    /**
     * Finds songs from the local catalog that fit 100% with the current song's musical universe.
     * STRICT ISOLATION & DURATION: Only individual tracks <= 5 minutes (300s) without mixes.
     */
    fun findLocalCatalogRecommendations(
        currentSong: SongEntity,
        allSongs: List<SongEntity>,
        excludedIds: Set<String>
    ): List<SongEntity> {
        val targetUniverse = detectMusicUniverse(currentSong)

        // Universe pool: songs from the same universe, allowing single tracks and remixes up to 8 minutes (480s)
        val universePool = allSongs.filter { s ->
            !excludedIds.contains(s.id) && s.id != currentSong.id &&
            detectMusicUniverse(s) == targetUniverse &&
            s.durationSeconds in 40..480 &&
            !isMixOrCompilationTitle(s.title, s.durationSeconds)
        }

        if (universePool.isEmpty()) {
            return emptyList()
        }

        val mood = detectSongMood(currentSong)
        val related = findRelatedArtists(currentSong.artist)

        val artistMatches = universePool.filter { s ->
            s.artist.equals(currentSong.artist, ignoreCase = true) ||
            related.any { rel -> s.artist.contains(rel, ignoreCase = true) }
        }

        val moodMatches = universePool.filter { s -> mood.songIds.contains(s.id) }

        return (artistMatches + moodMatches + universePool).distinctBy { it.id }.take(3)
    }

    /**
     * Checks if a title indicates a multi-song mix, megamix, session, compilation, or long album set.
     * EXPLICITLY ALLOWS REMIXES ("remix") like "Fuera del Planeta Remix" or "La Ocasión Remix"
     * as requested by the user, while excluding long continuous mixes > 7 minutes.
     */
    fun isMixOrCompilationTitle(title: String, durationSec: Int = 0): Boolean {
        val nfd = Normalizer.normalize(title.lowercase(), Normalizer.Form.NFD)
        val cleanLower = nfd.replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")

        // Explicitly ALLOW remixes! A remix is a single collaborative track.
        val isRemix = cleanLower.contains("remix")
        if (isRemix) {
            if (durationSec > 480) return true // Over 8 minutes
            if (cleanLower.contains("mix de remix") || cleanLower.contains("megamix") || cleanLower.contains("enganchado")) {
                return true
            }
            return false // It's a legitimate collaborative remix!
        }

        // Long sets over 7.5 minutes (450s) are continuous mixes/albums
        if (durationSec > 450) return true

        // Word boundary regex ensures "mix" only matches standalone words, NEVER "remix"
        val standaloneMixRegex = Regex("(?i)\\b(mix|megamix|dj\\s*mix|extended\\s*mix)\\b")
        if (standaloneMixRegex.containsMatchIn(cleanLower)) {
            return true
        }

        val forbidden = listOf(
            "session", "sesion", "sessions",
            "compilacion", "compilation", "recopilacion",
            "enganchado", "enganchados", "live set", "dj set",
            "full album", "album completo", "disco completo",
            "discografia", "todos los exitos", "grandes exitos",
            "top canciones", "mejores canciones", "las mejores canciones",
            "1 hora", "1 hour", "1hr", "2 horas", "2 hours", "3 horas", "10 horas",
            "15 minutos", "15 min", "20 min", "30 min", "podcast",
            "concierto completo", "en vivo completo",
            "sesion acustica", "acoustic session", "acustico completo"
        )
        return forbidden.any { cleanLower.contains(it) }
    }
}
