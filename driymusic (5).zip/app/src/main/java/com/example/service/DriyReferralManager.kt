package com.example.service

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import android.widget.Toast
import com.example.data.model.ReferralFriendInfo
import com.example.data.model.ReferralProgressState
import com.example.data.model.UserEntity
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.net.URLEncoder

/**
 * DriyReferralManager
 *
 * Manages DriyMusic's 20-Friends Invitation & Reward Program:
 * - Each user shares their referral code (@username).
 * - Invited friends enter the code when paying their membership.
 * - Once the invited friend's subscription is paid/activated, they count towards the 20-friends goal.
 * - Reaching 20 activated friends unlocks a 3-month VIP activation code reward claim sent to the administrator.
 */
object DriyReferralManager {
    private const val TAG = "DriyReferralManager"
    private const val USERS_COLLECTION = "driystream_users"
    private const val CLAIMS_COLLECTION = "driystream_referral_claims"

    // Default admin phone for WhatsApp claims
    const val ADMIN_PHONE = DriyActivationCodeManager.DEFAULT_ADMIN_PHONE
    const val GOAL_REQUIRED_FRIENDS = 20

    /**
     * Fetches current referral progress for a user by querying users who registered using their referral code.
     * Only friends with active paid memberships (subscriptionExpiresAt > now) count as activated.
     */
    suspend fun getReferralProgress(username: String): ReferralProgressState = withContext(Dispatchers.IO) {
        val cleanUser = username.trim().removePrefix("@").lowercase()
        if (cleanUser.isBlank()) {
            return@withContext ReferralProgressState()
        }

        val firestore = FirebaseFirestore.getInstance()
        val friendsList = mutableListOf<ReferralFriendInfo>()
        var hasClaimed = false

        try {
            // 1. Query users referred by this username (limit 50 to comply with firestore.rules)
            val snap = withTimeoutOrNull(6000L) {
                firestore.collection(USERS_COLLECTION)
                    .whereEqualTo("referredBy", cleanUser)
                    .limit(50)
                    .get()
                    .await()
            }

            if (snap != null && !snap.isEmpty) {
                for (doc in snap.documents) {
                    val uid = doc.id
                    val uname = doc.getString("username") ?: uid
                    val dName = doc.getString("displayName") ?: uname
                    val phone = doc.getString("phoneNumber") ?: ""
                    val exp = (doc.get("subscriptionExpiresAt") as? Number)?.toLong() ?: 0L
                    val createdAt = (doc.get("createdAt") as? Number)?.toLong() ?: 0L

                    // Skip self-referral if any
                    if (uname.equals(cleanUser, ignoreCase = true)) continue

                    friendsList.add(
                        ReferralFriendInfo(
                            userId = uid,
                            username = uname,
                            displayName = dName,
                            phoneNumber = phone,
                            subscriptionExpiresAt = exp,
                            createdAt = createdAt
                        )
                    )
                }
            }

            // 2. Check if a reward claim is already recorded
            val claimDoc = withTimeoutOrNull(3000L) {
                firestore.collection(CLAIMS_COLLECTION).document(cleanUser).get().await()
            }
            if (claimDoc != null && claimDoc.exists()) {
                hasClaimed = true
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error fetching referral progress for $cleanUser: ${e.message}")
        }

        // Sort: Activated first, then newest
        val sortedFriends = friendsList.sortedWith(
            compareByDescending<ReferralFriendInfo> { it.isActivatedAndPaid }
                .thenByDescending { it.createdAt }
        )
        val activeCount = sortedFriends.count { it.isActivatedAndPaid }

        ReferralProgressState(
            myReferralCode = cleanUser,
            totalReferrals = sortedFriends.size,
            activePaidReferrals = activeCount,
            requiredGoal = GOAL_REQUIRED_FRIENDS,
            friendsList = sortedFriends,
            hasClaimedReward = hasClaimed
        )
    }

    /**
     * Records referral claim and launches WhatsApp to notify administrator.
     */
    suspend fun claimThreeMonthsReward(
        context: Context,
        user: UserEntity,
        progress: ReferralProgressState
    ): Boolean = withContext(Dispatchers.IO) {
        val cleanUser = user.username.trim().removePrefix("@").lowercase()
        val displayName = user.displayName.ifBlank { cleanUser }
        val phone = user.phoneNumber.ifBlank { "No especificado" }

        try {
            val firestore = FirebaseFirestore.getInstance()
            val claimData = hashMapOf(
                "userId" to user.id,
                "username" to cleanUser,
                "displayName" to displayName,
                "phoneNumber" to phone,
                "activeReferralsCount" to progress.activePaidReferrals,
                "totalReferralsCount" to progress.totalReferrals,
                "claimedAt" to FieldValue.serverTimestamp(),
                "claimedAtMs" to System.currentTimeMillis(),
                "status" to "PENDING_VERIFICATION",
                "rewardMonths" to 3
            )
            withTimeoutOrNull(5000L) {
                firestore.collection(CLAIMS_COLLECTION).document(cleanUser).set(claimData).await()
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error persisting claim to Firestore: ${e.message}")
        }

        // Open WhatsApp with official claim template to the administrator
        withContext(Dispatchers.Main) {
            val message = """
🎉 *¡Hola Administrador de DriyMusic!*
Soy *@$cleanUser* ($displayName), con celular: $phone.

¡He completado con éxito la meta de *20 amigos invitados* que se registraron y pagaron su membresía en DriyMusic! 🏆🎧
✅ Amigos activados y verificados: *${progress.activePaidReferrals} / $GOAL_REQUIRED_FRIENDS*

Solicito la verificación en el sistema y la entrega de mi recompensa de *3 meses gratis* (código de activación VIP). ¡Muchas gracias!
            """.trimIndent()

            openWhatsApp(context, ADMIN_PHONE, message)
        }
        true
    }

    /**
     * Shares user's referral code and invitation link via WhatsApp.
     */
    fun shareReferralInvitation(context: Context, username: String) {
        val cleanUser = username.trim().removePrefix("@")
        val message = """
¡Hola! Te invito a unirte a *DriyMusic* para escuchar toda tu música favorita sin anuncios y con sonido HD 🎶🎧.
Descarga la app y al activar tu membresía ingresa mi código de referido:
👉 *@$cleanUser* 👈

¡A disfrutar de la mejor música juntos! 🔥
        """.trimIndent()

        openWhatsApp(context, targetPhone = "", message = message)
    }

    /**
     * Attaches referral code to the paying user in Firestore and Room.
     */
    suspend fun attachReferrerToUser(
        context: Context? = null,
        currentUserId: String,
        referrerUsername: String
    ): Boolean = withContext(Dispatchers.IO) {
        val cleanReferrer = referrerUsername.trim().removePrefix("@").lowercase()
        val cleanCurrent = currentUserId.trim().lowercase()

        if (cleanReferrer.isBlank() || cleanReferrer == cleanCurrent) {
            return@withContext false
        }

        var success = false
        // 1. Update local Room DB if context provided
        if (context != null) {
            try {
                val db = com.example.data.db.DriyDatabase.getInstance(context)
                db.userDao().updateReferredBy(cleanCurrent, cleanReferrer)
                success = true
            } catch (e: Exception) {
                Log.w(TAG, "Error updating local Room referredBy: ${e.message}")
            }
        }

        // 2. Update remote Firestore
        try {
            val firestore = FirebaseFirestore.getInstance()
            firestore.collection(USERS_COLLECTION).document(cleanCurrent)
                .update("referredBy", cleanReferrer)
                .await()
            Log.d(TAG, "User '$cleanCurrent' linked to referrer '@$cleanReferrer'")
            success = true
        } catch (e: Exception) {
            Log.w(TAG, "Could not update referredBy for user $cleanCurrent in Firestore: ${e.message}")
        }

        success
    }

    private fun openWhatsApp(context: Context, targetPhone: String, message: String) {
        try {
            val encodedMessage = URLEncoder.encode(message, "UTF-8")
            val cleanPhone = targetPhone.filter { it.isDigit() }
            val uri = if (cleanPhone.isNotBlank()) {
                Uri.parse("https://api.whatsapp.com/send?phone=$cleanPhone&text=$encodedMessage")
            } else {
                Uri.parse("https://api.whatsapp.com/send?text=$encodedMessage")
            }
            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            // General share fallback
            try {
                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, message)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(Intent.createChooser(shareIntent, "Compartir invitación DriyMusic"))
            } catch (ex: Exception) {
                Toast.makeText(context, "No se pudo compartir la invitación.", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
