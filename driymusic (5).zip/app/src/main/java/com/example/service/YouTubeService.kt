package com.example.service

import android.util.Log
import com.example.data.model.SongEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.Normalizer

object YouTubeService {
    private const val TAG = "YouTubeService"

    suspend fun searchYouTube(query: String, apiKey: String? = null): List<SongEntity> = withContext(Dispatchers.IO) {
        if (query.isBlank()) return@withContext emptyList()

        if (!apiKey.isNullOrBlank()) {
            val apiResults = searchWithYouTubeDataApi(query, apiKey)
            if (apiResults.isNotEmpty()) return@withContext apiResults
        }

        val directResults = searchDirectYouTube(query)
        if (directResults.isNotEmpty()) return@withContext directResults

        return@withContext searchSuggestQueries(query)
    }

    /**
     * Obtains related streams / similar songs for the current track based on YouTube radio,
     * artist graph, and 100% mood and genre matching via SmartMoodEngine.
     */
    suspend fun getRelatedStreams(song: SongEntity, maxResults: Int = 10): List<SongEntity> = withContext(Dispatchers.IO) {
        val collected = mutableListOf<SongEntity>()
        val seenIds = mutableSetOf(song.id)
        val cleanCurrentTitle = song.title.lowercase().replace(Regex("[^a-z0-9]"), "")
        val titleWords = song.title.lowercase()
            .replace(Regex("[^a-z0-9 ]"), " ")
            .split(" ")
            .filter { it.length > 2 && it !in listOf("the", "and", "los", "las", "del", "con", "por", "para") }

        // 1. Get smart queries based on artist, genre, mood and YouTube radio mix
        val queries = SmartMoodEngine.buildSearchQueriesForSong(song)
        val targetUniverse = SmartMoodEngine.detectMusicUniverse(song)
        val relatedArtists = SmartMoodEngine.findRelatedArtists(song.artist)

        for (q in queries) {
            try {
                val results = searchYouTube(q)
                for (item in results) {
                    if (!isIndividualSong(item.title, item.durationSeconds, maxDurationSeconds = 450, minDurationSeconds = 40)) {
                        continue
                    }

                    val cleanItemTitle = item.title.lowercase().replace(Regex("[^a-z0-9]"), "")
                    val isSameSong = cleanItemTitle == cleanCurrentTitle ||
                        (titleWords.isNotEmpty() && titleWords.all { cleanItemTitle.contains(it) } &&
                          (item.artist.contains(song.artist, ignoreCase = true) || song.artist.contains(item.artist, ignoreCase = true)))

                    val itemUniverse = SmartMoodEngine.detectMusicUniverse(item)
                    val isCompatibleUniverse = itemUniverse == targetUniverse ||
                        item.artist.contains(song.artist, ignoreCase = true) ||
                        relatedArtists.any { item.artist.contains(it, ignoreCase = true) }

                    if (!seenIds.contains(item.id) && !isSameSong && isCompatibleUniverse) {
                        seenIds.add(item.id)
                        collected.add(item.copy(genre = targetUniverse.displayName))
                    }
                    if (collected.size >= maxResults) break
                }
            } catch (e: Exception) {
                Log.w(TAG, "Error fetching related stream for query '$q': ${e.message}")
            }
            if (collected.size >= maxResults) break
        }
        return@withContext collected
    }

    private fun searchWithYouTubeDataApi(query: String, apiKey: String): List<SongEntity> {
        try {
            val encodedQuery = URLEncoder.encode(query, "UTF-8")
            val urlString = "https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&maxResults=20&q=$encodedQuery&key=$apiKey"
            val connection = URL(urlString).openConnection() as HttpURLConnection
            connection.requestMethod = "GET"
            connection.connectTimeout = 8000
            connection.readTimeout = 8000

            if (connection.responseCode == 200) {
                val json = connection.inputStream.bufferedReader().use { it.readText() }
                val root = JSONObject(json)
                val items = root.optJSONArray("items") ?: return emptyList()

                val list = mutableListOf<SongEntity>()
                for (i in 0 until items.length()) {
                    val item = items.getJSONObject(i)
                    val idObj = item.optJSONObject("id") ?: continue
                    val videoId = idObj.optString("videoId")
                    if (videoId.isNullOrBlank()) continue

                    val snippet = item.optJSONObject("snippet") ?: continue
                    val rawTitle = snippet.optString("title", "Desconocido")
                    if (isLikelyLongMixOrAlbum(rawTitle, 210, query)) continue

                    val channelTitle = snippet.optString("channelTitle", "YouTube")
                    val thumbs = snippet.optJSONObject("thumbnails")
                    val highThumb = thumbs?.optJSONObject("high")?.optString("url")
                        ?: "https://i.ytimg.com/vi/$videoId/hqdefault.jpg"

                    list.add(
                        SongEntity(
                            id = videoId,
                            title = cleanTitle(rawTitle),
                            artist = channelTitle,
                            album = "YouTube Music",
                            genre = "YouTube",
                            durationSeconds = 210,
                            audioUrl = "https://www.youtube.com/watch?v=$videoId",
                            coverUrl = highThumb,
                            isDownloaded = false,
                            localFilePath = null,
                            isFavorite = false,
                            playCount = 0
                        )
                    )
                }
                return list
            }
        } catch (e: Exception) {
            Log.w(TAG, "YouTube Data API search failed: ${e.message}")
        }
        return emptyList()
    }

    private fun extractInitialDataJson(html: String): String? {
        val marker = "ytInitialData"
        val idx = html.indexOf(marker)
        if (idx == -1) return null

        val start = html.indexOf('{', idx)
        if (start == -1) return null

        var braceCount = 0
        var inString = false
        var escape = false

        for (i in start until html.length) {
            val c = html[i]
            if (escape) {
                escape = false
                continue
            }
            if (c == '\\') {
                escape = true
                continue
            }
            if (c == '"') {
                inString = !inString
                continue
            }
            if (!inString) {
                if (c == '{') {
                    braceCount++
                } else if (c == '}') {
                    braceCount--
                    if (braceCount == 0) {
                        return html.substring(start, i + 1)
                    }
                }
            }
        }
        return null
    }

    private fun searchDirectYouTube(query: String): List<SongEntity> {
        try {
            val encoded = URLEncoder.encode(query, "UTF-8")
            val searchUrl = "https://www.youtube.com/results?search_query=$encoded"
            val conn = URL(searchUrl).openConnection() as HttpURLConnection
            conn.setRequestProperty(
                "User-Agent",
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
            )
            conn.connectTimeout = 7000
            conn.readTimeout = 7000

            if (conn.responseCode == 200) {
                val html = conn.inputStream.bufferedReader().use { it.readText() }
                val jsonStr = extractInitialDataJson(html)
                if (!jsonStr.isNullOrBlank()) {
                    val root = JSONObject(jsonStr)
                    val contents = root.optJSONObject("contents")
                        ?.optJSONObject("twoColumnSearchResultsRenderer")
                        ?.optJSONObject("primaryContents")
                        ?.optJSONObject("sectionListRenderer")
                        ?.optJSONArray("contents") ?: return emptyList()

                    val resultList = mutableListOf<SongEntity>()

                    for (i in 0 until contents.length()) {
                        val section = contents.optJSONObject(i) ?: continue
                        val itemSection = section.optJSONObject("itemSectionRenderer") ?: continue
                        val items = itemSection.optJSONArray("contents") ?: continue

                        for (j in 0 until items.length()) {
                            val item = items.optJSONObject(j) ?: continue
                            val videoRenderer = item.optJSONObject("videoRenderer") ?: continue
                            val videoId = videoRenderer.optString("videoId")
                            if (videoId.isNullOrBlank()) continue

                            val title = videoRenderer.optJSONObject("title")
                                ?.optJSONArray("runs")?.optJSONObject(0)?.optString("text") ?: "Canción"
                            val channel = videoRenderer.optJSONObject("ownerText")
                                ?.optJSONArray("runs")?.optJSONObject(0)?.optString("text") ?: "YouTube"
                            val lengthText = videoRenderer.optJSONObject("lengthText")?.optString("simpleText") ?: "3:30"
                            val durationSec = parseDurationToSeconds(lengthText)

                            if (isLikelyLongMixOrAlbum(title, durationSec, query)) {
                                continue
                            }

                            resultList.add(
                                SongEntity(
                                    id = videoId,
                                    title = cleanTitle(title),
                                    artist = channel,
                                    album = "YouTube Music",
                                    genre = "YouTube",
                                    durationSeconds = durationSec,
                                    audioUrl = "https://www.youtube.com/watch?v=$videoId",
                                    coverUrl = "https://i.ytimg.com/vi/$videoId/hqdefault.jpg",
                                    isDownloaded = false,
                                    localFilePath = null,
                                    isFavorite = false,
                                    playCount = 0
                                )
                            )
                            if (resultList.size >= 20) break
                        }
                        if (resultList.size >= 20) break
                    }

                    if (resultList.isNotEmpty()) {
                        return resultList
                    }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Direct YouTube search failed: ${e.message}")
        }
        return emptyList()
    }

    /**
     * Validates whether a track is an individual song or remix (Spotify-style).
     * Explicitly ALLOWS remixes (such as "Fuera del Planeta Remix", "La Ocasión Remix")
     * which are collaborative single tracks typically running up to 7-8 minutes.
     * Excludes long multi-song mixes, DJ sets, megamixes, and continuous compilations.
     */
    fun isIndividualSong(
        title: String,
        durationSec: Int,
        maxDurationSeconds: Int = 300,
        minDurationSeconds: Int = 40
    ): Boolean {
        val nfd = Normalizer.normalize(title.lowercase(), Normalizer.Form.NFD)
        val cleanLower = nfd.replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")

        val isRemix = cleanLower.contains("remix")
        if (isRemix) {
            // Remixes are single songs with artist collaborations; allow up to 8 minutes (480s)
            if (durationSec > 480) return false
            if (durationSec < minDurationSeconds) return false
            if (cleanLower.contains("mix de remix") || cleanLower.contains("megamix") || cleanLower.contains("enganchado")) {
                return false
            }
            return true
        }

        if (durationSec > maxDurationSeconds) return false
        if (durationSec < minDurationSeconds) return false

        // Standalone "mix" check (word boundary ensures "remix" is never matched)
        val standaloneMixRegex = Regex("(?i)\\b(mix|megamix|dj\\s*mix|extended\\s*mix)\\b")
        if (standaloneMixRegex.containsMatchIn(cleanLower)) {
            return false
        }

        val forbiddenTerms = listOf(
            "session", "sesion", "sessions",
            "compilacion", "compilation", "recopilacion",
            "enganchado", "enganchados", "live set", "dj set",
            "full album", "album completo", "disco completo",
            "discografia", "todos los exitos", "grandes exitos",
            "top canciones", "mejores canciones", "las mejores canciones",
            "1 hora", "1 hour", "1hr", "2 horas", "2 hours", "3 horas", "10 horas",
            "15 minutos", "15 min", "20 min", "30 min", "podcast",
            "concierto completo", "en vivo completo",
            "sesion acustica", "acoustic session", "acustico completo"
        )
        return forbiddenTerms.none { cleanLower.contains(it) }
    }

    private fun isLikelyLongMixOrAlbum(title: String, durationSec: Int, userQuery: String = ""): Boolean {
        val queryLower = userQuery.lowercase()
        // If the user explicitly searched for an album or 1-hour video, allow it in direct search
        if (queryLower.contains("album completo") || queryLower.contains("disco completo") || queryLower.contains("1 hora")) {
            return false
        }

        val nfd = Normalizer.normalize(title.lowercase(), Normalizer.Form.NFD)
        val cleanLower = nfd.replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")

        val isRemix = cleanLower.contains("remix")
        if (isRemix) {
            // Allow collaborative remixes up to 8 minutes (480s)
            if (durationSec > 480) return true
            if (durationSec < 40) return true
            if (cleanLower.contains("mix de remix") || cleanLower.contains("megamix") || cleanLower.contains("enganchado")) {
                return true
            }
            return false // ALLOW IT!
        }

        // Multi-song mixes are longer than 7-7.5 minutes
        if (durationSec > 450) return true
        if (durationSec < 40) return true

        return !isIndividualSong(title, durationSec, maxDurationSeconds = 450, minDurationSeconds = 40)
    }

    private fun searchSuggestQueries(query: String): List<SongEntity> {
        try {
            val encoded = URLEncoder.encode(query, "UTF-8")
            val url = "https://suggestqueries.google.com/complete/search?client=firefox&ds=yt&q=$encoded"
            val conn = URL(url).openConnection() as HttpURLConnection
            conn.setRequestProperty("User-Agent", "Mozilla/5.0")
            conn.connectTimeout = 4000
            conn.readTimeout = 4000

            if (conn.responseCode == 200) {
                val text = conn.inputStream.bufferedReader().use { it.readText() }
                val array = JSONArray(text)
                if (array.length() > 1) {
                    val suggestions = array.optJSONArray(1) ?: return emptyList()
                    val firstSuggestion = suggestions.optString(0)
                    if (!firstSuggestion.isNullOrBlank()) {
                        val resolved = searchDirectYouTube(firstSuggestion)
                        if (resolved.isNotEmpty()) {
                            return resolved
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Suggest search failed: ${e.message}")
        }
        return emptyList()
    }

    private fun cleanTitle(title: String): String {
        return title
            .replace("&amp;", "&")
            .replace("&quot;", "\"")
            .replace("&#39;", "'")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
    }

    private fun parseDurationToSeconds(text: String): Int {
        val parts = text.split(":")
        return when (parts.size) {
            2 -> (parts[0].toIntOrNull() ?: 0) * 60 + (parts[1].toIntOrNull() ?: 0)
            3 -> (parts[0].toIntOrNull() ?: 0) * 3600 + (parts[1].toIntOrNull() ?: 0) * 60 + (parts[2].toIntOrNull() ?: 0)
            else -> 210
        }
    }
}
