package com.example.service

import android.content.Context
import android.util.Log
import com.example.data.db.DriyDatabase
import com.example.data.model.UserEntity
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.text.Normalizer
import com.example.util.PasswordHasher
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.functions.FirebaseFunctions

class FirebaseUserManager(private val context: Context) {
    private val firestore by lazy { FirebaseFirestore.getInstance() }
    private val userDao = DriyDatabase.getInstance(context).userDao()
    private val prefs = context.getSharedPreferences("driystream_auth_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val TAG = "FirebaseUserManager"
        private const val USERS_COLLECTION = "driystream_users"
        private const val KEY_ACTIVE_USER_ID = "active_user_id"
        private const val KEY_IS_LOGGED_IN = "is_logged_in"
    }

    var lastCloudError: String? = null
        private set

    private fun normalize(str: String): String {
        val nfd = Normalizer.normalize(str.trim().lowercase(), Normalizer.Form.NFD)
        return nfd.replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
    }

    /**
     * Checks if a given username or phone is currently marked as a deleted account AND has not been re-created since.
     */
    suspend fun isDeletedAccount(identifier: String): Boolean = withContext(Dispatchers.IO) {
        if (identifier.isBlank()) return@withContext false
        val clean = identifier.trim().removePrefix("@").lowercase()
        return@withContext try {
            val delDoc = withTimeoutOrNull(2500L) {
                firestore.collection("driystream_deleted_accounts").document(clean).get().await()
            } ?: return@withContext false

            if (!delDoc.exists()) return@withContext false
            val deletedAt = delDoc.getLong("deletedAt") ?: 0L

            // Check if there is an active user document in USERS_COLLECTION created AFTER deletedAt
            val userDoc = withTimeoutOrNull(2500L) {
                firestore.collection(USERS_COLLECTION).document(clean).get().await()
            }

            if (userDoc != null && userDoc.exists()) {
                val createdAt = userDoc.getLong("createdAt") ?: 0L
                if (createdAt > deletedAt) {
                    // Re-registered by a user after deletion! Clean up tombstone
                    try { delDoc.reference.delete().await() } catch (_: Exception) {}
                    return@withContext false
                } else {
                    // Stale document from before deletion that wasn't purged! Purge it now
                    try { userDoc.reference.delete().await() } catch (_: Exception) {}
                    try { userDao.deleteUserById(clean) } catch (_: Exception) {}
                    return@withContext true
                }
            }

            // Also check query by username/phone field
            val queryUser = withTimeoutOrNull(2500L) {
                val field = if (clean.all { it.isDigit() }) "phoneNumber" else "username"
                firestore.collection(USERS_COLLECTION)
                    .whereEqualTo(field, clean)
                    .limit(1)
                    .get()
                    .await()
            }

            if (queryUser != null && !queryUser.isEmpty) {
                val found = queryUser.documents.first()
                val createdAt = found.getLong("createdAt") ?: 0L
                if (createdAt > deletedAt) {
                    try { delDoc.reference.delete().await() } catch (_: Exception) {}
                    return@withContext false
                } else {
                    try { found.reference.delete().await() } catch (_: Exception) {}
                    try { userDao.deleteUserById(clean) } catch (_: Exception) {}
                    return@withContext true
                }
            }

            true
        } catch (e: Exception) {
            false
        }
    }

    /**
     * Checks if a username is already taken across all devices in Firebase Firestore or locally.
     * If an account was previously deleted, its username is FREE to be used by any future person!
     */
    suspend fun isUsernameTaken(username: String): Boolean = withContext(Dispatchers.IO) {
        val clean = username.trim().removePrefix("@").lowercase()
        if (clean.equals("driyadmincompany", ignoreCase = true) || clean.equals("driycompany", ignoreCase = true)) {
            return@withContext true
        }
        if (clean.length < 3) return@withContext false

        // 0. Check if this username belonged to a deleted account.
        // If it was deleted and not re-registered, the username is AVAILABLE for future registrations!
        if (isDeletedAccount(clean)) {
            Log.d(TAG, "Username '$clean' belonged to a deleted account and is now FREE to be registered!")
            try { userDao.deleteUserById(clean) } catch (_: Exception) {}
            try { GlobalUserSyncClient.deleteUserGlobal(clean, "") } catch (_: Exception) {}
            return@withContext false
        }

        // 1. Check local Room first for instant offline/online check
        val localMatch = userDao.getUserByUsername(clean) ?: userDao.getUserById(clean)
        if (localMatch != null) {
            if (isDeletedAccount(localMatch.username)) {
                try { userDao.deleteUserById(localMatch.id) } catch (_: Exception) {}
            } else {
                Log.d(TAG, "Username '$clean' found locally")
                return@withContext true
            }
        }

        // 2. Check Cloud Firestore across all devices
        try {
            val takenInCloud = withTimeoutOrNull(4000L) {
                val doc = firestore.collection(USERS_COLLECTION).document(clean).get().await()
                if (doc.exists()) {
                    // Verify if this doc is actually a deleted account
                    val createdAt = doc.getLong("createdAt") ?: 0L
                    val delDoc = firestore.collection("driystream_deleted_accounts").document(clean).get().await()
                    if (delDoc.exists()) {
                        val deletedAt = delDoc.getLong("deletedAt") ?: 0L
                        if (createdAt <= deletedAt) {
                            try { doc.reference.delete().await() } catch (_: Exception) {}
                            return@withTimeoutOrNull false
                        }
                    }
                    return@withTimeoutOrNull true
                }
                val querySnap = firestore.collection(USERS_COLLECTION)
                    .whereEqualTo("username", clean)
                    .limit(1)
                    .get()
                    .await()
                if (!querySnap.isEmpty) {
                    val found = querySnap.documents.first()
                    val createdAt = found.getLong("createdAt") ?: 0L
                    val delDoc = firestore.collection("driystream_deleted_accounts").document(clean).get().await()
                    if (delDoc.exists()) {
                        val deletedAt = delDoc.getLong("deletedAt") ?: 0L
                        if (createdAt <= deletedAt) {
                            try { found.reference.delete().await() } catch (_: Exception) {}
                            return@withTimeoutOrNull false
                        }
                    }
                    return@withTimeoutOrNull true
                }
                false
            }
            if (takenInCloud == true) {
                lastCloudError = null
                return@withContext true
            }
        } catch (e: Exception) {
            lastCloudError = e.localizedMessage ?: e.message
            Log.w(TAG, "Firestore username check fallback: ${e.message}")
        }

        // 3. Fallback to global sync
        try {
            if (GlobalUserSyncClient.isUsernameTakenGlobal(clean)) {
                return@withContext true
            }
        } catch (e: Exception) {
            // ignore
        }

        false
    }

    /**
     * Checks if an account exists with the given username OR phone number across all devices.
     * Ignores accounts that were deleted so that their username and phone can be re-registered freely.
     */
    suspend fun findExistingAccount(username: String, phoneNumber: String): UserEntity? = withContext(Dispatchers.IO) {
        val cleanUsername = username.trim().removePrefix("@").lowercase()
        val rawDigits = phoneNumber.filter { it.isDigit() }
        val standardPhone = if (rawDigits.length == 9 && !rawDigits.startsWith("51")) "51$rawDigits" else rawDigits
        val localPhone = if (rawDigits.length == 11 && rawDigits.startsWith("51")) rawDigits.removePrefix("51") else rawDigits

        // If checking by username and it was deleted, do not return it as existing!
        if (cleanUsername.isNotBlank() && isDeletedAccount(cleanUsername)) {
            Log.d(TAG, "findExistingAccount: '$cleanUsername' is a deleted account. Free for registration.")
            try { userDao.deleteUserById(cleanUsername) } catch (_: Exception) {}
            return@withContext null
        }
        // If checking by phone and it was deleted, do not return it as existing!
        if (rawDigits.isNotBlank() && isDeletedAccount(rawDigits)) {
            Log.d(TAG, "findExistingAccount: phone '$rawDigits' belongs to a deleted account. Free for registration.")
            try { userDao.deleteUserById(rawDigits) } catch (_: Exception) {}
            return@withContext null
        }

        // 1. Check local Room first
        if (cleanUsername.isNotBlank()) {
            val local = userDao.getUserByUsername(cleanUsername)
                ?: userDao.getUserById(cleanUsername)
            if (local != null) {
                if (isDeletedAccount(local.username) || isDeletedAccount(local.phoneNumber)) {
                    try { userDao.deleteUserById(local.id) } catch (_: Exception) {}
                } else {
                    return@withContext local
                }
            }
        } else if (rawDigits.isNotBlank()) {
            val localByPhone = userDao.getUserByPhoneNumber(rawDigits)
                ?: userDao.getUserByPhoneNumber(standardPhone)
                ?: userDao.getUserByPhoneNumber(localPhone)
            if (localByPhone != null && !localByPhone.username.equals("driyadmincompany", ignoreCase = true)) {
                if (isDeletedAccount(localByPhone.username) || isDeletedAccount(localByPhone.phoneNumber)) {
                    try { userDao.deleteUserById(localByPhone.id) } catch (_: Exception) {}
                } else {
                    return@withContext localByPhone
                }
            }
        }

        // 2. Check Cloud Firestore across all devices
        try {
            val cloudUser = withTimeoutOrNull(5000L) {
                if (cleanUsername.isNotBlank()) {
                    // Check by document ID
                    val doc = firestore.collection(USERS_COLLECTION).document(cleanUsername).get().await()
                    if (doc.exists()) {
                        val user = mapDocToUser(doc)
                        if (user != null) {
                            if (isDeletedAccount(user.username) || isDeletedAccount(user.phoneNumber)) {
                                return@withTimeoutOrNull null
                            }
                            return@withTimeoutOrNull user
                        }
                    }
                    // Check by 'username' field
                    val queryUser = firestore.collection(USERS_COLLECTION)
                        .whereEqualTo("username", cleanUsername)
                        .limit(1)
                        .get()
                        .await()
                    if (!queryUser.isEmpty) {
                        val user = mapDocToUser(queryUser.documents.first())
                        if (user != null) {
                            if (isDeletedAccount(user.username) || isDeletedAccount(user.phoneNumber)) {
                                return@withTimeoutOrNull null
                            }
                            return@withTimeoutOrNull user
                        }
                    }
                } else if (rawDigits.isNotBlank()) {
                    // Check raw digits
                    val phoneSnap = firestore.collection(USERS_COLLECTION)
                        .whereEqualTo("phoneNumber", rawDigits)
                        .limit(1)
                        .get()
                        .await()
                    if (!phoneSnap.isEmpty) {
                        val user = mapDocToUser(phoneSnap.documents.first())
                        if (user != null && !user.username.equals("driyadmincompany", ignoreCase = true)) {
                            if (isDeletedAccount(user.username) || isDeletedAccount(user.phoneNumber)) {
                                return@withTimeoutOrNull null
                            }
                            return@withTimeoutOrNull user
                        }
                    }

                    // Check standard formatted phone with Peru prefix (51XXXXXXXXX)
                    if (standardPhone != rawDigits) {
                        val standardSnap = firestore.collection(USERS_COLLECTION)
                            .whereEqualTo("phoneNumber", standardPhone)
                            .limit(1)
                            .get()
                            .await()
                        if (!standardSnap.isEmpty) {
                            val user = mapDocToUser(standardSnap.documents.first())
                            if (user != null && !user.username.equals("driyadmincompany", ignoreCase = true)) {
                                if (isDeletedAccount(user.username) || isDeletedAccount(user.phoneNumber)) {
                                    return@withTimeoutOrNull null
                                }
                                return@withTimeoutOrNull user
                            }
                        }
                    }

                    // Check 9-digit local phone without country prefix
                    if (localPhone != rawDigits) {
                        val localSnap = firestore.collection(USERS_COLLECTION)
                            .whereEqualTo("phoneNumber", localPhone)
                            .limit(1)
                            .get()
                            .await()
                        if (!localSnap.isEmpty) {
                            val user = mapDocToUser(localSnap.documents.first())
                            if (user != null && !user.username.equals("driyadmincompany", ignoreCase = true)) {
                                if (isDeletedAccount(user.username) || isDeletedAccount(user.phoneNumber)) {
                                    return@withTimeoutOrNull null
                                }
                                return@withTimeoutOrNull user
                            }
                        }
                    }
                }
                null
            }
            if (cloudUser != null) {
                lastCloudError = null
                userDao.insertUser(cloudUser)
                return@withContext cloudUser
            }
        } catch (e: Exception) {
            lastCloudError = e.localizedMessage ?: e.message
            Log.w(TAG, "Firestore search error: ${e.message}")
        }

        // 3. Fallback to Global User Sync
        try {
            val globalUser = GlobalUserSyncClient.getUserGlobal(cleanUsername.ifBlank { rawDigits })
            if (globalUser != null) {
                if (isDeletedAccount(globalUser.username) || isDeletedAccount(globalUser.phoneNumber)) {
                    return@withContext null
                }
                userDao.insertUser(globalUser)
                return@withContext globalUser
            }
        } catch (e: Exception) {
            // ignore
        }

        null
    }

    /**
     * Verifies identity for account recovery:
     * Compares firstName, lastName, and phoneNumber across local Room, Firestore, and Global Cloud.
     */
    suspend fun findUserForRecovery(
        firstName: String,
        lastName: String,
        phoneNumber: String
    ): UserEntity? = withContext(Dispatchers.IO) {
        val cleanPhone = phoneNumber.filter { it.isDigit() }
        val targetFirst = normalize(firstName)
        val targetLast = normalize(lastName)

        if (cleanPhone.length < 6 || targetFirst.isBlank() || targetLast.isBlank()) {
            return@withContext null
        }

        fun matchesUser(candidate: UserEntity): Boolean {
            val candPhone = candidate.phoneNumber.filter { it.isDigit() }
            val phoneMatch = candPhone.isNotBlank() && cleanPhone.isNotBlank() &&
                    (candPhone.endsWith(cleanPhone.takeLast(7)) || cleanPhone.endsWith(candPhone.takeLast(7)) || candPhone == cleanPhone)

            val candFirst = normalize(candidate.firstName)
            val candLast = normalize(candidate.lastName)
            val candDisplay = normalize(candidate.displayName)

            val nameMatch = (candFirst == targetFirst || candFirst.contains(targetFirst) || targetFirst.contains(candFirst) || candDisplay.contains(targetFirst)) &&
                    (candLast == targetLast || candLast.contains(targetLast) || targetLast.contains(candLast) || candDisplay.contains(targetLast))

            return phoneMatch && nameMatch
        }

        // 1. Search local Room registered users
        try {
            val localUsers = userDao.getAllRegisteredUsers()
            val localMatch = localUsers.firstOrNull { matchesUser(it) }
            if (localMatch != null) {
                Log.d(TAG, "Recovery user found in local Room: ${localMatch.username}")
                return@withContext localMatch
            }
        } catch (e: Exception) {
            Log.w(TAG, "Local recovery check error: ${e.message}")
        }

        // 2. Search Global User Sync
        val globalMatch = GlobalUserSyncClient.verifyIdentityGlobal(firstName, lastName, phoneNumber)
        if (globalMatch != null) {
            userDao.insertUser(globalMatch)
            return@withContext globalMatch
        }

        // 3. Search Firestore by phoneNumber query
        try {
            val cloudMatch = withTimeoutOrNull(3500L) {
                val queryPhone = firestore.collection(USERS_COLLECTION)
                    .whereEqualTo("phoneNumber", cleanPhone)
                    .get()
                    .await()
                for (doc in queryPhone.documents) {
                    val user = mapDocToUser(doc)
                    if (user != null && matchesUser(user)) {
                        return@withTimeoutOrNull user
                    }
                }
                // Try also matching trailing 9 digits
                if (cleanPhone.length > 9) {
                    val shortPhone = cleanPhone.takeLast(9)
                    val queryShort = firestore.collection(USERS_COLLECTION)
                        .whereEqualTo("phoneNumber", shortPhone)
                        .get()
                        .await()
                    for (doc in queryShort.documents) {
                        val user = mapDocToUser(doc)
                        if (user != null && matchesUser(user)) {
                            return@withTimeoutOrNull user
                        }
                    }
                }
                null
            }
            if (cloudMatch != null) {
                userDao.insertUser(cloudMatch)
                return@withContext cloudMatch
            }
        } catch (e: Exception) {
            Log.w(TAG, "Firestore recovery search error: ${e.message}")
        }
        null
    }

    /**
     * Resets password securely in local Room, Global Cloud Store, and Cloud Firestore.
     */
    suspend fun resetUserPassword(
        userIdOrUsername: String,
        newPassword: String
    ): Boolean = withContext(Dispatchers.IO) {
        val clean = userIdOrUsername.trim().removePrefix("@").lowercase()
        val hashedNewPassword = PasswordHasher.hashPassword(newPassword)
        var updated = false

        // 1. Update local Room
        try {
            userDao.updateUserPassword(clean, hashedNewPassword)
            val user = userDao.getUserByUsername(clean) ?: userDao.getUserById(clean)
            if (user != null) {
                userDao.insertUser(user.copy(passwordHash = hashedNewPassword))
                updated = true
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to update local password: ${e.message}")
        }

        // 2. Update Global User Sync
        try {
            GlobalUserSyncClient.updatePasswordGlobal(clean, hashedNewPassword)
            updated = true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to update global password: ${e.message}")
        }

        // 3. Update Cloud Firestore
        try {
            withTimeoutOrNull(2500L) {
                firestore.collection(USERS_COLLECTION)
                    .document(clean)
                    .update("passwordHash", hashedNewPassword)
                    .await()
            }
            updated = true
        } catch (e: Exception) {
            Log.w(TAG, "Firestore password update error: ${e.message}")
        }
        updated
    }

    /**
     * Registers a new user. Persists in Room immediately AND pushes to Firebase Firestore.
     */
    suspend fun registerUser(
        firstName: String,
        lastName: String,
        username: String,
        password: String,
        phoneNumber: String
    ): UserEntity = withContext(Dispatchers.IO) {
        val cleanUsername = username.trim().removePrefix("@").lowercase()
        val cleanPhone = phoneNumber.filter { it.isDigit() }.ifBlank { phoneNumber.trim() }

        val isReservedAdminAccount = cleanUsername == "driyadmincompany" ||
                                     cleanUsername == "driycompany" ||
                                     cleanPhone == "928598496" ||
                                     cleanPhone == "921483434" ||
                                     cleanPhone == "950312209"
        if (isReservedAdminAccount) {
            throw IllegalArgumentException("Esta cuenta y número están reservados para la administración de DriyStream. Si eres el dueño, por favor inicia sesión.")
        }

        val fullName = "${firstName.trim()} ${lastName.trim()}".trim().ifBlank { cleanUsername }
        val userId = cleanUsername

        val newUser = UserEntity(
            id = userId,
            displayName = fullName,
            email = "$cleanUsername@driystream.com",
            photoUrl = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400&q=80",
            favoriteGenres = emptyList(),
            favoriteArtists = emptyList(),
            isOnboarded = false,
            createdAt = System.currentTimeMillis(),
            firstName = firstName.trim(),
            lastName = lastName.trim(),
            username = cleanUsername,
            passwordHash = PasswordHasher.hashPassword(password),
            phoneNumber = cleanPhone
        )

        // 1. Save to local Room immediately
        userDao.insertUser(newUser)

        // 2. Persist local active session
        prefs.edit()
            .putString(KEY_ACTIVE_USER_ID, newUser.id)
            .putBoolean(KEY_IS_LOGGED_IN, true)
            .putBoolean("is_onboarded", false)
            .apply()

        // 3. Optional publish to Global Multi-Device Cloud Store
        try {
            GlobalUserSyncClient.saveUserGlobal(newUser)
        } catch (e: Exception) {
            // ignore
        }

        // 4. Push to Firebase Firestore and clear any previous deleted tombstone
        try {
            val userMap = hashMapOf(
                "id" to newUser.id,
                "username" to newUser.username,
                "firstName" to newUser.firstName,
                "lastName" to newUser.lastName,
                "displayName" to newUser.displayName,
                "email" to newUser.email,
                "photoUrl" to newUser.photoUrl,
                "phoneNumber" to newUser.phoneNumber,
                "passwordHash" to newUser.passwordHash,
                "isOnboarded" to newUser.isOnboarded,
                "createdAt" to newUser.createdAt,
                "favoriteGenres" to newUser.favoriteGenres,
                "favoriteArtists" to newUser.favoriteArtists,
                "subscriptionExpiresAt" to newUser.subscriptionExpiresAt,
                "themeConfig" to newUser.themeConfig,
                "referredBy" to newUser.referredBy
            )
            val success = withTimeoutOrNull(6000L) {
                firestore.collection(USERS_COLLECTION).document(cleanUsername).set(userMap).await()
                // Clear any deleted tombstone
                try {
                    firestore.collection("driystream_deleted_accounts").document(cleanUsername).delete().await()
                    if (cleanPhone.isNotBlank()) {
                        firestore.collection("driystream_deleted_accounts").document(cleanPhone).delete().await()
                    }
                } catch (e: Exception) {
                    // ignore
                }
                true
            }
            if (success == true) {
                lastCloudError = null
                Log.d(TAG, "User '$cleanUsername' registered and synced to Firestore successfully")
            } else {
                lastCloudError = "Tiempo de espera agotado al conectar con Firebase Firestore"
                Log.w(TAG, "Firestore registration timeout")
            }
        } catch (e: Exception) {
            lastCloudError = e.localizedMessage ?: e.message
            Log.e(TAG, "Failed to persist user in Firestore: ${e.message}", e)
        }
        newUser
    }

    /**
     * Logs in with username, password, and phone number against Firebase Firestore and Room.
     */
    suspend fun loginUser(
        username: String,
        password: String,
        phoneNumber: String
    ): Result<UserEntity> = withContext(Dispatchers.IO) {
        val cleanUsername = username.trim().removePrefix("@").lowercase()
        val cleanPhone = phoneNumber.filter { it.isDigit() }.ifBlank { phoneNumber.trim() }

        // Special handling for Master Admin account ONLY if username or email is explicitly the admin
        val isAdminAttempt = cleanUsername.equals("driyadmincompany", ignoreCase = true)
        if (isAdminAttempt) {
            val existingAdmin = userDao.getUserById("driyadmincompany")
                ?: userDao.getUserByUsername(cleanUsername)
                ?: withTimeoutOrNull(5000L) {
                    try {
                        val doc = firestore.collection(USERS_COLLECTION).document("driyadmincompany").get().await()
                        if (doc.exists()) mapDocToUser(doc) else null
                    } catch (e: Exception) { null }
                }

            if (existingAdmin == null) {
                return@withContext Result.failure(Exception("No se encontró la cuenta de administración."))
            }

            val adminPasswordMatches = if (existingAdmin.passwordHash.isNotBlank()) {
                PasswordHasher.verifyPassword(password, existingAdmin.passwordHash)
            } else {
                false
            }
            if (!adminPasswordMatches) {
                return@withContext Result.failure(Exception("La contraseña ingresada no es correcta."))
            }

            val adminStoredPhone = existingAdmin.phoneNumber.filter { it.isDigit() }
            if (cleanPhone.isNotBlank() && adminStoredPhone.isNotBlank()) {
                val phoneMatches = cleanPhone.endsWith(adminStoredPhone.takeLast(7)) ||
                                   adminStoredPhone.endsWith(cleanPhone.takeLast(7)) ||
                                   cleanPhone == adminStoredPhone
                if (!phoneMatches) {
                    return@withContext Result.failure(Exception("El número telefónico no coincide con el registrado en tu cuenta."))
                }
            }

            userDao.insertUser(existingAdmin)
            prefs.edit()
                .putString(KEY_ACTIVE_USER_ID, existingAdmin.id)
                .putBoolean(KEY_IS_LOGGED_IN, true)
                .putBoolean("is_onboarded", true)
                .apply()
            return@withContext Result.success(existingAdmin)
        }

        // 0. Explicit check for deleted account
        val isAccountDeleted = withTimeoutOrNull(3000L) {
            try {
                if (cleanUsername.isNotBlank() && isDeletedAccount(cleanUsername)) return@withTimeoutOrNull true
                if (cleanPhone.isNotBlank() && isDeletedAccount(cleanPhone)) return@withTimeoutOrNull true
                false
            } catch (e: Exception) {
                false
            }
        } ?: false

        if (isAccountDeleted) {
            return@withContext Result.failure(Exception("Esta cuenta fue eliminada y ya no existe. Por favor regístrate nuevamente si deseas usar la app."))
        }

        var foundUser: UserEntity? = null

        // 1. Search in Firebase Firestore across all devices by USERNAME/EMAIL
        try {
            foundUser = withTimeoutOrNull(6000L) {
                if (cleanUsername.isNotBlank()) {
                    val doc = firestore.collection(USERS_COLLECTION).document(cleanUsername).get().await()
                    if (doc.exists()) {
                        val u = mapDocToUser(doc)
                        if (u != null) return@withTimeoutOrNull u
                    }
                    val queryUser = firestore.collection(USERS_COLLECTION)
                        .whereEqualTo("username", cleanUsername)
                        .limit(1)
                        .get()
                        .await()
                    if (!queryUser.isEmpty) {
                        val u = mapDocToUser(queryUser.documents.first())
                        if (u != null) return@withTimeoutOrNull u
                    }
                    val queryEmail = firestore.collection(USERS_COLLECTION)
                        .whereEqualTo("email", cleanUsername)
                        .limit(1)
                        .get()
                        .await()
                    if (!queryEmail.isEmpty) {
                        val u = mapDocToUser(queryEmail.documents.first())
                        if (u != null) return@withTimeoutOrNull u
                    }
                } else if (cleanPhone.isNotBlank()) {
                    val queryPhone = firestore.collection(USERS_COLLECTION)
                        .whereEqualTo("phoneNumber", cleanPhone)
                        .limit(1)
                        .get()
                        .await()
                    if (!queryPhone.isEmpty) {
                        val u = mapDocToUser(queryPhone.documents.first())
                        if (u != null && !u.username.equals("driyadmincompany", ignoreCase = true)) {
                            return@withTimeoutOrNull u
                        }
                    }
                }
                null
            }
            if (foundUser != null) {
                lastCloudError = null
            }
        } catch (e: Exception) {
            lastCloudError = e.localizedMessage ?: e.message
            Log.w(TAG, "Firestore login search error: ${e.message}")
        }

        // 2. Search local Room database if offline or not found in cloud
        if (foundUser == null) {
            if (cleanUsername.isNotBlank()) {
                foundUser = userDao.getUserByUsername(cleanUsername)
                    ?: userDao.getUserById(cleanUsername)
            } else if (cleanPhone.isNotBlank()) {
                foundUser = userDao.getUserByPhoneNumber(cleanPhone)
                    ?: userDao.getUserByPhoneNumber(phoneNumber.trim())
            }
        }

        // 3. Fallback to Global Sync
        if (foundUser == null && cleanUsername.isNotBlank()) {
            try {
                foundUser = GlobalUserSyncClient.getUserGlobal(cleanUsername)
            } catch (e: Exception) {
                // ignore
            }
        }

        // Absolute safeguard: A common user login must NEVER yield the admin user
        if (foundUser != null && (foundUser.username.equals("driyadmincompany", ignoreCase = true) || foundUser.id.equals("driyadmincompany", ignoreCase = true))) {
            if (!isAdminAttempt) {
                foundUser = null
            }
        }

        if (foundUser == null) {
            val cloudErr = lastCloudError
            val errorText = if (!cloudErr.isNullOrBlank() && (cloudErr.contains("PERMISSION_DENIED", ignoreCase = true) || cloudErr.contains("disabled", ignoreCase = true) || cloudErr.contains("not been used", ignoreCase = true))) {
                "⚠️ La base de datos Firebase Firestore no está activada en tu consola de Firebase. Por favor actívala para iniciar sesión en cualquier celular."
            } else if (!cloudErr.isNullOrBlank()) {
                "No se pudo conectar con la nube de Firebase ($cloudErr). Verifica tu conexión o activa Firestore."
            } else {
                "No se encontró ninguna cuenta registrada con el usuario '$cleanUsername'. Por favor verifica o crea una nueva cuenta."
            }
            return@withContext Result.failure(Exception(errorText))
        }

        // 4. Validate password securely using PasswordHasher
        if (foundUser.passwordHash.isNotBlank()) {
            val passwordCorrect = PasswordHasher.verifyPassword(password, foundUser.passwordHash)
            if (!passwordCorrect) {
                return@withContext Result.failure(Exception("La contraseña ingresada no es correcta."))
            }
        }

        // 5. Validate phone number with flexible digit matching
        val userPhoneClean = foundUser.phoneNumber.filter { it.isDigit() }.ifBlank { foundUser.phoneNumber.trim() }
        if (userPhoneClean.isNotBlank() && cleanPhone.isNotBlank()) {
            val matches = userPhoneClean.endsWith(cleanPhone.takeLast(7)) ||
                          cleanPhone.endsWith(userPhoneClean.takeLast(7)) ||
                          userPhoneClean == cleanPhone
            if (!matches) {
                return@withContext Result.failure(
                    Exception("El número telefónico no coincide con el registrado en tu cuenta.")
                )
            }
        }

        // 6. Update local Room database with cloud user data
        userDao.insertUser(foundUser)

        // 7. Load personalized theme for this specific user
        com.example.ui.theme.ThemeManager.loadUserTheme(foundUser.id, foundUser.themeConfig)

        // 8. Persist local active session
        prefs.edit()
            .putString(KEY_ACTIVE_USER_ID, foundUser.id)
            .putBoolean(KEY_IS_LOGGED_IN, true)
            .putBoolean("is_onboarded", foundUser.isOnboarded)
            .apply()

        Result.success(foundUser)
    }

    @Suppress("UNCHECKED_CAST")
    private fun mapMapToUser(map: Map<*, *>): UserEntity {
        val username = (map["username"] as? String) ?: (map["id"] as? String) ?: "usuario"
        val firstName = (map["firstName"] as? String) ?: ""
        val lastName = (map["lastName"] as? String) ?: ""
        val displayName = (map["displayName"] as? String) ?: "$firstName $lastName".trim().ifBlank { username }
        val email = (map["email"] as? String) ?: "$username@driystream.com"
        val photoUrl = (map["photoUrl"] as? String) ?: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400&q=80"
        val phoneNumber = (map["phoneNumber"] as? String) ?: ""
        val isOnboarded = (map["isOnboarded"] as? Boolean) ?: false
        val createdAt = ((map["createdAt"] as? Number)?.toLong()) ?: System.currentTimeMillis()
        val genres = (map["favoriteGenres"] as? List<*>)?.filterIsInstance<String>() ?: emptyList()
        val artists = (map["favoriteArtists"] as? List<*>)?.filterIsInstance<String>() ?: emptyList()
        val subscriptionExpiresAt = ((map["subscriptionExpiresAt"] as? Number)?.toLong()) ?: 0L
        val themeConfig = (map["themeConfig"] as? String) ?: ""

        return UserEntity(
            id = username.lowercase(),
            displayName = displayName,
            email = email,
            photoUrl = photoUrl,
            favoriteGenres = genres,
            favoriteArtists = artists,
            isOnboarded = isOnboarded,
            createdAt = createdAt,
            firstName = firstName,
            lastName = lastName,
            username = username.lowercase(),
            passwordHash = "", // Omitted on client for zero-knowledge security
            phoneNumber = phoneNumber,
            subscriptionExpiresAt = subscriptionExpiresAt,
            themeConfig = themeConfig
        )
    }

    @Suppress("UNCHECKED_CAST")
    private fun mapDocToUser(doc: DocumentSnapshot): UserEntity? {
        return try {
            val username = doc.getString("username") ?: doc.id
            val firstName = doc.getString("firstName") ?: ""
            val lastName = doc.getString("lastName") ?: ""
            val displayName = doc.getString("displayName") ?: "$firstName $lastName".trim().ifBlank { username }
            val email = doc.getString("email") ?: "$username@driystream.com"
            val photoUrl = doc.getString("photoUrl") ?: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400&q=80"
            val phoneNumber = doc.getString("phoneNumber") ?: ""
            val passwordHash = doc.getString("passwordHash") ?: ""
            val isOnboarded = doc.getBoolean("isOnboarded") ?: false
            val createdAt = doc.getLong("createdAt") ?: System.currentTimeMillis()
            val genres = (doc.get("favoriteGenres") as? List<String>) ?: emptyList()
            val artists = (doc.get("favoriteArtists") as? List<String>) ?: emptyList()
            val subscriptionExpiresAt = doc.getLong("subscriptionExpiresAt") ?: 0L
            val themeConfig = doc.getString("themeConfig") ?: ""
            val referredBy = doc.getString("referredBy") ?: ""

            UserEntity(
                id = username.lowercase(),
                displayName = displayName,
                email = email,
                photoUrl = photoUrl,
                favoriteGenres = genres,
                favoriteArtists = artists,
                isOnboarded = isOnboarded,
                createdAt = createdAt,
                firstName = firstName,
                lastName = lastName,
                username = username.lowercase(),
                passwordHash = passwordHash,
                phoneNumber = phoneNumber,
                subscriptionExpiresAt = subscriptionExpiresAt,
                themeConfig = themeConfig,
                referredBy = referredBy
            )
        } catch (e: Exception) {
            Log.e(TAG, "Error mapping Firestore document to UserEntity: ${e.message}")
            null
        }
    }

    suspend fun updateUserReferredBy(userId: String, referredBy: String): Boolean = withContext(Dispatchers.IO) {
        val cleanReferrer = referredBy.trim().removePrefix("@").lowercase()
        if (cleanReferrer.isBlank()) return@withContext false
        try {
            userDao.updateReferredBy(userId, cleanReferrer)
            firestore.collection(USERS_COLLECTION).document(userId.lowercase())
                .update("referredBy", cleanReferrer)
                .await()
            true
        } catch (e: Exception) {
            Log.w(TAG, "Error updating referredBy in Firestore: ${e.message}")
            false
        }
    }
}
