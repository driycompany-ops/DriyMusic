package com.example.service

import android.net.Uri
import android.util.Log
import com.example.data.model.SongEntity
import com.example.data.model.UploadedSongEntity
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.io.File

object FirebaseMusicSyncManager {
    private const val TAG = "FirebaseMusicSync"
    private const val COLLECTION_COMMUNITY_SONGS = "community_songs"

    private fun getFirestoreSafe(): FirebaseFirestore? {
        return try {
            FirebaseFirestore.getInstance()
        } catch (e: Exception) {
            null
        }
    }

    private fun getStorageSafe(): FirebaseStorage? {
        return try {
            FirebaseStorage.getInstance()
        } catch (e: Exception) {
            null
        }
    }

    suspend fun publishSongToGlobalCloud(
        uploadedSong: UploadedSongEntity,
        audioFile: File,
        pdfFile: File?,
        coverFile: File?,
        uploaderEmail: String?,
        uploaderName: String?,
        onProgress: (Float) -> Unit = {}
    ): Result<UploadedSongEntity> = withContext(Dispatchers.IO) {
        try {
            val storageInstance = getStorageSafe() ?: return@withContext Result.failure(Exception("Firebase Storage not available"))
            val firestoreInstance = getFirestoreSafe() ?: return@withContext Result.failure(Exception("Firestore not available"))

            onProgress(0.1f)
            val audioExtension = audioFile.extension.ifBlank { "mp3" }
            val audioStorageRef = storageInstance.reference.child("community_music/${uploadedSong.id}.$audioExtension")
            
            val audioUploadTask = audioStorageRef.putFile(Uri.fromFile(audioFile))
            audioUploadTask.addOnProgressListener { taskSnapshot ->
                val progress = (taskSnapshot.bytesTransferred.toFloat() / taskSnapshot.totalByteCount.toFloat()) * 0.6f
                onProgress(0.1f + progress)
            }.await()

            val cloudAudioUrl = audioStorageRef.downloadUrl.await().toString()
            onProgress(0.7f)

            var cloudPdfUrl: String? = null
            if (pdfFile != null && pdfFile.exists()) {
                val pdfStorageRef = storageInstance.reference.child("community_legal_docs/${uploadedSong.id}_legal.pdf")
                pdfStorageRef.putFile(Uri.fromFile(pdfFile)).await()
                cloudPdfUrl = pdfStorageRef.downloadUrl.await().toString()
            }
            onProgress(0.85f)

            var cloudCoverUrl: String? = uploadedSong.coverUrl
            if (coverFile != null && coverFile.exists()) {
                val coverStorageRef = storageInstance.reference.child("community_covers/${uploadedSong.id}_cover.jpg")
                coverStorageRef.putFile(Uri.fromFile(coverFile)).await()
                cloudCoverUrl = coverStorageRef.downloadUrl.await().toString()
            }
            onProgress(0.95f)

            val songDocument = hashMapOf(
                "id" to uploadedSong.id,
                "title" to uploadedSong.title,
                "composer" to uploadedSong.composer,
                "authorshipPercentage" to uploadedSong.authorshipPercentage,
                "artist" to uploadedSong.artist,
                "genre" to uploadedSong.genre,
                "approxDuration" to uploadedSong.approxDuration,
                "releaseDate" to uploadedSong.releaseDate,
                "audioUrl" to cloudAudioUrl,
                "audioFileName" to uploadedSong.audioFileName,
                "audioFormatBadge" to uploadedSong.audioFormatBadge,
                "coverUrl" to (cloudCoverUrl ?: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=500&q=80"),
                "hasPdf" to (cloudPdfUrl != null),
                "pdfDocUrl" to cloudPdfUrl,
                "pdfDocName" to uploadedSong.pdfDocName,
                "uploaderEmail" to (uploaderEmail ?: "indie_artist@driystream.com"),
                "uploaderName" to (uploaderName ?: uploadedSong.artist),
                "isCopyrightDeclared" to true,
                "createdAt" to System.currentTimeMillis()
            )

            firestoreInstance.collection(COLLECTION_COMMUNITY_SONGS)
                .document(uploadedSong.id)
                .set(songDocument)
                .await()

            onProgress(1.0f)
            Log.d(TAG, "Song successfully published to global cloud: ${uploadedSong.title}")

            val updatedSong = uploadedSong.copy(
                audioFilePath = cloudAudioUrl,
                coverUrl = cloudCoverUrl,
                pdfDocPath = cloudPdfUrl
            )
            Result.success(updatedSong)
        } catch (e: Exception) {
            Log.e(TAG, "Error publishing song to cloud: ${e.message}", e)
            Result.failure(e)
        }
    }

    fun getGlobalCommunitySongsFlow(): Flow<List<SongEntity>> = callbackFlow {
        val fs = getFirestoreSafe()
        if (fs == null) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }

        val listenerRegistration = try {
            fs.collection(COLLECTION_COMMUNITY_SONGS)
                .orderBy("createdAt", Query.Direction.DESCENDING)
                .limit(50)
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        Log.w(TAG, "Firestore community songs listen failed: ${error.message}")
                        return@addSnapshotListener
                    }
                    if (snapshot != null) {
                        val songs = snapshot.documents.mapNotNull { doc ->
                            try {
                                val id = doc.getString("id") ?: doc.id
                                val title = doc.getString("title") ?: "Sin título"
                                val artist = doc.getString("artist") ?: "Artista Emergente"
                                val genre = doc.getString("genre") ?: "Original"
                                val approxDuration = doc.getString("approxDuration") ?: "03:30"
                                val releaseDate = doc.getString("releaseDate") ?: "2026"
                                val audioUrl = doc.getString("audioUrl") ?: return@mapNotNull null
                                val coverUrl = doc.getString("coverUrl")
                                    ?: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=500&q=80"

                                val durationParts = approxDuration.split(":")
                                val durationSec = if (durationParts.size == 2) {
                                    (durationParts[0].toIntOrNull() ?: 3) * 60 + (durationParts[1].toIntOrNull() ?: 30)
                                } else {
                                    approxDuration.toIntOrNull() ?: 210
                                }

                                SongEntity(
                                    id = id,
                                    title = title,
                                    artist = artist,
                                    genre = genre,
                                    album = "Comunidad DriyMusic ($releaseDate)",
                                    coverUrl = coverUrl,
                                    audioUrl = audioUrl,
                                    durationSeconds = durationSec,
                                    isDownloaded = false,
                                    localFilePath = null
                                )
                            } catch (e: Exception) {
                                null
                            }
                        }
                        trySend(songs)
                    }
                }
        } catch (e: Exception) {
            Log.w(TAG, "Failed to attach firestore listener: ${e.message}")
            trySend(emptyList())
            null
        }

        awaitClose {
            listenerRegistration?.remove()
        }
    }.flowOn(Dispatchers.IO)
}
