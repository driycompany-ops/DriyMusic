package com.example.service

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import com.example.data.model.AssistantAnimationMode
import com.example.data.model.VirtualAssistantCatalog
import com.example.data.model.VirtualAssistantState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.Normalizer
import java.util.Locale

object VirtualAssistantManager {
    private const val TAG = "VirtualAssistantManager"
    private const val PREFS_NAME = "driystream_assistant_prefs"
    private const val KEY_ENABLED = "assistant_enabled"
    private const val KEY_AVATAR_ID = "selected_avatar_id"
    private const val KEY_CUSTOM_NAME = "custom_avatar_name"
    private const val KEY_CALLING_TITLE = "user_calling_title"

    // 1 minute (60 seconds) of inactivity before sitting down / going to sleep
    private const val INACTIVITY_TIMEOUT_MS = 60_000L

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var prefs: SharedPreferences? = null
    private var appContext: Context? = null

    private val _state = MutableStateFlow(VirtualAssistantState())
    val state: StateFlow<VirtualAssistantState> = _state.asStateFlow()

    private var speechRecognizer: SpeechRecognizer? = null
    private var voiceMediaPlayer: MediaPlayer? = null
    private val handler = Handler(Looper.getMainLooper())
    private var animationResetJob: Job? = null
    private var thoughtClearJob: Job? = null
    private var inactivityTimerJob: Job? = null

    // Track last command processed timestamp to avoid duplicate triggers
    private var lastProcessedTimestamp = 0L

    fun init(context: Context) {
        if (prefs != null) return
        val ctx = context.applicationContext
        appContext = ctx
        val sp = ctx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs = sp

        // Disabled by default. Only active if the user explicitly turns it ON in settings/profile.
        val hasExplicitChoice = sp.contains("assistant_user_explicitly_set_v2")
        val enabled = if (hasExplicitChoice) {
            sp.getBoolean(KEY_ENABLED, false)
        } else {
            sp.edit().putBoolean(KEY_ENABLED, false).putBoolean("assistant_user_explicitly_set_v2", true).apply()
            false
        }
        val avatarId = sp.getString(KEY_AVATAR_ID, "zoe") ?: "zoe"
        val customName = sp.getString(KEY_CUSTOM_NAME, when (avatarId) {
            "jungkook" -> "Jungkook"
            "zoe" -> "Zoe"
            else -> "Zoe"
        }) ?: when (avatarId) {
            "jungkook" -> "Jungkook"
            "zoe" -> "Zoe"
            else -> "Zoe"
        }
        val callingTitle = sp.getString(KEY_CALLING_TITLE, when (avatarId) {
            "jungkook" -> "ARMY"
            "zoe" -> "amor"
            else -> "amor"
        }) ?: when (avatarId) {
            "jungkook" -> "ARMY"
            "zoe" -> "amor"
            else -> "amor"
        }

        _state.value = VirtualAssistantState(
            isEnabled = enabled,
            selectedAvatarId = avatarId,
            customAvatarName = customName,
            userCallingTitle = callingTitle,
            isListening = false,
            currentAnimationMode = AssistantAnimationMode.STANDING,
            lastInteractionTimeMs = System.currentTimeMillis()
        )

        if (enabled) {
            resetInactivityTimer()
        }
    }

    fun setEnabled(enabled: Boolean) {
        lastProcessedTimestamp = 0L
        val current = _state.value
        val avatar = VirtualAssistantCatalog.getById(current.selectedAvatarId)
        _state.value = current.copy(
            isEnabled = enabled,
            currentAnimationMode = AssistantAnimationMode.STANDING,
            thoughtText = if (enabled) {
                when (avatar.id) {
                    "jungkook" -> "¡Aquí estoy listo y de pie, ${current.userCallingTitle}! 💜💭"
                    "zoe" -> "¡Aquí estoy de pie y lista para tus canciones, ${current.userCallingTitle}! 🌸💭"
                    else -> "¡Aquí estoy parado y listo, ${current.userCallingTitle}! 💭"
                }
            } else null,
            thoughtTimestamp = System.currentTimeMillis(),
            lastInteractionTimeMs = System.currentTimeMillis(),
            isListening = false
        )
        prefs?.edit()
            ?.putBoolean(KEY_ENABLED, enabled)
            ?.putBoolean("assistant_user_explicitly_set_v2", true)
            ?.apply()

        if (enabled) {
            scheduleThoughtAutoClear()
            resetInactivityTimer()
        } else {
            inactivityTimerJob?.cancel()
            stopListening()
            stopVoiceAudio()
        }
    }

    fun selectAvatar(avatarId: String) {
        val avatar = VirtualAssistantCatalog.getById(avatarId)
        val current = _state.value
        val defaultName = when (avatar.id) {
            "jungkook" -> "Jungkook"
            "zoe" -> "Zoe"
            "jorge_luna" -> "Jorge"
            else -> avatar.name.split(" ").last()
        }
        val defaultTitle = avatar.defaultCallingTitle

        _state.value = current.copy(
            selectedAvatarId = avatarId,
            customAvatarName = if (current.customAvatarName.isBlank() || current.customAvatarName in listOf("Jorge", "Jungkook", "Zoe")) defaultName else current.customAvatarName,
            userCallingTitle = if (current.userCallingTitle.isBlank() || current.userCallingTitle in listOf("mi rey", "ARMY", "amor")) defaultTitle else current.userCallingTitle,
            currentAnimationMode = AssistantAnimationMode.STANDING,
            thoughtText = when (avatar.id) {
                "jungkook" -> "안녕하세요! Ahora te acompaño como Jungkook, ${if (current.userCallingTitle.isBlank()) defaultTitle else current.userCallingTitle} 💜💭"
                "zoe" -> "¡Hola! Ahora te acompaño como Zoe, lista para tu música, ${if (current.userCallingTitle.isBlank()) defaultTitle else current.userCallingTitle} 🌸💭"
                else -> "¡Hola! Ahora te acompaño como ${avatar.name}, ${current.userCallingTitle} 💭"
            },
            thoughtTimestamp = System.currentTimeMillis(),
            lastInteractionTimeMs = System.currentTimeMillis()
        )
        prefs?.edit()?.putString(KEY_AVATAR_ID, avatarId)?.apply()

        // Only Jungkook responds with real audio voice (greeting clip)
        if (avatar.hasVoiceAudio && avatar.greetingAudioRes != null) {
            playAvatarVoice(avatar.greetingAudioRes)
        }

        scheduleThoughtAutoClear()
        resetInactivityTimer()
    }

    fun setCustomAvatarName(name: String) {
        val current = _state.value
        val fallback = when (current.selectedAvatarId) {
            "jungkook" -> "Jungkook"
            "zoe" -> "Zoe"
            else -> "Jorge"
        }
        val clean = name.trim().ifBlank { fallback }
        _state.value = _state.value.copy(
            customAvatarName = clean,
            lastInteractionTimeMs = System.currentTimeMillis()
        )
        prefs?.edit()?.putString(KEY_CUSTOM_NAME, clean)?.apply()
        standUpAndInteract("Desde ahora responderé cuando me llames $clean, ${state.value.userCallingTitle} 💭")
    }

    fun setUserCallingTitle(title: String) {
        val clean = title.trim().ifBlank { "mi rey" }
        _state.value = _state.value.copy(
            userCallingTitle = clean,
            lastInteractionTimeMs = System.currentTimeMillis()
        )
        prefs?.edit()?.putString(KEY_CALLING_TITLE, clean)?.apply()
        standUpAndInteract("Entendido, desde ahora te llamaré $clean 💭")
    }

    /**
     * Resets the 1-minute inactivity timer.
     * When 60 seconds pass with no commands or taps:
     * - Jorge Luna brings a chair and sits down.
     * - Jungkook enters his cute sleeping cycle (poses a -> b -> c -> d with Zzz).
     * - Zoe enters her peaceful meditation and sleep cycle.
     */
    fun resetInactivityTimer() {
        if (!_state.value.isEnabled) return
        inactivityTimerJob?.cancel()
        _state.value = _state.value.copy(lastInteractionTimeMs = System.currentTimeMillis())

        inactivityTimerJob = scope.launch {
            delay(INACTIVITY_TIMEOUT_MS)
            if (_state.value.isEnabled && _state.value.currentAnimationMode == AssistantAnimationMode.STANDING) {
                val currentAvatar = VirtualAssistantCatalog.getById(_state.value.selectedAvatarId)
                if (currentAvatar.id == "jungkook") {
                    Log.d(TAG, "1 min inactivity -> Jungkook sleeping cycle")
                    _state.value = _state.value.copy(currentAnimationMode = AssistantAnimationMode.SEATED)
                    emitThought("Zzz... me duermo un ratito, ${_state.value.userCallingTitle}... 💤💜💭", 4500L)
                } else if (currentAvatar.id == "zoe") {
                    Log.d(TAG, "1 min inactivity -> Zoe meditation and sleeping cycle")
                    _state.value = _state.value.copy(currentAnimationMode = AssistantAnimationMode.SITTING_DOWN)
                    delay(1200L)
                    if (_state.value.currentAnimationMode == AssistantAnimationMode.SITTING_DOWN) {
                        _state.value = _state.value.copy(currentAnimationMode = AssistantAnimationMode.SEATED)
                        emitThought("Zzz... me quedo dormidita descansando, ${_state.value.userCallingTitle}... 💤🌸", 4500L)
                    }
                } else {
                    Log.d(TAG, "1 minute inactivity -> Jorge sitting animation")
                    _state.value = _state.value.copy(currentAnimationMode = AssistantAnimationMode.SITTING_DOWN)
                    delay(1200L)
                    if (_state.value.currentAnimationMode == AssistantAnimationMode.SITTING_DOWN) {
                        _state.value = _state.value.copy(currentAnimationMode = AssistantAnimationMode.SEATED)
                        emitThought("Me siento un ratito en mi silla a descansar, ${_state.value.userCallingTitle}... 💭", 3500L)
                    }
                }
            }
        }
    }

    /**
     * Wakes up avatar from seated/sleeping pose to standing immediately upon interaction.
     */
    fun standUpAndInteract(thought: String? = null) {
        resetInactivityTimer()
        val currentMode = _state.value.currentAnimationMode
        if (currentMode == AssistantAnimationMode.SEATED || currentMode == AssistantAnimationMode.SITTING_DOWN) {
            _state.value = _state.value.copy(currentAnimationMode = AssistantAnimationMode.STANDING)
        }
        if (thought != null) {
            emitThought(thought)
        }
    }

    /**
     * Plays voice audio specifically for Jungkook without stopping song playback.
     */
    fun playAvatarVoice(audioResId: Int?) {
        if (audioResId == null) return
        val currentAvatar = VirtualAssistantCatalog.getById(_state.value.selectedAvatarId)
        if (!currentAvatar.hasVoiceAudio) return // Only Jungkook responds with audio!

        val ctx = appContext ?: return
        handler.post {
            try {
                voiceMediaPlayer?.stop()
                voiceMediaPlayer?.release()
                voiceMediaPlayer = null

                // Duck music slightly so voice clip is loud and clear
                DriyAudioPlayer.duckAudio(true)

                val mp = MediaPlayer.create(ctx, audioResId) ?: run {
                    DriyAudioPlayer.duckAudio(false)
                    return@post
                }
                voiceMediaPlayer = mp
                mp.setOnCompletionListener {
                    DriyAudioPlayer.duckAudio(false)
                    try {
                        it.release()
                    } catch (_: Exception) {}
                    if (voiceMediaPlayer == it) {
                        voiceMediaPlayer = null
                    }
                }
                mp.start()
            } catch (e: Exception) {
                Log.e(TAG, "Error playing avatar voice: ${e.message}")
                DriyAudioPlayer.duckAudio(false)
            }
        }
    }

    private fun stopVoiceAudio() {
        handler.post {
            try {
                voiceMediaPlayer?.stop()
                voiceMediaPlayer?.release()
                voiceMediaPlayer = null
            } catch (_: Exception) {}
        }
    }

    private fun getAudioManager(): AudioManager? {
        return appContext?.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
    }

    /**
     * Adjusts system music volume up or down by delta steps.
     * Returns resulting volume percentage (0..100).
     */
    fun adjustVolume(delta: Int): Int {
        val am = getAudioManager() ?: return 50
        val current = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val target = (current + delta).coerceIn(0, max)
        am.setStreamVolume(AudioManager.STREAM_MUSIC, target, AudioManager.FLAG_SHOW_UI)
        return if (max > 0) (target * 100) / max else 50
    }

    /**
     * Sets volume based on a 1-to-10 scale (1 = 10%, 10 = 100%).
     */
    fun setVolumeStep1to10(step: Int): Int {
        val am = getAudioManager() ?: return 50
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val fraction = step.coerceIn(0, 10) / 10f
        val target = (fraction * max).toInt().coerceIn(0, max)
        am.setStreamVolume(AudioManager.STREAM_MUSIC, target, AudioManager.FLAG_SHOW_UI)
        return if (max > 0) (target * 100) / max else 50
    }

    /**
     * Sets volume percentage directly (0 to 100%).
     */
    fun setVolumePercent(percent: Int): Int {
        val am = getAudioManager() ?: return 50
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val fraction = percent.coerceIn(0, 100) / 100f
        val target = (fraction * max).toInt().coerceIn(0, max)
        am.setStreamVolume(AudioManager.STREAM_MUSIC, target, AudioManager.FLAG_SHOW_UI)
        return if (max > 0) (target * 100) / max else 50
    }

    /**
     * Mutes or unmutes the audio stream.
     */
    fun setMute(mute: Boolean) {
        val am = getAudioManager() ?: return
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            val direction = if (mute) AudioManager.ADJUST_MUTE else AudioManager.ADJUST_UNMUTE
            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, AudioManager.FLAG_SHOW_UI)
        } else {
            @Suppress("DEPRECATION")
            am.setStreamMute(AudioManager.STREAM_MUSIC, mute)
        }
    }

    /**
     * Emits a thought bubble without making unwanted noise.
     */
    fun emitThought(text: String, durationMs: Long = 4000L) {
        _state.value = _state.value.copy(
            thoughtText = text,
            thoughtTimestamp = System.currentTimeMillis()
        )
        scheduleThoughtAutoClear(durationMs)
    }

    private fun scheduleThoughtAutoClear(durationMs: Long = 4000L) {
        thoughtClearJob?.cancel()
        thoughtClearJob = scope.launch {
            delay(durationMs)
            _state.value = _state.value.copy(thoughtText = null)
        }
    }

    private fun triggerAnimation(mode: AssistantAnimationMode, durationMs: Long = 4500L) {
        animationResetJob?.cancel()
        _state.value = _state.value.copy(currentAnimationMode = mode)
        animationResetJob = scope.launch {
            delay(durationMs)
            // After finishing action, return to STANDING (resetting inactivity timer)
            _state.value = _state.value.copy(currentAnimationMode = AssistantAnimationMode.STANDING)
            resetInactivityTimer()
        }
    }

    private fun normalize(str: String): String {
        val nfd = Normalizer.normalize(str.trim().lowercase(Locale.getDefault()), Normalizer.Form.NFD)
        return nfd.replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
    }

    /**
     * Checks if the phrase contains the avatar's wake word / name.
     * STRICT: Only responds when the user mentions the avatar by name!
     * Examples: "jorge", "jorgito", "jungkook", "jonkug", "kookie", custom name
     */
    fun containsWakeWord(cleanText: String): Boolean {
        val custom = normalize(_state.value.customAvatarName)
        val currentAvatar = VirtualAssistantCatalog.getById(_state.value.selectedAvatarId)
        val avatarName = normalize(currentAvatar.name)
        val title = normalize(_state.value.userCallingTitle)

        val validWakeWords = listOf(
            custom,
            avatarName,
            title,
            "jorge",
            "jorgito",
            "jorgi",
            "jorgeluna",
            "jorge luna",
            "hey jorge",
            "oye jorge",
            "hola jorge",
            "hey jorgito",
            "oye jorgito",
            "jungkook",
            "jung kook",
            "jungko",
            "jungkuk",
            "yunkuk",
            "yunque",
            "jonkug",
            "jonkuk",
            "kookie",
            "kuki",
            "jk",
            "jeon jungkook",
            "jungkooki",
            "galleta",
            "maknae",
            "hey jungkook",
            "oye jungkook",
            "hola jungkook",
            "zoe",
            "soe",
            "soi",
            "zoi",
            "zoy",
            "soy",
            "zoee",
            "soee",
            "hey zoe",
            "oye zoe",
            "hola zoe",
            "chica zoe",
            "amor zoe",
            "linda zoe",
            "mi zoe"
        )
        return validWakeWords.any { it.isNotBlank() && cleanText.contains(it) }
    }

    /**
     * Processes command issued either by voice or text input.
     * STRICT WAKE WORD REQUIREMENT: Only executes if the assigned name is heard!
     */
    fun processCommand(rawInput: String, isDirectChip: Boolean = false): Boolean {
        if (rawInput.isBlank()) return false
        val now = System.currentTimeMillis()
        if (!isDirectChip && now - lastProcessedTimestamp < 800L) {
            // Debounce fast speech recognizer repeats
            return false
        }

        val clean = normalize(rawInput)
        val currentState = _state.value
        val callingTitle = currentState.userCallingTitle
        val avatarName = normalize(currentState.customAvatarName)
        val currentAvatar = VirtualAssistantCatalog.getById(currentState.selectedAvatarId)

        val hasWakeWord = isDirectChip || containsWakeWord(clean)

        // STRICT: If the user didn't mention the avatar name (and it's not a direct button tap), IGNORE!
        if (!hasWakeWord) {
            Log.d(TAG, "Speech ignored (no wake word for '$avatarName'): $rawInput")
            return false
        }

        lastProcessedTimestamp = now
        standUpAndInteract()
        _state.value = currentState.copy(
            lastHeardCommand = rawInput,
            lastInteractionTimeMs = now,
            currentAnimationMode = AssistantAnimationMode.STANDING
        )

        // 1. REACCIÓN DE AMOR / CORAZONES / BESO:
        // "te amo zoe", "te quiero zoe", "dame un beso zoe", "te amo", "amame", "te quiero", "dame un beso"
        val isLove = clean.contains("te amo") ||
                clean.contains("amame") ||
                clean.contains("te quiero") ||
                clean.contains("dame un beso") ||
                clean.contains("un beso") ||
                clean.contains("besame") ||
                clean.contains("dame beso") ||
                clean.contains("te adoro") ||
                clean.contains("saranghae") ||
                clean.contains("saranghaeyo") ||
                clean.contains("love you")

        if (isLove) {
            triggerAnimation(AssistantAnimationMode.LOVE, durationMs = 5000L)
            if (currentAvatar.id == "zoe") {
                emitThought("¡Muak! 💋 ¡Te amo y te quiero un montón, mi $callingTitle! Siempre contigo 🌸✨", 5000L)
            } else if (currentAvatar.hasVoiceAudio) {
                playAvatarVoice(currentAvatar.loveAudioRes)
                emitThought("나도 사랑해요 (¡Yo también te amo, $callingTitle!) 💜🫰", 5000L)
            } else {
                emitThought("¡Yo también te aprecio un montón, $callingTitle! 💭", 4500L)
            }
            return true
        }

        // 2. AUDIO Y VOLUMEN: SILENCIA EL AUDIO / PON EN SILENCIO / MUTE
        val isMute = clean.contains("silencia el audio") ||
                clean.contains("silenciando el audio") ||
                clean.contains("silencia la musica") ||
                clean.contains("silencia el sonido") ||
                clean.contains("silencia el volumen") ||
                clean.contains("pon en silencio") ||
                clean.contains("pon silencio") ||
                clean.contains("modo silencio") ||
                clean.contains("mutear el audio") ||
                clean.contains("mutea el audio") ||
                clean == "silencia" ||
                clean == "mute" ||
                clean == "mutear" ||
                clean.endsWith(" silencia") ||
                clean.endsWith(" mute") ||
                clean.endsWith(" mutear")

        if (isMute) {
            triggerAnimation(AssistantAnimationMode.CHANGING_MUSIC, durationMs = 4000L)
            setMute(true)
            if (currentAvatar.hasVoiceAudio) {
                playAvatarVoice(currentAvatar.muteAudioRes)
            }
            if (currentAvatar.id == "jungkook") {
                emitThought("🔇 Silenciando el audio, $callingTitle 💜💭", 4000L)
            } else {
                emitThought("🔇 Audio silenciado, $callingTitle 💭", 4000L)
            }
            return true
        }

        // 3. AUDIO Y VOLUMEN: ACTIVA EL SONIDO / DESMUTEAR
        val isUnmute = clean.contains("activa el sonido") ||
                clean.contains("activa el audio") ||
                clean.contains("activa el volumen") ||
                clean.contains("quita el silencio") ||
                clean.contains("saca el silencio") ||
                clean.contains("desmutea") ||
                clean.contains("desmutear") ||
                clean.contains("reactiva el audio") ||
                clean.contains("reactiva el sonido")

        if (isUnmute) {
            triggerAnimation(AssistantAnimationMode.CHANGING_MUSIC, durationMs = 4000L)
            setMute(false)
            emitThought("🔊 Sonido activado, $callingTitle 💭", 4000L)
            return true
        }

        // 4. AUDIO Y VOLUMEN: PON EL VOLUMEN AL [NÚMERO 1 AL 10 / PORCENTAJE / PALABRAS] / PON LA MÚSICA AL 50
        val isExplicit50 = clean.contains("al 50") ||
                clean.contains("a 50") ||
                clean.contains("en 50") ||
                clean.contains("al cincuenta") ||
                clean.contains("musica al 50") ||
                clean.contains("musia al 50") ||
                clean.contains("poniendo musica al 50") ||
                clean.contains("pon la musia al 50") ||
                clean.contains("pon la musica al 50")
        val isVolumeSet = isExplicit50 || ((clean.contains("volumen") || clean.contains("sonido") || clean.contains("musica") || clean.contains("musia")) &&
                (clean.contains(" al ") || clean.contains(" a ") || clean.contains(" en ") || clean.contains(" nivel ") ||
                 clean.contains("maximo") || clean.contains("minimo") || clean.contains("mitad") || clean.contains("medio")))

        if (isVolumeSet) {
            triggerAnimation(AssistantAnimationMode.CHANGING_MUSIC, durationMs = 4000L)
            val isFifty = isExplicit50 || clean.contains("50") || clean.contains("cincuenta") || clean.contains("mitad") || clean.contains("medio")
            val pct = when {
                clean.contains("maximo") || clean.contains("cien") -> setVolumePercent(100)
                clean.contains("minimo") -> setVolumePercent(10)
                isFifty -> setVolumePercent(50)
                else -> {
                    val regex = Regex("""(?:volumen|sonido|musica|musia).*?(?:al|a|en|nivel)?\s*(\d{1,3})\s*(%|por ciento)?""")
                    val match = regex.find(clean)
                    val num = match?.groupValues?.getOrNull(1)?.toIntOrNull()
                    val hasPercent = match?.groupValues?.getOrNull(2)?.isNotBlank() == true
                    if (num != null) {
                        if (hasPercent || num > 10) {
                            setVolumePercent(num)
                        } else {
                            setVolumeStep1to10(num)
                        }
                    } else {
                        adjustVolume(0)
                    }
                }
            }
            if (currentAvatar.hasVoiceAudio) {
                if (isFifty || pct in 45..55) {
                    playAvatarVoice(currentAvatar.volume50AudioRes)
                }
            }
            if (currentAvatar.id == "jungkook") {
                if (isFifty || pct in 45..55) {
                    emitThought("🔊 Poniendo la música al 50%, $callingTitle 💜💭", 4000L)
                } else {
                    emitThought("🔊 Volumen ajustado al $pct%, $callingTitle 💜💭", 4000L)
                }
            } else {
                emitThought("🔊 Volumen ajustado al $pct%, $callingTitle 💭", 4000L)
            }
            return true
        }

        // 5. AUDIO Y VOLUMEN: SUBE EL VOLUMEN / SUBA VOLUMEN
        val isVolumeUp = clean.contains("sube el volumen") ||
                clean.contains("suba el volumen") ||
                clean.contains("subiendo el volumen") ||
                clean.contains("subiendo volumen") ||
                clean.contains("sube volumen") ||
                clean.contains("suba volumen") ||
                clean.contains("aumenta el volumen") ||
                clean.contains("aumenta volumen") ||
                clean.contains("mas volumen") ||
                clean.contains("subele") ||
                clean.contains("mas fuerte") ||
                clean.contains("sube el audio") ||
                clean.contains("sube el sonido")

        if (isVolumeUp) {
            triggerAnimation(AssistantAnimationMode.CHANGING_MUSIC, durationMs = 4000L)
            val pct = adjustVolume(+2)
            if (currentAvatar.hasVoiceAudio) {
                playAvatarVoice(currentAvatar.volumeUpAudioRes)
            }
            if (currentAvatar.id == "zoe") {
                emitThought("📱 Sacando celular para subir el volumen ($pct%), $callingTitle 🌸🔊", 4000L)
            } else if (currentAvatar.id == "jungkook") {
                emitThought("🔊 Subiendo el volumen ($pct%), $callingTitle 💜💭", 4000L)
            } else {
                emitThought("🔊 Volumen aumentado ($pct%), $callingTitle 💭", 4000L)
            }
            return true
        }

        // 6. AUDIO Y VOLUMEN: BAJA EL VOLUMEN / BAJE VOLUMEN
        val isVolumeDown = clean.contains("baja el volumen") ||
                clean.contains("baje el volumen") ||
                clean.contains("bajando el volumen") ||
                clean.contains("bajando volumen") ||
                clean.contains("baja volumen") ||
                clean.contains("baje volumen") ||
                clean.contains("disminuye el volumen") ||
                clean.contains("disminuye volumen") ||
                clean.contains("menos volumen") ||
                clean.contains("bajale") ||
                clean.contains("mas bajo") ||
                clean.contains("mas despacio") ||
                clean.contains("baja el audio") ||
                clean.contains("baja el sonido")

        if (isVolumeDown) {
            triggerAnimation(AssistantAnimationMode.CHANGING_MUSIC, durationMs = 4000L)
            val pct = adjustVolume(-2)
            if (currentAvatar.hasVoiceAudio) {
                playAvatarVoice(currentAvatar.volumeDownAudioRes)
            }
            if (currentAvatar.id == "zoe") {
                emitThought("📱 Sacando celular para bajar el volumen ($pct%), $callingTitle 🌸🔉", 4000L)
            } else if (currentAvatar.id == "jungkook") {
                emitThought("🔉 Bajando el volumen ($pct%), $callingTitle 💜💭", 4000L)
            } else {
                emitThought("🔉 Volumen reducido ($pct%), $callingTitle 💭", 4000L)
            }
            return true
        }

        // 7. CONSULTA DE CANCIÓN: ¿QUÉ CANCIÓN ESTÁ SONANDO? / ESTÁ SONANDO
        val isSongQuery = clean.contains("que cancion esta sonando") ||
                clean.contains("que cancion suena") ||
                clean.contains("que cancion se escucha") ||
                clean.contains("que tema esta sonando") ||
                clean.contains("que tema suena") ||
                clean.contains("que musica esta sonando") ||
                clean.contains("esta sonando") ||
                clean.contains("que musica suena") ||
                clean.contains("como se llama esta cancion") ||
                clean.contains("como se llama el tema") ||
                clean.contains("cual es esta cancion") ||
                clean.contains("que estamos escuchando") ||
                clean.contains("que cancion es esta") ||
                clean.contains("que cancion es")

        if (isSongQuery) {
            triggerAnimation(AssistantAnimationMode.CHANGING_MUSIC, durationMs = 5000L)
            val song = DriyAudioPlayer.playerState.value.currentSong
            val isPlaying = DriyAudioPlayer.playerState.value.isPlaying
            if (currentAvatar.hasVoiceAudio) {
                playAvatarVoice(currentAvatar.currentSongAudioRes)
            }
            if (song != null) {
                val stateDesc = if (isPlaying) "Está sonando" else "Está en pausa"
                if (currentAvatar.id == "jungkook") {
                    emitThought("🎵 $stateDesc \"${song.title}\" de ${song.artist}, $callingTitle 💜💭", 6000L)
                } else {
                    emitThought("🎵 $stateDesc \"${song.title}\" de ${song.artist}, $callingTitle 💭", 6000L)
                }
            } else {
                if (currentAvatar.id == "jungkook") {
                    emitThought("No hay ninguna canción sonando ahora mismo, $callingTitle. ¡Pídeme una cuando quieras! 💜💭", 4500L)
                } else {
                    emitThought("No hay ninguna canción sonando ahora mismo, $callingTitle. ¡Pídeme una cuando quieras! 💭", 4500L)
                }
            }
            return true
        }

        // 8. PAUSA DE MÚSICA / DETENER: "pon pausa", "pausala", "deten la musica", "deten", "para"
        val isPause = clean.contains("pon pausa") ||
                clean.contains("ponle pausa") ||
                clean.contains("pausala") ||
                clean.contains("pausalo") ||
                clean.contains("pausa la musica") ||
                clean.contains("pause la musica") ||
                clean.contains("pausando la musica") ||
                clean.contains("pausar la musica") ||
                clean.contains("pausa la cancion") ||
                clean.contains("deten la musica") ||
                clean.contains("detener la musica") ||
                clean.contains("deten la cancion") ||
                clean.contains("detener la cancion") ||
                clean.contains("detenla") ||
                clean.contains("detenlo") ||
                clean.contains("deten") ||
                clean.contains("detente") ||
                clean.contains("para la musica") ||
                clean.contains("parala") ||
                clean.contains("paralo") ||
                clean.contains("pause") ||
                clean.contains("puase") ||
                clean == "pausa" ||
                clean == "pausar" ||
                clean == "para" ||
                clean == "stop" ||
                clean.endsWith(" pausa") ||
                clean.endsWith(" pon pausa") ||
                clean.endsWith(" deten la musica") ||
                clean.endsWith(" pausala")

        if (isPause) {
            triggerAnimation(AssistantAnimationMode.CHANGING_MUSIC, durationMs = 4200L)
            if (currentAvatar.hasVoiceAudio) {
                playAvatarVoice(currentAvatar.pauseSongAudioRes ?: currentAvatar.changeSongAudioRes)
            }
            if (currentAvatar.id == "zoe") {
                emitThought("📱 Sacando celular para pausar la música, $callingTitle 🌸⏸️", 4200L)
            } else if (currentAvatar.id == "jungkook") {
                emitThought("⏸️ Pausando la música, $callingTitle 💜💭", 4200L)
            } else {
                emitThought("⏸️ Música en pausa, $callingTitle 💭", 4200L)
            }
            if (DriyAudioPlayer.playerState.value.isPlaying) {
                DriyAudioPlayer.togglePlayPause()
            }
            return true
        }

        // 9. NEXT TRACK / PASA A LA SIGUIENTE CANCIÓN / AVANCE / SIGUIENTE PISTA:
        val isNext = clean.contains("siguiente pista") ||
                clean.contains("siguiente cancion") ||
                clean.contains("pasa a la siguiente cancion") ||
                clean.contains("pasa a la siguiente pista") ||
                clean.contains("pasa a la siguiente") ||
                clean.contains("pasa la siguiente cancion") ||
                clean.contains("pasa la siguiente pista") ||
                clean.contains("pasa la cancion") ||
                clean.contains("pasa la pista") ||
                clean.contains("pasala") ||
                clean.contains("avance") ||
                clean.contains("avanza") ||
                clean.contains("avanzar") ||
                clean.contains("siguiente") ||
                clean.contains("adelanta") ||
                clean.contains("adelantar") ||
                clean.contains("salta de cancion") ||
                clean.contains("salta la cancion") ||
                clean.contains("salta cancion") ||
                clean.contains("salta pista") ||
                clean.contains("salta") ||
                clean.contains("cambia de cancion") ||
                clean.contains("cambia la cancion") ||
                clean.contains("cambiar cancion") ||
                clean.contains("cambia cancion") ||
                clean.contains("cambia tema") ||
                clean.contains("otra cancion") ||
                clean.contains("otra pista") ||
                clean.contains("proxima cancion") ||
                clean.contains("proxima pista") ||
                clean.contains("proxima")

        if (isNext) {
            triggerAnimation(AssistantAnimationMode.CHANGING_MUSIC, durationMs = 4500L)
            if (currentAvatar.hasVoiceAudio) {
                playAvatarVoice(currentAvatar.changeSongAudioRes)
                emitThought("⏭️ Cambiando a la siguiente canción, $callingTitle 💜🎶", 4500L)
            } else if (currentAvatar.id == "zoe") {
                emitThought("📱 Sacando celular para avanzar a la siguiente canción, $callingTitle 🌸⏭️", 4200L)
            } else {
                emitThought("¡Avanzando a la siguiente canción, $callingTitle! 💭", 4200L)
            }
            DriyAudioPlayer.playNext()
            return true
        }

        // 10. PREVIOUS TRACK / RETROCEDE / VUELVE A LA CANCIÓN ANTERIOR / REGRESA:
        val isPrevious = clean.contains("retrocede") ||
                clean.contains("retroceda") ||
                clean.contains("retroceder") ||
                clean.contains("vuelve a la cancion anterior") ||
                clean.contains("vuelve a la anterior musica") ||
                clean.contains("vuelve a la anterior cancion") ||
                clean.contains("vuelve a la anterior") ||
                clean.contains("vuelve a la cancion") ||
                clean.contains("vuelve atras") ||
                clean.contains("vuelve") ||
                clean.contains("regresa a la cancion anterior") ||
                clean.contains("regresa a la anterior musica") ||
                clean.contains("regresa a la anterior cancion") ||
                clean.contains("regresa a la anterior") ||
                clean.contains("regresa") ||
                clean.contains("regresar") ||
                clean.contains("cancion anterior") ||
                clean.contains("pista anterior") ||
                clean.contains("anterior pista") ||
                clean.contains("anterior cancion") ||
                clean.contains("cancion previa") ||
                clean.contains("pon la cancion anterior") ||
                clean.contains("poniendo cancion anterior") ||
                clean.contains("poniendo la cancion anterior") ||
                clean.contains("anterior") ||
                clean.contains("atras")

        if (isPrevious) {
            triggerAnimation(AssistantAnimationMode.CHANGING_MUSIC, durationMs = 4500L)
            if (currentAvatar.hasVoiceAudio) {
                playAvatarVoice(currentAvatar.previousSongAudioRes ?: currentAvatar.changeSongAudioRes)
                emitThought("⏮️ Poniendo la canción anterior, $callingTitle 💜🎶", 4500L)
            } else if (currentAvatar.id == "zoe") {
                emitThought("📱 Sacando celular para retroceder a la canción anterior, $callingTitle 🌸⏮️", 4200L)
            } else {
                emitThought("¡Volviendo a la anterior, $callingTitle! 💭", 4200L)
            }
            DriyAudioPlayer.playPrevious()
            return true
        }

        // 12. BENDICIÓN: "dame tu bendicion", "bendi", "bedi"
        val isBlessing = clean.contains("bendic") ||
                clean.contains("vendic") ||
                clean.contains("bedic") ||
                clean.contains("bendi") ||
                clean.contains("bedi")

        if (isBlessing) {
            if (currentAvatar.id == "jungkook") {
                triggerAnimation(AssistantAnimationMode.LOVE, durationMs = 5000L)
                playAvatarVoice(currentAvatar.loveAudioRes)
                emitThought("나도 사랑해요 (¡Toda mi bendición y amor para ti, $callingTitle!) 💜🫰", 5000L)
            } else {
                triggerAnimation(AssistantAnimationMode.BLESSING, durationMs = 4500L)
                emitThought("¡Toma mi bendición, $callingTitle! Que la risa y la buena música nunca te falten 💭", 4500L)
            }
            return true
        }

        // 13. PLAYLIST POR GÉNERO: "pon una lista de reproducción de [género]"
        val genreQuery = extractGenrePlaylistQuery(clean)
        if (!genreQuery.isNullOrBlank()) {
            triggerAnimation(AssistantAnimationMode.CHANGING_MUSIC, durationMs = 5000L)
            if (currentAvatar.hasVoiceAudio) {
                playAvatarVoice(currentAvatar.changeSongAudioRes)
            }
            emitThought("🎧 Buscando playlist de $genreQuery para ti, $callingTitle... 💭", 5000L)
            searchAndPlaySpecificSong(
                query = "playlist lo mejor de $genreQuery mix",
                callingTitle = callingTitle,
                customAnnouncement = "¡Playlist de $genreQuery lista para ti, $callingTitle! 🎶💭"
            )
            return true
        }

        // 14. MÚSICA PARA ACTIVIDAD O MOOD: "reproduce música para [estudiar / entrenar / relajarse]"
        val activityQuery = extractActivityMusicQuery(clean)
        if (!activityQuery.isNullOrBlank()) {
            triggerAnimation(AssistantAnimationMode.CHANGING_MUSIC, durationMs = 5000L)
            if (currentAvatar.hasVoiceAudio) {
                playAvatarVoice(currentAvatar.changeSongAudioRes)
            }
            emitThought("✨ Buscando música para $activityQuery para ti, $callingTitle... 💭", 5000L)
            searchAndPlaySpecificSong(
                query = "musica para $activityQuery mix",
                callingTitle = callingTitle,
                customAnnouncement = "¡Música para $activityQuery sonando, $callingTitle! 🎧💭"
            )
            return true
        }

        // 14. CANCIONES DE UN ARTISTA: "reproduce música de [Artista]", "pon la música de [Artista]", "reproduce la musica de tal cantante"
        val artistQuery = extractArtistMusicQuery(clean)
        if (!artistQuery.isNullOrBlank()) {
            triggerAnimation(AssistantAnimationMode.CHANGING_MUSIC, durationMs = 5000L)
            if (currentAvatar.hasVoiceAudio) {
                playAvatarVoice(currentAvatar.changeSongAudioRes)
            }
            if (currentAvatar.id == "zoe") {
                emitThought("📱 Sacando celular para buscar canciones de $artistQuery, $callingTitle 🌸🎶", 5000L)
            } else {
                emitThought("🎤 Buscando canciones de $artistQuery para ti, $callingTitle... 💭", 5000L)
            }
            searchAndPlaySpecificSong(
                query = "lo mejor de $artistQuery grandes exitos audio oficial",
                callingTitle = callingTitle,
                customAnnouncement = if (currentAvatar.id == "zoe") {
                    "📱 ¡Sonando lo mejor de $artistQuery, $callingTitle! 🌸🎵"
                } else {
                    "¡Sonando lo mejor de $artistQuery, $callingTitle! 🎵💭"
                }
            )
            return true
        }

        // 15. CANCIÓN ESPECÍFICA: "reproduce la canción [X]", "pon la música [X]", "busca la cancion [X] de [Y]"
        val specificSearchQuery = extractMusicSearchQuery(clean)
        if (!specificSearchQuery.isNullOrBlank()) {
            triggerAnimation(AssistantAnimationMode.CHANGING_MUSIC, durationMs = 5000L)
            if (currentAvatar.hasVoiceAudio) {
                playAvatarVoice(currentAvatar.changeSongAudioRes)
                emitThought("노래 바꾸기: Buscando \"$specificSearchQuery\" para ti, $callingTitle... 📱💭", 5000L)
            } else if (currentAvatar.id == "zoe") {
                emitThought("📱 Sacando celular para buscar y reproducir \"$specificSearchQuery\", $callingTitle 🌸🎶", 5000L)
            } else {
                emitThought("Buscando \"$specificSearchQuery\" para ti, $callingTitle... 💭", 5000L)
            }
            searchAndPlaySpecificSong(
                query = specificSearchQuery,
                callingTitle = callingTitle,
                customAnnouncement = if (currentAvatar.id == "zoe") {
                    "📱 ¡Sonando \"$specificSearchQuery\", $callingTitle! 🌸🎵"
                } else null
            )
            return true
        }

        // 16. REPRODUCCIÓN SIMPLE / REANUDAR MÚSICA / PLAY GENERAL:
        // "reproduce musica", "pon la musica", "pon musica", "dale play", "reanuda", "despausa"
        val isResumeOrPlay = clean.contains("reproduce musica") ||
                clean.contains("reproduce la musica") ||
                clean.contains("pon la musica") ||
                clean.contains("pon musica") ||
                clean.contains("ponga la musica") ||
                clean.contains("ponga musica") ||
                clean.contains("dale play") ||
                clean.contains("reanuda") ||
                clean.contains("reanudar") ||
                clean.contains("reanudando") ||
                clean.contains("despausa") ||
                clean.contains("despausar") ||
                clean.contains("quita la pausa") ||
                clean.contains("saca la pausa") ||
                clean.contains("continua la musica") ||
                clean.contains("continua") ||
                clean.contains("continuar") ||
                clean.contains("sigue la musica") ||
                clean.contains("sigue") ||
                clean.contains("toca musica") ||
                clean == "reproduce" ||
                clean == "play" ||
                clean == "toca" ||
                clean.endsWith(" reproduce") ||
                clean.endsWith(" pon musica") ||
                clean.endsWith(" pon la musica")

        if (isResumeOrPlay) {
            triggerAnimation(AssistantAnimationMode.CHANGING_MUSIC, durationMs = 4200L)
            if (currentAvatar.hasVoiceAudio) {
                playAvatarVoice(currentAvatar.changeSongAudioRes)
            }
            if (currentAvatar.id == "zoe") {
                emitThought("📱 Sacando celular para poner tu música, $callingTitle... ¡A disfrutar! 🌸▶️", 4200L)
            } else {
                emitThought("¡A la orden, $callingTitle! Reproduciendo la música 💭", 4200L)
            }
            if (!DriyAudioPlayer.playerState.value.isPlaying) {
                DriyAudioPlayer.togglePlayPause()
            }
            return true
        }

        // 18. SALUDOS CORDIALES
        if (clean.contains("hola") || clean.contains("saludos") || clean.contains("buenas") || clean.contains("annyeong") || clean.contains("anyeong")) {
            if (currentAvatar.id == "jungkook") {
                triggerAnimation(AssistantAnimationMode.LOVE, durationMs = 4500L)
                playAvatarVoice(currentAvatar.greetingAudioRes)
                emitThought("안녕하세요! Hola $callingTitle, ¿qué canción ponemos hoy? 💜💭", 4500L)
            } else {
                emitThought("¡Hola, $callingTitle! Aquí de pie listo para tus órdenes musicales 💭")
            }
            return true
        }

        // 19. FALLBACK CON COMANDOS COMPLETOS
        if (currentAvatar.id == "jungkook") {
            triggerAnimation(AssistantAnimationMode.LOVE, durationMs = 4000L)
            emitThought("Dime $callingTitle: 'reproduce la canción...', 'playlist de pop', 'música para estudiar', 'sube el volumen' o 'te amo' 💜💭")
        } else {
            emitThought("Dime $callingTitle: 'reproduce la canción...', 'canciones de [artista]', 'sube/baja volumen', 'qué canción suena' o 'avanza' 💭")
        }
        return true
    }

    /**
     * Removes avatar wake words and common polite prefixes from query text.
     */
    private fun removeWakeWords(text: String): String {
        var res = text
        val wakeWords = listOf(
            "hey", "oye", "hola", "por favor", "favor",
            "jorge luna", "jorgeluna", "jorge", "jorgito", "jorgi",
            "jeon jungkook", "jungkooki", "jungkook", "jung kook", "jonkug", "jonkuk", "kookie", "kuki", "jk",
            "dj neon", "dj", "neon", "maestro ritmo", "maestro", "ritmo",
            "zoe", "soe", "soi", "zoi", "zoy", "soy", "zoee", "soee",
            "chica zoe", "amor zoe", "linda zoe", "mi zoe",
            normalize(_state.value.customAvatarName),
            normalize(_state.value.userCallingTitle)
        )
        for (w in wakeWords) {
            if (w.isNotBlank()) {
                res = res.replace(w, " ")
            }
        }
        return res.replace(Regex("\\s+"), " ").trim()
    }

    /**
     * Extracts genre for "[Avatar], pon una lista de reproducción de [género]"
     */
    private fun extractGenrePlaylistQuery(cleanText: String): String? {
        val query = removeWakeWords(cleanText)
        val triggers = listOf(
            "pon una lista de reproduccion de",
            "reproduce una lista de reproduccion de",
            "pon una playlist de",
            "reproduce una playlist de",
            "pon lista de reproduccion de",
            "reproduce lista de reproduccion de",
            "lista de reproduccion de",
            "playlist de",
            "pon playlist de",
            "pon lista de",
            "lista de",
            "playlist del genero",
            "playlist genero"
        )
        for (t in triggers) {
            val idx = query.indexOf(t)
            if (idx != -1) {
                val candidate = query.substring(idx + t.length).trim()
                    .removePrefix("musica ").removePrefix("canciones ").removePrefix("genero ")
                    .trim()
                if (candidate.length >= 2) return candidate
            }
        }
        return null
    }

    /**
     * Extracts activity/mood for "[Avatar], reproduce música para [estudiar / entrenar / relajarse]"
     */
    private fun extractActivityMusicQuery(cleanText: String): String? {
        val query = removeWakeWords(cleanText)
        val triggers = listOf(
            "reproduce musica para",
            "reproduce canciones para",
            "pon musica para",
            "pon canciones para",
            "busca musica para",
            "toca musica para",
            "musica para",
            "canciones para",
            "temas para",
            "playlist para",
            "pistas para"
        )
        for (t in triggers) {
            val idx = query.indexOf(t)
            if (idx != -1) {
                val candidate = query.substring(idx + t.length).trim()
                if (candidate.length >= 3) return candidate
            }
        }
        return null
    }

    /**
     * Extracts artist for "[Avatar], reproduce música de [Artista]", "[Avatar], pon la música de [Artista]"
     */
    private fun extractArtistMusicQuery(cleanText: String): String? {
        val query = removeWakeWords(cleanText)
        val triggers = listOf(
            "reproduce la musica de",
            "reproduce musica de",
            "reproduce las canciones de",
            "reproduce canciones de",
            "pon la musica de",
            "pon musica de",
            "pon las canciones de",
            "pon canciones de",
            "busca la musica de",
            "busca canciones de",
            "busca musica de",
            "busca las canciones de",
            "toca canciones de",
            "toca musica de",
            "canciones de",
            "lo mejor de",
            "exitos de",
            "musica de"
        )
        for (t in triggers) {
            val idx = query.indexOf(t)
            if (idx != -1) {
                val candidate = query.substring(idx + t.length).trim()
                    .removePrefix("el grupo ").removePrefix("la banda ").removePrefix("el cantante ").removePrefix("la cantante ")
                    .removePrefix("los ").removePrefix("las ").removePrefix("el ").removePrefix("la ")
                    .trim()
                if (candidate.length >= 2 && candidate !in listOf("ti", "mi", "hoy", "manana", "siempre", "musica", "cancion")) {
                    return candidate
                }
            }
        }
        return null
    }

    /**
     * Extracts search query for "reproduce la canción [X]", "pon la música [X]", "busca la canción [X] de [Y]"
     */
    private fun extractMusicSearchQuery(cleanText: String): String? {
        var query = removeWakeWords(cleanText)

        val triggers = listOf(
            "busca y reproduce la cancion",
            "busca y reproduce el tema",
            "busca y reproduce la musica",
            "busca y reproduce",
            "busca la cancion",
            "busca el tema",
            "busca la musica",
            "buscame la cancion",
            "buscame el tema",
            "buscame a",
            "buscame",
            "busca a",
            "busca",
            "reproduce la cancion",
            "reproduce el tema",
            "reproduce la musica",
            "reproduce",
            "pon la musica",
            "pon la cancion",
            "pon el tema",
            "ponme la cancion",
            "ponme",
            "pon",
            "coloca la cancion",
            "coloca el tema",
            "coloca la musica",
            "coloca",
            "toca la cancion",
            "toca el tema",
            "toca la musica",
            "toca"
        )

        for (t in triggers) {
            val idx = query.indexOf(t)
            if (idx != -1) {
                query = query.substring(idx + t.length).trim()
                break
            }
        }

        // Clean up common filler words and trailing noise
        query = query
            .removePrefix("a ")
            .removePrefix("la ")
            .removePrefix("el ")
            .removePrefix("un ")
            .removePrefix("una ")
            .removeSuffix(" musica")
            .removeSuffix(" la musica")
            .removeSuffix(" cancion")
            .removeSuffix(" la cancion")
            .removeSuffix(" tema")
            .trim()

        // Guard against control keywords so they never get searched as a song
        val controlBlacklist = listOf(
            "avanza", "avanzar", "avance", "siguiente", "retrocede", "retroceda", "retroceder", "regresa", "regresar",
            "anterior", "pausa", "pausar", "pausala", "pausalo", "pause", "puase", "para", "parala", "paralo", "stop",
            "musica", "cancion", "tema", "silencio", "callate", "cambia", "cambiar",
            "salta", "saltar", "amor", "te amo", "amame", "beso", "te quiero", "dame un beso",
            "volumen", "sonido", "audio", "sube", "baja", "mute", "despausa", "reanuda"
        )
        if (query in controlBlacklist) {
            return null
        }

        if (query.length >= 2) {
            return query
        }

        return null
    }

    /**
     * Searches YouTube for specific song, playlist or artist requested by voice and starts playback immediately.
     */
    private fun searchAndPlaySpecificSong(
        query: String,
        callingTitle: String,
        customAnnouncement: String? = null
    ) {
        scope.launch(Dispatchers.IO) {
            try {
                val results = YouTubeService.searchYouTube("$query audio oficial")
                    .ifEmpty { YouTubeService.searchYouTube(query) }

                val songToPlay = results.firstOrNull { it.durationSeconds in 45..450 } ?: results.firstOrNull()

                withContext(Dispatchers.Main) {
                    if (songToPlay != null) {
                        DriyAudioPlayer.playSong(songToPlay, listOf(songToPlay))
                        val announcement = customAnnouncement ?: "¡Sonando \"${songToPlay.title}\" de ${songToPlay.artist}, $callingTitle! 💭"
                        emitThought(announcement, 5500L)
                    } else {
                        emitThought("No pude encontrar \"$query\" en este momento, $callingTitle 💭", 4000L)
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error in voice search: ${e.message}")
                withContext(Dispatchers.Main) {
                    emitThought("Hubo un detalle al buscar la música, $callingTitle. Intenta de nuevo 💭")
                }
            }
        }
    }

    /**
     * Starts on-demand or wake-triggered voice recognition.
     * DUCKS THE MUSIC VOLUME (baja de volumen un poco sin pausar la canción).
     * Does NOT auto-restart in an infinite loop!
     */
    fun startListeningSession() {
        val ctx = appContext ?: return
        if (!_state.value.isEnabled) return
        if (_state.value.isListening) return

        handler.post {
            try {
                if (speechRecognizer == null) {
                    if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
                        Log.w(TAG, "Speech recognition not available on this device")
                        emitThought("Reconocimiento de voz no disponible en este dispositivo 💭")
                        return@post
                    }
                    speechRecognizer = SpeechRecognizer.createSpeechRecognizer(ctx)
                }

                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-ES")
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                    putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
                }

                speechRecognizer?.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        _state.value = _state.value.copy(isListening = true)
                        DriyAudioPlayer.duckAudio(true)
                        val avatar = VirtualAssistantCatalog.getById(_state.value.selectedAvatarId)
                        val hint = if (avatar.id == "jungkook") "(di 'Jungkook cambia de canción' o 'Jungkook te amo') 🎙️ 💜" else "(di su nombre y orden) 🎙️ 💭"
                        standUpAndInteract("Te escucho, ${_state.value.userCallingTitle}... $hint")
                    }

                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() {
                        _state.value = _state.value.copy(isListening = false)
                        DriyAudioPlayer.duckAudio(false)
                    }

                    override fun onError(error: Int) {
                        _state.value = _state.value.copy(isListening = false)
                        DriyAudioPlayer.duckAudio(false)
                        Log.d(TAG, "SpeechRecognizer finished (code: $error). Clean stop without looping.")
                    }

                    override fun onResults(results: Bundle?) {
                        _state.value = _state.value.copy(isListening = false)
                        DriyAudioPlayer.duckAudio(false)

                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val recognizedText = matches?.firstOrNull() ?: ""
                        if (recognizedText.isNotBlank()) {
                            Log.d(TAG, "Recognized speech: $recognizedText")
                            processCommand(recognizedText)
                        }
                    }

                    override fun onPartialResults(partialResults: Bundle?) {}
                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })

                speechRecognizer?.startListening(intent)
            } catch (e: Exception) {
                Log.w(TAG, "Error starting SpeechRecognizer: ${e.message}")
                DriyAudioPlayer.duckAudio(false)
                _state.value = _state.value.copy(isListening = false)
            }
        }
    }

    fun stopListening() {
        handler.post {
            try {
                DriyAudioPlayer.duckAudio(false)
                speechRecognizer?.stopListening()
                speechRecognizer?.cancel()
                speechRecognizer?.destroy()
                speechRecognizer = null
                _state.value = _state.value.copy(isListening = false)
            } catch (_: Exception) {
            }
        }
    }

    /**
     * Toggle listening session (Tap to listen)
     */
    fun toggleListening() {
        if (_state.value.isListening) {
            stopListening()
        } else {
            startListeningSession()
        }
    }
}
