package com.example.service

import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.util.Log
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.BuildConfig
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File

data class AppUpdateInfo(
    val latestVersionCode: Int = BuildConfig.VERSION_CODE,
    val latestVersionName: String = BuildConfig.VERSION_NAME,
    val apkUrl: String = "",
    val releaseNotes: String = "",
    val isForceUpdate: Boolean = false,
    val publishedAt: Long = System.currentTimeMillis()
)

object DriyAppUpdater {
    private const val TAG = "DriyAppUpdater"
    private const val CONFIG_COLLECTION = "app_config"
    private const val VERSION_DOC = "version_info"

    // Default fallback download URL if not configured yet
    const val DEFAULT_DOWNLOAD_URL = "https://driymusic.com/download/app-release.apk"

    /**
     * Checks if a new version is published in Firebase Firestore.
     * Returns AppUpdateInfo if latestVersionCode > current BuildConfig.VERSION_CODE, or null otherwise.
     */
    suspend fun checkForUpdate(): AppUpdateInfo? = withContext(Dispatchers.IO) {
        try {
            val firestore = FirebaseFirestore.getInstance()
            val doc = withTimeoutOrNull(5000L) {
                firestore.collection(CONFIG_COLLECTION)
                    .document(VERSION_DOC)
                    .get()
                    .await()
            }

            if (doc != null && doc.exists()) {
                val latestCode = (doc.getLong("latestVersionCode") ?: doc.getDouble("latestVersionCode")?.toLong() ?: BuildConfig.VERSION_CODE.toLong()).toInt()
                val latestName = doc.getString("latestVersionName") ?: BuildConfig.VERSION_NAME
                val apkUrl = doc.getString("apkUrl") ?: ""
                val notes = doc.getString("releaseNotes") ?: "Nuevas mejoras de rendimiento y corrección de errores."
                val isForce = doc.getBoolean("isForceUpdate") ?: false
                val publishedAt = doc.getLong("publishedAt") ?: System.currentTimeMillis()

                val currentCode = BuildConfig.VERSION_CODE
                Log.d(TAG, "Update check: Current=$currentCode, Remote=$latestCode, URL=$apkUrl")

                if (latestCode > currentCode && apkUrl.isNotBlank()) {
                    return@withContext AppUpdateInfo(
                        latestVersionCode = latestCode,
                        latestVersionName = latestName,
                        apkUrl = apkUrl,
                        releaseNotes = notes,
                        isForceUpdate = isForce,
                        publishedAt = publishedAt
                    )
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Check for update failed (offline or network): ${e.message}")
        }
        null
    }

    /**
     * Admin tool: Publishes or updates the current latest version info in Firestore.
     * When this is saved, all users worldwide will receive the update prompt upon opening the app.
     */
    suspend fun publishNewVersion(
        versionCode: Int,
        versionName: String,
        apkUrl: String,
        releaseNotes: String,
        isForceUpdate: Boolean
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val firestore = FirebaseFirestore.getInstance()
            val payload = hashMapOf(
                "latestVersionCode" to versionCode,
                "latestVersionName" to versionName,
                "apkUrl" to apkUrl.trim(),
                "releaseNotes" to releaseNotes.trim(),
                "isForceUpdate" to isForceUpdate,
                "publishedAt" to System.currentTimeMillis()
            )

            firestore.collection(CONFIG_COLLECTION)
                .document(VERSION_DOC)
                .set(payload, SetOptions.merge())
                .await()

            Log.i(TAG, "Successfully published version $versionName (build $versionCode) to Firestore")
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to publish version to Firestore: ${e.message}")
            Result.failure(e)
        }
    }

    /**
     * Initiates the APK download and installation process.
     * First attempts direct system DownloadManager with FileProvider prompt;
     * also offers direct web browser fallback if system restrictions apply.
     */
    fun startUpdate(context: Context, apkUrl: String) {
        if (apkUrl.isBlank()) {
            Toast.makeText(context, "URL de descarga no disponible", Toast.LENGTH_SHORT).show()
            return
        }

        try {
            val downloadUri = Uri.parse(apkUrl)
            val downloadManager = context.getSystemService(Context.DOWNLOAD_SERVICE) as? DownloadManager

            if (downloadManager == null) {
                openBrowserDownload(context, apkUrl)
                return
            }

            val fileName = "DriyMusic_Update_${System.currentTimeMillis()}.apk"
            val request = DownloadManager.Request(downloadUri).apply {
                setTitle("Descargando actualización de DriyMusic...")
                setDescription("La nueva versión se instalará al finalizar la descarga.")
                setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
                setMimeType("application/vnd.android.package-archive")
                setAllowedOverMetered(true)
                setAllowedOverRoaming(true)
            }

            val downloadId = downloadManager.enqueue(request)
            Toast.makeText(context, "Iniciando descarga de actualización...", Toast.LENGTH_SHORT).show()

            // Register receiver to trigger install when download completes
            val receiver = object : BroadcastReceiver() {
                override fun onReceive(recvContext: Context?, intent: Intent?) {
                    val id = intent?.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L) ?: -1L
                    if (id == downloadId && recvContext != null) {
                        try {
                            recvContext.unregisterReceiver(this)
                        } catch (_: Exception) {}
                        installDownloadedApk(recvContext, fileName)
                    }
                }
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                context.registerReceiver(
                    receiver,
                    IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE),
                    Context.RECEIVER_EXPORTED
                )
            } else {
                context.registerReceiver(
                    receiver,
                    IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE)
                )
            }

        } catch (e: Exception) {
            Log.w(TAG, "DownloadManager failed, falling back to browser: ${e.message}")
            openBrowserDownload(context, apkUrl)
        }
    }

    /**
     * Triggers the Android Package Installer for the downloaded APK using FileProvider.
     */
    fun installDownloadedApk(context: Context, fileName: String) {
        try {
            val file = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), fileName)
            if (!file.exists()) {
                Log.e(TAG, "Downloaded file not found at: ${file.absolutePath}")
                return
            }

            val apkUri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )

            val installIntent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(apkUri, "application/vnd.android.package-archive")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION
            }

            context.startActivity(installIntent)
        } catch (e: Exception) {
            Log.e(TAG, "Install intent error: ${e.message}")
            Toast.makeText(context, "Por favor abre la descarga en tu barra de notificaciones para instalar.", Toast.LENGTH_LONG).show()
        }
    }

    /**
     * Browser fallback: Opens the APK download URL directly in Chrome/system browser.
     */
    fun openBrowserDownload(context: Context, apkUrl: String) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(apkUrl)).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "No se pudo abrir el navegador: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }
}
