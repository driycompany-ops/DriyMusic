package com.example.service

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import android.widget.Toast
import com.example.data.db.DriyDatabase
import com.example.data.model.ActivationCodeEntity
import com.example.data.model.UserEntity
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.google.firebase.functions.FirebaseFunctions
import com.google.firebase.functions.FirebaseFunctionsException
import android.provider.Settings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

sealed class RedeemResult {
    data class Success(
        val newExpirationMs: Long,
        val addedDays: Int,
        val months: Int,
        val code: String,
        val isServerVerified: Boolean = true,
        val verifiedBy: String = "Firebase Cloud Function"
    ) : RedeemResult()

    data class AlreadyUsed(
        val usedAt: Long?,
        val usedByUsername: String?
    ) : RedeemResult()

    data class InvalidCode(val message: String) : RedeemResult()

    data class Error(val message: String) : RedeemResult()
}

object DriyActivationCodeManager {
    private const val TAG = "ActivationCodeManager"
    private const val CODES_COLLECTION = "driystream_activation_codes"
    private const val USERS_COLLECTION = "driystream_users"

    // Default admin phone for Yape / Plin and WhatsApp customer service
    // Peruvian mobile format (9 digits, prefix 51)
    const val PLIN_PHONE = "921483434"
    const val PLIN_DISPLAY_PHONE = "921 483 434"
    const val YAPE_PHONE = "950312209"
    const val YAPE_DISPLAY_PHONE = "950 312 209"
    const val WHATSAPP_REQUEST_PHONE = "51921483434"
    const val WHATSAPP_REQUEST_DISPLAY_PHONE = "921 483 434"
    const val ADMIN_CONTACT_PHONE = "928598496"
    const val ADMIN_CONTACT_DISPLAY_PHONE = "928 598 496"

    const val DEFAULT_ADMIN_PHONE = "51921483434"
    const val DEFAULT_ADMIN_DISPLAY_PHONE = "921 483 434"
    const val DEFAULT_ADMIN_HOLDER_NAME = "driy company"
    const val PRICE_PER_MONTH = 5.0
    const val DAYS_PER_MONTH = 28 // Exact user requirement: 28 days per month

    private val secureRandom = SecureRandom()
    // Characters excluding ambiguous 0, O, 1, I, L
    private val CODE_CHARSET = "23456789ABCDEFGHJKMNPQRSTUVWXYZ".toCharArray()

    fun calculateTotal(months: Int): Double {
        val safeMonths = months.coerceIn(1, 12)
        return safeMonths * PRICE_PER_MONTH
    }

    fun calculateDays(months: Int): Int {
        val safeMonths = months.coerceIn(1, 12)
        return safeMonths * DAYS_PER_MONTH
    }

    fun safeLong(doc: com.google.firebase.firestore.DocumentSnapshot, field: String): Long? {
        val v = doc.get(field) ?: return null
        return when (v) {
            is Number -> v.toLong()
            is com.google.firebase.Timestamp -> v.toDate().time
            is String -> v.toLongOrNull()
            else -> null
        }
    }

    fun safeDouble(doc: com.google.firebase.firestore.DocumentSnapshot, field: String): Double? {
        val v = doc.get(field) ?: return null
        return when (v) {
            is Number -> v.toDouble()
            is String -> v.toDoubleOrNull()
            else -> null
        }
    }

    fun safeInt(doc: com.google.firebase.firestore.DocumentSnapshot, field: String): Int? {
        val v = doc.get(field) ?: return null
        return when (v) {
            is Number -> v.toInt()
            is String -> v.toIntOrNull()
            else -> null
        }
    }

    fun safeString(doc: com.google.firebase.firestore.DocumentSnapshot, field: String): String? {
        val v = doc.get(field) ?: return null
        return v.toString()
    }

    fun safeBoolean(doc: com.google.firebase.firestore.DocumentSnapshot, field: String): Boolean {
        val v = doc.get(field) ?: return false
        return when (v) {
            is Boolean -> v
            is String -> v.toBoolean()
            is Number -> v.toInt() != 0
            else -> false
        }
    }

    /**
     * Generates a unique, cryptographically random activation code formatted as DRIY-XXXX-XXXX.
     */
    fun createUniqueCodeString(): String {
        fun randomSegment(length: Int): String {
            val sb = java.lang.StringBuilder(length)
            for (i in 0 until length) {
                sb.append(CODE_CHARSET[secureRandom.nextInt(CODE_CHARSET.size)])
            }
            return sb.toString()
        }
        return "DRIY-${randomSegment(4)}-${randomSegment(4)}"
    }

    /**
     * Admin action: Generates a single-use activation code, saves it to Firestore and local Room DB.
     */
    suspend fun generateCode(
        context: Context,
        months: Int,
        clientName: String = "",
        clientPhone: String = "",
        note: String = ""
    ): ActivationCodeEntity = withContext(Dispatchers.IO) {
        val safeMonths = months.coerceIn(1, 12)
        val durationDays = calculateDays(safeMonths)
        val price = calculateTotal(safeMonths)
        val codeStr = createUniqueCodeString()
        val now = System.currentTimeMillis()

        val entity = ActivationCodeEntity(
            code = codeStr,
            durationDays = durationDays,
            months = safeMonths,
            pricePaid = price,
            createdAt = now,
            isUsed = false,
            usedByUserId = null,
            usedByUsername = null,
            usedAt = null,
            clientName = clientName.trim(),
            clientPhone = clientPhone.filter { it.isDigit() || it == '+' }.trim(),
            note = note.trim()
        )

        // 1. Save to local Room
        try {
            val db = DriyDatabase.getInstance(context)
            db.activationCodeDao().insertCode(entity)
        } catch (e: Exception) {
            Log.e(TAG, "Error saving code locally: ${e.message}")
        }

        // 2. Save to Firebase Firestore so ANY device can validate and redeem it
        try {
            val firestore = FirebaseFirestore.getInstance()
            val payload = hashMapOf<String, Any?>(
                "code" to entity.code,
                "durationDays" to entity.durationDays,
                "months" to entity.months,
                "pricePaid" to entity.pricePaid,
                "createdAt" to entity.createdAt,
                "isUsed" to false,
                "usedByUserId" to null,
                "usedByUsername" to null,
                "usedAt" to null,
                "clientName" to entity.clientName,
                "clientPhone" to entity.clientPhone,
                "note" to entity.note
            )
            withTimeoutOrNull(6000L) {
                firestore.collection(CODES_COLLECTION).document(entity.code)
                    .set(payload, SetOptions.merge())
                    .await()
            }
            Log.d(TAG, "Activation code '${entity.code}' saved to Firestore successfully")
        } catch (e: Exception) {
            Log.w(TAG, "Firestore code write error (offline fallback active): ${e.message}")
        }

        entity
    }

    private fun getDeviceId(context: Context): String {
        return try {
            Settings.Secure.getString(
                context.contentResolver,
                Settings.Secure.ANDROID_ID
            ) ?: "device_generic_${System.currentTimeMillis()}"
        } catch (e: Exception) {
            "device_${System.currentTimeMillis()}"
        }
    }

    /**
     * Client action: Redeems a single-use activation code.
     * Delegates code validation and day calculations to the Firebase Cloud Functions backend.
     * Prevents code cloning, device clock spoofing, and race conditions.
     */
    suspend fun redeemCode(
        context: Context,
        rawCode: String,
        activeUser: UserEntity
    ): RedeemResult = withContext(Dispatchers.IO) {
        val code = rawCode.trim().uppercase()
        if (code.isBlank() || code.length < 6) {
            return@withContext RedeemResult.InvalidCode("Por favor escribe un código válido.")
        }

        val db = DriyDatabase.getInstance(context)
        val codeDao = db.activationCodeDao()
        val userDao = db.userDao()
        val deviceId = getDeviceId(context)
        val username = activeUser.username.ifBlank { activeUser.displayName }

        // =========================================================================
        // 1. PRIMARY: Firebase Cloud Function Verification (Server-Side Execution)
        // =========================================================================
        try {
            Log.d(TAG, "Requesting server-side verification via Firebase Cloud Function for code: $code")
            val functions = FirebaseFunctions.getInstance()
            val payload = hashMapOf(
                "code" to code,
                "userId" to activeUser.id,
                "username" to username,
                "deviceId" to deviceId,
                "clientVersion" to "1.0"
            )

            val callTask = functions.getHttpsCallable("redeemActivationCode").call(payload)
            val result = withTimeoutOrNull(9000L) { callTask.await() }

            if (result != null) {
                val data = result.data as? Map<*, *>
                if (data != null && data["success"] == true) {
                    val newExpirationMs = (data["newExpirationMs"] as? Number)?.toLong() ?: 0L
                    val addedDays = (data["addedDays"] as? Number)?.toInt() ?: 28
                    val months = (data["months"] as? Number)?.toInt() ?: 1
                    val verifiedBy = data["verifiedBy"] as? String ?: "Firebase Cloud Function"

                    // Persist verified state locally
                    try {
                        userDao.updateSubscriptionExpiresAt(activeUser.id, newExpirationMs)
                        val freshUser = userDao.getUserById(activeUser.id) ?: userDao.getUserByUsername(activeUser.username)
                        if (freshUser != null) {
                            userDao.insertUser(freshUser.copy(subscriptionExpiresAt = newExpirationMs))
                        }
                        codeDao.insertCode(
                            ActivationCodeEntity(
                                code = code,
                                durationDays = addedDays,
                                months = months,
                                pricePaid = (months * 5.0),
                                createdAt = System.currentTimeMillis(),
                                isUsed = true,
                                usedByUserId = activeUser.id,
                                usedByUsername = username,
                                usedAt = System.currentTimeMillis()
                            )
                        )
                    } catch (e: Exception) {
                        Log.e(TAG, "Local Room update error after cloud function verification: ${e.message}")
                    }

                    Log.i(TAG, "Code '$code' successfully verified and redeemed by Cloud Function! Exp: $newExpirationMs")
                    return@withContext RedeemResult.Success(
                        newExpirationMs = newExpirationMs,
                        addedDays = addedDays,
                        months = months,
                        code = code,
                        isServerVerified = true,
                        verifiedBy = verifiedBy
                    )
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Cloud Function invocation: ${e.javaClass.simpleName} - ${e.message}")
            if (e is FirebaseFunctionsException) {
                when (e.code) {
                    FirebaseFunctionsException.Code.ALREADY_EXISTS -> {
                        return@withContext RedeemResult.AlreadyUsed(
                            usedAt = System.currentTimeMillis(),
                            usedByUsername = e.message ?: "otro usuario"
                        )
                    }
                    FirebaseFunctionsException.Code.NOT_FOUND -> {
                        if (e.message?.contains("no existe", ignoreCase = true) == true) {
                            return@withContext RedeemResult.InvalidCode(e.message ?: "El código no existe.")
                        }
                    }
                    FirebaseFunctionsException.Code.INVALID_ARGUMENT -> {
                        return@withContext RedeemResult.InvalidCode(e.message ?: "Código con formato incorrecto.")
                    }
                    FirebaseFunctionsException.Code.UNAUTHENTICATED -> {
                        return@withContext RedeemResult.Error("Sesión de usuario requerida para validar.")
                    }
                    else -> {}
                }
            }
        }

        // =========================================================================
        // 2. RESILIENT FALLBACK: Atomic Server-Side Firestore Transaction
        //    (Guarantees single-use isolation, anti-cloning, and server-time base
        //    even if Cloud Function is not yet deployed or temporarily unreachable)
        // =========================================================================
        try {
            Log.d(TAG, "Falling back to Atomic Server-Side Firestore Transaction for code: $code")
            val firestore = FirebaseFirestore.getInstance()
            val codeRef = firestore.collection(CODES_COLLECTION).document(code)
            val userRef = firestore.collection(USERS_COLLECTION).document(activeUser.id)
            val logsRef = firestore.collection("driystream_redemption_logs").document()

            val txResult = withTimeoutOrNull(9000L) {
                firestore.runTransaction { tx ->
                    val codeDoc = tx.get(codeRef)
                    if (!codeDoc.exists()) {
                        throw IllegalStateException("CODE_NOT_FOUND")
                    }

                    val isUsed = safeBoolean(codeDoc, "isUsed")
                    if (isUsed) {
                        val usedBy = safeString(codeDoc, "usedByUsername") ?: "otro usuario"
                        throw IllegalStateException("ALREADY_USED:$usedBy")
                    }

                    val durationDays = safeInt(codeDoc, "durationDays") ?: 28
                    val months = safeInt(codeDoc, "months") ?: (durationDays / 28).coerceAtLeast(1)
                    val durationMs = durationDays.toLong() * 24L * 60L * 60L * 1000L

                    // Read user inside transaction
                    val userDoc = tx.get(userRef)
                    val currentExp = if (userDoc.exists()) {
                        safeLong(userDoc, "subscriptionExpiresAt") ?: 0L
                    } else {
                        activeUser.subscriptionExpiresAt
                    }

                    val now = System.currentTimeMillis()
                    val baseTime = if (currentExp > now) currentExp else now
                    val newExpiresAt = baseTime + durationMs

                    // Atomic writes
                    tx.update(
                        codeRef,
                        mapOf(
                            "isUsed" to true,
                            "usedByUserId" to activeUser.id,
                            "usedByUsername" to username,
                            "usedAt" to FieldValue.serverTimestamp(),
                            "usedDeviceId" to deviceId,
                            "redeemedVia" to "firestore_transaction_server"
                        )
                    )

                    tx.update(
                        userRef,
                        mapOf(
                            "subscriptionExpiresAt" to newExpiresAt,
                            "subscriptionPlan" to "PREMIUM",
                            "lastRedeemedCode" to code,
                            "lastRedeemedAt" to FieldValue.serverTimestamp()
                        )
                    )

                    tx.set(
                        logsRef,
                        mapOf(
                            "code" to code,
                            "userId" to activeUser.id,
                            "username" to username,
                            "deviceId" to deviceId,
                            "months" to months,
                            "addedDays" to durationDays,
                            "newExpirationMs" to newExpiresAt,
                            "timestamp" to FieldValue.serverTimestamp(),
                            "verificationMethod" to "ATOMIC_FIRESTORE_TRANSACTION"
                        )
                    )

                    Triple(newExpiresAt, durationDays, months)
                }.await()
            }

            if (txResult != null) {
                val (newExpiresAt, durationDays, months) = txResult

                // Update local Room
                userDao.updateSubscriptionExpiresAt(activeUser.id, newExpiresAt)
                val freshUser = userDao.getUserById(activeUser.id) ?: userDao.getUserByUsername(activeUser.username)
                if (freshUser != null) {
                    userDao.insertUser(freshUser.copy(subscriptionExpiresAt = newExpiresAt))
                }
                codeDao.insertCode(
                    ActivationCodeEntity(
                        code = code,
                        durationDays = durationDays,
                        months = months,
                        pricePaid = (months * 5.0),
                        createdAt = System.currentTimeMillis(),
                        isUsed = true,
                        usedByUserId = activeUser.id,
                        usedByUsername = username,
                        usedAt = System.currentTimeMillis()
                    )
                )

                return@withContext RedeemResult.Success(
                    newExpirationMs = newExpiresAt,
                    addedDays = durationDays,
                    months = months,
                    code = code,
                    isServerVerified = true,
                    verifiedBy = "Firebase Transaction (Anti-Clonación)"
                )
            }
        } catch (e: Exception) {
            val msg = e.cause?.message ?: e.message ?: ""
            if (msg.contains("CODE_NOT_FOUND")) {
                return@withContext RedeemResult.InvalidCode("El código '$code' no existe o fue escrito con un error.")
            }
            if (msg.contains("ALREADY_USED")) {
                val who = msg.substringAfter("ALREADY_USED:").ifBlank { "otro usuario" }
                return@withContext RedeemResult.AlreadyUsed(
                    usedAt = System.currentTimeMillis(),
                    usedByUsername = who
                )
            }
            Log.w(TAG, "Transaction verification error: ${e.message}")
        }

        // =========================================================================
        // 3. OFFLINE LOCAL ROOM FALLBACK
        // =========================================================================
        val localCode = codeDao.getCode(code)
        if (localCode == null) {
            return@withContext RedeemResult.InvalidCode("El código '$code' no existe en el sistema.")
        }
        if (localCode.isUsed) {
            return@withContext RedeemResult.AlreadyUsed(
                usedAt = localCode.usedAt,
                usedByUsername = localCode.usedByUsername ?: "otro usuario"
            )
        }

        // Mark local code as used
        val now = System.currentTimeMillis()
        val durationMs = localCode.durationDays.toLong() * 24L * 60L * 60L * 1000L
        val baseTime = if (activeUser.subscriptionExpiresAt > now) activeUser.subscriptionExpiresAt else now
        val newExpiresAt = baseTime + durationMs

        codeDao.insertCode(
            localCode.copy(
                isUsed = true,
                usedByUserId = activeUser.id,
                usedByUsername = username,
                usedAt = now
            )
        )
        userDao.updateSubscriptionExpiresAt(activeUser.id, newExpiresAt)
        val freshUser = userDao.getUserById(activeUser.id) ?: userDao.getUserByUsername(activeUser.username)
        if (freshUser != null) {
            userDao.insertUser(freshUser.copy(subscriptionExpiresAt = newExpiresAt))
        }

        RedeemResult.Success(
            newExpirationMs = newExpiresAt,
            addedDays = localCode.durationDays,
            months = localCode.months,
            code = code,
            isServerVerified = false,
            verifiedBy = "Base de datos local"
        )
    }

    /**
     * Returns a real-time Flow of all activation codes synced live with Firebase Firestore.
     * When any client in the world redeems a code, this flow receives the update immediately.
     */
    fun getRealtimeCodesFlow(context: Context): Flow<List<ActivationCodeEntity>> = callbackFlow {
        val db = DriyDatabase.getInstance(context)
        val codeDao = db.activationCodeDao()

        // 1. Immediately emit local Room codes
        val initialJob = launch(Dispatchers.IO) {
            try {
                val localList = codeDao.getAllCodes()
                if (localList.isNotEmpty()) {
                    trySend(localList)
                }
            } catch (e: Exception) {
                Log.w(TAG, "Error reading initial local codes: ${e.message}")
            }
        }

        // 2. Attach real-time Firestore Snapshot Listener
        var listenerRegistration: com.google.firebase.firestore.ListenerRegistration? = null
        try {
            val firestore = FirebaseFirestore.getInstance()
            listenerRegistration = firestore.collection(CODES_COLLECTION)
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        Log.w(TAG, "Firestore snapshot listener error: ${error.message}")
                        launch(Dispatchers.IO) {
                            try {
                                trySend(codeDao.getAllCodes())
                            } catch (e: Exception) {
                                Log.e(TAG, "Error emitting local codes on failure: ${e.message}")
                            }
                        }
                        return@addSnapshotListener
                    }

                    if (snapshot != null) {
                        launch(Dispatchers.IO) {
                            try {
                                val codesList = ArrayList<ActivationCodeEntity>(snapshot.size())
                                for (doc in snapshot.documents) {
                                    try {
                                        val code = safeString(doc, "code") ?: doc.id
                                        val isUsed = safeBoolean(doc, "isUsed")
                                        val usedByUserId = safeString(doc, "usedByUserId")
                                        val usedByUsername = safeString(doc, "usedByUsername")
                                        val usedAt = safeLong(doc, "usedAt")
                                        val durationDays = safeInt(doc, "durationDays") ?: 28
                                        val months = safeInt(doc, "months") ?: (durationDays / 28).coerceAtLeast(1)
                                        val pricePaid = safeDouble(doc, "pricePaid") ?: (months * 5.0)
                                        val createdAt = safeLong(doc, "createdAt") ?: System.currentTimeMillis()
                                        val clientName = safeString(doc, "clientName") ?: ""
                                        val clientPhone = safeString(doc, "clientPhone") ?: ""
                                        val note = safeString(doc, "note") ?: ""

                                        val entity = ActivationCodeEntity(
                                            code = code,
                                            durationDays = durationDays,
                                            months = months,
                                            pricePaid = pricePaid,
                                            createdAt = createdAt,
                                            isUsed = isUsed,
                                            usedByUserId = usedByUserId,
                                            usedByUsername = usedByUsername,
                                            usedAt = usedAt,
                                            clientName = clientName,
                                            clientPhone = clientPhone,
                                            note = note
                                        )
                                        try {
                                            codeDao.insertCode(entity)
                                        } catch (e: Exception) {
                                            // ignore insert conflict
                                        }
                                        codesList.add(entity)
                                    } catch (e: Throwable) {
                                        Log.w(TAG, "Skipping corrupted code doc ${doc.id}: ${e.message}")
                                    }
                                }

                                codesList.sortByDescending { it.createdAt }
                                Log.d(TAG, "Real-time codes update received: ${codesList.size} codes")
                                trySend(codesList)
                            } catch (e: Throwable) {
                                Log.e(TAG, "Error processing snapshot coroutine: ${e.message}", e)
                            }
                        }
                    }
                }
        } catch (e: Exception) {
            Log.e(TAG, "Error initializing Firestore snapshot listener: ${e.message}")
        }

        awaitClose {
            Log.d(TAG, "Closing real-time activation codes snapshot listener")
            try {
                listenerRegistration?.remove()
            } catch (e: Exception) {
                // ignore
            }
            initialJob.cancel()
        }
    }

    /**
     * Returns a Flow of all generated codes for the admin panel.
     */
    fun getAllCodesFlow(context: Context): Flow<List<ActivationCodeEntity>> {
        val db = DriyDatabase.getInstance(context)
        return db.activationCodeDao().getAllCodesFlow()
    }

    /**
     * Synchronizes recent codes from Firestore into local Room for Admin inspection.
     */
    suspend fun syncCodesFromCloud(context: Context) = withContext(Dispatchers.IO) {
        try {
            val firestore = FirebaseFirestore.getInstance()
            val snap = withTimeoutOrNull(6000L) {
                firestore.collection(CODES_COLLECTION)
                    .get()
                    .await()
            } ?: return@withContext

            val db = DriyDatabase.getInstance(context)
            val codeDao = db.activationCodeDao()

            for (doc in snap.documents) {
                try {
                    val code = safeString(doc, "code") ?: doc.id
                    val isUsed = safeBoolean(doc, "isUsed")
                    val usedByUserId = safeString(doc, "usedByUserId")
                    val usedByUsername = safeString(doc, "usedByUsername")
                    val usedAt = safeLong(doc, "usedAt")
                    val durationDays = safeInt(doc, "durationDays") ?: 28
                    val months = safeInt(doc, "months") ?: (durationDays / 28).coerceAtLeast(1)
                    val pricePaid = safeDouble(doc, "pricePaid") ?: (months * 5.0)
                    val createdAt = safeLong(doc, "createdAt") ?: System.currentTimeMillis()
                    val clientName = safeString(doc, "clientName") ?: ""
                    val clientPhone = safeString(doc, "clientPhone") ?: ""
                    val note = safeString(doc, "note") ?: ""

                    codeDao.insertCode(
                        ActivationCodeEntity(
                            code = code,
                            durationDays = durationDays,
                            months = months,
                            pricePaid = pricePaid,
                            createdAt = createdAt,
                            isUsed = isUsed,
                            usedByUserId = usedByUserId,
                            usedByUsername = usedByUsername,
                            usedAt = usedAt,
                            clientName = clientName,
                            clientPhone = clientPhone,
                            note = note
                        )
                    )
                } catch (e: Throwable) {
                    Log.w(TAG, "Error syncing single code ${doc.id}: ${e.message}")
                }
            }
        } catch (e: Throwable) {
            Log.w(TAG, "Error syncing codes from cloud: ${e.message}")
        }
    }

    /**
     * Builds and launches WhatsApp with the exact user requested presentation:
     * "hola soy [Nombre]
     * con numero de celular [Celular],
     * estoy solicitando un codigo x la cantidad de meses [Meses] (S/. [Total]) y abajo enviando el voucher."
     */
    fun sendVoucherViaWhatsApp(
        context: Context,
        userName: String,
        userPhone: String,
        months: Int,
        adminPhone: String = DEFAULT_ADMIN_PHONE,
        referredBy: String = ""
    ) {
        val total = calculateTotal(months)
        val cleanUserPhone = userPhone.ifBlank { "No especificado" }
        val cleanUserName = userName.ifBlank { "Usuario DriyMusic" }
        val cleanAdminPhone = adminPhone.filter { it.isDigit() }.let {
            if (it.length == 9 && !it.startsWith("51")) "51$it" else it
        }

        val monthLabel = if (months == 1) "1 mes" else "$months meses"
        val cleanReferredBy = referredBy.trim().removePrefix("@")
        val referralLine = if (cleanReferredBy.isNotBlank()) {
            "\n🎁 Vengo invitado por mi amigo: @$cleanReferredBy"
        } else ""

        val message = """
hola soy "$cleanUserName"
con numero de celular $cleanUserPhone,
estoy solicitando un codigo x la cantidad de $monthLabel (total S/. ${"%.2f".format(total)})$referralLine y abajo enviando el baucher.
        """.trimIndent()

        openWhatsAppWithMessage(context, cleanAdminPhone, message)
    }

    /**
     * Admin action: Sends the newly created single-use activation code back to the client via WhatsApp.
     */
    fun sendActivationCodeToClientViaWhatsApp(
        context: Context,
        clientPhone: String,
        clientName: String,
        code: String,
        months: Int,
        durationDays: Int,
        pricePaid: Double
    ) {
        val cleanClientPhone = clientPhone.filter { it.isDigit() }.let {
            if (it.length == 9 && !it.startsWith("51")) "51$it" else it
        }
        val nameGreeting = if (clientName.isNotBlank()) " $clientName" else ""

        val message = """
¡Hola$nameGreeting! Tu pago de S/. ${"%.2f".format(pricePaid)} por $months mes${if (months > 1) "es" else ""} ($durationDays días) ha sido verificado con éxito 🎉.

Tu código de activación único es:
👉 *$code* 👈

Para activarlo en DriyMusic:
1. Abre tu aplicación DriyMusic
2. Ve a la pestaña Perfil > "Canjear Código"
3. Pega tu código y ¡listo! Disfruta de toda tu música sin límites 🎶🎧
        """.trimIndent()

        openWhatsAppWithMessage(context, cleanClientPhone, message)
    }

    private fun openWhatsAppWithMessage(context: Context, targetPhone: String, message: String) {
        try {
            val encodedMessage = Uri.encode(message)
            val uri = if (targetPhone.isNotBlank()) {
                Uri.parse("https://api.whatsapp.com/send?phone=$targetPhone&text=$encodedMessage")
            } else {
                Uri.parse("https://api.whatsapp.com/send?text=$encodedMessage")
            }

            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            // Fallback: standard share intent
            try {
                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, message)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(Intent.createChooser(shareIntent, "Enviar comprobante por:"))
            } catch (ex: Exception) {
                Toast.makeText(context, "No se pudo abrir WhatsApp: ${ex.message}", Toast.LENGTH_LONG).show()
            }
        }
    }
}
