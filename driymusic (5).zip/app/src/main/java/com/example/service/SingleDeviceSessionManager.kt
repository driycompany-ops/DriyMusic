package com.example.service

import android.content.Context
import android.os.Build
import android.util.Log
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.util.UUID

object SingleDeviceSessionManager {
    private const val TAG = "SingleDeviceSession"
    private const val PREFS_NAME = "driystream_auth_prefs"
    private const val KEY_SESSION_TOKEN = "active_session_token"
    private const val USERS_COLLECTION = "driystream_users"

    private var snapshotListener: ListenerRegistration? = null
    private var currentMonitoredUserId: String? = null

    fun getLocalSessionToken(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        var token = prefs.getString(KEY_SESSION_TOKEN, null)
        if (token.isNullOrBlank()) {
            token = UUID.randomUUID().toString()
            prefs.edit().putString(KEY_SESSION_TOKEN, token).apply()
        }
        return token
    }

    /**
     * Creates a new unique session token for this device, persists it locally,
     * and updates Firebase Firestore so any other previously logged-in phone is invalidated.
     */
    suspend fun createAndRegisterSession(context: Context, userId: String): String = withContext(Dispatchers.IO) {
        val newToken = UUID.randomUUID().toString()
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_SESSION_TOKEN, newToken).apply()

        val rawModel = Build.MODEL ?: "Dispositivo"
        val rawManufacturer = Build.MANUFACTURER ?: "Android"
        val deviceName = "${rawManufacturer.replaceFirstChar { it.uppercase() }} $rawModel"

        try {
            val firestore = FirebaseFirestore.getInstance()
            firestore.collection(USERS_COLLECTION).document(userId)
                .set(
                    mapOf(
                        "activeSessionToken" to newToken,
                        "activeDeviceName" to deviceName,
                        "lastLoginTimestamp" to System.currentTimeMillis()
                    ),
                    SetOptions.merge()
                ).await()
            Log.d(TAG, "Registered new active session for user '$userId' on device '$deviceName' with token '$newToken'")
        } catch (e: Exception) {
            Log.w(TAG, "Failed to register session token in cloud: ${e.message}")
        }
        newToken
    }

    /**
     * Starts real-time monitoring on the user's Firestore document.
     * If another phone logs in, activeSessionToken changes and onSessionTerminated is called.
     */
    fun startMonitoring(
        context: Context,
        userId: String,
        onSessionTerminated: (otherDeviceName: String) -> Unit
    ) {
        if (userId.isBlank()) return
        if (currentMonitoredUserId == userId && snapshotListener != null) {
            return
        }

        stopMonitoring()
        currentMonitoredUserId = userId

        val localToken = getLocalSessionToken(context)
        try {
            val firestore = FirebaseFirestore.getInstance()
            snapshotListener = firestore.collection(USERS_COLLECTION)
                .document(userId)
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        Log.w(TAG, "Session monitor error: ${error.message}")
                        return@addSnapshotListener
                    }
                    if (snapshot != null && snapshot.exists()) {
                        val cloudToken = snapshot.getString("activeSessionToken")
                        val otherDevice = snapshot.getString("activeDeviceName") ?: "otro teléfono"

                        // If cloud has a token and it doesn't match our local token, another device logged in!
                        if (!cloudToken.isNullOrBlank() && cloudToken != localToken) {
                            Log.w(TAG, "Single-session mismatch detected! Cloud token: $cloudToken, local: $localToken. Invalidating session.")
                            stopMonitoring()
                            CoroutineScope(Dispatchers.Main).launch {
                                onSessionTerminated(otherDevice)
                            }
                        }
                    }
                }
            Log.d(TAG, "Started single-device session monitoring for '$userId'")
        } catch (e: Exception) {
            Log.e(TAG, "Could not start session listener: ${e.message}", e)
        }
    }

    /**
     * Stops listening for session updates (e.g. on logout).
     */
    fun stopMonitoring() {
        snapshotListener?.remove()
        snapshotListener = null
        currentMonitoredUserId = null
        Log.d(TAG, "Stopped session monitoring")
    }
}
