package com.example.util

import java.security.MessageDigest
import java.security.SecureRandom

/**
 * Utility for secure password hashing and verification using salted, stretched SHA-256.
 *
 * Stored format: pbkdf_v1$<hex_salt>$<hex_hash>
 * Backward-compatible with existing legacy plain-text accounts.
 */
object PasswordHasher {
    private const val PREFIX = "pbkdf_v1$"
    private const val ITERATIONS = 10000
    private const val SALT_LEN = 16

    /**
     * Generates a cryptographically salted and stretched hash for the given plain text password.
     */
    fun hashPassword(password: String): String {
        if (password.isBlank()) return ""
        val random = SecureRandom()
        val salt = ByteArray(SALT_LEN)
        random.nextBytes(salt)

        val hash = computeHash(password, salt, ITERATIONS)
        return "$PREFIX${bytesToHex(salt)}$${bytesToHex(hash)}"
    }

    /**
     * Verifies a plain text password against a stored string.
     * Backwards-compatible:
     * - Returns true if the password matches the salted hash.
     * - Returns true if the stored value is legacy plain text and matches directly.
     */
    fun verifyPassword(password: String, stored: String): Boolean {
        if (password.isBlank() || stored.isBlank()) return false

        if (stored.startsWith(PREFIX)) {
            val parts = stored.removePrefix(PREFIX).split("$")
            if (parts.size != 2) return false
            val salt = hexToBytes(parts[0]) ?: return false
            val expectedHash = hexToBytes(parts[1]) ?: return false
            val computedHash = computeHash(password, salt, ITERATIONS)
            return MessageDigest.isEqual(expectedHash, computedHash)
        }

        // Backward compatibility: support legacy plaintext passwords for pre-existing accounts
        return password == stored
    }

    /**
     * Returns true if the stored string is already in the secure hashed format.
     */
    fun isHashed(stored: String): Boolean {
        return stored.startsWith(PREFIX)
    }

    private fun computeHash(password: String, salt: ByteArray, iterations: Int): ByteArray {
        val md = MessageDigest.getInstance("SHA-256")
        md.update(salt)
        var current = md.digest(password.toByteArray(Charsets.UTF_8))
        for (i in 1 until iterations) {
            md.reset()
            md.update(salt)
            md.update(current)
            current = md.digest()
        }
        return current
    }

    private fun bytesToHex(bytes: ByteArray): String {
        val sb = StringBuilder(bytes.size * 2)
        for (b in bytes) {
            sb.append(String.format("%02x", b))
        }
        return sb.toString()
    }

    private fun hexToBytes(hex: String): ByteArray? {
        if (hex.length % 2 != 0) return null
        val len = hex.length / 2
        val data = ByteArray(len)
        try {
            for (i in 0 until len) {
                data[i] = ((Character.digit(hex[i * 2], 16) shl 4) +
                        Character.digit(hex[i * 2 + 1], 16)).toByte()
            }
            return data
        } catch (_: Exception) {
            return null
        }
    }
}
