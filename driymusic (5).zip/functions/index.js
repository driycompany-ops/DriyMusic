const functions = require("firebase-functions");
const admin = require("firebase-admin");

if (!admin.apps.length) {
  admin.initializeApp();
}

const db = admin.firestore();

const CODES_COLLECTION = "driystream_activation_codes";
const USERS_COLLECTION = "driystream_users";
const LOGS_COLLECTION = "driystream_redemption_logs";

/**
 * Cloud Function: redeemActivationCode
 *
 * Runs entirely on the Firebase / Google Cloud server.
 * Authoritatively validates single-use activation codes, calculates subscription
 * days using server time (preventing client clock tampering and code cloning),
 * updates records atomically via Firestore Transaction, and writes an immutable audit log.
 */
exports.redeemActivationCode = functions.https.onCall(async (data, context) => {
  // 1. Sanitize and validate inputs
  const rawCode = (data && data.code) ? String(data.code).trim().toUpperCase() : "";
  const userId = (data && data.userId) ? String(data.userId).trim() : (context.auth ? context.auth.uid : "");
  const username = (data && data.username) ? String(data.username).trim() : "Usuario";
  const deviceId = (data && data.deviceId) ? String(data.deviceId).trim() : "unknown-device";
  const clientVersion = (data && data.clientVersion) ? String(data.clientVersion).trim() : "1.0";

  if (!rawCode || rawCode.length < 6) {
    throw new functions.https.HttpsError(
      "invalid-argument",
      "El código de activación es requerido y debe tener formato válido."
    );
  }

  if (!userId) {
    throw new functions.https.HttpsError(
      "unauthenticated",
      "Debes tener una sesión activa para activar un código de membresía."
    );
  }

  const codeDocRef = db.collection(CODES_COLLECTION).doc(rawCode);
  const userDocRef = db.collection(USERS_COLLECTION).doc(userId);
  const logDocRef = db.collection(LOGS_COLLECTION).doc();

  try {
    const result = await db.runTransaction(async (transaction) => {
      // Step A: Read Code Document
      const codeSnapshot = await transaction.get(codeDocRef);
      if (!codeSnapshot.exists) {
        throw new functions.https.HttpsError(
          "not-found",
          `El código '${rawCode}' no existe en el sistema o fue escrito incorrectamente.`
        );
      }

      const codeData = codeSnapshot.data() || {};

      // Step B: Anti-Cloning & Single-Use Check
      if (codeData.isUsed === true) {
        const usedBy = codeData.usedByUsername || "otro usuario";
        const usedDateStr = codeData.usedAtMs ? new Date(codeData.usedAtMs).toLocaleString("es-PE") : "previamente";
        throw new functions.https.HttpsError(
          "already-exists",
          `Este código ya fue utilizado por "${usedBy}" el ${usedDateStr}. No puede volver a canjearse.`
        );
      }

      // Step C: Verify Code Integrity
      const months = Number.isInteger(codeData.months) ? codeData.months : 1;
      const durationDays = Number.isInteger(codeData.durationDays) ? codeData.durationDays : (months * 28);
      const durationMs = durationDays * 24 * 60 * 60 * 1000;

      // Step D: Authoritative Server Time & Expiration Calculation
      const serverTimestampNow = admin.firestore.Timestamp.now();
      const serverNowMs = serverTimestampNow.toMillis();

      // Read current User record inside transaction
      const userSnapshot = await transaction.get(userDocRef);
      let currentExpirationMs = 0;
      let existingUserData = {};

      if (userSnapshot.exists) {
        existingUserData = userSnapshot.data() || {};
        currentExpirationMs = Number(existingUserData.subscriptionExpiresAt) || 0;
      }

      // If user currently has active days, append to existing expiration; otherwise start from server time
      const baseMs = (currentExpirationMs > serverNowMs) ? currentExpirationMs : serverNowMs;
      const newExpirationMs = baseMs + durationMs;

      // Step E: Atomic Updates
      // 1. Mark Code as permanently used (Single-use lock)
      transaction.update(codeDocRef, {
        isUsed: true,
        usedByUserId: userId,
        usedByUsername: username,
        usedAt: serverTimestampNow,
        usedAtMs: serverNowMs,
        usedDeviceId: deviceId,
        clientVersion: clientVersion,
        redeemedVia: "firebase_cloud_function",
        serverVerified: true
      });

      // 2. Update User Subscription with server-calculated expiration
      if (userSnapshot.exists) {
        transaction.update(userDocRef, {
          subscriptionExpiresAt: newExpirationMs,
          subscriptionPlan: "PREMIUM",
          lastRedeemedCode: rawCode,
          lastRedeemedAt: serverTimestampNow,
          lastRedeemedDays: durationDays,
          updatedAt: serverTimestampNow
        });
      } else {
        transaction.set(userDocRef, {
          id: userId,
          username: username,
          displayName: username,
          subscriptionExpiresAt: newExpirationMs,
          subscriptionPlan: "PREMIUM",
          lastRedeemedCode: rawCode,
          lastRedeemedAt: serverTimestampNow,
          lastRedeemedDays: durationDays,
          createdAt: serverTimestampNow,
          updatedAt: serverTimestampNow
        }, { merge: true });
      }

      // 3. Immutable Security Audit Log
      transaction.set(logDocRef, {
        id: logDocRef.id,
        code: rawCode,
        userId: userId,
        username: username,
        deviceId: deviceId,
        months: months,
        addedDays: durationDays,
        previousExpirationMs: currentExpirationMs,
        newExpirationMs: newExpirationMs,
        serverTimestamp: serverTimestampNow,
        serverTimestampMs: serverNowMs,
        status: "SUCCESS_REDEEMED",
        verificationMethod: "CLOUD_FUNCTION_TRANSACTION"
      });

      return {
        success: true,
        code: rawCode,
        months: months,
        addedDays: durationDays,
        newExpirationMs: newExpirationMs,
        serverVerified: true,
        verifiedBy: "Firebase Cloud Functions (Production Server)",
        serverTimeMs: serverNowMs
      };
    });

    return result;
  } catch (error) {
    if (error instanceof functions.https.HttpsError) {
      throw error;
    }
    console.error("Error executing redeemActivationCode transaction:", error);
    throw new functions.https.HttpsError(
      "internal",
      `Error procesando activación en el servidor: ${error.message || "Error desconocido"}`
    );
  }
});

/**
 * Cloud Function: verifyActivationCode
 *
 * Checks code existence and validity without redeeming it.
 */
exports.verifyActivationCode = functions.https.onCall(async (data) => {
  const rawCode = (data && data.code) ? String(data.code).trim().toUpperCase() : "";
  if (!rawCode) {
    throw new functions.https.HttpsError("invalid-argument", "Código no proporcionado.");
  }

  const doc = await db.collection(CODES_COLLECTION).doc(rawCode).get();
  if (!doc.exists) {
    return { valid: false, message: "Código no encontrado en el sistema." };
  }

  const codeData = doc.data() || {};
  return {
    valid: !codeData.isUsed,
    isUsed: Boolean(codeData.isUsed),
    months: codeData.months || 1,
    durationDays: codeData.durationDays || 28,
    pricePaid: codeData.pricePaid || 5.0,
    usedByUsername: codeData.usedByUsername || null,
    usedAt: codeData.usedAtMs || null
  };
});

const crypto = require("crypto");

/**
 * Server-side password verification matching PasswordHasher.kt
 */
function verifyPassword(password, stored) {
  if (!password || !stored) return false;
  if (stored.startsWith("pbkdf_v1$")) {
    const parts = stored.slice("pbkdf_v1$".length).split("$");
    if (parts.length !== 2) return false;
    const salt = Buffer.from(parts[0], "hex");
    const expectedHash = Buffer.from(parts[1], "hex");
    let m = crypto.createHash("sha256");
    m.update(salt);
    m.update(Buffer.from(password, "utf-8"));
    let current = m.digest();
    for (let i = 1; i < 10000; i++) {
      m = crypto.createHash("sha256");
      m.update(salt);
      m.update(current);
      current = m.digest();
    }
    return crypto.timingSafeEqual(expectedHash, current);
  }
  return password === stored;
}

/**
 * Cloud Function: authenticateUser
 *
 * Verifies user credentials securely on the server without ever exposing password hashes to the client.
 * Returns safe profile data and a Firebase Auth custom token.
 */
exports.authenticateUser = functions.https.onCall(async (data) => {
  const username = (data && data.username) ? String(data.username).trim().replace(/^@/, "").toLowerCase() : "";
  const password = (data && data.password) ? String(data.password) : "";
  const phoneNumber = (data && data.phoneNumber) ? String(data.phoneNumber).replace(/\D/g, "") : "";

  if (!username && !phoneNumber) {
    throw new functions.https.HttpsError("invalid-argument", "Debes ingresar tu nombre de usuario o número telefónico.");
  }
  if (!password) {
    throw new functions.https.HttpsError("invalid-argument", "Debes ingresar tu contraseña.");
  }

  let userDoc = null;
  if (username) {
    const doc = await db.collection(USERS_COLLECTION).doc(username).get();
    if (doc.exists) {
      userDoc = doc;
    } else {
      const q = await db.collection(USERS_COLLECTION).where("username", "==", username).limit(1).get();
      if (!q.empty) {
        userDoc = q.docs[0];
      }
    }
  }

  if (!userDoc && phoneNumber) {
    const qPhone = await db.collection(USERS_COLLECTION).where("phoneNumber", "==", phoneNumber).limit(1).get();
    if (!qPhone.empty) {
      userDoc = qPhone.docs[0];
    }
  }

  if (!userDoc || !userDoc.exists) {
    throw new functions.https.HttpsError("not-found", "No se encontró ninguna cuenta registrada con estos datos.");
  }

  const userData = userDoc.data() || {};

  // Check if account was deleted
  try {
    const delDoc = await db.collection("driystream_deleted_accounts").doc(userDoc.id).get();
    if (delDoc.exists) {
      throw new functions.https.HttpsError("not-found", "Esta cuenta ha sido eliminada.");
    }
  } catch (err) {
    if (err instanceof functions.https.HttpsError) throw err;
  }

  // Verify password securely on server
  const storedHash = userData.passwordHash || "";
  const isMatch = verifyPassword(password, storedHash);
  if (!isMatch) {
    throw new functions.https.HttpsError("permission-denied", "La contraseña ingresada no es correcta.");
  }

  // Verify phone number if required
  const userPhoneClean = (userData.phoneNumber || "").replace(/\D/g, "");
  if (phoneNumber && userPhoneClean) {
    const phoneMatches = userPhoneClean.endsWith(phoneNumber.slice(-7)) ||
                         phoneNumber.endsWith(userPhoneClean.slice(-7)) ||
                         userPhoneClean === phoneNumber;
    if (!phoneMatches) {
      throw new functions.https.HttpsError("permission-denied", "El número telefónico no coincide con el registrado en tu cuenta.");
    }
  }

  // Create Firebase Auth custom token so client can authenticate to Firestore rules securely
  let customToken = "";
  try {
    customToken = await admin.auth().createCustomToken(userDoc.id, {
      username: userData.username || userDoc.id,
      admin: (userDoc.id === "driyadmincompany")
    });
  } catch (err) {
    console.warn("Could not generate custom token:", err.message);
  }

  // Strip password hash from returned data for absolute zero-knowledge security on the client
  const safeUser = { ...userData };
  delete safeUser.passwordHash;

  return {
    success: true,
    user: safeUser,
    customToken: customToken
  };
});

const VERIFICATION_COLLECTION = "driystream_verification_codes";
const VERIFICATION_SALT = "driy_music_wa_salt_2026_secure";
const HMAC_SECRET = "driy_hmac_secret_proof_2026";

/**
 * Cloud Function: requestWhatsAppVerification
 *
 * Generates a cryptographically secure 6-digit OTP exclusively on the server,
 * hashes it with a private salt before storing in Firestore, and records the session.
 * Zero-Knowledge: The plaintext code is NEVER returned to the client device.
 */
exports.requestWhatsAppVerification = functions.https.onCall(async (data) => {
  const rawPhone = (data && data.phoneNumber) ? String(data.phoneNumber).replace(/\D/g, "") : "";
  const username = (data && data.username) ? String(data.username).trim() : "";
  const purpose = (data && data.purpose) ? String(data.purpose).trim().toUpperCase() : "VERIFY";

  if (!rawPhone || rawPhone.length < 8 || rawPhone.length > 15) {
    throw new functions.https.HttpsError(
      "invalid-argument",
      "Número telefónico inválido. Por favor ingresa un número de teléfono válido para WhatsApp."
    );
  }

  // Format phone (add Peru country code 51 if 9 digits)
  const phone = (rawPhone.length === 9 && !rawPhone.startsWith("51")) ? `51${rawPhone}` : rawPhone;
  const docRef = db.collection(VERIFICATION_COLLECTION).doc(phone);
  const now = Date.now();

  // Check rate limiting / anti-spam (60 seconds cooldown)
  const existingDoc = await docRef.get();
  if (existingDoc.exists) {
    const existingData = existingDoc.data() || {};
    const lastRequestedAt = existingData.createdAtMs || 0;
    const cooldownMs = 60 * 1000;
    if (now - lastRequestedAt < cooldownMs) {
      const waitSeconds = Math.ceil((cooldownMs - (now - lastRequestedAt)) / 1000);
      throw new functions.https.HttpsError(
        "resource-exhausted",
        `Por favor espera ${waitSeconds} segundos antes de solicitar un nuevo código de verificación por WhatsApp.`
      );
    }
  }

  // Generate cryptographically secure 6-digit OTP exclusively on the server
  const otpCode = String(crypto.randomInt(100000, 1000000));
  const codeHash = crypto.createHash("sha256").update(otpCode + VERIFICATION_SALT).digest("hex");
  const sessionToken = "DRIY-" + crypto.randomBytes(3).toString("hex").toUpperCase();
  const expiresAtMs = now + (10 * 60 * 1000); // 10 minutes

  await docRef.set({
    phone: phone,
    username: username,
    purpose: purpose,
    codeHash: codeHash,
    sessionToken: sessionToken,
    attempts: 0,
    createdAt: admin.firestore.Timestamp.now(),
    createdAtMs: now,
    expiresAtMs: expiresAtMs,
    verified: false
  });

  console.log(`[WhatsApp Verification] Code generated securely for +${phone}, session: ${sessionToken}, purpose: ${purpose}`);

  return {
    success: true,
    phone: phone,
    sessionToken: sessionToken,
    expiresInSeconds: 600,
    cooldownSeconds: 60,
    message: "Código de seguridad de 6 dígitos generado por el servidor y registrado."
  };
});

/**
 * Cloud Function: verifyWhatsAppVerificationCode
 *
 * Verifies the 6-digit OTP on the server using constant-time hash comparison.
 * Enforces rate limiting (max 5 attempts) and expiration (10 min).
 * Issues a cryptographically signed proof token on success.
 */
exports.verifyWhatsAppVerificationCode = functions.https.onCall(async (data) => {
  const rawPhone = (data && data.phoneNumber) ? String(data.phoneNumber).replace(/\D/g, "") : "";
  const code = (data && data.code) ? String(data.code).trim() : "";
  const username = (data && data.username) ? String(data.username).trim() : "";

  if (!rawPhone || !code || code.length !== 6) {
    throw new functions.https.HttpsError(
      "invalid-argument",
      "Debes ingresar el código de 6 dígitos recibido por WhatsApp."
    );
  }

  const phone = (rawPhone.length === 9 && !rawPhone.startsWith("51")) ? `51${rawPhone}` : rawPhone;
  const docRef = db.collection(VERIFICATION_COLLECTION).doc(phone);

  const verificationResult = await db.runTransaction(async (transaction) => {
    const docSnap = await transaction.get(docRef);
    if (!docSnap.exists) {
      throw new functions.https.HttpsError(
        "not-found",
        "No hay ningún código de verificación activo para este número. Por favor solicita uno nuevo."
      );
    }

    const docData = docSnap.data() || {};
    const now = Date.now();

    // Check expiration
    if (now > (docData.expiresAtMs || 0)) {
      throw new functions.https.HttpsError(
        "failed-precondition",
        "El código de verificación ha expirado (válido por 10 minutos). Por favor solicita uno nuevo."
      );
    }

    // Check brute force attempts
    const currentAttempts = (docData.attempts || 0) + 1;
    if (currentAttempts > 5) {
      transaction.delete(docRef);
      throw new functions.https.HttpsError(
        "resource-exhausted",
        "Has superado el límite máximo de intentos (5). El código ha sido anulado por seguridad. Solicita uno nuevo."
      );
    }

    // Verify hash using constant-time comparison
    const submittedHash = crypto.createHash("sha256").update(code + VERIFICATION_SALT).digest("hex");
    const storedHash = docData.codeHash || "";

    const isMatch = (submittedHash.length === storedHash.length) &&
      crypto.timingSafeEqual(Buffer.from(submittedHash), Buffer.from(storedHash));

    if (!isMatch) {
      transaction.update(docRef, { attempts: currentAttempts });
      const remaining = 5 - currentAttempts;
      throw new functions.https.HttpsError(
        "permission-denied",
        `Código incorrecto. Te quedan ${remaining} ${remaining === 1 ? 'intento' : 'intentos'}.`
      );
    }

    // Mark as verified
    const proofToken = crypto.createHmac("sha256", HMAC_SECRET)
      .update(`${phone}:${now}:${username}`)
      .digest("hex");

    transaction.update(docRef, {
      verified: true,
      verifiedAt: admin.firestore.Timestamp.now(),
      verifiedAtMs: now,
      proofToken: proofToken
    });

    return {
      success: true,
      verified: true,
      proofToken: proofToken,
      phone: phone,
      verifiedAtMs: now
    };
  });

  return verificationResult;
});


